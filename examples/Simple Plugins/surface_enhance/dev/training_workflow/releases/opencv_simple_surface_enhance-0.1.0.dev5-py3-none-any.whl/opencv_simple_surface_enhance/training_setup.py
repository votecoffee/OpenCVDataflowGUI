"""Lightweight setup validation and explicit source-observation auditing, without fitting."""

import math
from dataclasses import replace

import numpy as np

from .inputs import DARK, INPUT_CEILING, NONFINITE, OUTSIDE_ROI, LightRig, prepare_stack


def definition(reference, rows, *, black, ceiling, tolerance, fraction, support, virtual):
    """Validate only edited small definitions; do not copy/prepare the image stack."""
    if reference is None:
        raise ValueError("Import or capture an ordered reference first")
    if len(rows) != reference.reference.shape[0]:
        raise ValueError("Every retained source plane needs one ordered light definition")
    if not rows or any(len(row) != 6 or any(value is None for value in row) for row in rows):
        raise ValueError("Complete every light ID/direction/power/exposure field")
    rig = LightRig(
        tuple(row[0] for row in rows),
        [[float(v) for v in row[1:4]] for row in rows],
        [float(row[4]) for row in rows],
        [float(row[5]) for row in rows],
        reference.rig.frame,
    )
    settings = replace(
        reference.settings,
        relative_tolerance=float(tolerance),
        minimum_support_fraction=float(fraction),
        minimum_support=support,
    )
    if settings.minimum_support > len(rig.light_ids):
        raise ValueError("Minimum fit support exceeds the calibrated light count")
    black, ceiling = float(black), float(ceiling)
    if not np.isfinite([black, ceiling]).all() or not 0 <= black < ceiling <= 1:
        raise ValueError("Declare ordered normalized black level and input ceiling in 0..1")
    virtual = tuple(float(v.strip()) for v in virtual.split(","))
    if (
        len(virtual) != 3
        or not np.isfinite(virtual).all()
        or not np.isclose(np.linalg.norm(virtual), 1, atol=1e-6, rtol=0)
    ):
        raise ValueError("Declare a unit virtual light in the normal frame")
    return dict(
        rig=rig, settings=settings, black_level=black, input_ceiling=ceiling, virtual_light=virtual
    )


def audit(reference, values, mask, *, cancelled=lambda: False):
    """Count exact preparation flags; no normals, consensus, relighting or decisions."""
    if cancelled():
        raise RuntimeError("Observation audit cancelled")
    rig, settings = values["rig"], values["settings"]
    prepared = prepare_stack(
        reference.reference,
        rig,
        rig.light_ids,
        capture_id=reference.capture_id,
        pixel_grid=reference.pixel_grid,
        black_level=values["black_level"],
        input_ceiling=values["input_ceiling"],
        mask=mask,
    )
    if cancelled():
        raise RuntimeError("Observation audit cancelled")
    selected = (prepared.flags[0] & OUTSIDE_ROI) == 0
    count = int(selected.sum())
    available = prepared.valid.sum(axis=0)
    required = max(
        settings.minimum_support, math.ceil(len(rig.light_ids) * settings.minimum_support_fraction)
    )
    rows = []
    for i, name in enumerate(rig.light_ids):
        if cancelled():
            raise RuntimeError("Observation audit cancelled")
        flags = prepared.flags[i]
        rows.append(
            dict(
                index=i,
                light_id=name,
                active_pixels=count,
                available=int(prepared.valid[i].sum()),
                nonfinite=int(np.count_nonzero(selected & ((flags & NONFINITE) != 0))),
                at_or_below_black=int(np.count_nonzero(selected & ((flags & DARK) != 0))),
                at_input_ceiling=int(np.count_nonzero(selected & ((flags & INPUT_CEILING) != 0))),
                outside_roi=int(np.count_nonzero((flags & OUTSIDE_ROI) != 0)),
            )
        )
    singular = np.linalg.svd(rig.directions, compute_uv=False)
    return dict(
        schema="simple_surface_observation_audit/v1",
        capture_id=reference.capture_id,
        pixel_grid=reference.pixel_grid,
        frame=rig.frame,
        image_size=list(selected.shape[::-1]),
        active_pixels=count,
        required_available_lights=required,
        sufficient_available_pixels=int(np.count_nonzero(selected & (available >= required))),
        insufficient_available_pixels=int(np.count_nonzero(selected & (available < required))),
        exactly_three_available_pixels=int(np.count_nonzero(selected & (available == 3))),
        global_light_rank_ratio=float(singular[-1] / singular[0]),
        lights=rows,
        scope="Source availability only; no diffuse fit, local conditioning, normal/albedo "
        "accuracy, registration/synchrony or material/defect classification",
    )


def setup_summary(reference, values, mask):
    rig = values["rig"]
    h, w = reference.reference.shape[1:]
    selected = h * w if mask is None else int(mask.sum())
    return (
        f"{len(rig.light_ids)} ordered lights · {w} x {h} · {selected:,} selected source pixels\n"
        f"Frame {rig.frame}; grid {reference.pixel_grid}; reference {reference.capture_id}.\n"
        "Directions point surface → light. Camera X right, Y down, Z forward; "
        "a front-facing normal points toward -Z. Normal maps are not XYZ/height.\n"
        f"Linear codes: (source - {values['black_level']:.9g}) / (power × exposure seconds); "
        f"input ceiling {values['input_ceiling']:.9g}. Power/exposure and unit direction "
        "are separate; relative albedo is not absolute reflectance.\n"
        "Grid/capture IDs do not establish measured alignment or synchronization. "
        "Actual runtime exposures may change only with explicit matching declarations."
    )
