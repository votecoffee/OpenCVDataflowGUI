"""Exact completed lighting-stack and map evidence, independent of estimation."""

import copy
import hashlib
import json
from dataclasses import asdict, dataclass, field, is_dataclass
from functools import cached_property
from pathlib import Path
from uuid import uuid4

import cv2
import numpy as np
from opencv_dataflow.payloads import NO_VALUE

from .inputs import DARK, INPUT_CEILING, NONFINITE, OUTSIDE_ROI
from .recipe import rig_record
from .render import PALETTE, panel, scalar_rgb
from .solver import REASONS

BINDING = "surface_completed_review"
CAPTURE_FIELDS = (
    "schema",
    "images",
    "lighting",
    "capture_id",
    "pixel_grid",
    "response",
    "black_level",
    "input_ceiling",
    "mask",
)
VIEW_NAMES = (
    "source",
    "reference",
    "normals",
    "albedo",
    "relight",
    "detail",
    "residual",
    "quality",
    "support",
    "available",
    "singular_ratio",
    "fit_rms",
    "used",
    "light_residual",
    "observation_flags",
    "overview",
)


def json_bytes(value):
    return json.dumps(value, sort_keys=True, allow_nan=False).encode("utf-8")


def readonly(value):
    array = np.asarray(value)
    return np.frombuffer(array.tobytes(), dtype=array.dtype).reshape(array.shape)


def freeze(value, memo=None):
    memo = {} if memo is None else memo
    if id(value) in memo:
        return memo[id(value)]
    if isinstance(value, np.ndarray):
        result = readonly(value)
    elif is_dataclass(value):
        result = object.__new__(type(value))
        memo[id(value)] = result
        for name, item in vars(value).items():
            object.__setattr__(result, name, freeze(item, memo))
    elif isinstance(value, dict):
        result = {key: freeze(item, memo) for key, item in value.items()}
    elif isinstance(value, (list, tuple)):
        result = type(value)(freeze(item, memo) for item in value)
    else:
        result = copy.deepcopy(value)
    memo[id(value)] = result
    return result


def same(left, right):
    if isinstance(left, np.ndarray):
        return (
            isinstance(right, np.ndarray)
            and left.shape == right.shape
            and left.dtype == right.dtype
            and left.tobytes() == right.tobytes()
        )
    if isinstance(left, dict):
        return (
            isinstance(right, dict)
            and left.keys() == right.keys()
            and all(same(value, right[key]) for key, value in left.items())
        )
    if isinstance(left, (list, tuple)):
        return (
            isinstance(right, type(left))
            and len(left) == len(right)
            and all(same(a, b) for a, b in zip(left, right))
        )
    return left == right


def describe(value):
    if isinstance(value, np.ndarray):
        return dict(
            shape=list(value.shape),
            dtype=value.dtype.str,
            sha256=hashlib.sha256(value.tobytes()).hexdigest(),
        )
    if isinstance(value, dict):
        return {key: describe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [describe(item) for item in value]
    return value.item() if isinstance(value, np.generic) else value


def configuration(recipe):
    return dict(
        lighting=rig_record(recipe.rig),
        settings=asdict(recipe.settings),
        black_level=recipe.black_level,
        input_ceiling=recipe.input_ceiling,
        capture_id=recipe.capture_id,
        pixel_grid=recipe.pixel_grid,
        virtual_light=list(recipe.virtual_light),
        metadata=copy.deepcopy(recipe.metadata),
        reference=describe(recipe.reference),
        mask=describe(recipe.mask),
    )


def consumed_fields(capture):
    return {name: capture.get(name) for name in CAPTURE_FIELDS}


@dataclass(frozen=True)
class CompletedSurfaceRecord:
    identifier: str
    report_json: bytes
    parameters_json: bytes
    scalar_json: bytes
    ports: tuple
    ignored_fields: tuple
    _recipe: object = field(repr=False, compare=False)
    _capture: dict = field(repr=False, compare=False)
    _output: dict = field(repr=False, compare=False)
    _outputs: dict = field(repr=False, compare=False)
    _manifest: bytes | None = field(repr=False, compare=False)

    @property
    def report(self):
        return json.loads(self.report_json)

    @property
    def parameters(self):
        return json.loads(self.parameters_json)

    def __deepcopy__(self, memo):
        return self


def retain_completed(block, recipe, capture, output, outputs, manifest):
    if not (block.run_profile.input_previews and block.run_profile.output_previews):
        return {}
    emitted = {name: value for name, value in outputs.items() if value is not NO_VALUE}
    scalars = {
        name: value
        for name, value in emitted.items()
        if name not in ("report", "image", "overview", "maps")
    }
    record = CompletedSurfaceRecord(
        uuid4().hex,
        json_bytes(outputs["report"]),
        json_bytes(block.parameters),
        json_bytes(scalars),
        tuple(emitted),
        tuple(str(name) for name in capture if name not in CAPTURE_FIELDS),
        recipe,
        consumed_fields(capture),
        output,
        emitted,
        manifest,
    )
    block._completed_review = record
    return {name: {BINDING: {"id": record.identifier}} for name in record.ports}


class CompletedSurfaceReview:
    plugin_review_dialog_label = "Review completed surface maps…"

    def copy_runtime_from(self, other):
        super().copy_runtime_from(other)
        self._completed_review = other._completed_review

    def reset_runtime(self):
        super().reset_runtime()
        self._completed_review = None

    def close(self):
        self._completed_review = None
        super().close()

    def capture_completed_review(self, context):
        snapshot = getattr(context, "snapshot_processed_execution", None)
        if snapshot is None:
            raise ValueError("Completed review needs the host's paired execution-snapshot API")
        record = self._completed_review
        inputs = (
            ()
            if record is None or record.parameters["source"] == "capture manifest"
            else ("capture",)
        )
        try:
            bundle = snapshot(
                input_ports=inputs, output_ports=("report",) if record is None else record.ports
            )
        except ValueError as error:
            if (
                record is not None
                and not inputs
                and "Processed inputs are unavailable" in str(error)
            ):
                raise ValueError(
                    "Update the host for empty paired-input selections; this "
                    "completed manifest run consumed no wired inputs"
                ) from error
            raise
        return capture_completed(record, bundle)

    def create_plugin_review_dialog(self, parent, context):
        from .qt_completed_review import CompletedSurfaceReviewDialog

        return CompletedSurfaceReviewDialog(
            parent, context, lambda: self.capture_completed_review(context)
        )


@dataclass(frozen=True)
class CompletedSurfaceCapture:
    record: CompletedSurfaceRecord
    _provenance: dict = field(repr=False, compare=False)

    @property
    def provenance(self):
        return copy.deepcopy(self._provenance)

    @property
    def recipe_bytes(self):
        return self.record._recipe._source_bytes

    @property
    def shape(self):
        return self.record._output["maps"]["valid"].shape

    @property
    def light_count(self):
        return self.record._capture["images"].shape[0]

    @cached_property
    def _configuration(self):
        return configuration(self.record._recipe)

    @cached_property
    def _capture_description(self):
        return describe(self.record._capture)

    def light(self, index):
        if type(index) is not int or not 0 <= index < self.light_count:
            raise ValueError("Choose a recorded light index")
        return index

    def pixel(self, selected):
        if (
            not isinstance(selected, tuple)
            or len(selected) != 2
            or any(type(v) is not int for v in selected)
        ):
            raise ValueError("Choose one original (x, y) source pixel")
        x, y = selected
        if not 0 <= y < self.shape[0] or not 0 <= x < self.shape[1]:
            raise ValueError("Choose a pixel inside the recorded source grid")
        maps = self.record._output["maps"]
        values = {name: describe(value[y, x]) for name, value in maps.items() if value.ndim == 2}
        values["normals"] = maps["normals"][y, x].tolist()
        values["reason_name"] = REASONS[int(maps["reason"][y, x])]

        # Invalid native values stay NaN in arrays; JSON uses explicit null.
        def finite(value):
            if isinstance(value, list):
                return [finite(v) for v in value]
            return None if isinstance(value, float) and not np.isfinite(value) else value

        return dict(x=x, y=y, **{key: finite(value) for key, value in values.items()})

    def observations(self, selected):
        pixel = self.pixel(selected)
        x, y = selected
        prepared = self.record._output["_prepared"]
        maps = self.record._output["maps"]
        rows = []

        def number(value):
            return float(value) if np.isfinite(value) else None

        for i in range(self.light_count):
            flag = int(prepared.flags[i, y, x])
            value, residual = number(prepared.values[i, y, x]), number(maps["residual"][i, y, x])
            prediction = (
                value - residual
                if pixel["valid"] and value is not None and residual is not None
                else None
            )
            rows.append(
                dict(
                    index=i,
                    light_id=prepared.rig.light_ids[i],
                    direction=prepared.rig.directions[i].tolist(),
                    exposure_s=float(prepared.rig.exposure_s[i]),
                    relative_intensity=float(prepared.rig.relative_intensity[i]),
                    raw_code=number(self.record._capture["images"][i, y, x]),
                    prepared_value=value,
                    available=bool(prepared.valid[i, y, x]),
                    used=bool(maps["used"][i, y, x]),
                    residual=residual,
                    predicted_from_stored_residual=prediction,
                    flags=flag,
                    flag_names=[
                        name
                        for bit, name in (
                            (NONFINITE, "nonfinite"),
                            (DARK, "at_or_below_black"),
                            (INPUT_CEILING, "input_ceiling"),
                            (OUTSIDE_ROI, "outside_roi"),
                        )
                        if flag & bit
                    ],
                )
            )
        return rows

    def view(self, name, light=0, selected=None):
        self.light(light)
        if name not in VIEW_NAMES:
            raise ValueError("Choose a recorded source or map view")
        if selected is not None:
            self.pixel(selected)
        maps, output = self.record._output["maps"], self.record._output
        if name == "source":
            image, scale = scalar_rgb(self.record._capture["images"][light])
            note = f"Raw codes; display 0..{scale:.5g} (99p); cyan effective inspection ROI"
            active = (maps["reason"] != 1).astype(np.uint8)
            contours, _ = cv2.findContours(active, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
            cv2.drawContours(image, contours, -1, (30, 210, 230), 1)
        elif name == "reference":
            image, scale = scalar_rgb(self.record._recipe.reference[light])
            exposure = self.record._recipe.rig.exposure_s[light]
            note = (
                f"Training reference, {exposure:.6g} s; display 0..{scale:.5g}; not current source"
            )
        elif name == "overview":
            if "overview" in output["views"]:
                return np.array(output["views"]["overview"], copy=True), "Exact emitted overview"
            tiles = []
            for key, title in (
                ("source", "Consumed source light"),
                ("normals", "Normal direction"),
                ("albedo", "Relative albedo"),
                ("relight", "Frozen relighting"),
                ("residual", "Stored all-light RMS"),
                ("quality", "Fit validity"),
            ):
                raster, caption = self.view(key, light)
                tiles.append(panel(raster, title, caption))
            return np.vstack(
                (np.hstack(tiles[:3]), np.hstack(tiles[3:]))
            ), "Review-only frozen-map panels"
        elif name == "normals":
            image = np.rint(
                np.clip(np.nan_to_num(maps["normals"], nan=0) * 0.5 + 0.5, 0, 1) * 255
            ).astype(np.uint8)
            image[~maps["valid"]] = (70, 35, 85)
            note = "RGB=(NXYZ+1)/2; direction, not XYZ/height; purple unavailable"
        elif name == "quality":
            image, note = (
                PALETTE[maps["reason"]],
                "Categorical recorded fit reasons; not material labels",
            )
        elif name in ("used", "observation_flags"):
            values = maps[name][light]
            image = np.zeros((*self.shape, 3), np.uint8)
            if name == "used":
                image[:] = (95, 95, 95)
                image[values] = (40, 200, 80)
                image[output["_prepared"].flags[light] != 0] = (70, 35, 85)
                note = "Green used fit observation; gray excluded; purple unavailable"
            else:
                image[:] = (40, 200, 80)
                for bit, color in (
                    (DARK, (50, 55, 60)),
                    (INPUT_CEILING, (255, 175, 35)),
                    (NONFINITE, (70, 35, 85)),
                    (OUTSIDE_ROI, (115, 120, 125)),
                ):
                    image[(values & bit) != 0] = color
                note = "Flag precedence display only; exact combined bits retained per pixel"
        else:
            key = {
                "detail": "normal_change",
                "residual": "all_rms_relative",
                "fit_rms": "fit_rms_relative",
                "light_residual": "residual",
            }.get(name, name)
            values = maps[key][light] if name == "light_residual" else maps[key]
            if name == "light_residual":
                finite = np.isfinite(values)
                scale = float(np.percentile(abs(values[finite]), 99)) if finite.any() else 1.0
                scale = max(scale, 1e-12)
                unit = np.clip(np.nan_to_num(values, nan=0) / scale, -1, 1)
                image = np.repeat(np.full((*self.shape, 1), 230, np.float32), 3, axis=2)
                image[:, :, 0] -= np.maximum(-unit, 0) * 180
                image[:, :, 2] -= np.maximum(unit, 0) * 180
                image[:, :, 1] -= abs(unit) * 180
                image = image.astype(np.uint8)
                image[~finite] = (70, 35, 85)
                note = (
                    f"Signed stored residual: blue negative / red positive; display +/-{scale:.5g}"
                )
            else:
                maximum = (
                    1
                    if name in ("relight", "singular_ratio")
                    else 0.25
                    if name in ("residual", "fit_rms")
                    else None
                )
                image, scale = scalar_rgb(
                    values, maximum=maximum, heat=name in ("detail", "residual", "fit_rms")
                )
                note = f"Stored {key}; display 0..{scale:.5g}; purple nonfinite"
        image = np.array(image, copy=True)
        if selected is not None:
            cv2.drawMarker(image, selected, (250, 220, 40), cv2.MARKER_CROSS, 13, 1)
        return image, note

    def chart(self, selected):
        rows = self.observations(selected)
        image = np.full((380, 920, 3), 245, np.uint8)
        values = [
            r[key]
            for r in rows
            for key in ("prepared_value", "predicted_from_stored_residual")
            if r[key] is not None
        ]
        low, high = min([0] + values), max([1e-9] + values)
        span = max(high - low, 1e-9)

        def y(value):
            return round(285 - (value - low) / span * 220)

        cv2.putText(
            image,
            "Recorded prepared observations and observed - stored residual",
            (15, 24),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (30, 30, 30),
            1,
            cv2.LINE_AA,
        )
        for r in rows:
            x = round(60 + (r["index"] + 0.5) * 830 / len(rows))
            if r["prepared_value"] is None:
                cv2.drawMarker(image, (x, 295), (100, 40, 140), cv2.MARKER_TILTED_CROSS, 7, 1)
            else:
                color = (40, 170, 70) if r["used"] else (230, 135, 30)
                cv2.line(image, (x, y(0)), (x, y(r["prepared_value"])), color, 3)
            if r["predicted_from_stored_residual"] is not None:
                cv2.circle(image, (x, y(r["predicted_from_stored_residual"])), 4, (40, 100, 230), 1)
            if len(rows) <= 24:
                cv2.putText(
                    image,
                    str(r["index"]),
                    (x - 6, 316),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.35,
                    (30, 30, 30),
                    1,
                    cv2.LINE_AA,
                )
        cv2.putText(
            image,
            f"Relative irradiance display {low:.5g}..{high:.5g}; light indices; no refit",
            (15, 346),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.44,
            (30, 30, 30),
            1,
            cv2.LINE_AA,
        )
        cv2.putText(
            image,
            "Green used / orange excluded / purple unavailable / blue derived prediction",
            (15, 368),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.44,
            (30, 30, 30),
            1,
            cv2.LINE_AA,
        )
        return image

    def report(self, selected=None, light=0, view="normals"):
        self.light(light)
        return dict(
            schema="simple_surface_completed_review/v1",
            execution_binding=self.record.identifier,
            completed_result=self.record.report,
            executed_parameters=self.record.parameters,
            executed_configuration=copy.deepcopy(self._configuration),
            consumed_capture=copy.deepcopy(self._capture_description),
            ignored_capture_fields=list(self.record.ignored_fields),
            selected_pixel=None if selected is None else self.pixel(selected),
            selected_observations=[] if selected is None else self.observations(selected),
            selected_light=light,
            selected_view=view,
            provenance=self.provenance,
            emitted_overview="overview" in self.record.ports,
            emitted_views=list(self.record._output["views"]),
            display_ranges=copy.deepcopy(self.record._output["display"]),
            manifest_sha256=None
            if self.record._manifest is None
            else hashlib.sha256(self.record._manifest).hexdigest(),
            geometry_scope=(
                "Estimated normal directions and relative albedo, not measured XYZ or metric height"
            ),
            prediction_scope=(
                "Display prediction is observation minus stored residual for accepted fits only"
            ),
            source_scope=(
                "Actual normalized native capture codes retained; "
                "original encoded source-image bytes unavailable"
            ),
            identity_scope=(
                "Caller-declared capture/grid/calibration/tickets do not prove "
                "registration or synchrony"
            ),
            preparation_reexecuted=False,
            estimation_reexecuted=False,
            calibration_changed=False,
            capture_reloaded=False,
            recipe_reloaded=False,
            training_changed=False,
        )

    def export(self, directory, selected=None, light=0, view="normals"):
        document = self.report(selected, light, view)
        chosen, note = self.view(view, light, selected)
        if self.recipe_bytes is None:
            raise ValueError("Original executed recipe bytes are unavailable")
        target = Path(directory)
        target.mkdir(parents=True, exist_ok=False)
        (target / "executed_recipe.sse").write_bytes(self.recipe_bytes)
        document["exported_recipe_sha256"] = hashlib.sha256(self.recipe_bytes).hexdigest()
        if self.record._manifest is not None:
            (target / "consumed_manifest.json").write_bytes(self.record._manifest)
        capture, prepared = self.record._capture, self.record._output["_prepared"]
        np.save(target / "capture_images.npy", capture["images"], allow_pickle=False)
        if capture["mask"] is not None:
            np.save(target / "capture_mask.npy", capture["mask"], allow_pickle=False)
        for name in ("values", "valid", "flags"):
            np.save(target / f"prepared_{name}.npy", getattr(prepared, name), allow_pickle=False)
        for name, value in self.record._output["maps"].items():
            np.save(target / f"map_{name}.npy", value, allow_pickle=False)
        for name, value in self.record._output["views"].items():
            np.save(target / f"emitted_{name}.npy", value, allow_pickle=False)

        # Export array-bearing declarations without float32 re-import or mask-label loss.
        def native(value):
            if isinstance(value, np.ndarray):
                if value is capture["images"]:
                    name = "capture_images.npy"
                elif value is capture["mask"]:
                    name = "capture_mask.npy"
                else:
                    name = f"capture_declaration_{len(declarations):03d}.npy"
                    np.save(target / name, value, allow_pickle=False)
                    declarations.append(name)
                return dict(array_file=name, **describe(value))
            if isinstance(value, dict):
                return {key: native(item) for key, item in value.items()}
            if isinstance(value, (list, tuple)):
                return [native(item) for item in value]
            return describe(value)

        declarations = []
        (target / "capture_data.json").write_bytes(
            json.dumps(native(capture), indent=2, allow_nan=False).encode() + b"\n"
        )
        image_views = {
            "selected_view": chosen,
            "source": self.view("source", light, selected)[0],
            "reference": self.view("reference", light, selected)[0],
            "overview": self.view("overview", light)[0],
        }
        if selected is not None:
            image_views["observations"] = self.chart(selected)
        for name, image in image_views.items():
            okay, png = cv2.imencode(".png", image[:, :, ::-1])
            if not okay:
                raise ValueError("Could not encode frozen surface review")
            (target / f"{name}.png").write_bytes(png.tobytes())
        assessment = np.hstack(
            (
                panel(
                    image_views["source"],
                    "Consumed source",
                    note="Actual selected light / display only",
                ),
                panel(chosen, view, note=note),
                panel(
                    self.view("quality")[0],
                    "Recorded fit reason",
                    note="No refit or acceptance change",
                ),
            )
        )
        banner = np.full((54, assessment.shape[1], 3), 28, np.uint8)
        report = self.record.report
        pixel = None if selected is None else self.pixel(selected)
        title = (
            f"Completed surface fit | capture {report['capture_id']} | "
            f"{report['coverage']:.1%} available | light {light} | "
            f"pixel {selected}: {pixel['reason_name'] if pixel else 'overview'}"
        )
        cv2.putText(
            banner,
            title.encode("ascii", errors="replace").decode("ascii")[:180],
            (10, 24),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (240, 240, 240),
            1,
            cv2.LINE_AA,
        )
        cv2.putText(
            banner,
            "Estimated directions / relative albedo, not measured XYZ or metric height",
            (10, 45),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.44,
            (220, 220, 220),
            1,
            cv2.LINE_AA,
        )
        legend = np.full((48, assessment.shape[1], 3), 28, np.uint8)
        for i, reason in enumerate(REASONS):
            x, y = 10 + (i % 5) * 274, 5 + (i // 5) * 22
            cv2.rectangle(legend, (x, y), (x + 11, y + 11), PALETTE[i].tolist(), -1)
            cv2.putText(
                legend,
                reason.replace("_", " "),
                (x + 17, y + 10),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.37,
                (235, 235, 235),
                1,
                cv2.LINE_AA,
            )
        assessment = np.vstack((banner, assessment, legend))
        okay, png = cv2.imencode(".png", assessment[:, :, ::-1])
        if not okay:
            raise ValueError("Could not encode assessment")
        (target / "assessment.png").write_bytes(png.tobytes())
        (target / "review.json").write_bytes(
            json.dumps(document, indent=2, allow_nan=False).encode() + b"\n"
        )
        return target


def capture_completed(record, bundle):
    if record is None:
        raise ValueError("No retained completed surface fit; execute in Debug before reviewing")
    if set(bundle.outputs) != set(record.ports) or any(
        bundle.outputs[name].payload.get(BINDING, {}).get("id") != record.identifier
        for name in record.ports
    ):
        raise ValueError("Completed capture/model/result changed; capture latest explicitly")
    if json_bytes(bundle.outputs["report"].value) != record.report_json:
        raise ValueError("Completed report changed")
    scalars = {
        name: packet.value
        for name, packet in bundle.outputs.items()
        if name not in ("report", "image", "overview", "maps")
    }
    if json_bytes(scalars) != record.scalar_json:
        raise ValueError("Completed coverage/count changed")
    for name in ("image", "maps", "overview"):
        if name in record.ports and not same(record._outputs[name], bundle.outputs[name].value):
            raise ValueError("Completed raw map/image evidence changed")
    if record.parameters["source"] == "connected capture":
        if not same(record._capture, consumed_fields(bundle.inputs["capture"].value)):
            raise ValueError("Completed connected capture changed")
    provenance = dict(
        snapshot_id=bundle.snapshot_id,
        block_id=bundle.block_id,
        execution_count=bundle.execution_count,
        output_revision=bundle.output_revision,
        passed=bool(bundle.passed),
        score=bundle.score,
        message=bundle.message,
        inputs={name: copy.deepcopy(packet.payload) for name, packet in bundle.inputs.items()},
        outputs={name: copy.deepcopy(packet.payload) for name, packet in bundle.outputs.items()},
    )
    return CompletedSurfaceCapture(freeze(record), provenance)
