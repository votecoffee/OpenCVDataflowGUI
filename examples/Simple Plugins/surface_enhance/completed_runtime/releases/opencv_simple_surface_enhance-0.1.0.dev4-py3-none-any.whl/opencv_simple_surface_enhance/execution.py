"""One reusable compiled estimator, explicit capture contract and numerical/result views."""

import numpy as np

from .inputs import LightRig, prepare_stack
from .recipe import SurfaceRecipe, rig_record
from .solver import SurfaceEstimator, relight


def retain_capture(capture, *, metadata=None):
    if (
        not isinstance(capture, dict)
        or capture.get("schema") != "simple_surface_stack/v1"
        or (capture.get("response") != "linear")
    ):
        raise ValueError("Retain a simple_surface_stack/v1 capture with explicit linear response")
    return SurfaceRecipe(
        LightRig(**capture["lighting"]),
        capture["images"],
        mask=capture.get("mask"),
        capture_id=capture["capture_id"],
        pixel_grid=capture["pixel_grid"],
        black_level=capture["black_level"],
        input_ceiling=capture["input_ceiling"],
        metadata=metadata or {},
    )


def capture_from_recipe(recipe):
    return dict(
        schema="simple_surface_stack/v1",
        images=recipe.reference,
        lighting=rig_record(recipe.rig),
        capture_id=recipe.capture_id,
        pixel_grid=recipe.pixel_grid,
        response="linear",
        black_level=recipe.black_level,
        input_ceiling=recipe.input_ceiling,
        mask=recipe.mask,
    )


def prepare_capture(recipe, capture):
    if (
        not isinstance(recipe, SurfaceRecipe)
        or not isinstance(capture, dict)
        or (capture.get("schema") != "simple_surface_stack/v1")
    ):
        raise ValueError("Provide a retained surface recipe and simple_surface_stack/v1 capture")
    actual = LightRig(**capture["lighting"])
    if (
        actual.light_ids != recipe.rig.light_ids
        or actual.frame != recipe.rig.frame
        or not np.array_equal(actual.directions, recipe.rig.directions)
        or not np.array_equal(actual.relative_intensity, recipe.rig.relative_intensity)
    ):
        raise ValueError("Capture light order, directions, power calibration and frame must match")
    if capture["pixel_grid"] != recipe.pixel_grid or (
        np.asarray(capture["images"]).shape != recipe.reference.shape
    ):
        raise ValueError(
            "Capture dimensions and source pixel grid must match the retained reference"
        )
    if capture.get("response") != "linear" or (
        capture.get("black_level") != recipe.black_level
        or capture.get("input_ceiling") != recipe.input_ceiling
    ):
        raise ValueError(
            "Capture linear response, black level and code ceiling must match training"
        )
    mask = capture.get("mask")
    if mask is not None:
        mask = np.asarray(mask)
        if mask.shape != recipe.reference.shape[1:] or mask.dtype.kind not in "bui":
            raise ValueError("Capture ROI must match source pixels")
        if np.any(mask < 0):
            raise ValueError("Capture ROI must be nonnegative")
        mask = mask != 0
    if recipe.mask is not None:
        mask = recipe.mask if mask is None else mask & recipe.mask
    return prepare_stack(
        capture["images"],
        actual,
        actual.light_ids,
        capture_id=capture["capture_id"],
        pixel_grid=capture["pixel_grid"],
        response=capture["response"],
        black_level=recipe.black_level,
        input_ceiling=recipe.input_ceiling,
        mask=mask,
    )


def execute(
    recipe,
    capture=None,
    *,
    estimator=None,
    graphics=True,
    cancelled=lambda: False,
    retain_prepared=False,
):
    from .render import normal_change, render_views

    capture = capture_from_recipe(recipe) if capture is None else capture
    stack = prepare_capture(recipe, capture)
    if estimator is None:
        estimator = SurfaceEstimator(recipe.rig, recipe.settings)
    if estimator.settings != recipe.settings:
        raise ValueError("Compiled estimator settings differ from the retained recipe")
    result = estimator.estimate(stack, cancelled=cancelled)
    maps = {
        name: getattr(result, name)
        for name in (
            "normals",
            "albedo",
            "valid",
            "reason",
            "support",
            "available",
            "singular_ratio",
            "fit_rms_relative",
            "all_rms_relative",
            "used",
            "residual",
        )
    }
    maps.update(
        relight=relight(result, recipe.virtual_light),
        normal_change=normal_change(result),
        observation_flags=stack.flags,
    )
    report = dict(result.report)
    report["radiometry"] = dict(
        response="linear",
        black_level=recipe.black_level,
        input_ceiling=recipe.input_ceiling,
        lighting=rig_record(stack.rig),
    )
    report["reference_capture_id"] = recipe.capture_id
    report["registration_scope"] = (
        "Caller-declared source grid; not measured registration/synchrony"
    )
    views, display = (
        render_views(result, capture["images"][0], virtual_light=recipe.virtual_light)
        if graphics
        else ({}, {})
    )
    output = dict(
        result=result,
        maps=maps,
        report=report,
        views=views,
        display=display,
        source=capture["images"][0],
    )
    if retain_prepared:
        output["_prepared"] = stack
    return output
