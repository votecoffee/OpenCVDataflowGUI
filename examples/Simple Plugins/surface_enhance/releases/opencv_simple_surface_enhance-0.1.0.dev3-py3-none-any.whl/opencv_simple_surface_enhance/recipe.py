"""Sealed light-stack recipes retaining source codes, calibration, mask and settings."""

import hashlib
import io
import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from tempfile import NamedTemporaryFile
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np

from .cli import load_plane, strict_json
from .inputs import LightRig, frozen, prepare_stack
from .solver import SurfaceSettings

LIMIT = 160 * 1024 * 1024


def rig_record(rig):
    return dict(
        light_ids=list(rig.light_ids),
        directions=rig.directions.tolist(),
        relative_intensity=rig.relative_intensity.tolist(),
        exposure_s=rig.exposure_s.tolist(),
        frame=rig.frame,
    )


@dataclass(frozen=True)
class SurfaceRecipe:
    rig: LightRig
    reference: np.ndarray = field(repr=False)
    settings: SurfaceSettings = field(default_factory=SurfaceSettings)
    mask: np.ndarray | None = field(default=None, repr=False)
    black_level: float = 0.0
    input_ceiling: float = 1.0
    capture_id: str = "reference"
    pixel_grid: str = "camera_original"
    virtual_light: tuple = (0.6, 0.0, -0.8)
    metadata: dict = field(default_factory=dict)

    def __post_init__(self):
        if not isinstance(self.settings, SurfaceSettings):
            raise ValueError("Retain validated surface fit settings")
        raw = np.asarray(self.reference)
        if raw.dtype.str not in ("<f4", "<f8") or raw.nbytes > LIMIT - 8 * 1024 * 1024:
            raise ValueError("Retain bounded normalized float32/float64 source codes")
        prepare_stack(
            raw,
            self.rig,
            self.rig.light_ids,
            capture_id=self.capture_id,
            pixel_grid=self.pixel_grid,
            black_level=self.black_level,
            input_ceiling=self.input_ceiling,
            mask=self.mask,
        )
        if self.settings.minimum_support > len(self.rig.light_ids):
            raise ValueError("Minimum fit support exceeds the calibrated light count")
        if self.mask is not None and not np.any(self.mask):
            raise ValueError("Select a nonempty source-pixel inspection region")
        virtual = np.asarray(self.virtual_light, np.float64)
        if (
            virtual.shape != (3,)
            or not np.isfinite(virtual).all()
            or not np.isclose(np.linalg.norm(virtual), 1, atol=1e-6, rtol=0)
        ):
            raise ValueError("Declare a unit virtual light in the normal frame")
        if not isinstance(self.metadata, dict):
            raise ValueError("Retain plain JSON reference/calibration provenance")
        metadata = json.dumps(self.metadata, allow_nan=False).encode()
        if len(metadata) > 1024 * 1024:
            raise ValueError("Reference metadata exceeds 1 MiB")
        object.__setattr__(self, "reference", frozen(raw, raw.dtype))
        object.__setattr__(
            self, "mask", None if self.mask is None else frozen(np.asarray(self.mask) != 0, bool)
        )
        object.__setattr__(self, "virtual_light", tuple(float(v) for v in virtual))
        object.__setattr__(self, "metadata", strict_json(metadata))


def import_capture(path):
    """Import declared radiometry; never infer gamma or normalize lights independently."""
    path = Path(path)
    if path.stat().st_size > 2 * 1024 * 1024:
        raise ValueError("Capture manifest exceeds 2 MiB")
    data = strict_json(path.read_bytes())
    if data.get("schema") != "simple_surface_capture/v1" or data.get("response") != "linear":
        raise ValueError(
            "Import a simple_surface_capture/v1 manifest with explicit linear response"
        )
    entries = data.get("lights")
    if not isinstance(entries, list) or not 3 <= len(entries) <= 128:
        raise ValueError("Declare 3..128 calibrated light/image entries")
    rig = LightRig(
        tuple(row["id"] for row in entries),
        [row["direction"] for row in entries],
        [row["relative_intensity"] for row in entries],
        [row["exposure_s"] for row in entries],
        data.get("frame", "camera"),
    )
    scale = data.get("input_scale")
    if type(scale) not in (int, float) or not np.isfinite(scale) or scale <= 0:
        raise ValueError("Declare a positive source-code input_scale; normalized floats use 1")
    planes, shape = [], None
    for row in entries:
        image = load_plane(path.parent / row["image"], data.get("channel", "gray"))
        if shape is None:
            shape = image.shape
            if image.size * len(entries) > 16_000_000:
                raise ValueError("Capture stack exceeds 16 million observations")
        elif image.shape != shape:
            raise ValueError("All lights must use the same registered image dimensions")
        planes.append(image.astype(np.float32) / scale)
    mask = load_plane(path.parent / data["mask"]) if data.get("mask") else None
    return SurfaceRecipe(
        rig,
        np.stack(planes),
        SurfaceSettings(**data.get("settings", {})),
        mask,
        data.get("black_level", 0),
        data.get("input_ceiling", 1),
        data["capture_id"],
        data["pixel_grid"],
        tuple(data.get("virtual_light", (0.6, 0, -0.8))),
        metadata=dict(
            manifest_name=path.name,
            input_scale=scale,
            channel=data.get("channel", "gray"),
            response="linear",
        ),
    )


def array_bytes(value):
    stream = io.BytesIO()
    np.save(stream, value, allow_pickle=False)
    return stream.getvalue()


def read_array(raw, *, stack):
    stream = io.BytesIO(raw)
    version = np.lib.format.read_magic(stream)
    if version not in ((1, 0), (2, 0)):
        raise ValueError("Use numeric NPY v1/v2 arrays")
    reader = (
        np.lib.format.read_array_header_1_0
        if version == (1, 0)
        else (np.lib.format.read_array_header_2_0)
    )
    shape, _, dtype = reader(stream)
    if (
        len(shape) != (3 if stack else 2)
        or min(shape) < 2
        or max(shape[-2:]) > 16384
        or np.prod(shape) > 16_000_000
        or (stack and not 3 <= shape[0] <= 128)
        or dtype.str not in (("<f4", "<f8") if stack else ("|b1",))
        or int(np.prod(shape)) * dtype.itemsize != len(raw) - stream.tell()
    ):
        raise ValueError("Invalid bounded retained stack/mask header")
    return np.load(io.BytesIO(raw), allow_pickle=False)


def save_recipe(path, recipe):
    if not isinstance(recipe, SurfaceRecipe):
        raise ValueError("Save a validated surface reference recipe")
    path = Path(path)
    if path.suffix != ".sse":
        raise ValueError("Use a .sse surface recipe filename")
    if path.exists():
        raise FileExistsError("Preserve the existing recipe; choose a new filename")
    entries = {"reference.npy": array_bytes(recipe.reference)}
    if recipe.mask is not None:
        entries["mask.npy"] = array_bytes(recipe.mask)
    document = dict(
        schema="simple_surface_recipe/v1",
        lighting=rig_record(recipe.rig),
        settings=asdict(recipe.settings),
        black_level=recipe.black_level,
        input_ceiling=recipe.input_ceiling,
        capture_id=recipe.capture_id,
        pixel_grid=recipe.pixel_grid,
        virtual_light=list(recipe.virtual_light),
        metadata=recipe.metadata,
        response="linear",
        sha256={name: hashlib.sha256(body).hexdigest() for name, body in entries.items()},
    )
    entries["recipe.json"] = (json.dumps(document, indent=2, allow_nan=False) + "\n").encode()
    if sum(map(len, entries.values())) > LIMIT:
        raise ValueError("Retained recipe expansion exceeds 160 MiB")
    with NamedTemporaryFile(dir=path.parent, prefix="." + path.name, delete=False) as stream:
        temporary = Path(stream.name)
    try:
        with ZipFile(temporary, "w", compression=ZIP_DEFLATED) as archive:
            for name, body in entries.items():
                archive.writestr(name, body)
        if temporary.stat().st_size > LIMIT:
            raise ValueError("Retained recipe exceeds 160 MiB")
        os.link(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_recipe(path, *, sha256=None):
    path = Path(path)
    if path.stat().st_size > LIMIT:
        raise ValueError("Retained recipe exceeds 160 MiB")
    raw = path.read_bytes()
    if len(raw) > LIMIT or (sha256 is not None and hashlib.sha256(raw).hexdigest() != sha256):
        raise ValueError("Recipe archive checksum/size differs")
    with ZipFile(io.BytesIO(raw)) as archive:
        infos = archive.infolist()
        names = [i.filename for i in infos]
        if (
            set(names) - {"recipe.json", "reference.npy", "mask.npy"}
            or not {"recipe.json", "reference.npy"} <= set(names)
            or len(names) != len(set(names))
            or any(i.flag_bits & 1 for i in infos)
            or sum(i.file_size for i in infos) > LIMIT
            or archive.getinfo("recipe.json").file_size > 2 * 1024 * 1024
        ):
            raise ValueError("Invalid bounded surface recipe members")
        document = strict_json(archive.read("recipe.json"))
        if document.get("schema") != "simple_surface_recipe/v1" or (
            document.get("response") != "linear"
        ):
            raise ValueError("Unsupported surface recipe schema/response")
        if set(document["sha256"]) != set(names) - {"recipe.json"}:
            raise ValueError("Retained array manifest differs")
        arrays = {}
        for name in names:
            if name == "recipe.json":
                continue
            body = archive.read(name)
            if hashlib.sha256(body).hexdigest() != document["sha256"][name]:
                raise ValueError("Retained array checksum differs")
            arrays[name[:-4]] = read_array(body, stack=name == "reference.npy")
    return SurfaceRecipe(
        LightRig(**document["lighting"]),
        settings=SurfaceSettings(**document["settings"]),
        **{
            key: document[key]
            for key in (
                "black_level",
                "input_ceiling",
                "capture_id",
                "pixel_grid",
                "virtual_light",
                "metadata",
            )
        },
        **arrays,
    )
