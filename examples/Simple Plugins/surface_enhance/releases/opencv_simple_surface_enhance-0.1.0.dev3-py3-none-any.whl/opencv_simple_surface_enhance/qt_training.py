"""Retained lighting/reference editor, frozen worker previews and draft-only staging."""

import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from pathlib import Path
from threading import Event

import cv2
import numpy as np
from opencv_dataflow.canvas import pixmap
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from opencv_dataflow.images import ImageArray
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from .dataflow import recipe_path
from .execution import capture_from_recipe, execute, retain_capture
from .inputs import LightRig
from .qt_region import SurfaceRegionView
from .recipe import import_capture, load_recipe, save_recipe
from .render import scalar_rgb


def rectangle(mask, shape):
    if mask is None:
        return (0, 0, shape[1], shape[0])
    y, x = np.nonzero(mask)
    if not len(x):
        return None
    left, right, top, bottom = int(x.min()), int(x.max()) + 1, int(y.min()), int(y.max()) + 1
    return (
        (left, top, right - left, bottom - top)
        if mask.sum() == (right - left) * (bottom - top)
        else None
    )


class SurfaceTrainingDialog(QDialog):
    def __init__(self, parent, parameters, context):
        super().__init__(parent)
        self.setWindowTitle("SimpleSurfaceEnhance · lighting and reference")
        self.resize(1320, 880)
        self.parameters, self.context = parameters, context
        self.reference = self.candidate = self.reference_result = self.last_result = None
        self.mask = None
        self.revision = 0
        self.closed = self.restoring = False
        self.pending = None
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="surface-teaching")
        self.unsubscribe = None
        layout = QVBoxLayout(self)
        self.status = QLabel(
            "1. Import an ordered light capture. 2. Review lighting/region. "
            "3. Preview the reference, then Stage."
        )
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        row = QHBoxLayout()
        for title, action in (
            ("Import reference capture…", self.import_reference),
            ("Capture connected reference", self.capture_reference),
            ("Import recipe…", self.import_recipe),
        ):
            self.button(row, title, action)
        layout.addLayout(row)
        split = QSplitter(Qt.Orientation.Horizontal)
        layout.addWidget(split, 1)
        side = QWidget()
        controls = QVBoxLayout(side)
        self.identity = QLabel("No retained light stack")
        self.identity.setWordWrap(True)
        controls.addWidget(self.identity)
        self.source_light = QComboBox()
        self.source_light.currentIndexChanged.connect(self.show_source)
        controls.addWidget(QLabel("Reference light to inspect"))
        controls.addWidget(self.source_light)
        self.lights = QTableWidget(0, 6)
        self.lights.setHorizontalHeaderLabels(["Light ID", "X", "Y", "Z", "Power", "Seconds"])
        self.lights.setMinimumHeight(205)
        self.lights.setToolTip(
            "Unit direction from surface toward light; known calibration only. "
            "Power and actual exposure seconds are separate."
        )
        self.lights.cellChanged.connect(lambda *_: self.invalidate())
        controls.addWidget(self.lights)
        form = QFormLayout()
        self.black = QLineEdit("0")
        self.ceiling = QLineEdit("1")
        self.tolerance = QLineEdit("0.06")
        self.fraction = QLineEdit("0.5")
        self.support = QSpinBox()
        self.support.setRange(3, 128)
        self.support.setValue(3)
        self.virtual = QLineEdit("0.6, 0, -0.8")
        for label, field in (
            ("Black level (0..1)", self.black),
            ("Input ceiling (0..1)", self.ceiling),
            ("Relative fit tolerance (0..1)", self.tolerance),
            ("Minimum light fraction (0..1)", self.fraction),
            ("Minimum supporting lights", self.support),
            ("Unit virtual light X, Y, Z", self.virtual),
        ):
            form.addRow(label, field)
            signal = field.valueChanged if isinstance(field, QSpinBox) else field.textChanged
            signal.connect(lambda *_: self.invalidate())
        controls.addLayout(form)
        for title, action in (
            ("Import inspection mask…", self.import_mask),
            ("Use full source region", lambda: self.set_mask(None)),
            ("Draw inspection rectangle", lambda: self.region_mode("draw")),
            ("Move / resize rectangle", lambda: self.region_mode("edit")),
            ("Pan image", lambda: self.region_mode("pan")),
        ):
            self.button(controls, title, action)
        self.preview_button = self.button(controls, "Preview reference fit", self.preview_reference)
        self.test_button = self.button(controls, "Preview another capture…", self.preview_file)
        self.wire_button = self.button(
            controls, "Preview connected capture", self.preview_connected
        )
        self.health = QLabel(
            "Fit coverage, rejected observations and missing evidence appear here."
        )
        self.health.setWordWrap(True)
        controls.addWidget(self.health)
        controls.addStretch()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(side)
        split.addWidget(scroll)
        self.tabs = QTabWidget()
        self.editor = SurfaceRegionView(self.tabs)
        self.views = {}
        self.add_view(self.editor, "Retained source / region")
        for name, title in (
            ("overview", "Fit overview"),
            ("normals", "Normals"),
            ("albedo", "Albedo"),
            ("relight", "Virtual light"),
            ("quality", "Availability"),
            ("residual", "Fit residual"),
            ("detail", "Normal detail"),
        ):
            view = FilmstripImageView(self.tabs)
            self.views[name] = view
            self.add_view(view, title)
        self.editor.region_changed.connect(lambda roi: self.safe(lambda: self.set_region(roi)))
        split.addWidget(self.tabs)
        split.setSizes([450, 870])
        hint = QLabel(
            "Source images must share a fixed pixel grid and linear camera response. "
            "Directions/power come from a known lighting setup, not automatic image calibration. "
            "Scroll to zoom; Pan moves the view. Imported masks stay exact until replaced. "
            "Independent previews never replace training. Stage edits the inspector draft; "
            "Apply configuration commits it. Normals are not metric XYZ/height."
        )
        hint.setWordWrap(True)
        layout.addWidget(hint)
        row = QHBoxLayout()
        self.stage_button = self.button(row, "Stage recipe", self.stage)
        self.button(row, "Cancel", self.reject)
        layout.addLayout(row)
        self.timer = QTimer(self)
        self.timer.setInterval(40)
        self.timer.timeout.connect(self.poll)
        if hasattr(context, "subscribe_outputs"):
            self.unsubscribe = context.subscribe_outputs(self.outputs_changed)
        if parameters.get("recipe_path"):
            self.safe(
                lambda: self.restore(
                    load_recipe(
                        recipe_path(context.project_dir, parameters["recipe_path"]),
                        sha256=parameters["sha256"],
                    ),
                    preview=True,
                )
            )
        self.refresh()
        self.finished.connect(lambda *_: self.shutdown())

    def button(self, layout, title, action):
        button = QPushButton(title)
        button.setAutoDefault(False)
        button.clicked.connect(lambda checked=False: self.safe(action))
        layout.addWidget(button)
        return button

    def add_view(self, view, title):
        page = QWidget()
        box = QVBoxLayout(page)
        box.addWidget(view, 1)
        zoom = QHBoxLayout()
        for label, action in (
            ("−", lambda: view.zoom(0.8)),
            ("+", lambda: view.zoom(1.25)),
            ("Fit", view.fit_image),
            ("100%", view.actual_size),
        ):
            self.button(zoom, label, action)
        box.addLayout(zoom)
        self.tabs.addTab(page, title)

    def safe(self, action):
        try:
            action()
        except Exception as error:
            self.status.setText(str(error))

    def choose(self, title, pattern):
        path, _ = QFileDialog.getOpenFileName(self, title, "", pattern)
        return Path(path) if path else None

    def restore(self, recipe, *, preview=False):
        self.restoring = True
        try:
            self.reference, self.mask = recipe, recipe.mask
            self.source_light.clear()
            self.source_light.addItems(recipe.rig.light_ids)
            self.lights.setRowCount(len(recipe.rig.light_ids))
            for row, identifier in enumerate(recipe.rig.light_ids):
                values = [
                    identifier,
                    *recipe.rig.directions[row],
                    recipe.rig.relative_intensity[row],
                    recipe.rig.exposure_s[row],
                ]
                for column, value in enumerate(values):
                    text = value if isinstance(value, str) else repr(float(value))
                    self.lights.setItem(row, column, QTableWidgetItem(text))
            self.lights.resizeColumnsToContents()
            for field, value in (
                (self.black, recipe.black_level),
                (self.ceiling, recipe.input_ceiling),
                (self.tolerance, recipe.settings.relative_tolerance),
                (self.fraction, recipe.settings.minimum_support_fraction),
            ):
                field.setText(repr(float(value)))
            self.support.setValue(recipe.settings.minimum_support)
            self.virtual.setText(", ".join(repr(v) for v in recipe.virtual_light))
            self.identity.setText(
                f"Retained {len(recipe.rig.light_ids)} lights · "
                f"{recipe.reference.shape[2]} × {recipe.reference.shape[1]}\n"
                f"Frame: {recipe.rig.frame} · grid: {recipe.pixel_grid}\n"
                f"Reference: {recipe.capture_id} · normalized {recipe.reference.dtype}"
            )
        finally:
            self.restoring = False
        self.invalidate()
        self.show_source()
        self.status.setText(
            "Original light images/calibration retained. Review, then preview the fit."
        )
        if preview:
            self.preview_reference()

    def invalidate(self):
        if self.restoring or self.closed:
            return
        self.revision += 1
        self.candidate = self.reference_result = self.last_result = None
        if self.pending:
            self.pending[1].set()
            self.pending[0].cancel()
        for view in self.views.values():
            view.image_item.setPixmap(QPixmap())
        self.health.setText("Draft changed. Preview the reference fit again before Stage.")
        self.refresh()

    def show_source(self, *_):
        if self.reference is None or self.restoring:
            return
        index = max(0, self.source_light.currentIndex())
        rgb, _ = scalar_rgb(self.reference.reference[index])
        if self.mask is not None:
            contours, _ = cv2.findContours(
                self.mask.astype(np.uint8), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE
            )
            cv2.drawContours(rgb, contours, -1, (30, 210, 230), 1)
        self.editor.set_image(pixmap(ImageArray(rgb, "rgb")))
        self.editor.set_roi(rectangle(self.mask, rgb.shape))

    def import_reference(self):
        path = self.choose("Ordered reference capture", "Surface capture (*.json)")
        if path:
            self.restore(import_capture(path))

    def import_recipe(self):
        path = self.choose("Retained surface recipe", "Surface recipes (*.sse)")
        if path:
            self.restore(load_recipe(path), preview=True)

    def connected(self):
        self.context.refresh_images()
        bundle = self.context.snapshot_connected_inputs(["capture"])
        if "capture" not in bundle.inputs:
            raise ValueError("Connect an illumination capture data bundle first")
        return bundle.inputs["capture"].value, self.context.output_revision, bundle.snapshot_id

    def capture_reference(self):
        capture, _, identity = self.connected()
        self.restore(
            retain_capture(
                capture,
                metadata={
                    "source": "connected capture",
                    "snapshot_id": identity,
                    "identity_scope": "Editor copy provenance; no physical synchronization claim",
                },
            )
        )

    def region_mode(self, mode):
        self.editor.mode = mode
        self.tabs.setCurrentIndex(0)

    def set_region(self, roi):
        if self.reference is None:
            raise ValueError("Import or capture a reference first")
        x, y, width, height = roi
        h, w = self.reference.reference.shape[1:]
        if (
            any(type(v) is not int for v in roi)
            or min(x, y) < 0
            or min(width, height) < 1
            or (x + width > w or y + height > h)
        ):
            raise ValueError("Keep a positive inspection rectangle inside source pixels")
        mask = np.zeros((h, w), bool)
        mask[y : y + height, x : x + width] = True
        self.set_mask(mask)

    def set_mask(self, mask):
        if self.reference is None:
            raise ValueError("Import or capture a reference first")
        # Validate/copy with the same contract used by retained execution.
        self.mask = replace(self.reference, mask=mask).mask
        self.invalidate()
        self.show_source()

    def import_mask(self):
        from .cli import load_plane

        path = self.choose("Source-aligned inspection mask", "Mask (*.png *.tif *.tiff *.npy)")
        if path:
            self.set_mask(load_plane(path))

    def build_candidate(self):
        if self.reference is None:
            raise ValueError("Import or capture a reference first")
        rows = [
            [self.lights.item(r, c).text() for c in range(6)] for r in range(self.lights.rowCount())
        ]
        rig = LightRig(
            tuple(row[0] for row in rows),
            [[float(v) for v in row[1:4]] for row in rows],
            [float(row[4]) for row in rows],
            [float(row[5]) for row in rows],
            self.reference.rig.frame,
        )
        settings = replace(
            self.reference.settings,
            relative_tolerance=float(self.tolerance.text()),
            minimum_support=self.support.value(),
            minimum_support_fraction=float(self.fraction.text()),
        )
        virtual = tuple(float(v.strip()) for v in self.virtual.text().split(","))
        return replace(
            self.reference,
            rig=rig,
            settings=settings,
            mask=self.mask,
            black_level=float(self.black.text()),
            input_ceiling=float(self.ceiling.text()),
            virtual_light=virtual,
        )

    def submit(self, function, callback, *, publication=None):
        if self.closed:
            raise ValueError("This setup editor has closed")
        if self.pending:
            self.pending[1].set()
            self.pending[0].cancel()
        cancellation = Event()
        self.pending = (
            self.pool.submit(function, cancellation.is_set),
            cancellation,
            self.revision,
            callback,
            publication,
        )
        self.timer.start()
        self.status.setText("Computing a frozen preview…")
        self.refresh()

    def preview_reference(self):
        recipe = self.build_candidate()

        def complete(output):
            self.candidate, self.reference_result = recipe, output
            self.show_result(output, title="Reference fit")

        self.submit(lambda cancelled: execute(recipe, cancelled=cancelled), complete)

    def preview_capture(self, capture, *, title="Independent capture", publication=None):
        if self.candidate is None:
            raise ValueError("Preview the current reference before an independent capture")
        recipe = self.candidate
        self.submit(
            lambda cancelled: execute(recipe, capture, cancelled=cancelled),
            lambda output: self.show_result(output, title=title),
            publication=publication,
        )

    def preview_file(self):
        path = self.choose("Independent test capture", "Surface capture (*.json)")
        if path:
            self.preview_capture(capture_from_recipe(import_capture(path)), title=path.name)

    def preview_connected(self):
        capture, revision, _ = self.connected()
        self.preview_capture(capture, title="Connected preview", publication=revision)

    def poll(self):
        if self.pending is None or not self.pending[0].done() or self.closed:
            return
        future, cancellation, revision, callback, publication = self.pending
        self.pending = None
        self.timer.stop()
        try:
            output = future.result()
            if (
                not cancellation.is_set()
                and revision == self.revision
                and (publication is None or publication == self.context.output_revision)
            ):
                callback(output)
            else:
                self.status.setText("Discarded stale work. Preview the current draft/capture.")
        except Exception as error:
            self.status.setText(str(error))
        self.refresh()

    def show_result(self, output, *, title):
        self.last_result = output
        for name, view in self.views.items():
            view.set_image(pixmap(ImageArray(output["views"][name], "rgb")))
        report = output["report"]
        self.health.setText(
            f"{title}: {report['valid_pixels']}/{report['active_pixels']} valid pixels\n"
            f"Coverage {report['coverage']:.1%} (availability, not accuracy)\n"
            f"Rejected observations: {report['rejected_observations']}\n"
            f"No-redundancy pixels: {report['no_redundancy_pixels']}\n"
            + ", ".join(f"{key}: {value}" for key, value in report["reason_counts"].items())
        )
        self.status.setText(title + ": inspect normal/albedo, residual and unavailable layers.")
        self.tabs.setCurrentIndex(1)

    def stage(self):
        if (
            self.pending
            or self.candidate is None
            or self.reference_result is None
            or not (self.reference_result["report"]["valid_pixels"])
        ):
            raise ValueError("Preview the current reference with some valid fit before Stage")
        relative = f"assets/surface_enhance/{uuid.uuid4().hex}.sse"
        path = recipe_path(self.context.project_dir, relative)
        path.parent.mkdir(parents=True, exist_ok=True)
        recipe = replace(
            self.candidate,
            metadata={**self.candidate.metadata, "reference_fit": self.reference_result["report"]},
        )
        digest = save_recipe(path, recipe)
        self.parameters.update(recipe_path=relative, sha256=digest)
        self.accept()

    def refresh(self):
        busy = self.pending is not None
        self.preview_button.setEnabled(self.reference is not None and not busy)
        ready = self.candidate is not None and not busy
        self.test_button.setEnabled(ready)
        self.wire_button.setEnabled(ready)
        self.stage_button.setEnabled(
            ready
            and self.context.project_dir is not None
            and self.reference_result is not None
            and self.reference_result["report"]["valid_pixels"] > 0
        )

    def outputs_changed(self, *_):
        if not self.pending:
            self.status.setText(
                "New graph outputs available. Capture explicitly; reference is frozen."
            )

    def shutdown(self):
        if not self.closed:
            self.closed = True
            self.timer.stop()
            if self.pending:
                self.pending[1].set()
                self.pending[0].cancel()
            self.pool.shutdown(wait=False, cancel_futures=True)
            if self.unsubscribe:
                self.unsubscribe()
                self.unsubscribe = None

    def done(self, result):
        self.shutdown()
        super().done(result)
