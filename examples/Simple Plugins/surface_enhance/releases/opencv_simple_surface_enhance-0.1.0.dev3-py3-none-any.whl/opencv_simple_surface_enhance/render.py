"""Source-aligned RGB evidence views; raw normal/albedo arrays remain separate."""

import cv2
import numpy as np

from .solver import REASONS, relight

PALETTE = np.array(
    [
        [40, 200, 80],
        [50, 55, 60],
        [65, 130, 240],
        [255, 175, 35],
        [230, 95, 35],
        [215, 65, 220],
        [115, 120, 125],
        [200, 75, 75],
        [120, 30, 160],
    ],
    np.uint8,
)


def normal_change(result):
    """Normal-vector change per source pixel, using only intact cross neighborhoods."""
    valid = result.valid
    out = np.full(valid.shape, np.nan, np.float32)
    if min(valid.shape) < 3:
        return out
    selected = (
        valid[1:-1, 1:-1] & valid[:-2, 1:-1] & valid[2:, 1:-1] & valid[1:-1, :-2] & valid[1:-1, 2:]
    )
    dx = (result.normals[1:-1, 2:] - result.normals[1:-1, :-2]) / 2
    dy = (result.normals[2:, 1:-1] - result.normals[:-2, 1:-1]) / 2
    values = np.sqrt(np.sum(dx * dx + dy * dy, axis=-1))
    out[1:-1, 1:-1][selected] = values[selected]
    return out


def scalar_rgb(values, *, maximum=None, heat=False):
    finite = np.isfinite(values)
    maximum = (
        (max(1e-12, float(np.percentile(values[finite], 99))) if finite.any() else 1.0)
        if maximum is None
        else maximum
    )
    pixels = np.rint(np.clip(np.nan_to_num(values, nan=0, posinf=0) / maximum, 0, 1) * 255).astype(
        np.uint8
    )
    if heat:
        rgb = cv2.applyColorMap(pixels, cv2.COLORMAP_TURBO)[:, :, ::-1].copy()
    else:
        rgb = np.repeat(pixels[:, :, None], 3, axis=2)
    rgb[~finite] = (70, 35, 85)
    return rgb, float(maximum)


def panel(image, title, note, width=460, height=330):
    canvas = np.full((height, width, 3), 28, np.uint8)
    factor = min(width / image.shape[1], (height - 52) / image.shape[0])
    size = max(1, round(image.shape[1] * factor)), max(1, round(image.shape[0] * factor))
    resized = cv2.resize(
        image, size, interpolation=cv2.INTER_AREA if factor < 1 else cv2.INTER_NEAREST
    )
    x, y = (width - size[0]) // 2, 45 + (height - 50 - size[1]) // 2
    canvas[y : y + size[1], x : x + size[0]] = resized
    cv2.putText(
        canvas, title, (9, 19), cv2.FONT_HERSHEY_SIMPLEX, 0.52, (245, 245, 245), 1, cv2.LINE_AA
    )
    cv2.putText(
        canvas, note, (9, 37), cv2.FONT_HERSHEY_SIMPLEX, 0.34, (205, 210, 215), 1, cv2.LINE_AA
    )
    return canvas


def render_views(result, source, *, virtual_light=(0.6, 0, -0.8)):
    valid = result.valid
    normals = np.rint(np.clip(np.nan_to_num(result.normals, nan=0) * 0.5 + 0.5, 0, 1) * 255).astype(
        np.uint8
    )
    normals[~valid] = (70, 35, 85)
    albedo, scale = scalar_rgb(result.albedo)
    relit, _ = scalar_rgb(relight(result, virtual_light), maximum=1.0)
    change = normal_change(result)
    detail, change_scale = scalar_rgb(change, heat=True)
    residual, _ = scalar_rgb(result.all_rms_relative, maximum=0.25, heat=True)
    quality = PALETTE[result.reason]
    original, original_scale = scalar_rgb(source)
    dashboard = np.vstack(
        (
            np.hstack(
                (
                    panel(
                        original,
                        "Source / first light",
                        f"Display 0..{original_scale:.4g} (99p); linear raw codes retained",
                    ),
                    panel(
                        normals, "Diffuse surface normal", "RGB = (NXYZ+1)/2; purple unavailable"
                    ),
                    panel(
                        albedo, "Relative albedo", f"Display only: 0..{scale:.5g} (99th percentile)"
                    ),
                )
            ),
            np.hstack(
                (
                    panel(
                        relit,
                        "Virtual directional relighting",
                        "Orientation-only cosine 0..1; gaps retained",
                    ),
                    panel(
                        residual,
                        "All-observation relative RMS",
                        "Fixed display 0..0.25; raw values retained",
                    ),
                    panel(
                        quality,
                        "Available / rejected fit",
                        f"Valid {result.report['coverage']:.1%}; see reason legend",
                    ),
                )
            ),
        )
    )
    legend = np.full((42, dashboard.shape[1], 3), 28, np.uint8)
    labels = [
        "Valid",
        "Outside ROI",
        "Few observations",
        "Poor lighting geometry",
        "Low consensus",
        "Competing normals",
        "Weak signal",
        "Back facing",
        "Numerical failure",
    ]
    for index, label in enumerate(labels):
        x, y = 10 + (index % 5) * 274, 4 + (index // 5) * 20
        cv2.rectangle(legend, (x, y), (x + 11, y + 11), PALETTE[index].tolist(), -1)
        cv2.putText(
            legend,
            label,
            (x + 17, y + 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.36,
            (220, 220, 220),
            1,
            cv2.LINE_AA,
        )
    dashboard = np.vstack((dashboard, legend))
    return dict(
        source=original,
        normals=normals,
        albedo=albedo,
        relight=relit,
        detail=detail,
        residual=residual,
        quality=quality,
        overview=dashboard,
    ), dict(
        albedo_max=scale,
        normal_change_max=change_scale,
        input_max=original_scale,
        residual_max=0.25,
        relight_max=1.0,
        scope="Display ranges only; numerical maps, fit and validity are unchanged",
        reason_legend={name: PALETTE[i].tolist() for i, name in enumerate(REASONS)},
    )
