"""Bounded calibrated diffuse fitting with deterministic light-triplet consensus."""

import itertools
import math
from dataclasses import asdict, dataclass

import numpy as np

from .inputs import OUTSIDE_ROI, LightRig, PreparedStack, frozen

REASONS = (
    "valid",
    "outside_roi",
    "insufficient_observations",
    "ill_conditioned",
    "insufficient_consensus",
    "ambiguous_orientation",
    "weak_signal",
    "back_facing",
    "numerical_failure",
)


@dataclass(frozen=True)
class SurfaceSettings:
    minimum_support: int = 3
    minimum_support_fraction: float = 0.5
    relative_tolerance: float = 0.06
    absolute_tolerance: float = 1e-6
    minimum_singular_ratio: float = 1e-3
    ambiguity_angle_deg: float = 8.0
    minimum_albedo: float = 1e-8
    view_direction: tuple = (0.0, 0.0, -1.0)
    minimum_view_cosine: float = 0.02
    seed_count: int = 32

    def __post_init__(self):
        for name, low, high in (
            ("minimum_support_fraction", 0, 1),
            ("relative_tolerance", 0, 1),
            ("absolute_tolerance", 0, 1e6),
            ("minimum_singular_ratio", 0, 1),
            ("ambiguity_angle_deg", 0, 180),
            ("minimum_albedo", 0, 1e6),
            ("minimum_view_cosine", 0, 1),
        ):
            value = getattr(self, name)
            if isinstance(value, bool) or not np.isfinite(value) or not low <= value <= high:
                raise ValueError("Bound " + name + " to its finite range")
        if min(self.absolute_tolerance, self.minimum_singular_ratio, self.minimum_albedo) <= 0:
            raise ValueError("Absolute tolerance, conditioning and signal floors must be positive")
        for name, low, high in (("minimum_support", 3, 128), ("seed_count", 1, 128)):
            if type(getattr(self, name)) is not int or not low <= getattr(self, name) <= high:
                raise ValueError("Use a bounded integer " + name)
        view = np.asarray(self.view_direction, np.float64)
        if (
            view.shape != (3,)
            or not np.isfinite(view).all()
            or not np.isclose(np.linalg.norm(view), 1)
        ):
            raise ValueError("Declare a unit view direction in the light/normal frame")
        object.__setattr__(self, "view_direction", tuple(float(v) for v in view))


@dataclass(frozen=True)
class SurfaceResult:
    normals: np.ndarray
    albedo: np.ndarray
    valid: np.ndarray
    reason: np.ndarray
    support: np.ndarray
    available: np.ndarray
    singular_ratio: np.ndarray
    fit_rms_relative: np.ndarray
    all_rms_relative: np.ndarray
    used: np.ndarray
    residual: np.ndarray
    report: dict


def triplets(rig, settings):
    """Compile geometry only, never choose seed schedules from test image values."""
    count = len(rig.light_ids)
    if math.comb(count, 3) <= 2048:
        pool = list(itertools.combinations(range(count), 3))
    else:
        rng = np.random.default_rng(20261116)
        pool = {
            tuple(sorted((i, (i + count // 3) % count, (i + 2 * count // 3) % count)))
            for i in range(count)
        }
        while len(pool) < 2048:
            pool.add(tuple(sorted(rng.choice(count, 3, replace=False).tolist())))
        pool = sorted(pool)
    choices = np.asarray(pool, np.int32)
    singular = np.linalg.svd(rig.directions[choices], compute_uv=False)
    ratio = singular[:, -1] / singular[:, 0]
    remaining = np.flatnonzero(ratio >= settings.minimum_singular_ratio)
    selected, usage = [], np.zeros(count, int)
    while len(selected) < settings.seed_count and len(remaining):
        # Prefer unused lights, then better conditioning; deterministic for one rig.
        priority = np.lexsort((-ratio[remaining], usage[choices[remaining]].sum(axis=1)))
        pick = remaining[priority[0]]
        selected.append(pick)
        usage[choices[pick]] += 1
        remaining = remaining[remaining != pick]
    chosen = choices[selected]
    inverse = np.linalg.inv(rig.directions[chosen]) if len(chosen) else np.empty((0, 3, 3))
    return frozen(chosen, np.int32), frozen(inverse, np.float64)


def least_squares(lights, values, selected, minimum_ratio):
    weights = selected.astype(np.float64)
    gram = np.einsum("ni,nj,np->pij", lights, lights, weights)
    rhs = np.einsum("ni,np->pi", lights, weights * values)
    eigenvalues, vectors = np.linalg.eigh(gram)
    ratio = np.sqrt(np.maximum(eigenvalues[:, 0], 0) / np.maximum(eigenvalues[:, -1], 1e-300))
    stable = (selected.sum(axis=0) >= 3) & (ratio >= minimum_ratio)
    safe = np.where(stable[:, None], eigenvalues, 1.0)
    solution = np.einsum("pij,pj->pi", vectors, np.einsum("pji,pj->pi", vectors, rhs) / safe)
    solution[~stable] = np.nan
    return solution, ratio, stable


def agreement(lights, values, observed, solution, tolerance):
    raw_prediction = lights @ solution.T
    residual = values - np.maximum(raw_prediction, 0)
    selected = observed & (raw_prediction > 0) & (np.abs(residual) <= tolerance)
    count = selected.sum(axis=0)
    error = np.sqrt(np.sum(np.where(selected, residual, 0) ** 2, axis=0) / np.maximum(count, 1))
    error[count == 0] = np.inf
    return selected, count, error, residual


class SurfaceEstimator:
    """Reuse compiled lighting across frames. No per-pixel normal continuity prior."""

    def __init__(self, rig, settings=None):
        if not isinstance(rig, LightRig):
            raise ValueError("Use a validated directional light rig")
        self.rig, self.settings = rig, settings or SurfaceSettings()
        if not isinstance(self.settings, SurfaceSettings):
            raise ValueError("Use validated surface settings")
        if self.settings.minimum_support > len(rig.light_ids):
            raise ValueError("Minimum support exceeds the number of calibrated lights")
        self.seeds, self.inverse = triplets(rig, self.settings)

    def _tile(self, values, observed):
        s, lights = self.settings, self.rig.directions
        pixels = values.shape[1]
        available = observed.sum(axis=0)
        required = max(s.minimum_support, math.ceil(len(lights) * s.minimum_support_fraction))
        signal = np.zeros(pixels)
        active = available > 0
        signal[active] = np.nanmedian(
            np.where(observed[:, active], values[:, active], np.nan), axis=0
        )
        tolerance = s.absolute_tolerance + s.relative_tolerance * signal
        clean = np.where(observed, values, 0).astype(np.float64)
        initial, initial_ratio, initial_stable = least_squares(
            lights, clean, observed, s.minimum_singular_ratio
        )
        solutions = [initial]
        for indices, inverse in zip(self.seeds, self.inverse):
            g = (inverse @ clean[indices]).T
            g[~observed[indices].all(axis=0)] = np.nan
            solutions.append(g)
        candidates = np.stack(solutions)
        counts, errors = [], []
        for g in candidates:
            _, n, error, _ = agreement(lights, clean, observed, g, tolerance)
            counts.append(n)
            errors.append(error)
        counts, errors = np.asarray(counts), np.asarray(errors)
        largest = counts.max(axis=0)
        costs = np.where(counts == largest, errors, np.inf)
        best = costs.argmin(axis=0)
        solution = candidates[best, np.arange(pixels)]
        for _ in range(2):
            used, _, _, _ = agreement(lights, clean, observed, solution, tolerance)
            solution, ratio, stable = least_squares(lights, clean, used, s.minimum_singular_ratio)
        used, support, error, residual = agreement(lights, clean, observed, solution, tolerance)
        strength = np.linalg.norm(solution, axis=1)
        normal = solution / np.maximum(strength[:, None], s.minimum_albedo)
        candidate_strength = np.linalg.norm(candidates, axis=2)
        candidate_normals = candidates / np.maximum(
            candidate_strength[:, :, None], s.minimum_albedo
        )
        cosine = np.einsum("cpi,pi->cp", candidate_normals, normal)
        plausible = (
            (counts >= support)
            & (counts >= required)
            & (errors <= error[None, :] + 0.25 * tolerance[None, :])
        )
        ambiguous = np.any(plausible & (cosine < np.cos(np.deg2rad(s.ambiguity_angle_deg))), axis=0)
        reason = np.zeros(pixels, np.uint8)
        reason[~np.isfinite(normal).all(axis=1)] = 8
        reason[(normal @ np.asarray(s.view_direction)) <= s.minimum_view_cosine] = 7
        reason[strength <= s.minimum_albedo] = 6
        reason[ambiguous] = 5
        reason[support < required] = 4
        reason[~initial_stable | ~stable] = 3
        reason[available < required] = 2
        valid = reason == 0
        normal[~valid], strength[~valid] = np.nan, np.nan
        residual[~observed] = np.nan
        all_error = np.sqrt(
            np.sum(np.where(observed, residual, 0) ** 2, axis=0) / np.maximum(available, 1)
        )
        scale = np.maximum(signal, s.absolute_tolerance)
        return dict(
            normals=normal,
            albedo=strength,
            valid=valid,
            reason=reason,
            support=support,
            available=available,
            singular_ratio=np.minimum(initial_ratio, ratio),
            fit_rms_relative=error / scale,
            all_rms_relative=all_error / scale,
            used=used,
            residual=residual,
        )

    def estimate(self, stack, *, tile_pixels=4096, cancelled=lambda: False):
        if not isinstance(stack, PreparedStack) or (
            stack.rig is not self.rig
            and (
                stack.rig.light_ids != self.rig.light_ids
                or stack.rig.frame != self.rig.frame
                or not np.array_equal(stack.rig.directions, self.rig.directions)
            )
        ):
            raise ValueError("Prepare the stack with this estimator's calibrated rig")
        values, observed = np.asarray(stack.values), np.asarray(stack.valid)
        if (
            values.ndim != 3
            or values.shape[0] != len(self.rig.light_ids)
            or observed.dtype != bool
            or observed.shape != values.shape
            or stack.flags.shape != values.shape
            or values.size > 16_000_000
            or not np.isfinite(values[observed]).all()
            or np.any(values[observed] <= 0)
        ):
            raise ValueError("Use a valid bounded prepared illumination stack")
        if type(tile_pixels) is not int or not 1 <= tile_pixels <= 16384:
            raise ValueError("Bound work tiles to 1..16384 source pixels")
        n, height, width = values.shape
        flat, selected = values.reshape(n, -1), observed.reshape(n, -1)
        result = dict(
            normals=np.full((height * width, 3), np.nan, np.float32),
            albedo=np.full(height * width, np.nan, np.float32),
            valid=np.zeros(height * width, bool),
            reason=np.zeros(height * width, np.uint8),
            support=np.zeros(height * width, np.uint16),
            available=np.zeros(height * width, np.uint16),
            singular_ratio=np.zeros(height * width, np.float32),
            fit_rms_relative=np.full(height * width, np.nan, np.float32),
            all_rms_relative=np.full(height * width, np.nan, np.float32),
            used=np.zeros((n, height * width), bool),
            residual=np.full((n, height * width), np.nan, np.float32),
        )
        for start in range(0, height * width, tile_pixels):
            if cancelled():
                raise RuntimeError("Surface estimation cancelled; no result published")
            end = min(start + tile_pixels, height * width)
            tile = self._tile(flat[:, start:end], selected[:, start:end])
            outside = np.all((stack.flags.reshape(n, -1)[:, start:end] & OUTSIDE_ROI) != 0, axis=0)
            tile["reason"][outside], tile["valid"][outside] = 1, False
            for key, value in tile.items():
                if key in ("used", "residual"):
                    result[key][:, start:end] = value
                else:
                    result[key][start:end] = value
        if cancelled():
            raise RuntimeError("Surface estimation cancelled; no result published")
        for key, value in result.items():
            shape = (
                (n, height, width)
                if key in ("used", "residual")
                else ((height, width, 3) if key == "normals" else (height, width))
            )
            result[key] = value.reshape(shape)
            result[key].flags.writeable = False
        active = result["reason"] != 1
        valid = result["valid"]
        report = dict(
            schema="simple_surface_result/v1",
            capture_id=stack.capture_id,
            pixel_grid=stack.pixel_grid,
            frame=self.rig.frame,
            image_size=[width, height],
            light_ids=list(self.rig.light_ids),
            settings=asdict(self.settings),
            compiled_triplet_seeds=len(self.seeds),
            valid_pixels=int(valid.sum()),
            active_pixels=int(active.sum()),
            coverage=float(valid.sum() / max(1, active.sum())),
            reason_counts={
                REASONS[i]: int(np.sum(result["reason"] == i))
                for i in range(len(REASONS))
                if np.any(result["reason"] == i)
            },
            no_redundancy_pixels=int(np.sum(valid & (result["support"] == 3))),
            rejected_observations=int(np.sum(observed & ~result["used"])),
            scope="Directional diffuse normal/albedo fit, not metric height or defect acceptance",
            residual_scope=(
                "Positive/negative residuals are model disagreement; "
                "material labels are not inferred"
            ),
        )
        return SurfaceResult(**result, report=report)


def relight(result, direction, *, use_albedo=False):
    direction = np.asarray(direction, np.float64)
    if (
        direction.shape != (3,)
        or not np.isfinite(direction).all()
        or not np.isclose(np.linalg.norm(direction), 1)
    ):
        raise ValueError("Use a unit virtual-light direction in the result normal frame")
    if type(use_albedo) is not bool:
        raise ValueError("Choose whether to include relative albedo")
    image = np.maximum(np.einsum("hwi,i->hw", result.normals, direction), 0)
    if use_albedo:
        image *= result.albedo
    image[~result.valid] = np.nan
    return image.astype(np.float32)
