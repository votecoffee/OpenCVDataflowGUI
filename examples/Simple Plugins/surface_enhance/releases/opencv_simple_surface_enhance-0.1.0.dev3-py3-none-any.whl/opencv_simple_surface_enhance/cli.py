"""Explicit offline capture manifests and bounded diagnostic/numeric result export."""

import argparse
import io
import json
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from .inputs import LightRig, prepare_stack
from .solver import SurfaceEstimator, SurfaceSettings, relight


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("Duplicate JSON key: " + key)
            result[key] = value
        return result

    def bad(value):
        raise ValueError("Use finite JSON numbers")

    def floating(value):
        number = float(value)
        return number if np.isfinite(number) else bad(value)

    return json.loads(raw, object_pairs_hook=pairs, parse_constant=bad, parse_float=floating)


def load_plane(path, channel="gray"):
    path = Path(path)
    if path.stat().st_size > 128 * 1024 * 1024:
        raise ValueError("Image file exceeds 128 MiB")
    if path.suffix.lower() == ".npy":
        raw = path.read_bytes()
        stream = io.BytesIO(raw)
        version = np.lib.format.read_magic(stream)
        if version not in ((1, 0), (2, 0)):
            raise ValueError("Use numeric NPY v1/v2 images")
        reader = (
            np.lib.format.read_array_header_1_0
            if version == (1, 0)
            else np.lib.format.read_array_header_2_0
        )
        shape, _, dtype = reader(stream)
        if (
            len(shape) != 2
            or min(shape) < 2
            or max(shape) > 16384
            or np.prod(shape) > 16_000_000
            or dtype.kind not in "uif"
            or dtype.itemsize > 8
            or int(np.prod(shape)) * dtype.itemsize != len(raw) - stream.tell()
        ):
            raise ValueError("Use a bounded numeric monochrome NPY image")
        image = np.load(io.BytesIO(raw), allow_pickle=False)
    else:
        with Image.open(path) as header:
            if (
                min(header.size) < 2
                or max(header.size) > 16384
                or header.width * header.height > 16_000_000
            ):
                raise ValueError("Image expansion exceeds source bounds")
        image = cv2.imdecode(np.frombuffer(path.read_bytes(), np.uint8), cv2.IMREAD_UNCHANGED)
        if image is None:
            raise ValueError("Cannot decode image: " + path.name)
    if image.ndim == 2:
        return image
    if image.ndim == 3 and image.shape[2] == 3 and channel in ("red", "green", "blue"):
        return image[:, :, {"red": 2, "green": 1, "blue": 0}[channel]]
    raise ValueError(
        "Use monochrome images, or explicitly select a calibrated red/green/blue channel"
    )


def read_capture(path):
    path = Path(path)
    if path.stat().st_size > 2 * 1024 * 1024:
        raise ValueError("Capture manifest exceeds 2 MiB")
    data = strict_json(path.read_bytes())
    if data.get("schema") != "simple_surface_capture/v1":
        raise ValueError("Use a simple_surface_capture/v1 manifest")
    entries = data.get("lights")
    if not isinstance(entries, list) or not 3 <= len(entries) <= 128:
        raise ValueError("Declare 3..128 calibrated light/image entries")
    rig = LightRig(
        tuple(row["id"] for row in entries),
        [row["direction"] for row in entries],
        [row["relative_intensity"] for row in entries],
        [row["exposure_s"] for row in entries],
        data.get("frame", "camera"),
    )
    scale = data.get("input_scale")
    if type(scale) not in (int, float) or not np.isfinite(scale) or scale <= 0:
        raise ValueError("Declare a positive source-code input_scale; normalized floats use 1")
    channel = data.get("channel", "gray")
    planes, shape = [], None
    for row in entries:
        image = load_plane(path.parent / row["image"], channel)
        if shape is None:
            shape = image.shape
            if image.size * len(entries) > 16_000_000:
                raise ValueError("Capture stack exceeds 16 million observations")
        elif image.shape != shape:
            raise ValueError("All lights must use the same registered image dimensions")
        planes.append(image.astype(np.float32) / scale)
    images = np.stack(planes)
    mask = load_plane(path.parent / data["mask"]) if data.get("mask") else None
    stack = prepare_stack(
        images,
        rig,
        rig.light_ids,
        capture_id=data["capture_id"],
        pixel_grid=data["pixel_grid"],
        response=data.get("response"),
        black_level=data.get("black_level", 0),
        input_ceiling=data.get("input_ceiling", 1),
        mask=mask,
    )
    settings = SurfaceSettings(**data.get("settings", {}))
    virtual = data.get("virtual_light", [0.6, 0, -0.8])
    return stack, settings, images[0], virtual


def export_result(output, result, stack, source, virtual_light, *, graphics=True):
    from .render import normal_change

    # Validate the requested view before creating any files.
    relit = relight(result, virtual_light)
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    arrays = {
        name: getattr(result, name)
        for name in (
            "normals",
            "albedo",
            "valid",
            "reason",
            "support",
            "available",
            "singular_ratio",
            "fit_rms_relative",
            "all_rms_relative",
            "used",
            "residual",
        )
    }
    arrays.update(relight=relit, normal_change=normal_change(result), observation_flags=stack.flags)
    with (output / "maps.npz").open("xb") as stream:
        np.savez_compressed(stream, **arrays)
    report = dict(result.report)
    report["rig"] = dict(
        directions=stack.rig.directions.tolist(),
        relative_intensity=stack.rig.relative_intensity.tolist(),
        exposure_s=stack.rig.exposure_s.tolist(),
    )
    report["virtual_light"] = list(virtual_light)
    report["map_units"] = dict(
        normals="unit vectors in named frame",
        albedo="relative signal per light-second",
        normal_change="normal-vector change per source pixel",
        relight="orientation cosine",
    )
    if graphics:
        from .render import render_views

        views, ranges = render_views(result, source, virtual_light=virtual_light)
        report["display"] = ranges
        for name, rgb in views.items():
            okay, encoded = cv2.imencode(".png", rgb[:, :, ::-1])
            if not okay:
                raise ValueError("Cannot encode diagnostic view")
            with (output / (name + ".png")).open("xb") as stream:
                stream.write(encoded.tobytes())
    with (output / "report.json").open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(report, indent=2, allow_nan=False) + "\n")
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capture", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--no-graphics", action="store_true")
    args = parser.parse_args(argv)
    stack, settings, source, virtual = read_capture(args.capture)
    result = SurfaceEstimator(stack.rig, settings).estimate(stack)
    report = export_result(
        args.output, result, stack, source, virtual, graphics=not args.no_graphics
    )
    print(
        json.dumps(
            {
                key: report[key]
                for key in (
                    "capture_id",
                    "active_pixels",
                    "valid_pixels",
                    "coverage",
                    "reason_counts",
                )
            }
        )
    )


if __name__ == "__main__":
    main()
