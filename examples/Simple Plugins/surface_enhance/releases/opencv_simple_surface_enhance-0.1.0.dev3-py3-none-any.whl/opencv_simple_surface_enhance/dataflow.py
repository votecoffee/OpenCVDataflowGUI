"""Single cached surface execution block; optional Qt imported only by its editor."""

import re
from pathlib import Path, PurePosixPath
from threading import RLock

import numpy as np
from opencv_dataflow.core import Block, Port, Result
from opencv_dataflow.images import ImageArray
from opencv_dataflow.parameter_validation import NumericRange, ValidationError
from opencv_dataflow.payloads import NO_VALUE, frame

from .execution import capture_from_recipe, execute
from .recipe import import_capture, load_recipe
from .solver import SurfaceEstimator


def recipe_path(project_dir, relative):
    if project_dir is None:
        raise ValueError("Save the project before staging a surface recipe")
    path = PurePosixPath(relative)
    if (
        not relative
        or path.is_absolute()
        or ".." in path.parts
        or ":" in relative
        or "\\" in relative
        or path.suffix != ".sse"
    ):
        raise ValueError("Choose a project-contained .sse recipe using forward slashes")
    root = Path(project_dir).resolve()
    target = (root / relative).resolve()
    if not target.is_relative_to(root):
        raise ValueError("Recipe resolves outside the project directory")
    return target


def signature(path):
    stat = path.stat()
    return stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns, stat.st_ino


class RecipeCache:
    def __init__(self):
        self.lock = RLock()
        self.key = self.recipe = self.estimator = None

    def get(self, path, digest):
        with self.lock:
            key = str(path), digest, signature(path)
            if key != self.key:
                recipe = load_recipe(path, sha256=digest)
                estimator = SurfaceEstimator(recipe.rig, recipe.settings)
                if signature(path) != key[2]:
                    raise ValueError("Recipe changed during loading; retry with the current recipe")
                self.key, self.recipe, self.estimator = key, recipe, estimator
            return self.recipe, self.estimator


class SimpleSurfaceEnhance(Block):
    type_id, title = "image.simple_surface_enhance", "SimpleSurfaceEnhance"
    category = block_type = "Image processing"
    subtype = "Surface enhancement"
    parallel_safe = process_inputs_readonly = preview_safe = True
    plugin_dialog_label = "Set up lighting and reference…"
    plugin_dialog_modeless = True
    inputs = (
        Port(
            "capture",
            "any",
            required=False,
            required_when_connected=True,
            visual_type="surface_illumination_stack",
        ),
    )
    outputs = (
        Port("image", "image"),
        Port("maps", "any", visual_type="surface_maps"),
        Port("report", "data"),
        Port("coverage", "number"),
        Port("valid_pixels", "integer"),
        Port("overview", "image", required=False),
    )
    defaults = dict(
        recipe_path="",
        sha256="",
        source="connected capture",
        capture_manifest="",
        minimum_coverage=0.0,
        render_graphics=True,
    )
    parameter_choices = {"source": ("connected capture", "capture manifest")}
    parameter_ranges = {"minimum_coverage": NumericRange(0, 1)}
    project_path_parameters = ("capture_manifest",)
    parameter_help = {
        "recipe_path": "Retained .sse recipe; use setup to teach lighting/reference.",
        "sha256": "SHA-256 of the staged recipe; validated once then cached by file identity/stat.",
        "source": "Use the connected data bundle, or explicitly replay a capture manifest.",
        "capture_manifest": "Offline simple_surface_capture/v1 file; paths inside it are relative "
        "to the manifest. Ignored in connected mode; no source is silently replaced by training.",
        "minimum_coverage": "Minimum valid/active source pixels (0..1). Zero still requires one "
        "valid pixel. Availability is not accuracy, confidence or defect acceptance.",
        "render_graphics": "Create source-aligned map views and a combined fit/reason overview. "
        "Raw relighting and numerical maps remain identical when graphics are disabled.",
    }
    input_help = {
        "capture": "simple_surface_stack/v1: normalized floating N×H×W source codes, declared "
        "lighting/exposures, linear response, black/ceiling, capture ID and source pixel grid. "
        "Order/calibration/grid must match; declared exposure changes are compensated.",
    }
    output_help = {
        "image": "Raw orientation-only relighting cosine 0..1 in source pixels; unavailable NaN.",
        "maps": "Fourteen source-aligned raw normal/albedo/fit/support/reason/relighting maps. "
        "Normal vectors are not measured XYZ or metric height.",
        "overview": "Diagnostic RGB panels for source, normals, albedo, relighting, residual and "
        "availability with a reason legend. More map views appear in Image results.",
        "report": "Calibration, actual exposure, reference/capture identity, availability and "
        "model-disagreement evidence; this tool does not classify defects.",
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.preview_output = "overview"
        self.cache = RecipeCache()

    def validate_parameters(self, parameters=None):
        super().validate_parameters(parameters)
        p = self.parameters if parameters is None else parameters
        if not all(
            isinstance(p[key], str) for key in ("recipe_path", "sha256", "capture_manifest")
        ):
            raise ValidationError("Choose recipe/capture paths and the recipe checksum")
        if p["recipe_path"] or p["sha256"]:
            try:
                recipe_path(self.project_dir, p["recipe_path"])
            except ValueError as error:
                raise ValidationError(str(error), "recipe_path") from error
            if re.fullmatch("[0-9a-f]{64}", p["sha256"]) is None:
                raise ValidationError("Stage/import the recipe and its SHA-256", "sha256")
        if type(p["render_graphics"]) is not bool:
            raise ValidationError("Render graphics must be boolean", "render_graphics")
        if type(p["minimum_coverage"]) not in (int, float) or not (
            np.isfinite(p["minimum_coverage"]) and 0 <= p["minimum_coverage"] <= 1
        ):
            raise ValidationError("Minimum coverage must be in 0..1", "minimum_coverage")

    def process(self, inputs):
        p = self.parameters
        if not p["recipe_path"]:
            raise ValidationError("Set up lighting and retain a reference first", "recipe_path")
        recipe, estimator = self.cache.get(
            recipe_path(self.project_dir, p["recipe_path"]), p["sha256"]
        )
        if p["source"] == "connected capture":
            if "capture" not in inputs:
                raise ValidationError("Connect an illumination capture or select capture manifest")
            capture = inputs["capture"]
        else:
            if "capture" in inputs:
                raise ValidationError(
                    "Select connected capture to use the wired illumination stack"
                )
            if not p["capture_manifest"]:
                raise ValidationError("Choose an offline capture manifest", "capture_manifest")
            path = Path(p["capture_manifest"])
            if not path.is_absolute():
                if self.project_dir is None:
                    raise ValidationError("Save the project or use an absolute capture manifest")
                path = self.project_dir / path
            capture = capture_from_recipe(import_capture(path))
        graphics = self.generate_graphics and p["render_graphics"]
        output = execute(
            recipe, capture, estimator=estimator, graphics=graphics, cancelled=self._cancelled
        )
        report = output["report"]
        passed = report["valid_pixels"] > 0 and report["coverage"] >= p["minimum_coverage"]
        report["decision"] = dict(
            passed=passed,
            minimum_coverage=p["minimum_coverage"],
            scope="Available fit coverage only, not defect or gauge acceptance",
        )
        size = report["image_size"]
        payloads = {
            name: {"spatial": frame(size, "surface-source:" + recipe.pixel_grid)}
            for name in ("image", "maps")
        }
        if graphics:
            overview = output["views"]["overview"]
            payloads["overview"] = {
                "spatial": frame(list(overview.shape[1::-1]), "surface-overview:" + self.id)
            }
        return Result(
            outputs=dict(
                image=ImageArray(output["maps"]["relight"], "gray"),
                maps=output["maps"],
                report=report,
                coverage=report["coverage"],
                valid_pixels=report["valid_pixels"],
                overview=ImageArray(output["views"]["overview"], "rgb") if graphics else NO_VALUE,
            ),
            payloads=payloads,
            graphics={key: ImageArray(value, "rgb") for key, value in output["views"].items()},
            passed=passed,
            message=f"{report['valid_pixels']}/{report['active_pixels']} valid pixels "
            f"({report['coverage']:.1%}); diffuse orientation/albedo, no metric height",
            fail_reasons=[] if passed else ["surface_unavailable_coverage"],
        )

    def create_plugin_dialog(self, parent, parameters, context):
        from .qt_training import SurfaceTrainingDialog

        return SurfaceTrainingDialog(parent, parameters, context)

    def close(self):
        self.cache = RecipeCache()


def register(registry):
    registry.register(SimpleSurfaceEnhance)
