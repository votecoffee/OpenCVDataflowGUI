"""Explicit linear radiometry, light ordering and per-observation availability."""

from dataclasses import dataclass

import numpy as np

NONFINITE, DARK, INPUT_CEILING, OUTSIDE_ROI = 1, 2, 4, 8


def named(value):
    return isinstance(value, str) and 0 < len(value.strip()) <= 128


def frozen(value, dtype):
    result = np.array(value, dtype=dtype, copy=True, order="C")
    result.flags.writeable = False
    return result


@dataclass(frozen=True)
class LightRig:
    light_ids: tuple
    directions: np.ndarray
    relative_intensity: np.ndarray
    exposure_s: np.ndarray
    frame: str = "camera"

    def __post_init__(self):
        ids = tuple(self.light_ids)
        if not 3 <= len(ids) <= 128 or not all(named(v) for v in ids) or len(set(ids)) != len(ids):
            raise ValueError("Use 3..128 unique named light IDs")
        directions = np.asarray(self.directions)
        if (
            directions.dtype.kind not in "iuf"
            or directions.shape != (len(ids), 3)
            or not np.isfinite(directions).all()
            or not np.allclose(np.linalg.norm(directions, axis=1), 1, atol=1e-6, rtol=0)
        ):
            raise ValueError("Declare unit light directions from surface toward each source")
        singular = np.linalg.svd(directions, compute_uv=False)
        if singular[-1] / singular[0] < 1e-3:
            raise ValueError("Light directions must span stable 3D orientation information")
        for name, minimum, maximum in (
            ("relative_intensity", 1e-6, 1e6),
            ("exposure_s", 1e-9, 3600),
        ):
            value = np.asarray(getattr(self, name))
            if (
                value.dtype.kind not in "iuf"
                or value.shape != (len(ids),)
                or not np.isfinite(value).all()
                or np.any(value < minimum)
                or np.any(value > maximum)
            ):
                raise ValueError("Declare bounded positive per-light " + name)
            object.__setattr__(self, name, frozen(value, np.float64))
        if not named(self.frame):
            raise ValueError("Name the physical light/normal coordinate frame")
        object.__setattr__(self, "light_ids", ids)
        object.__setattr__(self, "directions", frozen(directions, np.float64))


@dataclass(frozen=True)
class PreparedStack:
    rig: LightRig
    values: np.ndarray
    valid: np.ndarray
    flags: np.ndarray
    capture_id: str
    pixel_grid: str


def prepare_stack(
    images,
    rig,
    observed_light_ids,
    *,
    capture_id,
    pixel_grid,
    response="linear",
    black_level=0.0,
    input_ceiling=1.0,
    mask=None,
):
    """Normalize explicit linear codes by black level, relative light power and seconds.

    One registered monochrome stack from a fixed view. Capture/grid identifiers
    are provenance supplied by the caller, not proof of alignment or synchrony.
    No normal, albedo, height or inspection decision is produced by this E0 API.
    """
    if not isinstance(rig, LightRig) or tuple(observed_light_ids) != rig.light_ids:
        raise ValueError("Capture light order/identity must exactly match the calibrated rig")
    if response != "linear":
        raise ValueError("Linearize camera response explicitly; no per-image auto normalization")
    if not named(capture_id) or not named(pixel_grid):
        raise ValueError("Declare one capture group and registered source-pixel grid")
    raw = np.asarray(images)
    if (
        raw.ndim != 3
        or raw.shape[0] != len(rig.light_ids)
        or raw.dtype.kind != "f"
        or min(raw.shape[1:]) < 2
        or max(raw.shape[1:]) > 16384
        or raw.size > 16_000_000
    ):
        raise ValueError("Use a bounded N×H×W normalized floating monochrome stack")
    if (
        isinstance(black_level, bool)
        or isinstance(input_ceiling, bool)
        or not np.isfinite([black_level, input_ceiling]).all()
        or not 0 <= black_level < input_ceiling <= 1
    ):
        raise ValueError("Declare ordered normalized black level and input ceiling")
    finite = np.isfinite(raw)
    if np.any(finite & ((raw < 0) | (raw > 1))):
        raise ValueError("Use normalized source codes in 0..1; nonfinite samples stay unavailable")
    selected = np.ones(raw.shape[1:], bool)
    if mask is not None:
        mask = np.asarray(mask)
        if mask.shape != raw.shape[1:] or mask.dtype.kind not in "bui" or np.any(mask < 0):
            raise ValueError("ROI mask must match the common source-pixel grid")
        selected = mask != 0
    flags = np.zeros(raw.shape, np.uint8)
    flags[~finite] |= NONFINITE
    flags[finite & (raw <= black_level)] |= DARK
    flags[finite & (raw >= input_ceiling)] |= INPUT_CEILING
    flags[:, ~selected] |= OUTSIDE_ROI
    valid = flags == 0
    values = np.full(raw.shape, np.nan, np.float32)
    # Irradiance and exposure remain explicit; scale is relative, not physical reflectance.
    divisor = (rig.relative_intensity * rig.exposure_s)[:, None, None]
    np.divide(raw - black_level, divisor, out=values, where=valid)
    values.flags.writeable = valid.flags.writeable = flags.flags.writeable = False
    return PreparedStack(rig, values, valid, flags, capture_id, pixel_grid)
