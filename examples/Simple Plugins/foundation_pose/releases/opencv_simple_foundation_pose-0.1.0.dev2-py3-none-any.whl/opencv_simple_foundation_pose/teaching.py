"""Object setup helpers independent of Qt, neural runtimes and host graph state."""

from dataclasses import asdict
from pathlib import Path

import cv2
import numpy as np

from .persistence import Recipe, bounded_array, strict_json
from .specs import Frame


def reference_health(recipe):
    if not isinstance(recipe, Recipe):
        raise TypeError("Retain a metric mesh and calibrated reference")
    active = int(recipe.reference.mask.sum())
    measured = int((recipe.reference.mask & (recipe.reference.depth >= 0.1)).sum())
    return dict(
        valid=active > 0 and measured >= 12,
        selected_pixels=active,
        measured_target_pixels=measured,
        unknown_target_pixels=active - measured,
        units="m",
        mesh_frame=recipe.mesh.frame,
        camera_frame=recipe.reference.frame,
        diameter_m=recipe.mesh.diameter,
        original_origin_preserved=True,
        settings=asdict(recipe.settings),
        network_training=False,
        qualification="Setup consistency only; no pose/accuracy/grasp qualification",
    )


def read_mask(path, shape, *, label=None):
    path = Path(path)
    if path.stat().st_size > 64 * 1024 * 1024:
        raise ValueError("Mask exceeds 64 MiB")
    value = (
        bounded_array(path.read_bytes(), dtypes=("|u1", "<i4", "|b1"))
        if path.suffix.lower() == ".npy"
        else cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    )
    if value is None or value.shape != shape or value.dtype.kind not in "bui" or np.any(value < 0):
        raise ValueError("Import a same-size single-channel nonnegative integer mask")
    labels = np.unique(value[value != 0])
    if label is None and len(labels) > 1:
        raise ValueError("Select one foreground label from this multi-instance mask")
    result = value == label if label is not None else value != 0
    if not result.any():
        raise ValueError("Selected mask label is empty")
    return result


def read_images(rgb, depth, camera, *, depth_scale, mask=None):
    """Explicit file import; an absent mask starts blank for interactive teaching."""
    if (
        isinstance(depth_scale, bool)
        or not np.isfinite(depth_scale)
        or not 1e-12 <= depth_scale <= 1
    ):
        raise ValueError("Declare stored axial-depth units to meters")
    image = cv2.imread(str(rgb), cv2.IMREAD_COLOR)
    raw = cv2.imread(str(depth), cv2.IMREAD_UNCHANGED)
    if image is None or raw is None or raw.ndim != 2:
        raise ValueError("Choose readable RGB and registered single-channel axial depth images")
    if raw.dtype not in (np.uint16, np.float32, np.float64):
        raise ValueError("Depth must retain uint16/float physical values, not uint8 display codes")
    path = Path(camera)
    if path.stat().st_size > 65_536:
        raise ValueError("Oversized camera declaration")
    calibration = strict_json(path.read_bytes())
    if (
        not isinstance(calibration, dict)
        or calibration.get("lens", "pinhole") != "pinhole"
        or np.any(calibration.get("distortion", []))
        or tuple(calibration.get("image_size", ())) != raw.shape[::-1]
    ):
        raise ValueError("Declare rectified pinhole matrix, matching image_size and frame")
    labels = read_mask(mask, raw.shape) if mask else np.zeros(raw.shape, bool)
    return Frame(
        image[..., ::-1],
        raw.astype(np.float32) * depth_scale,
        calibration.get("camera_matrix", calibration.get("matrix")),
        labels,
        calibration.get("frame"),
    )


def camera_cloud(frame, *, limit=30_000):
    y, x = np.where(frame.depth > 0)
    if len(x) > limit:
        chosen = np.linspace(0, len(x) - 1, limit, dtype=int)
        x, y = x[chosen], y[chosen]
    z = frame.depth[y, x]
    points = np.c_[
        (x - frame.camera[0, 2]) * z / frame.camera[0, 0],
        (y - frame.camera[1, 2]) * z / frame.camera[1, 1],
        z,
    ]
    return points.astype(np.float32), frame.rgb[y, x], np.c_[x, y].astype(np.int32)


def model_cloud(mesh):
    """Canonical CAD and origin axes, explicitly separate from measured scene points."""
    points, colors = [mesh.vertices], [mesh.colors]
    for axis in range(3):
        end = np.zeros(3)
        end[axis] = mesh.diameter / 2
        points.append(np.linspace(np.zeros(3), end, 100))
        color = np.zeros(3, np.uint8)
        color[axis] = 255
        colors.append(np.tile(color, (100, 1)))
    return np.concatenate(points).astype(np.float32), np.concatenate(colors).astype(np.uint8)
