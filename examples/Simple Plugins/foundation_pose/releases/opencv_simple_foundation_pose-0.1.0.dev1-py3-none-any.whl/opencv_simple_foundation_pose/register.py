"""Bounded global rotation proposals, learned refinement/ranking and raw-depth fit checks."""

import time
from dataclasses import asdict, dataclass

import numpy as np

from .preprocess import filter_depth, update_poses, xyz_map
from .render import fit_evidence, tensor_pair
from .specs import Frame, Mesh, Settings, rigid


class Cancelled(RuntimeError):
    pass


def initial_poses(frame, filtered, settings):
    import trimesh

    y, x = np.where(frame.mask)
    valid = frame.mask & (frame.depth >= 0.1) & (filtered >= 0.1)
    if len(x) == 0 or valid.sum() < 12:
        return np.empty((0, 4, 4))
    uv = [(float(x.min()) + x.max()) / 2, (float(y.min()) + y.max()) / 2, 1]
    translation = np.linalg.solve(frame.camera, uv) * float(np.median(filtered[valid]))
    views = trimesh.creation.icosphere(subdivisions=1).vertices
    z = -views / np.linalg.norm(views, axis=1)[:, None]
    x_axis = np.cross(np.array([0, 0, 1]), z)
    x_axis[np.linalg.norm(x_axis, axis=1) < 1e-12] = [1, 0, 0]
    x_axis /= np.linalg.norm(x_axis, axis=1)[:, None]
    y_axis = np.cross(z, x_axis)
    rotations = np.stack((x_axis, y_axis, z), axis=-1)
    poses = []
    for rotation in rotations:
        for angle in np.arange(settings.inplane_steps) * 2 * np.pi / settings.inplane_steps:
            c, s = np.cos(angle), np.sin(angle)
            inplane = np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])
            pose = np.eye(4)
            pose[:3, :3] = (rotation @ inplane).T
            pose[:3, 3] = translation
            poses.append(pose)
    return np.asarray(poses)


@dataclass(frozen=True)
class Registration:
    frame: Frame
    mesh: Mesh
    candidates: tuple
    execution: dict

    @property
    def accepted(self):
        return tuple(c for c in self.candidates if c["fit"]["status"] == "accepted")

    @property
    def best(self):
        return self.accepted[0] if self.accepted else None

    def report(self):
        return {
            "model": "simple_foundation_pose_v1",
            "units": "m",
            "source_frame": self.mesh.frame,
            "target_frame": self.frame.frame,
            "passed": self.best is not None,
            "accepted_candidates": len(self.accepted),
            "candidates": list(self.candidates),
            "execution": self.execution,
            "qualification": "Experimental CPU renderer/ONNX pilot; accuracy unqualified",
            "score_semantics": "Raw cohort-dependent ranking logit, not probability",
            "fit_semantics": "Raw depth in meters. Filtered/model points are not observations",
        }


class Estimator:
    def __init__(self, mesh, models, settings=None):
        if not isinstance(mesh, Mesh):
            raise TypeError("Import a validated metric Mesh")
        self.mesh, self.models, self.settings = mesh, models, settings or Settings()
        if not isinstance(self.settings, Settings):
            raise TypeError("Use validated Settings")

    def register(
        self,
        frame,
        *,
        initial=None,
        cancelled=lambda: False,
        progress=lambda stage, current, total: None,
    ):
        if not isinstance(frame, Frame):
            raise TypeError("Use a validated calibrated RGB-D Frame")
        start = time.perf_counter()
        settings, mesh = self.settings, self.mesh
        execution = {
            "settings": asdict(settings),
            "backend": self.models.provenance(),
            "initialization": "global_rotation_grid"
            if initial is None
            else "supplied_coarse_poses",
            "renderer": "bounded_cpu_first_return_triangles_unqualified_vs_cuda",
            "diameter_m": mesh.diameter,
            "model_center_m": mesh.center.tolist(),
            "score_calls": 0,
            "refiner_calls": 0,
            "candidate_count": 0,
        }

        def check():
            if cancelled():
                raise Cancelled("Registration cancelled; no current pose published")

        check()
        filtered = filter_depth(frame.depth)
        filtered_xyz = xyz_map(filtered, frame.camera)
        if initial is None:
            poses = initial_poses(frame, filtered, settings)
        else:
            if not 1 <= len(initial) <= 252:
                raise ValueError("Supply 1..252 original-model-frame coarse poses in meters")
            poses = np.asarray([rigid(p) for p in initial])
            poses[:, :3, 3] += poses[:, :3, :3] @ mesh.center
        prepared_at = time.perf_counter()
        execution["candidate_count"] = len(poses)
        if not len(poses) or (frame.mask & (frame.depth >= 0.1)).sum() < 12:
            execution["stop_reason"] = "insufficient_measured_target_depth"
            return Registration(frame, mesh, (), execution)

        for iteration in range(settings.iterations):
            for offset in range(0, len(poses), settings.refiner_batch):
                check()
                current = poses[offset : offset + settings.refiner_batch]
                pairs = [
                    tensor_pair(mesh, frame, pose, filtered, filtered_xyz)[:2] for pose in current
                ]
                a, b = (np.stack(items) for items in zip(*pairs, strict=True))
                check()
                trans, rot = self.models.refine(a, b)
                execution["refiner_calls"] += 1
                progress(
                    "refinement",
                    iteration * len(poses) + offset + len(current),
                    settings.iterations * len(poses),
                )
                poses[offset : offset + len(current)] = update_poses(
                    current, trans, rot, mesh.diameter
                )
                if np.any(poses[offset : offset + len(current), 2, 3] <= 0.1):
                    raise RuntimeError("Refiner moved the model behind its near plane")
        refined_at = time.perf_counter()
        check()
        # Build each pair separately, but send the complete cohort to the ranking network.
        a = np.empty((len(poses), 6, 160, 160), np.float32)
        b = np.empty_like(a)
        fits = []
        for i, pose in enumerate(poses):
            check()
            a[i], b[i], rendered = tensor_pair(
                mesh, frame, pose, filtered, filtered_xyz, scoring=True
            )
            fits.append(fit_evidence(mesh, frame, pose, settings, rendered))
            progress("score_preparation", i + 1, len(poses))
        score_prepared_at = time.perf_counter()
        logits = self.models.score(a, b)
        execution["score_calls"] = 1
        check()
        candidates = []
        for i in np.argsort(-logits, kind="stable"):
            # Undo only the internal bbox-center shift, retaining the original part origin.
            pose = rigid(poses[i])
            pose[:3, 3] -= pose[:3, :3] @ mesh.center
            candidates.append(
                {
                    "id": int(i),
                    "source_to_target": pose.tolist(),
                    "raw_logit": float(logits[i]),
                    "fit": fits[i],
                }
            )
        execution["seconds"] = {
            "prepare": prepared_at - start,
            "refinement": refined_at - prepared_at,
            "score_prepare_and_fit": score_prepared_at - refined_at,
            "score_inference": time.perf_counter() - score_prepared_at,
            "total": time.perf_counter() - start,
        }
        return Registration(frame, mesh, tuple(candidates), execution)
