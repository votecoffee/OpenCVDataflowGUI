"""Machine-local trusted interpreter/weights configuration, never saved in recipes."""

import json
import os
from pathlib import Path

from .wire import strict_json


def runtime_profile():
    base = Path(os.environ.get("LOCALAPPDATA", Path.home() / ".config"))
    return base / "OpenCVSimpleTools" / "foundationpose-runtime.json"


def _absolute(value, *, directory=False):
    if not isinstance(value, (str, os.PathLike)) or not Path(value).is_absolute():
        raise ValueError("Choose absolute installed runtime and weights paths")
    path = Path(value).resolve(strict=True)
    if not (path.is_dir() if directory else path.is_file()):
        raise ValueError("Choose an installed Python executable and weights directory")
    return str(path)


def runtime_paths():
    values = {}
    profile = runtime_profile()
    if profile.is_file():
        if profile.stat().st_size > 16_384:
            raise ValueError("Oversized FoundationPose runtime profile")
        values = strict_json(profile.read_bytes())
        if not isinstance(values, dict):
            raise ValueError("Invalid FoundationPose runtime profile")
    python = os.environ.get("SIMPLE_FOUNDATION_POSE_PYTHON") or values.get("python")
    weights = os.environ.get("SIMPLE_FOUNDATION_POSE_MODELS") or values.get("weights")
    if not python or not weights:
        raise ValueError("Choose the isolated FoundationPose Python and pinned weights in Runtime")
    return _absolute(python), _absolute(weights, directory=True)


def configure_runtime(python, weights):
    """Explicit setup action; no executable location is accepted from project data."""
    python, weights = _absolute(python), _absolute(weights, directory=True)
    target = runtime_profile()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps({"python": python, "weights": weights}) + "\n", encoding="utf-8", newline="\n"
    )
    os.environ["SIMPLE_FOUNDATION_POSE_PYTHON"] = python
    os.environ["SIMPLE_FOUNDATION_POSE_MODELS"] = weights
