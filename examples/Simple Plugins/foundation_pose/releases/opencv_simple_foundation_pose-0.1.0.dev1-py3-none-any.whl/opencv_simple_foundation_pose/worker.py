"""Private numeric-packet worker. No executable code or model paths in retained training."""

import argparse
import contextlib
import os
import re
import sys
import time
from pathlib import Path

import numpy as np

from .persistence import load_recipe
from .register import Estimator
from .review import overlay, result_cloud
from .runtime import ASSETS, REVISION, OnnxModels
from .specs import Frame, Mesh, capture_id
from .wire import read_packet, strict_json, write_packet


def _stamp(path):
    stat = path.stat()
    return stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns


def _path(value):
    if not isinstance(value, str) or not Path(value).is_absolute():
        raise ValueError("Worker assets require absolute paths selected by the host")
    return Path(value).resolve(strict=True)


class WorkerState:
    """One retained recipe and model pair per process, invalidated by identity/stat changes.

    model_factory exists for analytic unit controls; the process entry point always uses
    hash-verified OnnxModels. It cannot be selected through the wire protocol.
    """

    def __init__(self, *, model_factory=OnnxModels):
        self._factory = model_factory
        self._recipe_key = self._model_key = None
        self.recipe = self.models = None
        self.recipe_loads = self.model_loads = 0

    def close(self):
        if self.models is not None:
            self.models.close()
        self.recipe = self.models = None
        self._recipe_key = self._model_key = None

    def _training(self, metadata):
        path = _path(metadata["recipe_path"])
        digest = metadata["recipe_sha256"]
        if not isinstance(digest, str) or re.fullmatch("[a-f0-9]{64}", digest) is None:
            raise ValueError("Pin the retained recipe with its lowercase SHA-256")
        key = (str(path), digest, _stamp(path))
        recipe_hit = key == self._recipe_key
        if not recipe_hit:
            # A failed replacement cannot leave an older recipe marked current.
            self.recipe, self._recipe_key = None, None
            self.recipe = load_recipe(path, sha256=digest)
            self._recipe_key = key
            self.recipe_loads += 1
        weights = _path(metadata["weights_dir"])
        model_key = (
            str(weights),
            self.recipe.settings.threads,
            tuple((name, _stamp(weights / name)) for name in ASSETS),
        )
        model_hit = model_key == self._model_key
        if not model_hit:
            if self.models is not None:
                self.models.close()
            self.models, self._model_key = None, None
            self.models = self._factory(weights, threads=self.recipe.settings.threads)
            self._model_key = model_key
            self.model_loads += 1
        return dict(
            recipe_hit=recipe_hit,
            models_hit=model_hit,
            recipe_loads=self.recipe_loads,
            model_loads=self.model_loads,
        )

    def run(self, operation, metadata, arrays, *, progress=lambda stage, current, total: None):
        if not isinstance(metadata, dict) or not isinstance(arrays, dict):
            raise ValueError("Worker metadata and arrays must be objects")
        if operation == "describe":
            if arrays:
                raise ValueError("Describe takes no arrays")
            return dict(
                protocol=1,
                pid=os.getpid(),
                weights_revision=REVISION,
                operations=["describe", "import_mesh", "register"],
                score_semantics="raw_cohort_dependent_logit",
                provider="CPUExecutionProvider",
                qualification="Experimental CPU renderer/ONNX pilot; accuracy unqualified",
            ), {}
        if operation == "import_mesh":
            if arrays:
                raise ValueError("Mesh import takes no arrays")
            mesh = Mesh.read(
                _path(metadata["path"]), scale=metadata["scale"], frame=metadata["frame"]
            )
            return dict(
                units="m",
                frame=mesh.frame,
                diameter_m=mesh.diameter,
                original_origin_preserved=True,
            ), dict(vertices=mesh.vertices, faces=mesh.faces, colors=mesh.colors)
        if operation != "register":
            raise ValueError("Unknown FoundationPose operation")
        if set(arrays) not in (
            {"rgb", "depth", "camera", "mask"},
            {"rgb", "depth", "camera", "mask", "initial"},
        ):
            raise ValueError("Supply RGB, metric depth, camera and one instance mask")
        current_id = capture_id(metadata["capture_id"])
        graphics = metadata.get("graphics", True)
        if type(graphics) is not bool:
            raise ValueError("Graphics must be a boolean")
        frame = Frame(
            arrays["rgb"], arrays["depth"], arrays["camera"], arrays["mask"], metadata["frame"]
        )
        prepared = time.perf_counter()
        progress("loading", 0, 1)
        cache = self._training(metadata)
        loaded = time.perf_counter()
        progress("loading", 1, 1)
        result = Estimator(self.recipe.mesh, self.models, self.recipe.settings).register(
            frame,
            initial=arrays.get("initial"),
            progress=progress,
        )
        report = result.report()
        report.update(
            capture_id=current_id,
            recipe_sha256=metadata["recipe_sha256"],
            input_assistance="Supplied single-instance visible mask; calibrated registered RGB-D",
        )
        output = dict(
            accepted_poses=np.asarray(
                [item["source_to_target"] for item in result.accepted],
                dtype=np.float64,
            ).reshape(-1, 4, 4),
        )
        graphics_started = time.perf_counter()
        if graphics:
            output["overlay_rgb"] = overlay(result)
            output["review_xyz"], output["review_rgb"] = result_cloud(result)
            scene_count = int(min(30_000, (frame.depth > 0).sum()))
            selected = result.best or (result.candidates[0] if result.candidates else None)
            report["review"] = dict(
                selected_candidate_id=selected["id"] if selected else None,
                accepted=bool(result.best),
                frame=frame.frame,
                units="m",
                components=dict(
                    measured_scene=[0, scene_count],
                    derived_model=[scene_count, scene_count + len(self.recipe.mesh.vertices)]
                    if selected
                    else [scene_count, scene_count],
                    derived_pose_axes=[
                        scene_count + len(self.recipe.mesh.vertices),
                        len(output["review_xyz"]),
                    ]
                    if selected
                    else [scene_count, scene_count],
                ),
                colors=dict(
                    agreement=[40, 240, 80],
                    free_space_contradiction=[255, 40, 70],
                    occluded=[120, 100, 240],
                    unknown=[255, 160, 0],
                ),
                semantics="Diagnostic cloud includes derived model and axes, even on rejection",
            )
        report["worker"] = dict(
            pid=os.getpid(),
            cache=cache,
            training_load_seconds=loaded - prepared,
            graphics_seconds=time.perf_counter() - graphics_started,
        )
        return dict(report=report), output


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    root = parser.parse_args(argv).root.resolve(strict=True)
    if not root.is_dir():
        raise ValueError("Select the private worker packet directory")
    protocol = sys.stdout

    def send(message):
        import json

        protocol.write(json.dumps(message, allow_nan=False) + "\n")
        protocol.flush()

    state = WorkerState()
    try:
        while line := sys.stdin.buffer.readline(65_537):
            identifier = None
            try:
                if len(line) > 65_536:
                    raise ValueError("Oversized worker protocol message")
                message = strict_json(line)
                if not isinstance(message, dict) or set(message) != {"id", "op"}:
                    raise ValueError("Invalid request header")
                identifier = message["id"]
                if not isinstance(identifier, str) or not re.fullmatch("[a-f0-9]{32}", identifier):
                    raise ValueError("Invalid private request identifier")
                job = (root / identifier).resolve(strict=True)
                if job.parent != root:
                    raise ValueError("Request resolves outside private worker storage")
                started = time.perf_counter()
                last_progress = 0.0

                def progress(stage, current, total):
                    nonlocal last_progress
                    now = time.monotonic()
                    if now - last_progress >= 0.25 or current == total:
                        send(
                            dict(
                                id=identifier,
                                event="progress",
                                progress=dict(
                                    stage=stage,
                                    current=int(current),
                                    total=int(total),
                                ),
                            )
                        )
                        last_progress = now

                with contextlib.redirect_stdout(sys.stderr):
                    metadata, arrays = read_packet(job)
                    read_at = time.perf_counter()
                    metadata, arrays = state.run(message["op"], metadata, arrays, progress=progress)
                    calculated = time.perf_counter()
                    destination = job / "result"
                    destination.mkdir()
                    write_packet(destination, metadata, arrays)
                send(
                    dict(
                        id=identifier,
                        ok=True,
                        timing=dict(
                            read_seconds=read_at - started,
                            calculation_seconds=calculated - read_at,
                            write_seconds=time.perf_counter() - calculated,
                        ),
                    )
                )
            except Exception as error:
                send(dict(id=identifier, ok=False, error=f"{type(error).__name__}: {error}"[:2000]))
    finally:
        state.close()


if __name__ == "__main__":
    main()
