"""Source-aligned pose/fit images and native XYZ/RGB first-return review exports."""

import json
from pathlib import Path

import cv2
import numpy as np

from .specs import rigid


def overlay(result, *, candidate=None):
    frame, mesh = result.frame, result.mesh
    image = frame.rgb.copy()
    if candidate is None:
        candidate = result.best or (result.candidates[0] if result.candidates else None)
    if candidate is None:
        cv2.putText(
            image, "No observed target", (12, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 80, 80), 2
        )
        return image
    pose = np.asarray(candidate["source_to_target"])
    # Both image and cloud axes identify the ORIGINAL part origin, not bbox center.
    center = pose[:3, 3]
    scale = mesh.diameter / 3
    points = np.r_[center[None], center + scale * pose[:3, :3].T]
    projected = points @ frame.camera.T
    uv = np.rint(
        np.clip(
            projected[:, :2] / np.maximum(projected[:, 2:3], 1e-20),
            -1e9,
            1e9,
        )
    ).astype(int)
    for axis, color in enumerate(((255, 0, 0), (0, 255, 0), (60, 120, 255))):
        if points[0, 2] >= 0.1 and points[axis + 1, 2] >= 0.1:
            visible, start, end = cv2.clipLine(
                (0, 0, image.shape[1], image.shape[0]), tuple(uv[0]), tuple(uv[axis + 1])
            )
            if visible:
                cv2.arrowedLine(image, start, end, color, 2, cv2.LINE_AA, tipLength=0.15)
    vertices = mesh.vertices @ pose[:3, :3].T + pose[:3, 3]
    projected = vertices @ frame.camera.T
    uv = np.rint(projected[:, :2] / np.maximum(projected[:, 2:3], 1e-20)).astype(int)
    h, w = frame.depth.shape
    inside = (
        (vertices[:, 2] >= 0.1)
        & (uv[:, 0] >= 0)
        & (uv[:, 0] < w)
        & (uv[:, 1] >= 0)
        & (uv[:, 1] < h)
    )
    ids = np.flatnonzero(inside)
    x, y = uv[ids].T
    depth = frame.depth[y, x]
    delta = vertices[ids, 2] - depth
    tolerance = result.execution["settings"]["distance_tolerance"]
    known = depth >= 0.1
    colors = np.tile([255, 160, 0], (len(ids), 1))
    colors[known & (np.abs(delta) <= tolerance)] = [40, 240, 80]
    colors[known & (delta < -tolerance)] = [255, 40, 70]
    colors[known & (delta > tolerance)] = [120, 100, 240]
    image[y, x] = colors
    fit = candidate["fit"]
    label = f"{fit['status']} coverage={fit['coverage']:.2f} raw logit={candidate['raw_logit']:.2f}"
    cv2.putText(image, label, (12, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 230, 30), 2)
    return image


def result_cloud(result, *, candidate=None):
    frame, mesh = result.frame, result.mesh
    y, x = np.where(frame.depth > 0)
    if len(x) > 30_000:
        selected = np.linspace(0, len(x) - 1, 30_000, dtype=int)
        x, y = x[selected], y[selected]
    z = frame.depth[y, x]
    scene = np.c_[
        (x - frame.camera[0, 2]) * z / frame.camera[0, 0],
        (y - frame.camera[1, 2]) * z / frame.camera[1, 1],
        z,
    ]
    xyz, colors = [scene], [frame.rgb[y, x]]
    if candidate is None:
        candidate = result.best or (result.candidates[0] if result.candidates else None)
    if candidate is not None:
        pose = rigid(candidate["source_to_target"])
        points = mesh.vertices @ pose[:3, :3].T + pose[:3, 3]
        projection = points @ frame.camera.T
        pixels = np.rint(projection[:, :2] / np.maximum(projection[:, 2:3], 1e-20)).astype(int)
        px, py = pixels.T
        h, w = frame.depth.shape
        inside = (px >= 0) & (px < w) & (py >= 0) & (py < h) & (points[:, 2] >= 0.1)
        observed = frame.depth[np.clip(py, 0, h - 1), np.clip(px, 0, w - 1)]
        known = inside & (observed >= 0.1)
        delta = points[:, 2] - observed
        tolerance = result.execution["settings"]["distance_tolerance"]
        rgb = np.tile([255, 160, 0], (len(points), 1))
        rgb[known & (np.abs(delta) <= tolerance)] = [40, 240, 80]
        rgb[known & (delta < -tolerance)] = [255, 40, 70]
        rgb[known & (delta > tolerance)] = [120, 100, 240]
        xyz.append(points)
        colors.append(rgb)
        origin = pose[:3, 3]
        for axis in range(3):
            line = np.linspace(origin, origin + pose[:3, axis] * mesh.diameter / 2, 100)
            color = np.zeros(3, np.uint8)
            color[axis] = 255
            xyz.append(line)
            colors.append(np.tile(color, (len(line), 1)))
    return np.concatenate(xyz).astype(np.float32), np.concatenate(colors).astype(np.uint8)


def export_review(folder, result):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=False)
    report = json.dumps(result.report(), indent=2, allow_nan=False) + "\n"
    (folder / "report.json").write_bytes(report.encode("utf-8"))
    cv2.imwrite(str(folder / "overlay.png"), overlay(result)[..., ::-1])
    points, colors = result_cloud(result)
    # Standard binary RGB PLY opens directly in the host's native flyaround viewer.
    header = (
        "ply\nformat binary_little_endian 1.0\ncomment units=m frame="
        + result.frame.frame
        + f"\nelement vertex {len(points)}\nproperty float x\nproperty float y\nproperty float z\n"
        "property uchar red\nproperty uchar green\nproperty uchar blue\nend_header\n"
    )
    data = np.empty(len(points), dtype=[("xyz", "<f4", (3,)), ("rgb", "u1", (3,))])
    data["xyz"], data["rgb"] = points, colors
    (folder / "fit.ply").write_bytes(header.encode("utf-8") + data.tobytes())
    np.savez_compressed(
        folder / "capture.npz",
        rgb=result.frame.rgb,
        depth=result.frame.depth,
        mask=result.frame.mask,
        camera=result.frame.camera,
        frame=np.array(result.frame.frame),
        units=np.array("m"),
    )
    return folder
