"""Pinned NVIDIA models; CPU-only sessions and a complete scoring cohort.

The scorer attends across pose hypotheses. Splitting its cohort changes scores;
only the independently checked refinement network may be microbatched.
"""

import hashlib
import threading
import time
from pathlib import Path

import numpy as np

REVISION = "18d8309afc9790cddc03a1d50bc69954dc058693"
ASSETS = {
    "refiner_net.onnx": (
        68158609,
        "4a4445d2506b1bfc0a8d62fa80f8780a7e37bb0df13bb09aa5dd04a03bf0c954",
    ),
    "score_net.onnx": (
        63910103,
        "bb7208919557560ecb0e10a30612821f0025a2578190b17677bdf3653514a48d",
    ),
}


class OnnxModels:
    def __init__(self, directory, *, threads=4):
        started = time.perf_counter()
        if type(threads) is not int or not 1 <= threads <= 8:
            raise ValueError("CPU threads must be in 1..8")
        self.paths = {}
        for name, (size, digest) in ASSETS.items():
            path = Path(directory) / name
            if (
                path.stat().st_size != size
                or hashlib.sha256(path.read_bytes()).hexdigest() != digest
            ):
                raise ValueError(f"NVIDIA {name} differs from pinned size/SHA-256")
            self.paths[name] = path
        import onnxruntime as ort

        options = ort.SessionOptions()
        options.intra_op_num_threads = threads
        options.inter_op_num_threads = 1
        options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        self._sessions = {
            name: ort.InferenceSession(str(path), options, providers=["CPUExecutionProvider"])
            for name, path in self.paths.items()
        }
        self.lock = threading.RLock()
        self.version = ort.__version__
        self.threads, self.closed = threads, False
        for name, session in self._sessions.items():
            inputs = session.get_inputs()
            if [x.name for x in inputs] != ["inputA", "inputB"] or any(
                x.type != "tensor(float)" or x.shape[1:] != [6, 160, 160] for x in inputs
            ):
                raise ValueError(f"Unexpected tensor interface: {name}")
        if [x.name for x in self._sessions["refiner_net.onnx"].get_outputs()] != ["trans", "rot"]:
            raise ValueError("Unexpected refiner outputs")
        if [x.name for x in self._sessions["score_net.onnx"].get_outputs()] != ["score_logit"]:
            raise ValueError("Unexpected scorer outputs")
        self.compile_seconds = time.perf_counter() - started

    @staticmethod
    def _inputs(a, b):
        if (
            a.shape != b.shape
            or a.ndim != 4
            or a.shape[1:] != (6, 160, 160)
            or not 1 <= len(a) <= 252
            or a.dtype != np.float32
            or b.dtype != np.float32
            or not np.isfinite(a).all()
            or not np.isfinite(b).all()
        ):
            raise ValueError("Networks require 1..252 finite float32 N×6×160×160 pairs")
        return {"inputA": np.ascontiguousarray(a), "inputB": np.ascontiguousarray(b)}

    def refine(self, a, b):
        with self.lock:
            if self.closed:
                raise RuntimeError("Inference sessions are closed")
            values = self._sessions["refiner_net.onnx"].run(None, self._inputs(a, b))
        if any(x.shape != (len(a), 3) or not np.isfinite(x).all() for x in values):
            raise RuntimeError("Invalid refinement reply")
        return values

    def score(self, a, b):
        # One run for the complete cohort. Never chunk this into independent scores.
        with self.lock:
            if self.closed:
                raise RuntimeError("Inference sessions are closed")
            [values] = self._sessions["score_net.onnx"].run(None, self._inputs(a, b))
        if values.shape != (len(a), 1) or not np.isfinite(values).all():
            raise RuntimeError("Invalid scoring reply")
        return values[:, 0]

    def provenance(self):
        return {
            "model": "nvidia/foundationpose",
            "revision": REVISION,
            "assets": {name: digest for name, (_, digest) in ASSETS.items()},
            "runtime": "onnxruntime",
            "version": self.version,
            "provider": "CPUExecutionProvider",
            "threads": self.threads,
            "compile_seconds": self.compile_seconds,
            "score_semantics": "raw_cohort_dependent_logit",
        }

    def close(self):
        with self.lock:
            self._sessions.clear()
            self.closed = True
