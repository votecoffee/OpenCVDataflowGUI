"""CPU triangle first-return renderer; no hidden-surface scene samples or GPU context.

This development renderer is not claimed pixel-identical to NVIDIA's CUDA
rasterizer. Its perspective/occlusion behavior is checked on analytic surfaces.
"""

import numpy as np

from .preprocess import normalize_xyz, sample, scorer_xyz, warp_coordinates


def render(mesh, pose, camera, transform=None, shape=(160, 160)):
    h, w = shape
    vertices = (mesh.vertices - mesh.center) @ pose[:3, :3].T + pose[:3, 3]
    projected = vertices @ camera.T
    projected = projected[:, :2] / np.maximum(projected[:, 2:3], 1e-20)
    if transform is not None:
        # TAO renders the crop's 0..159 inverse-mapped box onto 160 pixel centers.
        projected = np.c_[projected, np.ones(len(projected))] @ transform.T
        projected = projected[:, :2] * 160 / 159 - 0.5
    normals = mesh.normals @ pose[:3, :3].T
    diffuse = np.clip(-normals[:, 2], 0, 1)
    zbuffer = np.full(shape, np.inf, np.float64)
    xyz = np.zeros((*shape, 3), np.float32)
    rgb = np.zeros_like(xyz)
    vertex_colors = mesh.colors.astype(np.float64) / 255
    for indices in mesh.faces:
        points = vertices[indices]
        if np.any(points[:, 2] < 0.1):
            # Abstain on near-plane-crossing triangles; no fabricated clipping geometry.
            continue
        p = projected[indices]
        x0, y0 = np.maximum(0, np.ceil(p.min(axis=0))).astype(int)
        x1, y1 = np.minimum([w - 1, h - 1], np.floor(p.max(axis=0))).astype(int)
        if x1 < x0 or y1 < y0:
            continue
        a, b, c = p
        denominator = (b[1] - c[1]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[1] - c[1])
        if abs(denominator) < 1e-12:
            continue
        y, x = np.mgrid[y0 : y1 + 1, x0 : x1 + 1]
        l0 = ((b[1] - c[1]) * (x - c[0]) + (c[0] - b[0]) * (y - c[1])) / denominator
        l1 = ((c[1] - a[1]) * (x - c[0]) + (a[0] - c[0]) * (y - c[1])) / denominator
        bary = np.stack((l0, l1, 1 - l0 - l1), axis=-1)
        reciprocal = bary / points[:, 2]
        depth = 1 / np.maximum(reciprocal.sum(axis=-1), 1e-20)
        target = zbuffer[y0 : y1 + 1, x0 : x1 + 1]
        inside = (bary.min(axis=-1) >= -1e-8) & (depth < target)
        if not inside.any():
            continue
        weights = reciprocal * depth[..., None]
        values = weights @ points
        colors = np.clip(
            (weights @ vertex_colors[indices])
            * (0.8 + 0.5 * (weights @ diffuse[indices]))[..., None],
            0,
            1,
        )
        target[inside] = depth[inside]
        xyz[y0 : y1 + 1, x0 : x1 + 1][inside] = values[inside]
        rgb[y0 : y1 + 1, x0 : x1 + 1][inside] = colors[inside]
    return rgb, xyz


def tensor_pair(mesh, frame, pose, filtered, filtered_xyz, *, scoring=False):
    from .preprocess import crop_transform

    tf = crop_transform(pose, mesh.diameter, frame.camera, 1.1 if scoring else 1.2)
    rendered_rgb, rendered_xyz = render(mesh, pose, frame.camera, tf)
    x, y = warp_coordinates(tf, frame.depth.shape)
    observed_rgb = sample(frame.rgb, x, y, linear=True) / 255
    if scoring:
        observed_depth = sample(filtered, x, y)
        model_xyz = scorer_xyz(rendered_xyz[..., 2], tf, frame.depth.shape, frame.camera)
        observed_xyz = scorer_xyz(observed_depth, tf, frame.depth.shape, frame.camera)
    else:
        model_xyz = rendered_xyz
        observed_xyz = sample(filtered_xyz, x, y)
    a = np.concatenate((rendered_rgb, normalize_xyz(model_xyz, pose[:3, 3], mesh.diameter / 2)), -1)
    b = np.concatenate(
        (observed_rgb, normalize_xyz(observed_xyz, pose[:3, 3], mesh.diameter / 2)), -1
    )
    return a.transpose(2, 0, 1).copy(), b.transpose(2, 0, 1).copy(), rendered_xyz


def fit_evidence(mesh, frame, pose, settings, rendered=None):
    if rendered is None:
        from .preprocess import crop_transform

        _, rendered = render(
            mesh, pose, frame.camera, crop_transform(pose, mesh.diameter, frame.camera, 1.1)
        )
    points = rendered[rendered[..., 2] >= 0.1]
    if not len(points):
        return {
            "status": "rejected",
            "reason": "no_rendered_surface",
            "coverage": 0.0,
            "contradiction": 0.0,
            "rmse_m": None,
            "rendered_samples": 0,
        }
    projected = points @ frame.camera.T
    pixels = np.rint(projected[:, :2] / projected[:, 2:3]).astype(int)
    x, y = pixels.T
    h, w = frame.depth.shape
    inside = (x >= 0) & (y >= 0) & (x < w) & (y < h)
    z = frame.depth[np.clip(y, 0, h - 1), np.clip(x, 0, w - 1)]
    target = frame.mask[np.clip(y, 0, h - 1), np.clip(x, 0, w - 1)] & inside
    known = inside & (z >= 0.1)
    delta = points[:, 2] - z
    supported = known & target & (np.abs(delta) <= settings.distance_tolerance)
    contradicted = known & (delta < -settings.distance_tolerance)
    coverage, contradiction = float(supported.mean()), float(contradicted.mean())
    accepted = (
        coverage >= settings.minimum_coverage and contradiction <= settings.maximum_contradiction
    )
    return {
        "status": "accepted" if accepted else "rejected",
        "reason": "fit_gates",
        "coverage": coverage,
        "contradiction": contradiction,
        "rmse_m": float(np.sqrt(np.mean(delta[supported] ** 2))) if supported.any() else None,
        "rendered_samples": len(points),
        "supported_samples": int(supported.sum()),
        "unknown_samples": int((~known).sum()),
        "occluded_samples": int((known & (delta > settings.distance_tolerance)).sum()),
        "outside_target_samples": int((known & ~target).sum()),
    }
