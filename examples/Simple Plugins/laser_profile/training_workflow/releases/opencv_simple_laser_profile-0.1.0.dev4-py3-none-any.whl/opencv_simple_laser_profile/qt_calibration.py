"""Read-only calibration coefficients/evidence and an explicit single-pixel ray check."""

import json

import numpy as np
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPlainTextEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from .calibration_setup import calibration_summary
from .geometry import intersect_pixels


class CalibrationReviewDialog(QDialog):
    def __init__(self, parent, camera, laser, evidence, *, allow_apply=False):
        super().__init__(parent)
        self.camera, self.laser = camera, laser
        self.setWindowTitle("Laser calibration · coefficients and evidence")
        available = self.screen().availableGeometry()
        self.resize(min(880, available.width() - 40), min(720, available.height() - 40))
        layout = QVBoxLayout(self)
        summary = QLabel(calibration_summary(camera, laser, evidence))
        summary.setWordWrap(True)
        layout.addWidget(summary)
        self.fit_summary = QLabel("No structured fit/validation record retained.")
        self.fit_summary.setWordWrap(True)
        layout.addWidget(self.fit_summary)
        self.observations = QTableWidget(0, 5)
        self.observations.setHorizontalHeaderLabels(
            ["Role", "ID", "Used / available", "Supplied", "Max target agreement (m)"]
        )
        self.observations.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.observations.setMaximumHeight(160)
        layout.addWidget(self.observations)
        fit = evidence.get("calibration_fit")
        if isinstance(fit, dict):
            self.fit_summary.setText(
                f"Reported fit RMS {fit.get('rmse_plane_residual_m')} m; "
                f"in-plane rank ratio {fit.get('in_plane_rank_ratio')}. "
                "Training residuals and validation target agreement have different meanings. "
                "Observation IDs do not establish independent acquisitions."
            )
            try:
                rows = [
                    ("Training", name, str(count), str(count), "Used for fit")
                    for name, count in zip(
                        fit.get("training_ids", []), fit.get("training_point_counts", [])
                    )
                ]
                rows += [
                    (
                        "Validation",
                        view["identifier"],
                        str(view["available_points"]),
                        str(view["supplied_points"]),
                        "Unavailable"
                        if view["maximum_point_distance_m"] is None
                        else f"{view['maximum_point_distance_m']:.9g}",
                    )
                    for view in fit.get("validation", [])
                ]
            except (KeyError, TypeError, ValueError):
                rows = []
                self.fit_summary.setText(
                    "Unrecognized fit metadata; review the raw retained JSON. "
                    "No fit/validation health is inferred from it."
                )
            self.observations.setRowCount(len(rows))
            for i, row in enumerate(rows):
                for j, value in enumerate(row):
                    self.observations.setItem(i, j, QTableWidgetItem(value))
            self.observations.resizeColumnsToContents()
        self.metadata = QPlainTextEdit()
        self.metadata.setReadOnly(True)
        self.metadata.setPlainText(
            json.dumps(evidence, indent=2, ensure_ascii=False, allow_nan=False)
        )
        layout.addWidget(self.metadata, 1)
        row = QHBoxLayout()
        layout.addLayout(row)
        self.pixel = [
            QLineEdit(repr(camera.image_size[i] / 2) if camera else "0") for i in range(2)
        ]
        for title, field in zip(("Source X (px)", "Source Y (px)"), self.pixel):
            row.addWidget(QLabel(title))
            row.addWidget(field)
        self.probe_button = QPushButton("Check pixel ray")
        self.probe_button.setEnabled(camera is not None)
        self.probe_button.clicked.connect(self.probe)
        row.addWidget(self.probe_button)
        self.probe_result = QLabel(
            "This checks declared geometry, not stripe presence or accuracy."
        )
        self.probe_result.setWordWrap(True)
        layout.addWidget(self.probe_result)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Close / keep draft")
        buttons.rejected.connect(self.reject)
        if allow_apply:
            use = buttons.addButton(
                "Use calibration in training draft", QDialogButtonBox.ButtonRole.AcceptRole
            )
            use.clicked.connect(self.accept)
        layout.addWidget(buttons)

    def probe(self):
        try:
            result = intersect_pixels(
                self.camera, self.laser, np.array([[float(field.text()) for field in self.pixel]])
            )
            reason = result["reason"][0]
            if not result["valid"][0]:
                text = f"Unavailable: {reason}. No XYZ point."
            else:
                xyz = tuple(float(v) for v in result["xyz_m"][0])
                text = (
                    f"XYZ {xyz} m · frame {result['frame']}; "
                    f"incidence {result['incidence'][0]:.6g}. "
                    "Declared ray/plane intersection; not a detected stripe sample."
                )
            self.probe_result.setText(text)
        except ValueError as error:
            self.probe_result.setText(str(error))
