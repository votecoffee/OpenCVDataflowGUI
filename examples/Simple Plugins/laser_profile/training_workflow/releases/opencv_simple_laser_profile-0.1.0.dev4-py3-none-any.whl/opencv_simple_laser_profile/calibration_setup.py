"""Explicit known-target laser-plane teaching; validation never participates in fitting."""

import copy
import json
from pathlib import Path

import numpy as np

from .geometry import Camera, Observation, Plane, calibrate_plane, intersect_pixels
from .recipe import strict_json

LIMIT = 4 * 1024 * 1024
SCHEMA = "simple_laser_observations/v1"


def read_observations(path):
    path = Path(path)
    if path.stat().st_size > LIMIT:
        raise ValueError("Calibration observations exceed 4 MiB")
    return strict_json(path.read_bytes())


def fit_observations(record, *, cancelled=lambda: False):
    """Fit explicit camera-frame target hits and report separate declared validation views."""
    if not isinstance(record, dict):
        raise ValueError("Calibration observations must be a JSON object")
    raw = json.dumps(record, allow_nan=False).encode("utf-8")
    if len(raw) > LIMIT:
        raise ValueError("Calibration observations exceed 4 MiB")
    record = strict_json(raw)
    if record.get("schema") != SCHEMA or record.get("units") != "m":
        raise ValueError("Use simple_laser_observations/v1 with explicit units m")
    if not isinstance(record.get("camera"), dict):
        raise ValueError("Supply an explicit camera calibration object")
    camera = Camera(**record["camera"])
    views = record.get("observations")
    if not isinstance(views, list) or not 2 <= len(views) <= 256:
        raise ValueError("Supply 2..256 uniquely identified training/validation observations")
    groups = {"training": [], "validation": []}
    identifiers, total = set(), 0
    for view in views:
        if cancelled():
            raise RuntimeError("Calibration fit cancelled")
        if not isinstance(view, dict):
            raise ValueError("Each observation must be a JSON object")
        identifier, role = view.get("identifier"), view.get("role")
        if (
            not isinstance(identifier, str)
            or not identifier.strip()
            or len(identifier) > 128
            or identifier in identifiers
            or role not in groups
        ):
            raise ValueError("Use unique observation IDs and explicit training/validation roles")
        identifiers.add(identifier)
        pixels = np.asarray(view["pixels"], dtype=float)
        if pixels.ndim != 2 or pixels.shape[1:] != (2,) or len(pixels) < 3:
            raise ValueError("Each observation needs at least three finite source pixel pairs")
        total += len(pixels)
        if total > 100000 or not np.isfinite(pixels).all():
            raise ValueError("Bound calibration to 100000 finite source pixel pairs")
        if ("target_plane" in view) == ("target_depth_m" in view):
            raise ValueError("Declare exactly one target_plane or target_depth_m per observation")
        if "target_depth_m" in view:
            depth = view["target_depth_m"]
            if (
                isinstance(depth, bool)
                or not isinstance(depth, (int, float))
                or not 0 < depth <= 100
            ):
                raise ValueError(
                    "Target axial depth must be explicitly positive meters within 100 m"
                )
            plane = Plane([0, 0, 1], -depth, camera.frame)
        else:
            plane = Plane(**view["target_plane"])
        if plane.frame != camera.frame:
            raise ValueError("Target planes must use the declared physical camera frame")
        groups[role].append(Observation(identifier, pixels, plane))
    fitted = calibrate_plane(camera, groups["training"])
    if cancelled():
        raise RuntimeError("Calibration fit cancelled")
    plane = fitted["plane"]
    validation = []
    for view in groups["validation"]:
        if cancelled():
            raise RuntimeError("Calibration fit cancelled")
        target = intersect_pixels(camera, view.target_plane, view.pixels)
        predicted = intersect_pixels(camera, plane, view.pixels)
        valid = target["valid"] & predicted["valid"]
        errors = np.linalg.norm(predicted["xyz_m"][valid] - target["xyz_m"][valid], axis=1)
        validation.append(
            dict(
                identifier=view.identifier,
                supplied_points=len(valid),
                available_points=int(valid.sum()),
                unavailable_points=int((~valid).sum()),
                rmse_point_distance_m=float(np.sqrt(np.mean(errors**2))) if len(errors) else None,
                maximum_point_distance_m=float(errors.max()) if len(errors) else None,
                target_reasons=_counts(target["reason"]),
                laser_reasons=_counts(predicted["reason"]),
            )
        )
    evidence = dict(
        schema="simple_laser_calibration/v1",
        source=record.get("source", "Declared target hits"),
        camera=dict(
            matrix=camera.matrix.tolist(),
            image_size=list(camera.image_size),
            distortion=[float(v) for v in camera.distortion],
            frame=camera.frame,
        ),
        laser=dict(normal=plane.normal.tolist(), offset_m=plane.offset_m, frame=plane.frame),
        observations=copy.deepcopy(views),
        calibration_fit=dict(
            method=fitted["method"],
            units="m",
            frame=camera.frame,
            training_ids=fitted["observation_ids"],
            training_point_counts=fitted["observation_point_counts"],
            rmse_plane_residual_m=fitted["rmse_m"],
            maximum_abs_plane_residual_m=fitted["maximum_abs_residual_m"],
            in_plane_rank_ratio=fitted["in_plane_rank_ratio"],
            validation=validation,
            scope="Declared target/calibration agreement; no automatic acceptance threshold, "
            "independent capture proof or physical gauge qualification",
        ),
    )
    if len(json.dumps(evidence, allow_nan=False).encode("utf-8")) > LIMIT:
        raise ValueError("Fitted calibration metadata exceeds 4 MiB; reduce observation count")
    return camera, plane, evidence


def _counts(reasons):
    keys, counts = np.unique(reasons, return_counts=True)
    return dict(zip(keys.tolist(), counts.tolist()))


def calibration_summary(camera, laser, evidence):
    if camera is None:
        return "PIXEL ONLY: no camera/laser calibration; no metric XYZ or cloud."
    normal = tuple(float(v) for v in laser.normal)
    return (
        f"METRIC m · camera frame {camera.frame} · "
        f"{camera.image_size[0]} x {camera.image_size[1]}\n"
        f"fx/fy {camera.matrix[0, 0]:.9g}/{camera.matrix[1, 1]:.9g} px; "
        f"{len(camera.distortion)} pinhole distortion coefficients.\n"
        f"Laser: normal {normal}; offset {laser.offset_m:.12g} m. "
        "normal dot XYZ + offset = 0. Camera axes: X right, Y down, Z forward.\n"
        "Default geometry checks use camera Z 0.001..100 m and incidence >= 1e-6. "
        "Missing/behind/parallel/out-of-range rays stay unavailable.\n"
        f"Source: {evidence.get('source', 'No retained calibration source description')}. "
        "Imported fit metadata is reported evidence, not a recomputed or independent gauge check."
    )
