"""One cached execution block; Qt is imported only when opening its trainer."""

import re
from pathlib import Path, PurePosixPath

import numpy as np
from opencv_dataflow.core import Port, Result
from opencv_dataflow.geometry3d_common import Tool3D
from opencv_dataflow.graphics_layers import GraphicDrawing, graphic_object
from opencv_dataflow.images import ImageArray, image_format
from opencv_dataflow.parameter_validation import NumericRange, ValidationError
from opencv_dataflow.payloads import NO_VALUE, frame, metadata
from opencv_dataflow.pointclouds import PointCloud

from .cli import execute
from .recipe import load_recipe
from .render import color


def recipe_path(project_dir, relative):
    if project_dir is None:
        raise ValueError("Save the project before staging a laser-profile recipe")
    path = PurePosixPath(relative)
    if (
        not relative
        or path.is_absolute()
        or ".." in path.parts
        or ":" in relative
        or "\\" in relative
        or path.suffix != ".slp"
    ):
        raise ValueError("Choose a project-contained .slp recipe using forward slashes")
    root = Path(project_dir).resolve()
    target = (root / relative).resolve()
    if not target.is_relative_to(root):
        raise ValueError("Recipe resolves outside the project directory")
    return target


def source_image(image, payload=None):
    """Keep physical calibration on the original, unwarped source pixel grid."""
    if not isinstance(image, np.ndarray) or image.ndim not in (2, 3):
        raise ValueError("Connect a grayscale or RGB/BGR source image")
    encoding = image_format(image)
    if (image.ndim == 2 and encoding == "gray") or (
        image.ndim == 3 and image.shape[2] == 3 and encoding in ("rgb", "bgr")
    ):
        spatial = (payload or metadata(image)).get("spatial")
        size = list(image.shape[1::-1])
        if spatial is not None and (
            spatial.get("image_size") != size
            or spatial.get("root_size") != size
            or not np.allclose(spatial.get("to_root"), np.eye(3), atol=1e-12, rtol=0)
        ):
            raise ValueError(
                "Use the original pixel grid; crop/warp/pyramid calibration is unsupported"
            )
        return np.asarray(image)[:, :, ::-1].copy() if encoding == "bgr" else np.asarray(image)
    raise ValueError("Use gray or explicit RGB/BGR; convert other channel encodings upstream")


def signature(path):
    stat = path.stat()
    return stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns, stat.st_ino


class RecipeCache:
    def __init__(self):
        self.key = self.recipe = None

    def get(self, path, digest):
        key = str(path), digest, signature(path)
        if key != self.key:
            recipe = load_recipe(path, sha256=digest)
            if signature(path) != key[2]:
                raise ValueError("Recipe changed during loading; retry with the current recipe")
            self.key, self.recipe = key, recipe
        return self.recipe


def result_cloud(result, *, colors=True):
    if not result["report"]["calibrated"] or not result["valid"].any():
        return NO_VALUE
    ids = np.flatnonzero(result["valid"])
    return PointCloud(
        result["xyz_m"][ids],
        "m",
        result["report"]["frame"],
        colors=np.tile([35, 210, 70], (len(ids), 1)) if colors else None,
        pixels=np.rint(result["stripe"]["pixels"][ids]).astype(np.int32),
        source_size=tuple(result["report"]["image_size"]),
        metadata={"laser_profile": {"source_bins": ids.tolist(), "gap_filling": False}},
    )


def stripe_drawing(result):
    objects, pixels = [], result["stripe"]["pixels"]
    # Keep accepted segments separate at every unavailable source bin.
    start = None
    for index in range(len(pixels) + 1):
        valid = index < len(pixels) and result["valid"][index]
        if valid and start is None:
            start = index
        elif not valid and start is not None:
            kind = "marker" if index - start == 1 else "polyline"
            objects.append(
                graphic_object(kind, pixels[start:index], color("valid")[::-1], thickness=1)
            )
            start = None
    # Candidate markers expose competing and rejected observations, including weak echoes.
    for candidate in result["stripe"]["candidates"]:
        if not result["valid"][candidate["bin"]] or candidate["rank"]:
            objects.append(
                graphic_object(
                    "marker", [candidate["pixel"]], color(result["reason"][candidate["bin"]])[::-1]
                )
            )
    return GraphicDrawing(tuple(objects), source="image")


class SimpleLaserProfile(Tool3D):
    type_id, title = "3d.simple_laser_profile", "SimpleLaserProfile"
    subtype = "Laser profiling"
    parallel_safe = True
    process_inputs_readonly = True
    preview_safe = True
    plugin_dialog_label = "Train laser profile…"
    plugin_dialog_modeless = True
    inputs = (Port("image", "image"),)
    outputs = (
        Port("image", "image"),
        Port("cloud", "cloud", required=False),
        Port("report", "data"),
        Port("coverage", "number"),
        Port("count", "integer"),
        Port("calibrated", "boolean"),
        Port("overlay", "image", required=False),
        Port("chart", "image", required=False),
    )
    defaults = dict(recipe_path="", sha256="", minimum_coverage=0.0, render_graphics=True)
    parameter_ranges = {"minimum_coverage": NumericRange(0, 1)}
    parameter_help = {
        "recipe_path": "Project-contained retained .slp recipe; use Train to import or teach.",
        "sha256": "SHA-256 of the staged recipe. Loaded once, then cached by file identity/stat.",
        "minimum_coverage": "Required valid/active bins (0..1). Zero still requires one valid bin. "
        "Coverage is availability, not accuracy or confidence.",
        "render_graphics": "Source overlay, chart, drawable stripe and RGB cloud colors. "
        "Turning this off preserves numerical profile/cloud points.",
    }
    input_help = {
        "image": "Original gray/RGB/BGR pixels matching retained dimensions and encoding."
    }
    output_help = {
        "cloud": "Native fly-around: accepted measured points only; meters in the camera frame. "
        "Absent in pixel-only mode or when no metric samples are available.",
        "image": "Original unchanged source with drawable accepted/rejected stripe graphics.",
        "overlay": "Diagnostic RGB image showing candidates, ROI and unavailable reasons.",
        "chart": "Diagnostic profile plot with gaps and availability strip.",
        "report": "Every source bin, subpixel center, reason and XYZ in meters when calibrated.",
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.preview_output = "cloud"
        self.cache = RecipeCache()

    def validate_parameters(self, parameters=None):
        super().validate_parameters(parameters)
        p = self.parameters if parameters is None else parameters
        if not isinstance(p["recipe_path"], str) or not isinstance(p["sha256"], str):
            raise ValidationError(
                "Choose a retained recipe and its checksum", "recipe_path", "sha256"
            )
        if p["recipe_path"] or p["sha256"]:
            try:
                recipe_path(self.project_dir, p["recipe_path"])
            except ValueError as error:
                raise ValidationError(str(error), "recipe_path") from error
            if re.fullmatch("[0-9a-f]{64}", p["sha256"]) is None:
                raise ValidationError("Stage/import a recipe with its SHA-256", "sha256")
        if type(p["render_graphics"]) is not bool:
            raise ValidationError("Render graphics must be boolean", "render_graphics")
        if type(p["minimum_coverage"]) not in (int, float) or not (
            np.isfinite(p["minimum_coverage"]) and 0 <= p["minimum_coverage"] <= 1
        ):
            raise ValidationError("Minimum coverage must be a number in 0..1", "minimum_coverage")

    def process(self, inputs):
        p = self.parameters
        if not p["recipe_path"]:
            raise ValidationError("Train or import a laser-profile recipe first", "recipe_path")
        recipe = self.cache.get(recipe_path(self.project_dir, p["recipe_path"]), p["sha256"])
        raw = source_image(inputs["image"], self.input_payloads.get("image"))
        graphics = self.generate_graphics and p["render_graphics"]
        result = execute(recipe, raw, graphics=graphics, cancelled=self._cancelled)
        report = result["report"]
        passed = report["available"] and report["coverage"] >= p["minimum_coverage"]
        report["decision"] = dict(
            passed=passed,
            minimum_coverage=p["minimum_coverage"],
            scope="Sample availability only; not stripe identity or gauge accuracy",
        )
        payloads = {"image": self.input_payloads.get("image", {})}
        if graphics:
            payloads["overlay"] = self.input_payloads.get("image", {})
            payloads["chart"] = {"spatial": frame([920, 380], "laser-profile-chart:" + self.id)}
        return Result(
            outputs=dict(
                image=inputs["image"],
                cloud=result_cloud(result, colors=graphics),
                report=report,
                coverage=report["coverage"],
                count=report["valid_samples"],
                calibrated=report["calibrated"],
                overlay=ImageArray(result["overlay"], "rgb") if graphics else NO_VALUE,
                chart=ImageArray(result["chart"], "rgb") if graphics else NO_VALUE,
            ),
            payloads=payloads,
            drawings={"stripe": stripe_drawing(result)} if graphics else {},
            passed=passed,
            message=(
                f"{report['valid_samples']}/{report['active_sample_count']} valid bins "
                f"({report['coverage']:.1%}); "
                + ("calibrated meters" if report["calibrated"] else "PIXEL ONLY")
            ),
            fail_reasons=[] if passed else ["laser_profile_unavailable_coverage"],
        )

    def create_plugin_dialog(self, parent, parameters, context):
        from .qt_training import LaserProfileTrainingDialog

        return LaserProfileTrainingDialog(parent, parameters, context)

    def close(self):
        self.cache = RecipeCache()


def register(registry):
    registry.register(SimpleLaserProfile)
