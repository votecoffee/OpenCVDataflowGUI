"""One bright stripe per scan bin, with explicit competing/invalid observations.

Original signal processing: cross-section background subtraction, smoothed peak
separation and a positive-signal weighted subpixel centroid. No gap filling or
continuity-based choice between different laser sheets is performed.
"""

from dataclasses import asdict, dataclass, replace

import numpy as np


@dataclass(frozen=True)
class StripeSettings:
    direction: str = "columns"
    channel: str = "intensity"
    threshold: float = 0.03
    minimum_width: int = 2
    maximum_width: int = 32
    ambiguity_ratio: float = 0.5
    valley_ratio: float = 0.75
    reject_saturated: bool = True

    def __post_init__(self):
        if self.direction not in ("columns", "rows"):
            raise ValueError("Choose source columns or rows as the scan bins")
        if self.channel not in ("intensity", "red_excess", "green_excess", "blue_excess"):
            raise ValueError("Choose intensity or RGB color excess")
        for name in ("threshold", "ambiguity_ratio", "valley_ratio"):
            value = getattr(self, name)
            if isinstance(value, bool) or not np.isfinite(value) or not 0 < value < 1:
                raise ValueError("Bound " + name + " to (0,1)")
        if (
            type(self.minimum_width) is not int
            or type(self.maximum_width) is not int
            or not 1 <= self.minimum_width <= self.maximum_width <= 16384
        ):
            raise ValueError("Use ordered cross-stripe width bounds in pixels")
        if type(self.reject_saturated) is not bool:
            raise ValueError("Choose an explicit input-ceiling rejection policy")


def normalize(image):
    raw = np.asarray(image)
    if (
        raw.ndim not in (2, 3)
        or (raw.ndim == 3 and raw.shape[2] != 3)
        or min(raw.shape[:2]) < 2
        or max(raw.shape[:2]) > 16384
        or np.prod(raw.shape[:2]) > 16_000_000
    ):
        raise ValueError("Use a bounded grayscale or explicit RGB image")
    if raw.dtype == np.uint8:
        scale, quantum = 255.0, 1 / 255
    elif raw.dtype == np.uint16:
        scale, quantum = 65535.0, 1 / 65535
    elif raw.dtype.kind == "f" and np.isfinite(raw).all() and raw.min() >= 0 and raw.max() <= 1:
        scale, quantum = 1.0, 1e-6
    else:
        raise ValueError("Use uint8/uint16 codes or finite floating intensities in [0,1]")
    data = raw.astype(np.float32) / scale
    saturated = np.any(data >= 1, axis=2) if data.ndim == 3 else data >= 1
    return data, saturated, quantum


def channel_signal(data, channel):
    if data.ndim == 2:
        if channel != "intensity":
            raise ValueError("Color-excess selection requires explicit RGB data")
        return data
    if channel == "intensity":
        return data @ np.array([0.2126, 0.7152, 0.0722], np.float32)
    axis = {"red_excess": 0, "green_excess": 1, "blue_excess": 2}[channel]
    other = [i for i in range(3) if i != axis]
    return np.maximum(data[:, :, axis] - data[:, :, other].max(axis=2), 0)


def inputs(image, channel, mask, background):
    data, saturated, quantum = normalize(image)
    signal = channel_signal(data, channel)
    if background is not None:
        if (
            np.asarray(background).shape != np.asarray(image).shape
            or np.asarray(background).dtype != np.asarray(image).dtype
        ):
            raise ValueError("Laser-off background must match image size, encoding and channels")
        off, _, _ = normalize(background)
        signal = signal - channel_signal(off, channel)
    if mask is None:
        selected = np.ones(signal.shape, bool)
    else:
        raw = np.asarray(mask)
        if raw.shape != signal.shape or raw.dtype.kind not in "bui":
            raise ValueError("Use a matching binary ROI mask")
        if raw.dtype.kind == "i" and np.any(raw < 0):
            raise ValueError("ROI mask must be nonnegative")
        selected = raw != 0
    return signal, selected, saturated, quantum


def runs(selected):
    changes = np.diff(np.r_[False, selected, False].astype(np.int8))
    return zip(np.flatnonzero(changes == 1), np.flatnonzero(changes == -1))


def candidates(profile, selected, saturated, threshold, valley_ratio):
    result = []
    for start, end in runs(selected):
        raw = profile[start:end]
        if len(raw) < 2:
            continue
        baseline = float(np.median(raw))
        positive = np.maximum(raw - baseline, 0)
        padded = np.pad(positive, 1, mode="edge")
        smooth = (padded[:-2] + 2 * padded[1:-1] + padded[2:]) * 0.25
        for low, high in runs(smooth > threshold):
            values = smooth[low:high]
            left = np.r_[-np.inf, values[:-1]]
            right = np.r_[values[1:], -np.inf]
            maxima = (values >= left) & (values >= right)
            peaks = [int((a + b - 1) // 2) + low for a, b in runs(maxima)]
            if len(peaks) > 256:
                return result[:8], True
            retained = []
            for peak in sorted(peaks, key=lambda p: -smooth[p]):
                separate = True
                for other in retained:
                    a, b = sorted((peak, other))
                    valley = float(smooth[a : b + 1].min())
                    if b - a < 2 or valley > valley_ratio * min(smooth[peak], smooth[other]):
                        separate = False
                        break
                if separate:
                    retained.append(peak)
            retained.sort()
            splits = [low]
            for a, b in zip(retained, retained[1:]):
                splits.append(a + int(np.argmin(smooth[a : b + 1])) + 1)
            splits.append(high)
            for peak, a, b in zip(retained, splits[:-1], splits[1:]):
                lo, hi = max(0, a - 1), min(len(raw), b + 1)
                weights = positive[lo:hi].astype(np.float64)
                if not weights.sum():
                    continue
                center = start + float(weights @ np.arange(lo, hi) / weights.sum())
                result.append(
                    dict(
                        cross=center,
                        peak=float(smooth[peak]),
                        width=int(b - a),
                        saturated=bool(saturated[start + lo : start + hi].any()),
                        clipped=bool(a == 0 or b == len(raw)),
                    )
                )
                if len(result) > 8:
                    return sorted(result, key=lambda p: -p["peak"])[:8], True
    return sorted(result, key=lambda p: -p["peak"]), False


def extract_stripe(image, settings, *, mask=None, background=None, cancelled=lambda: False):
    if not isinstance(settings, StripeSettings):
        raise TypeError("Use validated frozen stripe settings")
    signal, selected, saturated, _ = inputs(image, settings.channel, mask, background)
    if settings.direction == "rows":
        signal, selected, saturated = signal.T, selected.T, saturated.T
    count = signal.shape[1]
    pixels = np.full((count, 2), np.nan)
    pixels[:, 0 if settings.direction == "columns" else 1] = np.arange(count)
    reasons = np.full(count, "outside_roi", dtype="<U24")
    peaks, widths, counts = np.zeros(count), np.zeros(count), np.zeros(count, np.int32)
    clipped, ceiling = np.zeros(count, bool), np.zeros(count, bool)
    ledger = []
    for index in range(count):
        if cancelled():
            raise RuntimeError("Stripe extraction cancelled; no result published")
        if not selected[:, index].any():
            continue
        found, overflow = candidates(
            signal[:, index],
            selected[:, index],
            saturated[:, index],
            settings.threshold,
            settings.valley_ratio,
        )
        counts[index] = len(found) + (1 if overflow else 0)
        reasons[index] = "too_many_peaks" if overflow else "missing"
        for rank, candidate in enumerate(found):
            cross = candidate["cross"]
            point = (
                [float(index), cross] if settings.direction == "columns" else [cross, float(index)]
            )
            ledger.append(dict(bin=index, rank=rank, pixel=point, **candidate))
        if not found:
            continue
        best = found[0]
        pixels[index] = (
            [index, best["cross"]] if settings.direction == "columns" else [best["cross"], index]
        )
        peaks[index], widths[index] = best["peak"], best["width"]
        ceiling[index], clipped[index] = best["saturated"], best["clipped"]
        if overflow:
            continue
        if len(found) > 1 and found[1]["peak"] >= best["peak"] * settings.ambiguity_ratio:
            reasons[index] = "multiple_peaks"
        elif best["clipped"]:
            reasons[index] = "clipped"
        elif best["width"] < settings.minimum_width:
            reasons[index] = "too_narrow"
        elif best["width"] > settings.maximum_width:
            reasons[index] = "too_wide"
        elif best["saturated"] and settings.reject_saturated:
            reasons[index] = "input_ceiling"
        else:
            reasons[index] = "valid"
    if cancelled():
        raise RuntimeError("Stripe extraction cancelled; no result published")
    return dict(
        pixels=pixels,
        valid=reasons == "valid",
        reason=reasons,
        peak=peaks,
        support_width_px=widths,
        candidate_count=counts,
        at_input_ceiling=ceiling,
        clipped=clipped,
        candidates=ledger,
        direction=settings.direction,
        image_size=[int(np.asarray(image).shape[1]), int(np.asarray(image).shape[0])],
        settings=asdict(settings),
        units="pixels",
    )


def learn_stripe(
    reference,
    *,
    mask=None,
    background=None,
    channel="intensity",
    direction="auto",
    cancelled=lambda: False,
):
    signal, selected, _, quantum = inputs(reference, channel, mask, background)
    if not selected.any():
        raise ValueError("Select a nonempty stripe ROI")
    values = signal[selected]
    median = float(np.median(values))
    noise_sigma = float(1.4826 * np.median(np.abs(values - median)))
    threshold = max(6 * noise_sigma, 3 * quantum)
    if threshold >= 1:
        raise ValueError(
            "Reference contrast/noise is unsuitable; review ROI or laser-off background"
        )
    if direction == "auto":
        y, x = np.nonzero(selected & (signal > median + threshold))
        if len(x) < 3:
            raise ValueError("No stripe contrast found in the reference ROI")
        direction = "columns" if np.var(x) >= np.var(y) else "rows"
    settings = StripeSettings(
        direction=direction,
        channel=channel,
        threshold=threshold,
        maximum_width=16384,
        reject_saturated=False,
    )
    draft = extract_stripe(
        reference, settings, mask=mask, background=background, cancelled=cancelled
    )
    widths = draft["support_width_px"][draft["valid"]]
    if len(widths) < 3:
        raise ValueError(
            "Reference has too few unique unclipped stripe bins; select one stripe ROI"
        )
    maximum = min(16384, max(5, int(np.ceil(3 * np.median(widths)))))
    settings = replace(settings, maximum_width=maximum, reject_saturated=True)
    final = extract_stripe(
        reference, settings, mask=mask, background=background, cancelled=cancelled
    )
    active = final["reason"] != "outside_roi"
    health = dict(
        training_bins=int(active.sum()),
        valid_bins=int(final["valid"].sum()),
        reason_counts={
            str(reason): int(np.sum(final["reason"][active] == reason))
            for reason in np.unique(final["reason"][active])
        },
        noise_sigma=noise_sigma,
        learned_threshold=threshold,
        median_support_width_px=float(np.median(widths)),
        source="Reference only; no test-image threshold relearning",
        accuracy_score=None,
    )
    health["status"] = "ready_for_review" if health["valid_bins"] else "reference_unavailable"
    return settings, health
