"""Read-only synchronized source, trend and native-cloud review of one finished profile."""

import json
import uuid
from pathlib import Path

from opencv_dataflow.canvas import pixmap
from opencv_dataflow.cloud_viewer import CloudViewer
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from opencv_dataflow.images import ImageArray
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from .completed_review import DEFAULT_LAYERS, LAYERS, UNAVAILABLE_DIAGNOSTICS, configuration


class SampleImageView(FilmstripImageView):
    bin_chosen = Signal(int)

    def __init__(self, parent, *, chart=False):
        super().__init__(parent)
        self.chart, self.direction, self.sample_count = chart, "columns", 0

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and (
            self.chart or event.modifiers() & Qt.KeyboardModifier.ShiftModifier
        ):
            point = self.mapToScene(event.position().toPoint())
            if self.chart:
                index = round((point.x() - 85) / (895 - 85) * max(1, self.sample_count - 1))
                inside = 85 <= point.x() <= 895 and 55 <= point.y() <= 322
            else:
                index = round(point.x() if self.direction == "columns" else point.y())
                inside = self.sceneRect().contains(point)
            if inside and 0 <= index < self.sample_count:
                self.bin_chosen.emit(index)
                event.accept()
                return
        super().mousePressEvent(event)


class CompletedLaserReviewDialog(QDialog):
    def __init__(self, parent, context, capture):
        super().__init__(parent)
        self.setWindowTitle("Completed laser profile review")
        self.resize(1360, 1030)
        self.snapshot, self.selected_bin = None, None
        self._capture, self._closed = capture, False
        self._rows = []
        layout = QVBoxLayout(self)
        actions = QHBoxLayout()
        self.capture_button = QPushButton("Capture latest completed run")
        self.capture_button.clicked.connect(self.capture_latest)
        self.export_button = QPushButton("Export frozen review…")
        self.export_button.setEnabled(False)
        self.export_button.clicked.connect(self.choose_export)
        close = QPushButton("Close review")
        close.clicked.connect(self.reject)
        for button in (self.capture_button, self.export_button, close):
            actions.addWidget(button)
        layout.addLayout(actions)
        self.identity, self.status, self.summary = (QLabel() for _ in range(3))
        for label in (self.identity, self.status, self.summary):
            label.setWordWrap(True)
            label.setTextFormat(Qt.TextFormat.PlainText)
            layout.addWidget(label)
        controls = QHBoxLayout()
        controls.addWidget(QLabel("Source bin"))
        self.bin = QSpinBox()
        self.bin.setSpecialValueText("Overview")
        self.bin.valueChanged.connect(lambda index: self.select_bin(None if index < 0 else index))
        controls.addWidget(self.bin)
        self.filter = QComboBox()
        for title, value in (
            ("All bins", "all"),
            ("Unavailable / rejected", "invalid"),
            ("Accepted", "valid"),
            ("Competing peaks", "multiple_peaks"),
        ):
            self.filter.addItem(title, value)
        self.filter.currentIndexChanged.connect(self.populate_table)
        controls.addWidget(self.filter)
        focus, overview = QPushButton("Focus source sample"), QPushButton("Overview")
        focus.clicked.connect(self.focus_sample)
        overview.clicked.connect(self.overview)
        controls.addWidget(focus)
        controls.addWidget(overview)
        controls.addStretch()
        layout.addLayout(controls)
        split = QSplitter(Qt.Orientation.Horizontal)
        layout.addWidget(split, 1)
        self.source_tabs, self.result_tabs = QTabWidget(), QTabWidget()
        split.addWidget(self.source_tabs)
        split.addWidget(self.result_tabs)
        self.overlay_view = SampleImageView(self)
        self.source_view, self.reference_view = FilmstripImageView(self), FilmstripImageView(self)
        for view, title in (
            (self.overlay_view, "Completed stripe / coverage"),
            (self.source_view, "Exact source (display)"),
            (self.reference_view, "Executed training reference"),
        ):
            self.source_tabs.addTab(view, title)
        self.chart_view = SampleImageView(self, chart=True)
        self.result_tabs.addTab(self.chart_view, "Completed profile / trend")
        native = QWidget()
        native_layout = QVBoxLayout(native)
        self.cloud_view = CloudViewer(None, self)
        self.cloud_view.setWindowFlags(Qt.WindowType.Widget)
        self.cloud_view.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, False)
        native_layout.addWidget(self.cloud_view)
        self.layer_boxes = {}
        layer_row = QHBoxLayout()
        for name in LAYERS:
            box = QCheckBox(name.replace("_", " ").capitalize())
            box.setChecked(name in DEFAULT_LAYERS)
            box.toggled.connect(self.show_cloud)
            self.layer_boxes[name] = box
            layer_row.addWidget(box)
        native_layout.addLayout(layer_row)
        note = QLabel(
            "Meters in the declared camera frame. Overview keeps emitted colors (host default "
            "when graphics were off); green review profile, yellow selected "
            "sample. Blue origin-to-sample segment, purple configured laser plane and "
            "RGB axes are derived display geometry, not extra sensor returns. "
            "Only valid recorded XYZ can appear; missing bins stay unavailable."
        )
        note.setWordWrap(True)
        native_layout.addWidget(note)
        self.native_index = self.result_tabs.addTab(native, "Native calibrated cloud")
        self.details = QPlainTextEdit()
        self.details.setReadOnly(True)
        self.result_tabs.addTab(self.details, "Sample / calibration evidence")
        self.overlay_view.bin_chosen.connect(self.select_bin)
        self.chart_view.bin_chosen.connect(self.select_bin)
        self.table = QTableWidget(0, 9)
        self.table.setHorizontalHeaderLabels(
            [
                "Bin",
                "Source pixel",
                "Accepted",
                "Reason",
                "Candidates",
                "Contrast",
                "Width [px]",
                "Incidence",
                "XYZ [m]",
            ]
        )
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setMaximumHeight(180)
        self.table.itemSelectionChanged.connect(self.select_row)
        layout.addWidget(self.table)
        note = QLabel(
            "Shift-click source or click trend to select a source bin; wheel zoom / drag "
            "pan. Green accepted · magenta competing · red input ceiling · blue missing · "
            "amber clipped/width/geometry rejected. Depth/contrast views are display only. "
            "Coverage is availability, not confidence, stripe identity or gauge accuracy."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        self.export_status = QLabel()
        self.export_status.setWordWrap(True)
        layout.addWidget(self.export_status)
        unsubscribe = context.subscribe_outputs(self.publication_changed)
        self.finished.connect(self.release_review)
        self.finished.connect(unsubscribe)
        self.destroyed.connect(unsubscribe)
        self.capture_latest()

    def release_review(self, *_):
        self._closed = True
        self.cloud_view.orbit_timer.stop()
        self.cloud_view.timer.stop()
        self.cloud_view.image.clear()
        self.cloud_view._rendered = self.cloud_view.cloud = None
        for view in (self.overlay_view, self.source_view, self.reference_view, self.chart_view):
            view.set_image(QPixmap())
        self.snapshot = self._capture = None
        self._rows = []

    def publication_changed(self, revision):
        if self.snapshot is not None and not self._closed:
            self.status.setText(
                "Editor publication changed. This frozen review stays unchanged; "
                "capture latest explicitly."
            )

    def capture_latest(self):
        if self._closed:
            return
        try:
            snapshot = self._capture()
        except (ValueError, RuntimeError, KeyError) as error:
            self.status.setText(
                str(error)
                + (" Previous frozen run remains displayed." if self.snapshot is not None else "")
            )
            return
        self.snapshot = snapshot
        report, p = snapshot.record.report, snapshot.provenance
        self._rows = report["samples"]
        mode = "calibrated meters" if report["calibrated"] else "PIXEL ONLY / UNCALIBRATED"
        self.identity.setText(
            f"{p['block_id']} · completion {p['execution_count']} · {mode} · "
            f"recipe {snapshot.record.parameters['sha256'][:16]} · "
            f"{report['valid_samples']}/{report['active_sample_count']} valid bins "
            f"({report['coverage']:.1%}) · "
            f"{'PASS' if p['passed'] else 'FAIL'} availability decision"
        )
        self.status.setText(
            "Frozen source, consumed encoding, executed calibration and completed "
            "stripe/profile decisions. No extraction, intersection or calibration. "
            "Unstored undistorted rays/reprojection errors remain unavailable. "
            "Teaching stays independent; missing bins are never filled."
        )
        for view in (self.overlay_view, self.chart_view):
            view.direction, view.sample_count = report["direction"], report["sample_count"]
        self.bin.blockSignals(True)
        self.bin.setRange(-1, report["sample_count"] - 1)
        self.bin.blockSignals(False)
        self.source_view.set_image(pixmap(ImageArray(snapshot.source_preview(), "rgb")))
        self.reference_view.set_image(pixmap(ImageArray(snapshot.reference_preview(), "rgb")))
        available = snapshot.record._cloud is not None
        self.result_tabs.setTabEnabled(self.native_index, available)
        for box in self.layer_boxes.values():
            box.setEnabled(available)
        self.populate_table()
        self.export_button.setEnabled(True)
        self.selected_bin = None
        self.overview()

    def populate_table(self, *_):
        if self.snapshot is None:
            return
        kind = self.filter.currentData()
        rows = [
            row
            for row in self._rows
            if kind == "all"
            or (kind == "valid" and row["valid"])
            or (kind == "invalid" and not row["valid"])
            or row["reason"] == kind
        ]
        self.table.blockSignals(True)
        self.table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            for column, key in enumerate(
                (
                    "bin",
                    "pixel",
                    "valid",
                    "reason",
                    "candidate_count",
                    "peak_contrast",
                    "support_width_px",
                    "incidence",
                    "xyz_m",
                )
            ):
                value = row[key]
                item = QTableWidgetItem("Unavailable" if value is None else str(value))
                item.setToolTip(item.text())
                item.setData(Qt.ItemDataRole.UserRole, row["bin"])
                self.table.setItem(r, column, item)
        self.table.resizeColumnsToContents()
        self.table.blockSignals(False)

    def select_row(self):
        rows = self.table.selectionModel().selectedRows()
        if rows:
            self.select_bin(self.table.item(rows[0].row(), 0).data(Qt.ItemDataRole.UserRole))

    @staticmethod
    def update_image(view, image):
        transform, fitted = view.transform(), view._fitted
        center = view.mapToScene(view.viewport().rect().center())
        view.set_image(pixmap(ImageArray(image, "rgb")))
        if not fitted:
            view.setTransform(transform)
            view._fitted = False
            view.centerOn(center)

    def select_bin(self, index):
        if self.snapshot is None or self._closed:
            return
        if index is None:
            self.overview()
            return
        row = self.snapshot.sample(index)
        self.selected_bin = index
        self.bin.blockSignals(True)
        self.bin.setValue(index)
        self.bin.blockSignals(False)
        self.table.blockSignals(True)
        self.table.clearSelection()
        for r in range(self.table.rowCount()):
            if self.table.item(r, 0).data(Qt.ItemDataRole.UserRole) == index:
                self.table.selectRow(r)
                break
        self.table.blockSignals(False)
        self.summary.setText(
            f"Bin {index}: {row['reason']} · source pixel "
            f"{row['pixel'] if row['pixel'] is not None else 'unavailable'} · "
            f"XYZ [m] {row['xyz_m'] if row['xyz_m'] is not None else 'unavailable'} · "
            f"{row['candidate_count']} candidate peaks · "
            f"input ceiling {row['input_ceiling']}"
        )
        self.update_image(self.overlay_view, self.snapshot.overlay(index))
        self.update_image(self.chart_view, self.snapshot.chart(index))
        self.details.setPlainText(
            json.dumps(
                dict(
                    sample=row,
                    candidates=self.snapshot.candidates(index),
                    executed_configuration=configuration(self.snapshot.record._recipe),
                    source=self.snapshot.source_description,
                    unavailable_diagnostics=list(UNAVAILABLE_DIAGNOSTICS),
                ),
                indent=2,
                allow_nan=False,
            )
        )
        self.show_cloud()

    def display_layers(self):
        return tuple(name for name, box in self.layer_boxes.items() if box.isChecked())

    def show_cloud(self, *_):
        if self.snapshot is None or self._closed:
            return
        cloud = (
            None
            if self.snapshot.record._cloud is None
            else self.snapshot.display_cloud(self.selected_bin, self.display_layers())
        )
        self.cloud_view.set_cloud(cloud)

    def focus_sample(self):
        if self.snapshot is None:
            return
        row = self.snapshot.sample(self.selected_bin)
        self.source_tabs.setCurrentIndex(0)
        self.overlay_view.actual_size()
        self.overlay_view.zoom(4)
        if row["pixel"] is not None:
            self.overlay_view.centerOn(*row["pixel"])
        elif self.snapshot.record.report["direction"] == "columns":
            self.overlay_view.centerOn(self.selected_bin, self.snapshot.source_array().shape[0] / 2)
        else:
            self.overlay_view.centerOn(self.snapshot.source_array().shape[1] / 2, self.selected_bin)

    def overview(self):
        if self.snapshot is None:
            return
        self.selected_bin = None
        self.bin.blockSignals(True)
        self.bin.setValue(-1)
        self.bin.blockSignals(False)
        self.table.clearSelection()
        self.summary.setText(
            "Overview of all recorded source bins; select a row or source bin "
            "for exact sample and candidate evidence."
        )
        self.details.setPlainText(json.dumps(self.snapshot.report(), indent=2, allow_nan=False))
        self.update_image(self.overlay_view, self.snapshot.overlay())
        self.update_image(self.chart_view, self.snapshot.chart())
        self.overlay_view.fit_image()
        self.chart_view.fit_image()
        for name, box in self.layer_boxes.items():
            box.setChecked(name in DEFAULT_LAYERS)
        self.cloud_view.set_cloud(
            None if self.snapshot.record._cloud is None else self.snapshot.display_cloud()
        )

    def export_to(self, directory):
        if self.snapshot is None:
            raise ValueError("Capture a completed profile before exporting")
        target = self.snapshot.export(directory, self.selected_bin, self.display_layers())
        self.export_status.setText(f"Exported frozen review: {target}")
        return target

    def choose_export(self):
        parent = QFileDialog.getExistingDirectory(self, "Choose parent for a new frozen review")
        if parent:
            try:
                self.export_to(Path(parent) / f"laser-review-{uuid.uuid4().hex[:12]}")
            except (ValueError, OSError) as error:
                self.export_status.setText(str(error))
