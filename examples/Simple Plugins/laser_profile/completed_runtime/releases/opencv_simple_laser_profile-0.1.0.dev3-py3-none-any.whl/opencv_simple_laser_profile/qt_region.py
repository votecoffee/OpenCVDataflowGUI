"""Source-pixel rectangle editing over the host's zoom/pan image view."""

import numpy as np
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from PySide6.QtCore import QRectF, Qt, Signal
from PySide6.QtGui import QColor, QPen
from PySide6.QtWidgets import QGraphicsItem


class StripeRegionView(FilmstripImageView):
    region_changed = Signal(tuple)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.mode = "pan"
        self.roi = None
        self.items = []
        self.gesture = None

    def set_roi(self, roi):
        self.roi = tuple(roi) if roi is not None else None
        for item in self.items:
            self.scene().removeItem(item)
        self.items = []
        if self.roi is None:
            return
        x, y, w, h = self.roi
        pen = QPen(QColor(30, 210, 230), 1)
        pen.setCosmetic(True)
        self.items.append(self.scene().addRect(QRectF(x, y, w, h), pen))
        for px, py in ((x, y), (x + w, y), (x + w, y + h), (x, y + h)):
            handle = self.scene().addRect(-4, -4, 8, 8, pen, QColor(30, 210, 230))
            handle.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations)
            handle.setPos(px, py)
            self.items.append(handle)

    def mousePressEvent(self, event):
        if event.button() != Qt.MouseButton.LeftButton or self.mode == "pan":
            return super().mousePressEvent(event)
        point = self.mapToScene(event.position().toPoint())
        image = self.image_item.boundingRect()
        if not image.contains(point):
            return super().mousePressEvent(event)
        action = "draw" if self.mode == "draw" else None
        if self.mode == "edit" and self.roi is not None:
            x, y, w, h = self.roi
            for index, (px, py) in enumerate(((x, y), (x + w, y), (x + w, y + h), (x, y + h))):
                handle = self.mapFromScene(px, py)
                if (handle - event.position().toPoint()).manhattanLength() <= 12:
                    action = index
                    break
            if action is None and QRectF(x, y, w, h).contains(point):
                action = "move"
        if action is None:
            return super().mousePressEvent(event)
        self.gesture = point, self.roi, action
        event.accept()

    def mouseMoveEvent(self, event):
        if self.gesture is None:
            return super().mouseMoveEvent(event)
        start, original, action = self.gesture
        point = self.mapToScene(event.position().toPoint())
        size = self.image_item.boundingRect()
        width, height = int(size.width()), int(size.height())
        px, py = np.clip([point.x(), point.y()], [0, 0], [width, height])
        if action == "draw":
            left, right = sorted((start.x(), px))
            top, bottom = sorted((start.y(), py))
        elif action == "move":
            x, y, w, h = original
            left = np.clip(x + px - start.x(), 0, width - w)
            top = np.clip(y + py - start.y(), 0, height - h)
            right, bottom = left + w, top + h
        else:
            x, y, w, h = original
            opposite = ((x + w, y + h), (x, y + h), (x, y), (x + w, y))[action]
            left, right = sorted((opposite[0], px))
            top, bottom = sorted((opposite[1], py))
        x, y = min(width - 1, int(np.floor(left))), min(height - 1, int(np.floor(top)))
        right = max(x + 1, min(width, int(np.ceil(right))))
        bottom = max(y + 1, min(height, int(np.ceil(bottom))))
        self.set_roi((x, y, right - x, bottom - y))
        event.accept()

    def mouseReleaseEvent(self, event):
        if self.gesture is None:
            return super().mouseReleaseEvent(event)
        self.mouseMoveEvent(event)
        self.gesture = None
        self.mode = "edit"
        self.region_changed.emit(self.roi)
        event.accept()
