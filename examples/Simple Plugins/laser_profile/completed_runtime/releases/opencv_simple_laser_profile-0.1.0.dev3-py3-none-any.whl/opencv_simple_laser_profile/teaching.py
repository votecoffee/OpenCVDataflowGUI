"""Private teaching draft and immutable job snapshots, independent of Qt/host state."""

from dataclasses import dataclass

import numpy as np

from .cli import execute
from .geometry import Camera, Plane
from .recipe import copied, strict_json, teach
from .stripe import inputs, normalize


def calibration_record(path):
    if path.stat().st_size > 4 * 1024 * 1024:
        raise ValueError("Calibration definition exceeds 4 MiB")
    record = strict_json(path.read_bytes())
    if record.get("schema") != "simple_laser_calibration/v1":
        raise ValueError("Import a simple_laser_calibration/v1 definition")
    return Camera(**record["camera"]), Plane(**record["laser"]), record


def rectangle(mask, shape):
    if mask is None:
        return (0, 0, shape[1], shape[0])
    y, x = np.nonzero(mask)
    if not len(x):
        return None
    left, right, top, bottom = int(x.min()), int(x.max()) + 1, int(y.min()), int(y.max()) + 1
    if mask.sum() == (right - left) * (bottom - top):
        return left, top, right - left, bottom - top
    return None


@dataclass(frozen=True)
class TrainingJob:
    revision: int
    reference: np.ndarray
    options: dict

    def run(self, cancelled=lambda: False):
        recipe = teach(self.reference, **self.options, cancelled=cancelled)
        result = execute(recipe, self.reference, cancelled=cancelled)
        if recipe.camera is not None and not result["report"]["valid_metric_samples"]:
            raise ValueError("Reference has no valid metric samples; review imported calibration")
        return recipe, result


class TeachingDraft:
    def __init__(self):
        self.revision = 0
        self.reference = self.mask = self.background = None
        self.camera = self.laser = None
        self.channel, self.direction = "intensity", "auto"
        self.metadata = {}
        self.candidate = self.result = None

    def changed(self):
        self.revision += 1
        self.candidate = self.result = None

    def restore(self, recipe):
        self.changed()
        self.reference, self.mask, self.background = (
            recipe.reference,
            recipe.mask,
            recipe.background,
        )
        self.camera, self.laser = recipe.camera, recipe.laser
        self.channel, self.direction = recipe.settings.channel, recipe.settings.direction
        self.metadata = dict(recipe.metadata)
        self.candidate = recipe

    def reference_image(self, image, *, source="Imported reference"):
        normalize(image)
        self.reference = copied(image)
        self.mask = None
        if self.background is not None and (
            self.background.shape != image.shape or self.background.dtype != image.dtype
        ):
            self.background = None
        if self.camera is not None and self.camera.image_size != tuple(image.shape[1::-1]):
            self.camera = self.laser = None
            self.metadata.pop("calibration_evidence", None)
        self.metadata["source"] = source
        self.changed()

    def region(self, xywh):
        if self.reference is None:
            raise ValueError("Import or capture a reference first")
        x, y, w, h = xywh
        height, width = self.reference.shape[:2]
        if any(type(n) is not int for n in xywh) or min(x, y) < 0 or min(w, h) < 1:
            raise ValueError("Use a positive source-pixel rectangle")
        if x + w > width or y + h > height:
            raise ValueError("Keep the rectangle inside the reference image")
        mask = np.zeros((height, width), bool)
        mask[y : y + h, x : x + w] = True
        self.set_mask(mask)

    def set_mask(self, mask):
        if self.reference is None:
            raise ValueError("Import or capture a reference first")
        inputs(self.reference, "intensity", mask, None)
        if mask is not None and not np.any(mask):
            raise ValueError("Select a nonempty stripe region")
        self.mask = copied(np.asarray(mask) != 0) if mask is not None else None
        self.changed()

    def set_background(self, image):
        if self.reference is None:
            raise ValueError("Import or capture a reference first")
        inputs(self.reference, "intensity", None, image)
        self.background = copied(image)
        self.changed()

    def set_calibration(self, camera, laser, evidence):
        if (camera is None) != (laser is None):
            raise ValueError("Import both camera and laser plane")
        if camera is not None and (
            camera.frame != laser.frame
            or (
                self.reference is not None
                and camera.image_size != tuple(self.reference.shape[1::-1])
            )
        ):
            raise ValueError("Calibration must match the reference size and physical frame")
        self.camera, self.laser = camera, laser
        self.metadata["calibration_evidence"] = evidence
        self.changed()

    def job(self):
        if self.reference is None:
            raise ValueError("Import or capture a reference first")
        return TrainingJob(
            self.revision,
            self.reference,
            dict(
                mask=self.mask,
                background=self.background,
                camera=self.camera,
                laser=self.laser,
                channel=self.channel,
                direction=self.direction,
                metadata=dict(self.metadata),
            ),
        )

    def accept(self, job, value):
        if job.revision != self.revision or job.reference is not self.reference:
            return False
        self.candidate, self.result = value
        return True
