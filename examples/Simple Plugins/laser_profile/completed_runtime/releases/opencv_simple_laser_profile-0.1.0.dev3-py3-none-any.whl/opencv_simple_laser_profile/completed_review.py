"""Paired completed stripe/profile evidence, independent of extraction and calibration."""

import copy
import hashlib
import json
from dataclasses import asdict, dataclass, field, is_dataclass
from pathlib import Path
from uuid import uuid4

import cv2
import numpy as np
from opencv_dataflow.images import ImageArray, image_format, preview_rgb
from opencv_dataflow.payloads import NO_VALUE
from opencv_dataflow.pointclouds import PointCloud

from .render import render_chart, render_overlay

BINDING = "laser_profile_completed_review"
LAYERS = ("profile", "selected", "ray_segment", "laser_plane", "camera_axes")
DEFAULT_LAYERS = ("profile", "selected")
UNAVAILABLE_DIAGNOSTICS = ("undistorted_rays", "reprojection_error")


def _json(value):
    return json.dumps(value, sort_keys=True, allow_nan=False).encode("utf-8")


def readonly(value):
    array = np.asarray(value)
    return np.frombuffer(array.tobytes(), dtype=array.dtype).reshape(array.shape)


def freeze(value, memo=None):
    memo = {} if memo is None else memo
    if id(value) in memo:
        return memo[id(value)]
    if isinstance(value, np.ndarray):
        result = readonly(value)
    elif is_dataclass(value):
        result = object.__new__(type(value))
        memo[id(value)] = result
        for name, item in vars(value).items():
            object.__setattr__(result, name, freeze(item, memo))
    elif isinstance(value, dict):
        result = {name: freeze(item, memo) for name, item in value.items()}
    elif isinstance(value, (tuple, list)):
        result = type(value)(freeze(item, memo) for item in value)
    else:
        result = copy.deepcopy(value)
    memo[id(value)] = result
    return result


def configuration(recipe):
    return dict(
        settings=asdict(recipe.settings),
        metadata=copy.deepcopy(recipe.metadata),
        reference_shape=list(recipe.reference.shape),
        reference_dtype=recipe.reference.dtype.str,
        has_mask=recipe.mask is not None,
        has_background=recipe.background is not None,
        camera=None
        if recipe.camera is None
        else dict(
            matrix=recipe.camera.matrix.tolist(),
            image_size=list(recipe.camera.image_size),
            distortion=list(recipe.camera.distortion),
            frame=recipe.camera.frame,
        ),
        laser=None
        if recipe.laser is None
        else dict(
            normal=recipe.laser.normal.tolist(),
            offset_m=recipe.laser.offset_m,
            frame=recipe.laser.frame,
        ),
    )


def describe_image(value):
    array = np.asarray(value)
    return dict(
        shape=list(array.shape),
        dtype=array.dtype.str,
        encoding=image_format(value),
        sha256=hashlib.sha256(array.tobytes()).hexdigest(),
        attributes={
            name: copy.deepcopy(getattr(value, name))
            for name in ("color_format", "metadata", "units", "display_min", "display_max")
            if hasattr(value, name)
        },
    )


def cloud_copy(value):
    return PointCloud(
        value.points,
        value.units,
        value.frame,
        colors=value.colors,
        normals=value.normals,
        pixels=value.pixels,
        source_size=value.source_size,
        metadata=copy.deepcopy(value.metadata),
    )


@dataclass(frozen=True)
class CompletedLaserRecord:
    identifier: str
    report_json: bytes
    parameters_json: bytes
    scalar_json: bytes
    ports: tuple
    _recipe: object = field(repr=False, compare=False)
    _consumed: np.ndarray = field(repr=False, compare=False)
    _result: dict = field(repr=False, compare=False)
    _images: dict = field(repr=False, compare=False)
    _cloud: object = field(repr=False, compare=False)

    @classmethod
    def create(cls, recipe, consumed, result, outputs, parameters):
        emitted = {name: value for name, value in outputs.items() if value is not NO_VALUE}
        images = {name: value for name, value in emitted.items() if isinstance(value, np.ndarray)}
        scalars = {
            name: value
            for name, value in emitted.items()
            if name not in (*images, "cloud", "report")
        }
        return cls(
            uuid4().hex,
            _json(outputs["report"]),
            _json(parameters),
            _json(scalars),
            tuple(emitted),
            recipe,
            consumed,
            result,
            images,
            emitted.get("cloud"),
        )

    @property
    def report(self):
        return json.loads(self.report_json)

    @property
    def parameters(self):
        return json.loads(self.parameters_json)

    def __deepcopy__(self, memo):
        return self


def retain_completed(block, recipe, consumed, result, outputs):
    if not (block.run_profile.input_previews and block.run_profile.output_previews):
        return {}
    record = CompletedLaserRecord.create(recipe, consumed, result, outputs, block.parameters)
    block._completed_review = record
    return {name: {BINDING: {"id": record.identifier}} for name in record.ports}


class CompletedLaserReview:
    plugin_review_dialog_label = "Review completed laser profile…"

    def copy_runtime_from(self, other):
        super().copy_runtime_from(other)
        self._completed_review = other._completed_review

    def reset_runtime(self):
        super().reset_runtime()
        self._completed_review = None

    def close(self):
        self._completed_review = None
        super().close()

    def capture_completed_review(self, context):
        snapshot = getattr(context, "snapshot_processed_execution", None)
        if snapshot is None:
            raise ValueError("Completed review needs the host's paired execution-snapshot API")
        record = self._completed_review
        bundle = snapshot(
            input_ports=("image",), output_ports=("report",) if record is None else record.ports
        )
        return capture_completed(record, bundle)

    def create_plugin_review_dialog(self, parent, context):
        from .qt_completed_review import CompletedLaserReviewDialog

        return CompletedLaserReviewDialog(
            parent, context, lambda: self.capture_completed_review(context)
        )


@dataclass(frozen=True)
class CompletedLaserCapture:
    record: CompletedLaserRecord
    _source: np.ndarray = field(repr=False, compare=False)
    _description: dict = field(repr=False, compare=False)
    _provenance: dict = field(repr=False, compare=False)
    _candidate_groups: dict = field(repr=False, compare=False)

    @property
    def recipe_bytes(self):
        return self.record._recipe._source_bytes

    @property
    def provenance(self):
        return copy.deepcopy(self._provenance)

    @property
    def source_description(self):
        return copy.deepcopy(self._description)

    def source_array(self):
        return self._source

    def consumed_array(self):
        return self.record._consumed

    def sample(self, index=None):
        if index is None:
            return None
        rows = self.record._result["report"]["samples"]
        if type(index) is not int or not 0 <= index < len(rows):
            raise ValueError("Choose a recorded source bin")
        return copy.deepcopy(rows[index])

    def candidates(self, index):
        self.sample(index)
        return copy.deepcopy(self._candidate_groups.get(index, []))

    def source_preview(self):
        return preview_rgb(ImageArray(self._source, self._description["encoding"]))

    def reference_preview(self):
        reference = self.record._recipe.reference
        return preview_rgb(ImageArray(reference, "rgb" if reference.ndim == 3 else "gray"))

    def overlay(self, selected=None):
        row = self.sample(selected)
        image = self.record._images.get("overlay")
        if image is None:
            image = render_overlay(
                self.record._consumed, self.record._result, self.record._recipe.mask
            )
        image = np.array(image, copy=True)
        if row is not None:
            height, width = image.shape[:2]
            if self.record._result["stripe"]["direction"] == "columns":
                cv2.line(image, (selected, 0), (selected, height - 1), (245, 210, 40), 1)
            else:
                cv2.line(image, (0, selected), (width - 1, selected), (245, 210, 40), 1)
            if row["pixel"] is not None:
                point = tuple(np.rint(row["pixel"]).astype(int))
                cv2.circle(image, point, 7, (245, 210, 40), 2, cv2.LINE_AA)
        return image

    def chart(self, selected=None):
        self.sample(selected)
        image = self.record._images.get("chart")
        image = np.array(render_chart(self.record._result) if image is None else image, copy=True)
        if selected is not None:
            x = round(85 + selected / max(1, len(self.record._result["valid"]) - 1) * (895 - 85))
            cv2.line(image, (x, 55), (x, 322), (220, 155, 0), 1, cv2.LINE_AA)
        return image

    def display_cloud(self, selected=None, layers=DEFAULT_LAYERS):
        row = self.sample(selected)
        if any(name not in LAYERS for name in layers):
            raise ValueError("Choose known profile display layers")
        original = self.record._cloud
        if original is None:
            raise ValueError("No calibrated valid profile cloud was emitted; it stays unavailable")
        if selected is None and set(layers) <= {"profile", "selected"} and "profile" in layers:
            return cloud_copy(original)
        xyz, colors, components = [], [], []
        count = 0

        def add(points, color, role, measured=False):
            nonlocal count
            points = np.asarray(points).reshape(-1, 3)
            xyz.append(points)
            colors.append(np.tile(color, (len(points), 1)))
            components.append(
                dict(
                    role=role,
                    rows=[count, count + len(points)],
                    calibrated_profile_samples=measured,
                )
            )
            count += len(points)

        if "profile" in layers:
            add(original.points, [35, 210, 70], "calibrated_profile", True)
        point = None if row is None or not row["valid"] else np.asarray(row["xyz_m"])
        if point is not None and "selected" in layers:
            add([point], [245, 210, 40], "selected_profile_sample", True)
        if point is not None and "ray_segment" in layers:
            add(np.linspace(np.zeros(3), point, 100), [80, 155, 245], "derived_origin_to_sample")
        extent = max(float(np.max(np.ptp(original.points, axis=0))), 0.001)
        if "laser_plane" in layers:
            plane = self.record._recipe.laser
            center = original.points.mean(0)
            center = center - (center @ plane.normal + plane.offset_m) * plane.normal
            axis = np.eye(3)[np.argmin(abs(plane.normal))]
            u = np.cross(plane.normal, axis)
            u /= np.linalg.norm(u)
            v = np.cross(plane.normal, u)
            for offset in np.linspace(-extent / 2, extent / 2, 9):
                for a, b in ((u, v), (v, u)):
                    add(
                        center + offset * a + np.linspace(-extent / 2, extent / 2, 50)[:, None] * b,
                        [145, 125, 225],
                        "derived_configured_laser_plane",
                    )
        if "camera_axes" in layers:
            for axis in range(3):
                color = np.zeros(3, int)
                color[axis] = 255
                add(
                    np.linspace(np.zeros(3), np.eye(3)[axis] * extent / 3, 50),
                    color,
                    "derived_camera_axis",
                )
        return PointCloud(
            np.concatenate(xyz) if xyz else np.empty((0, 3)),
            "m",
            original.frame,
            colors=np.concatenate(colors) if colors else np.empty((0, 3), np.uint8),
            metadata=dict(
                components=components,
                selected_bin=selected,
                scope="Frozen calibrated profile and derived display geometry",
            ),
        )

    def report(self, selected=None, layers=DEFAULT_LAYERS):
        row = self.sample(selected)
        return dict(
            schema="simple_laser_profile_completed_review/v1",
            execution_binding=self.record.identifier,
            completed_result=self.record.report,
            executed_parameters=self.record.parameters,
            executed_configuration=configuration(self.record._recipe),
            source=self.source_description,
            provenance=self.provenance,
            selected_sample=row,
            selected_candidates=[] if row is None else self.candidates(selected),
            display_layers=list(layers),
            emitted_images=list(self.record._images),
            emitted_cloud=self.record._cloud is not None,
            consumed_encoding="rgb" if self.record._consumed.ndim == 3 else "gray",
            consumed_sha256=hashlib.sha256(self.record._consumed.tobytes()).hexdigest(),
            unavailable_diagnostics=list(UNAVAILABLE_DIAGNOSTICS),
            scope="One identified sheet; coverage is availability, not accuracy or confidence",
            geometry_scope=(
                "Only recorded valid XYZ is a calibrated profile. Plane, axes and "
                "origin-to-sample segments are derived display geometry, not new returns"
            ),
            graphics_scope=(
                "Disabled output rasters stay absent from emitted history; "
                "review-only images may be drawn from frozen decisions"
            ),
            missing_scope="Missing/rejected/pixel-only samples stay unavailable; no gap filling",
            extraction_reexecuted=False,
            intersection_reexecuted=False,
            calibration_changed=False,
            recipe_reloaded=False,
            training_changed=False,
        )

    def assessment(self, selected=None):
        report, row = self.record.report, self.sample(selected)
        canvas = np.full((1120, 1280, 3), 28, np.uint8)
        mode = "CALIBRATED / m" if report["calibrated"] else "PIXEL ONLY / UNCALIBRATED"
        lines = [
            f"SimpleLaserProfile completed review | {mode}",
            f"{report['valid_samples']}/{report['active_sample_count']} valid bins | "
            f"coverage {report['coverage']:.1%} | frame {report['frame'] or 'source pixels'}",
        ]
        for y, text in zip((30, 58), lines):
            cv2.putText(
                canvas,
                text,
                (18, y),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.63,
                (235, 235, 235),
                1,
                cv2.LINE_AA,
            )
        overlay = self.overlay(selected)
        scale = min(640 / overlay.shape[1], 540 / overlay.shape[0])
        size = tuple(max(1, round(n * scale)) for n in overlay.shape[1::-1])
        image = cv2.resize(overlay, size, interpolation=cv2.INTER_AREA)
        canvas[90 : 90 + size[1], 18 : 18 + size[0]] = image
        info = [
            "Frozen executed recipe / inputs / decisions",
            "No extraction, intersection or calibration.",
            "Coverage is availability, not accuracy.",
            "Green accepted; magenta competing peaks;",
            "red input ceiling; blue missing; amber rejected.",
            "Missing/rejected bins are never filled.",
            "Selected source bin: " + ("overview" if row is None else str(selected)),
        ]
        if row is not None:
            info += [
                f"Reason: {row['reason']}",
                f"Source pixel: {row['pixel']}",
                f"Candidate count: {row['candidate_count']}",
                f"XYZ [m]: {row['xyz_m']}",
            ]
        for i, text in enumerate(info):
            text = text.encode("ascii", errors="replace").decode("ascii")[:78]
            cv2.putText(
                canvas,
                text,
                (680, 115 + 30 * i),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.46,
                (235, 235, 235),
                1,
                cv2.LINE_AA,
            )
        canvas[700:1080, 180:1100] = self.chart(selected)
        cv2.putText(
            canvas,
            "Display projection / contrast only; exact source and arrays exported.",
            (18, 1102),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (235, 235, 235),
            1,
            cv2.LINE_AA,
        )
        return canvas

    def export(self, directory, selected=None, layers=DEFAULT_LAYERS):
        from opencv_dataflow.cloud_io import write_cloud

        document = self.report(selected, layers)
        target = Path(directory)
        if self.recipe_bytes is None:
            raise ValueError("Original executed recipe bytes were not retained")
        cloud = None if self.record._cloud is None else self.display_cloud(selected, layers)
        target.mkdir(parents=True, exist_ok=False)
        (target / "executed_recipe.slp").write_bytes(self.recipe_bytes)
        document["exported_recipe_sha256"] = hashlib.sha256(self.recipe_bytes).hexdigest()
        np.save(target / "source_image.npy", self._source, allow_pickle=False)
        np.save(target / "consumed_image.npy", self.record._consumed, allow_pickle=False)
        arrays = {}
        for prefix, values in (
            ("profile", self.record._result),
            ("stripe", self.record._result["stripe"]),
        ):
            for name, value in values.items():
                if isinstance(value, np.ndarray):
                    filename = f"{prefix}_{name}.npy"
                    np.save(target / filename, value, allow_pickle=False)
                    arrays[f"{prefix}.{name}"] = filename
        document["native_arrays"] = arrays
        for name, value in self.record._images.items():
            np.save(target / f"emitted_{name}.npy", value, allow_pickle=False)
        if self.record._cloud is not None:
            from opencv_dataflow.pointclouds import render_cloud

            write_cloud(target / "emitted_profile.ply", self.record._cloud, binary=True)
            for name in ("points", "pixels", "colors"):
                value = getattr(self.record._cloud, name)
                if value is not None:
                    np.save(target / f"emitted_cloud_{name}.npy", value, allow_pickle=False)
            write_cloud(target / "selected_display.ply", cloud, binary=True)
            raster = render_cloud(cloud, width=920, height=640, yaw=25, pitch=-20)
            text = f"{cloud.units} / {cloud.frame} | display projection; see derived layers in JSON"
            cv2.putText(
                raster,
                text,
                (12, 24),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.46,
                (235, 235, 235),
                1,
                cv2.LINE_AA,
            )
            okay, png = cv2.imencode(".png", raster[:, :, ::-1])
            if not okay:
                raise ValueError("Could not encode native profile projection")
            (target / "cloud_projection.png").write_bytes(png.tobytes())
        for name, image in (
            ("source", self.source_preview()),
            ("overlay", self.overlay(selected)),
            ("profile", self.chart(selected)),
            ("assessment", self.assessment(selected)),
        ):
            okay, png = cv2.imencode(".png", image[:, :, ::-1])
            if not okay:
                raise ValueError("Could not encode frozen review image")
            (target / f"{name}.png").write_bytes(png.tobytes())
        (target / "review.json").write_bytes(
            json.dumps(document, indent=2, allow_nan=False).encode("utf-8") + b"\n"
        )
        return target


def capture_completed(record, bundle):
    if record is None:
        raise ValueError("No retained completed profile; execute in Debug before reviewing")
    if set(bundle.outputs) != set(record.ports) or any(
        bundle.outputs[name].payload.get(BINDING, {}).get("id") != record.identifier
        for name in record.ports
    ):
        raise ValueError("Completed model/result changed; capture the latest run again")
    if _json(bundle.outputs["report"].value) != record.report_json:
        raise ValueError("Completed sample decisions changed")
    scalars = {
        name: packet.value
        for name, packet in bundle.outputs.items()
        if name not in (*record._images, "cloud", "report")
    }
    if _json(scalars) != record.scalar_json:
        raise ValueError("Completed count/coverage/calibration changed")
    for name, expected in record._images.items():
        actual = bundle.outputs[name].value
        if (
            not isinstance(actual, np.ndarray)
            or actual.dtype != expected.dtype
            or not np.array_equal(actual, expected)
        ):
            raise ValueError("Completed image evidence changed")
    original = bundle.inputs["image"].value
    if original.dtype != bundle.outputs["image"].value.dtype or not np.array_equal(
        original, bundle.outputs["image"].value
    ):
        raise ValueError("Completed source/output pair changed")
    if record._cloud is not None:
        expected, actual = record._cloud, bundle.outputs["cloud"].value
        if (
            not isinstance(actual, PointCloud)
            or actual.frame != expected.frame
            or actual.units != expected.units
            or actual.source_size != expected.source_size
            or _json(actual.metadata) != _json(expected.metadata)
            or any(
                not np.array_equal(getattr(actual, name), getattr(expected, name))
                for name in ("points", "colors", "pixels", "normals")
            )
        ):
            raise ValueError("Completed cloud evidence changed")
    provenance = dict(
        snapshot_id=bundle.snapshot_id,
        block_id=bundle.block_id,
        output_revision=bundle.output_revision,
        execution_count=bundle.execution_count,
        passed=bool(bundle.passed),
        score=bundle.score,
        message=bundle.message,
        inputs={name: copy.deepcopy(packet.payload) for name, packet in bundle.inputs.items()},
        outputs={name: copy.deepcopy(packet.payload) for name, packet in bundle.outputs.items()},
    )
    frozen = freeze(record)
    groups = {}
    for candidate in frozen._result["report"]["candidates"]:
        groups.setdefault(candidate["bin"], []).append(candidate)
    return CompletedLaserCapture(
        frozen, readonly(original), describe_image(original), provenance, groups
    )
