"""Retained reference/ROI teaching with worker previews and transactional staging."""

import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Event

import cv2
import numpy as np
from opencv_dataflow.canvas import pixmap
from opencv_dataflow.cloud_viewer import CloudViewer
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from opencv_dataflow.images import ImageArray, preview_rgb
from opencv_dataflow.payloads import NO_VALUE
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from .cli import execute, load_image
from .dataflow import recipe_path, result_cloud, source_image
from .qt_region import StripeRegionView
from .recipe import load_recipe, save_recipe
from .teaching import TeachingDraft, calibration_record, rectangle


class LaserProfileTrainingDialog(QDialog):
    def __init__(self, parent, parameters, context):
        super().__init__(parent)
        self.setWindowTitle("SimpleLaserProfile · train and review")
        self.resize(1240, 850)
        self.parameters, self.context = parameters, context
        self.draft = TeachingDraft()
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="laser-teaching")
        self.pending = None
        self.closed = self.restoring = False
        self.unsubscribe = None
        self.last_result = None
        self.children = []
        layout = QVBoxLayout(self)
        self.status = QLabel(
            "1. Import/capture a reference. 2. Select one stripe. 3. Learn and review."
        )
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        row = QHBoxLayout()
        for title, action in (
            ("Import reference…", self.import_reference),
            ("Capture connected reference", self.capture_reference),
            ("Import recipe…", self.import_recipe),
        ):
            self.button(row, title, action)
        layout.addLayout(row)
        split = QSplitter(Qt.Orientation.Horizontal)
        layout.addWidget(split, 1)
        side = QWidget()
        controls = QVBoxLayout(side)
        self.identity = QLabel("No retained reference")
        self.identity.setWordWrap(True)
        controls.addWidget(self.identity)
        for title, action in (
            ("Import laser-off background…", self.import_background),
            ("Clear background", self.clear_background),
            ("Import camera / laser calibration…", self.import_calibration),
            ("Use pixel-only mode", self.clear_calibration),
            ("Import ROI mask image…", self.import_mask),
            ("Use full image region", lambda: self.set_region(None)),
        ):
            self.button(controls, title, action)
        form = QFormLayout()
        self.channel = QComboBox()
        self.channel.addItems(["intensity", "red_excess", "green_excess", "blue_excess"])
        self.direction = QComboBox()
        self.direction.addItems(["auto", "columns", "rows"])
        form.addRow("Signal", self.channel)
        form.addRow("Scan bins", self.direction)
        self.region_fields = []
        for text in ("ROI X", "ROI Y", "ROI width", "ROI height"):
            field = QSpinBox()
            field.setRange(0, 16384)
            self.region_fields.append(field)
            form.addRow(text, field)
        controls.addLayout(form)
        self.button(controls, "Set rectangle", self.region_from_fields)
        self.button(controls, "Draw new rectangle", lambda: self.region_mode("draw"))
        self.button(controls, "Move / resize rectangle", lambda: self.region_mode("edit"))
        self.button(controls, "Pan image", lambda: self.region_mode("pan"))
        self.channel.currentTextChanged.connect(self.settings_changed)
        self.direction.currentTextChanged.connect(self.settings_changed)
        self.learn_button = self.button(controls, "Learn / preview reference", self.start_learning)
        self.preview_file_button = self.button(
            controls, "Preview another image…", self.preview_file
        )
        self.preview_wire_button = self.button(
            controls, "Preview connected image", self.preview_connected
        )
        self.cloud_button = self.button(controls, "Open native profile cloud…", self.open_cloud)
        self.health = QLabel("Learned contrast/width and available bins will appear here.")
        self.health.setWordWrap(True)
        controls.addWidget(self.health)
        controls.addStretch()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(side)
        split.addWidget(scroll)
        self.tabs = QTabWidget()
        self.editor = StripeRegionView(self.tabs)
        self.preview_view = FilmstripImageView(self.tabs)
        self.chart_view = FilmstripImageView(self.tabs)
        for view, title in (
            (self.editor, "Training reference"),
            (self.preview_view, "Preview image"),
            (self.chart_view, "Profile / availability"),
        ):
            page = QWidget()
            box = QVBoxLayout(page)
            box.addWidget(view, 1)
            zoom = QHBoxLayout()
            for text, action in (
                ("−", lambda v=view: v.zoom(0.8)),
                ("+", lambda v=view: v.zoom(1.25)),
                ("Fit", view.fit_image),
                ("100%", view.actual_size),
            ):
                self.button(zoom, text, action)
            box.addLayout(zoom)
            self.tabs.addTab(page, title)
        self.editor.region_changed.connect(lambda roi: self.safe(lambda: self.set_region(roi)))
        split.addWidget(self.tabs)
        split.setSizes([300, 940])
        hint = QLabel(
            "Scroll to zoom; Pan to move the view. ROI handles resize the region in source pixels. "
            "Imported masks stay exact until replaced. Preview images never become training. "
            "Stage prepares a new recipe; Apply configuration in the host commits it."
        )
        hint.setWordWrap(True)
        layout.addWidget(hint)
        row = QHBoxLayout()
        self.stage_button = self.button(row, "Stage recipe", self.stage)
        self.button(row, "Cancel", self.reject)
        layout.addLayout(row)
        self.timer = QTimer(self)
        self.timer.setInterval(40)
        self.timer.timeout.connect(self.poll)
        if hasattr(context, "subscribe_outputs"):
            self.unsubscribe = context.subscribe_outputs(self.outputs_changed)
        if parameters.get("recipe_path"):
            self.safe(
                lambda: self.restore_recipe(
                    recipe_path(context.project_dir, parameters["recipe_path"]),
                    parameters["sha256"],
                )
            )
        self.refresh()

    def button(self, layout, title, action):
        button = QPushButton(title)
        button.setAutoDefault(False)
        button.clicked.connect(lambda checked=False: self.safe(action))
        layout.addWidget(button)
        return button

    def safe(self, action):
        try:
            action()
        except Exception as error:
            self.status.setText(str(error))

    def choose(self, title, pattern):
        path, _ = QFileDialog.getOpenFileName(self, title, "", pattern)
        return Path(path) if path else None

    def invalidate(self):
        if self.pending:
            self.pending[1].set()
        self.last_result = None
        self.health.setText("Edited draft; Learn again before Stage. Old results are cleared.")
        for view in (self.preview_view, self.chart_view):
            view.image_item.setPixmap(QPixmap())
        if self.draft.reference is not None:
            image = preview_rgb(
                ImageArray(
                    self.draft.reference, "gray" if self.draft.reference.ndim == 2 else "rgb"
                )
            ).copy()
            if self.draft.mask is not None:
                contours, _ = cv2.findContours(
                    self.draft.mask.astype(np.uint8), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE
                )
                cv2.drawContours(image, contours, -1, (30, 210, 230), 1)
            self.editor.set_image(pixmap(ImageArray(image, "rgb")))
        self.refresh()

    def set_reference(self, image, source="Imported reference"):
        self.draft.reference_image(image, source=source)
        self.invalidate()
        self.status.setText("Reference retained. Select one stripe region, then Learn.")

    def import_reference(self):
        path = self.choose("Reference image", "Images (*.png *.jpg *.jpeg *.bmp *.tif *.tiff)")
        if path:
            self.set_reference(load_image(path), path.name)

    def capture(self):
        self.context.refresh_images()
        packet = self.context.snapshot_input_image("image")
        return source_image(packet.value, packet.payload), self.context.output_revision

    def capture_reference(self):
        image, revision = self.capture()
        self.set_reference(image, f"Connected source snapshot / publication {revision}")

    def restore_recipe(self, path, digest=None):
        if self.pending:
            raise ValueError("Wait for the current preview before importing a recipe")
        recipe = load_recipe(path, sha256=digest)
        self.draft.restore(recipe)
        self.editor.set_image(
            pixmap(ImageArray(recipe.reference, "gray" if recipe.reference.ndim == 2 else "rgb"))
        )
        self.refresh()
        self.start_preview(recipe.reference, reference=True, title="Retained trained reference")

    def import_recipe(self):
        path = self.choose("Retained laser recipe", "Laser profile (*.slp)")
        if path:
            self.restore_recipe(path)

    def import_background(self):
        path = self.choose("Laser-off background", "Images (*.png *.jpg *.bmp *.tif *.tiff)")
        if path:
            self.draft.set_background(load_image(path))
            self.invalidate()

    def clear_background(self):
        self.draft.set_background(None)
        self.invalidate()

    def import_calibration(self):
        path = self.choose("Known camera / laser-plane calibration", "Calibration (*.json)")
        if path:
            self.draft.set_calibration(*calibration_record(path))
            self.invalidate()

    def clear_calibration(self):
        self.draft.set_calibration(None, None, {})
        self.invalidate()

    def import_mask(self):
        path = self.choose("Binary source ROI mask", "Mask images (*.png *.bmp *.tif *.tiff)")
        if path:
            self.draft.set_mask(load_image(path))
            self.invalidate()

    def set_region(self, roi):
        self.draft.set_mask(None) if roi is None else self.draft.region(tuple(roi))
        self.invalidate()

    def region_from_fields(self):
        self.set_region(tuple(field.value() for field in self.region_fields))

    def region_mode(self, mode):
        self.editor.mode = mode
        self.tabs.setCurrentIndex(0)
        self.status.setText(
            "Draw a rectangle."
            if mode == "draw"
            else "Drag inside to move, or drag corner handles to resize."
            if mode == "edit"
            else "Drag to pan; scroll to zoom."
        )

    def settings_changed(self, *_):
        if not self.restoring:
            self.draft.channel, self.draft.direction = (
                self.channel.currentText(),
                self.direction.currentText(),
            )
            self.draft.changed()
            self.invalidate()

    def submit(self, action, callback, *, publication=None):
        if self.pending:
            raise ValueError("Wait for the current task, or cancel the popup")
        cancellation = Event()
        self.pending = (
            self.pool.submit(action, cancellation.is_set),
            cancellation,
            self.draft.revision,
            callback,
            publication,
        )
        self.timer.start()
        self.status.setText("Working on a frozen draft…")
        self.refresh()

    def start_learning(self):
        job = self.draft.job()

        def completed(value):
            if self.draft.accept(job, value):
                self.show_result(value[1], reference=True, title="Newly learned reference")

        self.submit(job.run, completed)

    def start_preview(self, image, *, reference=False, title="Test preview", publication=None):
        recipe = self.draft.candidate
        if recipe is None:
            raise ValueError("Learn the current draft before previewing")
        self.submit(
            lambda cancelled: execute(recipe, image, cancelled=cancelled),
            lambda result: self.show_result(result, reference=reference, title=title),
            publication=publication,
        )

    def preview_file(self):
        path = self.choose("Independent preview image", "Images (*.png *.jpg *.bmp *.tif *.tiff)")
        if path:
            self.start_preview(load_image(path), title="Independent preview: " + path.name)

    def preview_connected(self):
        image, revision = self.capture()
        self.start_preview(
            image, title=f"Connected preview / publication {revision}", publication=revision
        )

    def poll(self):
        if self.pending is None or not self.pending[0].done() or self.closed:
            return
        future, cancellation, revision, callback, publication = self.pending
        self.pending = None
        self.timer.stop()
        try:
            value = future.result()
            if (
                not cancellation.is_set()
                and revision == self.draft.revision
                and (publication is None or publication == self.context.output_revision)
            ):
                callback(value)
            else:
                self.status.setText("Discarded stale work. Preview or Learn the current draft.")
        except Exception as error:
            self.status.setText(str(error))
        self.refresh()

    def show_result(self, result, *, reference, title):
        self.last_result = result
        if reference:
            self.draft.result = result
            self.editor.set_image(pixmap(ImageArray(result["overlay"], "rgb")))
            self.editor.set_roi(rectangle(self.draft.mask, self.draft.reference.shape))
        else:
            self.preview_view.set_image(pixmap(ImageArray(result["overlay"], "rgb")))
            self.tabs.setCurrentIndex(1)
        self.chart_view.set_image(pixmap(ImageArray(result["chart"], "rgb")))
        r = result["report"]
        counts = ", ".join(f"{key}: {value}" for key, value in r["reason_counts"].items())
        self.status.setText(
            f"{title}: {r['valid_samples']}/{r['active_sample_count']} valid bins. {counts}"
        )
        s = self.draft.candidate.settings
        self.health.setText(
            f"{'Calibrated meters' if r['calibrated'] else 'PIXEL ONLY · no XYZ'}\n"
            f"Availability {r['coverage']:.1%} (not accuracy)\n"
            f"Frozen threshold {s.threshold:.6g}; width {s.minimum_width}..{s.maximum_width} px\n"
            "Review source coverage and independent examples before Stage / Apply."
        )

    def open_cloud(self):
        if self.last_result is None:
            raise ValueError("Preview a calibrated result first")
        cloud = result_cloud(self.last_result)
        if cloud is NO_VALUE:
            raise ValueError(
                "No valid metric profile; pixel-only/unavailable results have no cloud"
            )
        viewer = CloudViewer(None, self)
        viewer.set_cloud(cloud)
        self.children.append(viewer)
        viewer.show()

    def stage(self):
        if (
            self.pending
            or self.draft.candidate is None
            or self.draft.result is None
            or not self.draft.result["report"]["available"]
        ):
            raise ValueError("Learn the current draft and wait for its preview before Stage")
        relative = f"assets/laser_profile/{uuid.uuid4().hex}.slp"
        path = recipe_path(self.context.project_dir, relative)
        path.parent.mkdir(parents=True, exist_ok=True)
        digest = save_recipe(path, self.draft.candidate)
        self.parameters.update(recipe_path=relative, sha256=digest)
        self.accept()

    def refresh(self):
        self.restoring = True
        try:
            self.channel.setCurrentText(self.draft.channel)
            self.direction.setCurrentText(self.draft.direction)
            if self.draft.reference is not None:
                ref = self.draft.reference
                mode = (
                    "Calibrated camera / laser plane"
                    if self.draft.camera
                    else "PIXEL ONLY / no calibration"
                )
                self.identity.setText(
                    f"Retained {ref.shape[1]} × {ref.shape[0]} · {ref.dtype}\n{mode}\n"
                    + (
                        "Laser-off background retained"
                        if self.draft.background is not None
                        else "No laser-off background"
                    )
                )
                roi = rectangle(self.draft.mask, ref.shape)
                if roi is None:
                    self.identity.setText(
                        self.identity.text()
                        + f"\nImported ROI mask: {int(self.draft.mask.sum())} pixels"
                    )
                self.editor.set_roi(roi)
                if roi:
                    for field, value in zip(self.region_fields, roi):
                        field.setValue(value)
            ready = self.draft.candidate is not None and self.pending is None
            self.learn_button.setEnabled(self.draft.reference is not None and self.pending is None)
            self.preview_file_button.setEnabled(ready)
            self.preview_wire_button.setEnabled(ready)
            self.stage_button.setEnabled(
                ready
                and self.context.project_dir is not None
                and self.draft.result is not None
                and self.draft.result["report"]["available"]
            )
            self.cloud_button.setEnabled(
                self.last_result is not None
                and self.last_result["report"]["valid_metric_samples"] > 0
            )
        finally:
            self.restoring = False

    def outputs_changed(self, *_):
        if not self.pending:
            self.status.setText(
                "New graph images are available. Capture explicitly; training stays frozen."
            )

    def done(self, result):
        if not self.closed:
            self.closed = True
            self.timer.stop()
            if self.pending:
                self.pending[1].set()
                self.pending[0].cancel()
            self.pool.shutdown(wait=False, cancel_futures=True)
            if self.unsubscribe:
                self.unsubscribe()
                self.unsubscribe = None
            for child in self.children:
                child.close()
        super().done(result)
