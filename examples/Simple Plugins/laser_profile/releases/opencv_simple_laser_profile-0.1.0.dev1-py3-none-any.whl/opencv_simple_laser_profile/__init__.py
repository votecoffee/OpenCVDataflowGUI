"""Retained laser stripe teaching, source-pixel diagnostics and calibrated profiles."""

from .geometry import Camera, Observation, Plane, calibrate_plane, intersect_pixels
from .profile import profile_image
from .recipe import Recipe, load_recipe, save_recipe, teach
from .stripe import StripeSettings, extract_stripe, learn_stripe

__all__ = [
    "Camera",
    "Observation",
    "Plane",
    "calibrate_plane",
    "intersect_pixels",
    "StripeSettings",
    "extract_stripe",
    "learn_stripe",
    "profile_image",
    "Recipe",
    "teach",
    "load_recipe",
    "save_recipe",
]
