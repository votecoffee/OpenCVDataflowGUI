"""Camera rays and laser planes in one physical camera frame, always meters.

No stripe image is interpreted as metric data without explicit camera and plane
calibration. Input ordering/invalid rows are retained; no missing-point filling.
"""

from dataclasses import dataclass

import cv2
import numpy as np


def array(value, shape, label):
    raw = np.asarray(value)
    if raw.dtype.kind not in "iuf" or raw.shape != shape or not np.isfinite(raw).all():
        raise ValueError("Use finite numeric " + label)
    result = np.array(raw, np.float64, copy=True)
    result.flags.writeable = False
    return result


def frame_name(value):
    if not isinstance(value, str) or not value.strip() or len(value) > 128:
        raise ValueError("Use an explicit physical camera frame")


@dataclass(frozen=True)
class Camera:
    matrix: np.ndarray
    image_size: tuple
    distortion: tuple = ()
    frame: str = "camera"

    def __post_init__(self):
        matrix = array(self.matrix, (3, 3), "camera intrinsics")
        if (
            min(matrix[0, 0], matrix[1, 1]) <= 0
            or abs(matrix[0, 1]) > 1e-12
            or abs(matrix[1, 0]) > 1e-12
            or not np.allclose(matrix[2], [0, 0, 1], atol=1e-12, rtol=0)
        ):
            raise ValueError("Use pinhole intrinsics with positive focal lengths")
        size = tuple(self.image_size)
        if len(size) != 2 or any(type(n) is not int or not 2 <= n <= 100000 for n in size):
            raise ValueError("Declare source image width and height")
        coefficients = np.asarray(self.distortion)
        if coefficients.ndim != 1 or len(coefficients) not in (0, 4, 5, 8, 12, 14):
            raise ValueError("Use OpenCV pinhole distortion coefficients, or an empty vector")
        coefficients = array(coefficients, coefficients.shape, "distortion coefficients")
        frame_name(self.frame)
        object.__setattr__(self, "matrix", matrix)
        object.__setattr__(self, "image_size", size)
        object.__setattr__(self, "distortion", tuple(coefficients))


@dataclass(frozen=True)
class Plane:
    normal: np.ndarray
    offset_m: float
    frame: str = "camera"

    def __post_init__(self):
        normal = array(self.normal, (3,), "plane normal")
        scale = np.linalg.norm(normal)
        if (
            scale < 1e-12
            or isinstance(self.offset_m, bool)
            or not isinstance(self.offset_m, (float, int, np.floating))
            or not np.isfinite(self.offset_m)
            or abs(self.offset_m / scale) > 100
        ):
            raise ValueError("Use a nonzero plane normal and finite metric offset within 100 m")
        frame_name(self.frame)
        object.__setattr__(self, "normal", array(normal / scale, (3,), "unit normal"))
        object.__setattr__(self, "offset_m", float(self.offset_m / scale))


def intersect_pixels(camera, plane, pixels, *, depth_range_m=(0.001, 100.0), min_incidence=1e-6):
    """Intersect distorted source pixels with n dot X + offset_m = 0.

    xyz_m has NaN rows for invalid samples; only valid rows are physical points.
    Axial depth bounds are in the declared camera frame, not Euclidean distance.
    """
    if (
        not isinstance(camera, Camera)
        or not isinstance(plane, Plane)
        or camera.frame != plane.frame
    ):
        raise ValueError("Camera and plane must name the same physical frame")
    raw = np.asarray(pixels)
    if raw.ndim != 2 or raw.shape[1:] != (2,) or len(raw) > 1000000:
        raise ValueError("Use up to one million source pixel pairs")
    pixels = array(raw, raw.shape, "pixel pairs")
    bounds = array(depth_range_m, (2,), "axial depth bounds")
    if not 0 < bounds[0] < bounds[1] <= 100:
        raise ValueError("Use positive increasing axial depth bounds within 100 m")
    if (
        isinstance(min_incidence, bool)
        or not np.isfinite(min_incidence)
        or not 0 < min_incidence < 1
    ):
        raise ValueError("Use a positive ray/plane incidence floor below one")
    reasons = np.full(len(pixels), "valid", dtype="<U24")
    xyz = np.full((len(pixels), 3), np.nan, np.float64)
    incidence = np.full(len(pixels), np.nan, np.float64)
    reprojection_error = np.full(len(pixels), np.nan, np.float64)
    inside = (
        (pixels[:, 0] >= 0)
        & (pixels[:, 0] < camera.image_size[0])
        & (pixels[:, 1] >= 0)
        & (pixels[:, 1] < camera.image_size[1])
    )
    reasons[~inside] = "outside_image"
    if inside.any():
        ids = np.flatnonzero(inside)
        distortion = np.asarray(camera.distortion) if camera.distortion else None
        criteria = (cv2.TERM_CRITERIA_COUNT | cv2.TERM_CRITERIA_EPS, 50, 1e-12)
        if hasattr(cv2, "undistortPointsIter"):  # OpenCV 4.x public iterative overload.
            normalized = cv2.undistortPointsIter(
                pixels[ids, None, :], camera.matrix, distortion, None, None, criteria
            )[:, 0, :]
        else:  # OpenCV 5 exposes the criteria on undistortPoints itself.
            normalized = cv2.undistortPoints(
                pixels[ids, None, :], camera.matrix, distortion, criteria=criteria
            )[:, 0, :]
        rays = np.c_[normalized, np.ones(len(ids))]
        projected, _ = cv2.projectPoints(
            rays,
            np.zeros(3),
            np.zeros(3),
            camera.matrix,
            np.asarray(camera.distortion) if camera.distortion else None,
        )
        error = np.linalg.norm(projected[:, 0, :] - pixels[ids], axis=1)
        reprojection_error[ids] = error
        denominator = rays @ plane.normal
        ratio = np.abs(denominator) / np.linalg.norm(rays, axis=1)
        incidence[ids] = ratio
        finite = (
            np.isfinite(rays).all(axis=1)
            & np.isfinite(ratio)
            & np.isfinite(error)
            & (error <= 1e-4)
        )
        stable = finite & (ratio >= min_incidence)
        reasons[ids[~finite]] = "undistort_failed"
        reasons[ids[finite & ~stable]] = "parallel_ray"
        depth = np.full(len(ids), np.nan)
        depth[stable] = -plane.offset_m / denominator[stable]
        reasons[ids[stable & (depth <= 0)]] = "behind_camera"
        positive = stable & (depth > 0)
        in_range = positive & (depth >= bounds[0]) & (depth <= bounds[1])
        reasons[ids[positive & ~in_range]] = "outside_depth_range"
        xyz[ids[in_range]] = rays[in_range] * depth[in_range, None]
    return dict(
        pixels=pixels.copy(),
        xyz_m=xyz,
        valid=reasons == "valid",
        reason=reasons,
        incidence=incidence,
        reprojection_error_px=reprojection_error,
        frame=camera.frame,
        units="m",
    )


@dataclass(frozen=True)
class Observation:
    identifier: str
    pixels: np.ndarray
    target_plane: Plane


def calibrate_plane(camera, observations):
    """Initial least-squares plane fit from stripes on known target planes.

    Every supplied point contributes; no robust/outlier or physical gauge claim.
    Later guided teaching supplies image observations and independent checks.
    """
    observations = tuple(observations)
    if not 2 <= len(observations) <= 256:
        raise ValueError("Use 2..256 independently identified target observations")
    identifiers, points = [], []
    target_planes = []
    total = 0
    for view in observations:
        if (
            not isinstance(view, Observation)
            or not isinstance(view.identifier, str)
            or not view.identifier.strip()
            or view.identifier in identifiers
        ):
            raise ValueError("Use unique nonempty calibration observation identities")
        raw = np.asarray(view.pixels)
        if raw.ndim != 2 or raw.shape[1:] != (2,) or total + len(raw) > 100000:
            raise ValueError("Bound calibration to 100000 observed pixel pairs")
        result = intersect_pixels(camera, view.target_plane, raw)
        if len(result["valid"]) < 3 or not result["valid"].all():
            raise ValueError("Each calibration observation needs at least three valid target hits")
        identifiers.append(view.identifier)
        points.append(result["xyz_m"])
        coefficients = np.r_[view.target_plane.normal, view.target_plane.offset_m]
        if coefficients[np.argmax(np.abs(coefficients[:3]))] < 0:
            coefficients = -coefficients
        target_planes.append(coefficients)
        total += len(raw)
    if all(np.allclose(p, target_planes[0], rtol=0, atol=1e-9) for p in target_planes[1:]):
        raise ValueError(
            "Target observations do not constrain a stable plane; vary target depth/pose"
        )
    counts = [len(p) for p in points]
    points = np.concatenate(points)
    center = points.mean(axis=0)
    _, singular, vt = np.linalg.svd(points - center, full_matrices=False)
    if singular[0] <= 1e-12 or singular[1] / singular[0] < 1e-4:
        raise ValueError(
            "Target observations do not constrain a stable plane; vary target depth/pose"
        )
    normal = vt[-1]
    if normal[np.argmax(np.abs(normal))] < 0:
        normal = -normal
    plane = Plane(normal, -float(normal @ center), camera.frame)
    residuals = points @ plane.normal + plane.offset_m
    return dict(
        plane=plane,
        points_m=points,
        residuals_m=residuals,
        rmse_m=float(np.sqrt(np.mean(residuals**2))),
        maximum_abs_residual_m=float(np.max(np.abs(residuals))),
        in_plane_rank_ratio=float(singular[1] / singular[0]),
        observation_ids=identifiers,
        observation_point_counts=counts,
        units="m",
        frame=camera.frame,
        method="All-point least-squares plane; not independent gauge qualification",
    )
