"""Diagnostic RGB raster views and a colored metric profile cloud."""

import cv2
import numpy as np

from .stripe import normalize

COLORS = dict(
    valid=(35, 210, 70),
    multiple_peaks=(225, 70, 220),
    input_ceiling=(255, 65, 45),
    clipped=(255, 175, 40),
    missing=(90, 145, 250),
    too_many_peaks=(225, 70, 220),
)


def color(reason):
    return COLORS.get(str(reason), (255, 175, 40))


def render_overlay(image, result, mask):
    values, _, _ = normalize(image)
    if values.ndim == 2:
        values = np.repeat(values[:, :, None], 3, axis=2)
    canvas = np.rint(values * 255).astype(np.uint8)
    if mask is not None:
        contours, _ = cv2.findContours(
            (np.asarray(mask) != 0).astype(np.uint8), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE
        )
        cv2.drawContours(canvas, contours, -1, (30, 210, 230), 1, cv2.LINE_AA)
    stripe = result["stripe"]
    for candidate in stripe["candidates"]:
        index = candidate["bin"]
        if result["reason"][index] == "outside_roi":
            continue
        point = tuple(np.rint(candidate["pixel"]).astype(int))
        cv2.drawMarker(canvas, point, color(result["reason"][index]), cv2.MARKER_CROSS, 5, 1)
    pixels = stripe["pixels"]
    for index in range(1, len(pixels)):
        if result["valid"][index - 1] and result["valid"][index]:
            cv2.line(
                canvas,
                tuple(np.rint(pixels[index - 1]).astype(int)),
                tuple(np.rint(pixels[index]).astype(int)),
                COLORS["valid"],
                1,
                cv2.LINE_AA,
            )
    for index, reason in enumerate(result["reason"]):
        if reason in ("outside_roi", "valid") or np.isfinite(pixels[index]).all():
            continue
        point = (
            (index, canvas.shape[0] - 3)
            if stripe["direction"] == "columns"
            else (canvas.shape[1] - 3, index)
        )
        cv2.drawMarker(canvas, point, color(reason), cv2.MARKER_TILTED_CROSS, 4, 1)
    mode = "CALIBRATED" if result["report"]["calibrated"] else "PIXEL ONLY / UNCALIBRATED"
    lines = [
        mode,
        f"Valid {result['report']['valid_samples']} / {result['report']['active_sample_count']}",
        "Green valid | magenta competing | red input ceiling",
        "Blue missing (border tick) | amber clipped / width rejected",
    ]
    for row, text in enumerate(lines):
        y = 17 + 17 * row
        cv2.putText(canvas, text, (7, y), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (0, 0, 0), 3, cv2.LINE_AA)
        cv2.putText(
            canvas, text, (7, y), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (245, 245, 245), 1, cv2.LINE_AA
        )
    return canvas


def render_chart(result):
    report = result["report"]
    canvas = np.full((380, 920, 3), 248, np.uint8)
    calibrated = report["calibrated"]
    values = (
        result["xyz_m"][:, 2] * 1000
        if calibrated
        else result["stripe"]["pixels"][:, 1 if report["direction"] == "columns" else 0]
    )
    accepted = result["valid"] & np.isfinite(values)
    observed = values[accepted]
    if len(observed):
        low, high = float(observed.min()), float(observed.max())
        margin = max((high - low) * 0.08, 0.001 if calibrated else 1.0)
        low, high = low - margin, high + margin
    else:
        low, high = 0.0, 1.0
    left, right, top, bottom = 85, 895, 58, 285
    cv2.putText(
        canvas,
        f"Z [mm] / {report['frame']}" if calibrated else "Cross-stripe coordinate [pixels]",
        (15, 24),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.62,
        (20, 30, 40),
        1,
        cv2.LINE_AA,
    )
    for fraction in np.linspace(0, 1, 5):
        y = round(bottom - (bottom - top) * fraction)
        cv2.line(canvas, (left, y), (right, y), (215, 220, 225), 1)
        cv2.putText(
            canvas,
            f"{low + (high - low) * fraction:.3f}",
            (3, y + 4),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.42,
            (40, 40, 40),
            1,
        )
    x = left + np.arange(len(values)) / max(1, len(values) - 1) * (right - left)
    y = bottom - (values - low) / (high - low) * (bottom - top)
    for i in np.flatnonzero(accepted):
        point = (round(x[i]), round(y[i]))
        cv2.circle(canvas, point, 1, COLORS["valid"], -1)
        if i and accepted[i - 1]:
            cv2.line(
                canvas, (round(x[i - 1]), round(y[i - 1])), point, COLORS["valid"], 1, cv2.LINE_AA
            )
    for i, reason in enumerate(result["reason"]):
        if reason != "outside_roi":
            cv2.line(canvas, (round(x[i]), 310), (round(x[i]), 319), color(reason), 1)
    cv2.putText(
        canvas,
        f"Source {report['direction']} 0..{max(0, len(values) - 1)} / gaps remain unavailable",
        (left, 344),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.49,
        (30, 35, 40),
        1,
        cv2.LINE_AA,
    )
    cv2.putText(
        canvas,
        f"Available {report['valid_samples']}/{report['active_sample_count']} | "
        f"coverage {report['coverage']:.1%}",
        (left, 367),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.49,
        (30, 35, 40),
        1,
        cv2.LINE_AA,
    )
    return canvas


def write_cloud(path, result):
    if not result["report"]["calibrated"]:
        raise ValueError("Pixel-only stripe results have no metric cloud")
    points = result["xyz_m"][result["valid"]]
    if not len(points):
        raise ValueError("No valid metric samples; no cloud written")
    with path.open("x", encoding="ascii", newline="\n") as stream:
        stream.write(
            f"ply\nformat ascii 1.0\ncomment units m\nelement vertex {len(points)}\n"
            "property float x\nproperty float y\nproperty float z\nproperty uchar red\n"
            "property uchar green\nproperty uchar blue\nend_header\n"
        )
        for point in points:
            stream.write(" ".join(f"{v:.9g}" for v in point) + " 35 210 70\n")
