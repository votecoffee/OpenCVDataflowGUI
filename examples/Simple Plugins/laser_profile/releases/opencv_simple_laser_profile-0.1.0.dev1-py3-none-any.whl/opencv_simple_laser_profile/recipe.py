"""Bounded portable recipes retaining reference, ROI, background and calibration."""

import hashlib
import io
import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from tempfile import NamedTemporaryFile
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np

from .geometry import Camera, Plane
from .stripe import StripeSettings, inputs, learn_stripe, normalize

LIMIT = 128 * 1024 * 1024


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("Duplicate JSON key")
            result[key] = value
        return result

    def number(value):
        result = float(value)
        if not np.isfinite(result):
            raise ValueError("Nonfinite JSON number")
        return result

    def bad(value):
        raise ValueError("Nonfinite JSON number")

    return json.loads(raw, object_pairs_hook=pairs, parse_float=number, parse_constant=bad)


def copied(value):
    if value is None:
        return None
    result = np.array(value, copy=True, order="C")
    result.flags.writeable = False
    return result


@dataclass(frozen=True)
class Recipe:
    settings: StripeSettings
    reference: np.ndarray = field(repr=False)
    mask: np.ndarray | None = field(default=None, repr=False)
    background: np.ndarray | None = field(default=None, repr=False)
    camera: Camera | None = None
    laser: Plane | None = None
    metadata: dict = field(default_factory=dict)

    def __post_init__(self):
        if not isinstance(self.settings, StripeSettings):
            raise ValueError("Retain validated stripe settings")
        values = [v for v in (self.reference, self.mask, self.background) if v is not None]
        if sum(np.asarray(v).nbytes for v in values) > LIMIT - 1024 * 1024:
            raise ValueError("Retained image arrays exceed the recipe budget")
        normalize(self.reference)
        inputs(self.reference, self.settings.channel, self.mask, self.background)
        if (self.camera is None) != (self.laser is None):
            raise ValueError("Retain both camera and laser plane, or pixel-only mode")
        if self.camera is not None:
            if (
                not isinstance(self.camera, Camera)
                or not isinstance(self.laser, Plane)
                or self.camera.frame != self.laser.frame
                or self.camera.image_size != tuple(np.asarray(self.reference).shape[1::-1])
            ):
                raise ValueError(
                    "Retained calibration must match source dimensions and physical frame"
                )
        if not isinstance(self.metadata, dict):
            raise ValueError("Retain plain JSON source/calibration metadata")
        encoded = json.dumps(self.metadata, allow_nan=False).encode()
        if len(encoded) > 4 * 1024 * 1024:
            raise ValueError("Recipe metadata exceeds 4 MiB")
        object.__setattr__(self, "metadata", strict_json(encoded))
        object.__setattr__(self, "reference", copied(self.reference))
        object.__setattr__(self, "background", copied(self.background))
        object.__setattr__(
            self, "mask", copied(np.asarray(self.mask) != 0) if self.mask is not None else None
        )


def teach(
    reference,
    *,
    mask=None,
    background=None,
    camera=None,
    laser=None,
    channel="intensity",
    direction="auto",
    metadata=None,
):
    settings, health = learn_stripe(
        reference, mask=mask, background=background, channel=channel, direction=direction
    )
    if not health["valid_bins"]:
        raise ValueError("Reference is unavailable: review exposure, stripe ROI and input ceiling")
    evidence = dict(metadata or {})
    evidence["training_health"] = health
    return Recipe(settings, reference, mask, background, camera, laser, evidence)


def array_bytes(value):
    stream = io.BytesIO()
    np.save(stream, value, allow_pickle=False)
    return stream.getvalue()


def read_array(raw):
    stream = io.BytesIO(raw)
    version = np.lib.format.read_magic(stream)
    if version not in ((1, 0), (2, 0)):
        raise ValueError("Use NPY version 1 or 2")
    reader = (
        np.lib.format.read_array_header_1_0
        if version == (1, 0)
        else np.lib.format.read_array_header_2_0
    )
    shape, _, dtype = reader(stream)
    if (
        len(shape) not in (2, 3)
        or min(shape) < 2
        or max(shape[:2]) > 16384
        or np.prod(shape[:2]) > 16_000_000
        or (len(shape) == 3 and shape[2] != 3)
        or dtype.str not in ("|u1", "<u2", "<f4", "<f8", "|b1")
        or int(np.prod(shape)) * dtype.itemsize != len(raw) - stream.tell()
    ):
        raise ValueError("Invalid bounded numeric image header")
    return np.load(io.BytesIO(raw), allow_pickle=False)


def save_recipe(path, recipe):
    if not isinstance(recipe, Recipe):
        raise ValueError("Save a trained laser-profile recipe")
    path = Path(path)
    if path.suffix != ".slp":
        raise ValueError("Use a .slp recipe filename")
    if path.exists():
        raise FileExistsError("Preserve the existing recipe; choose a new filename")
    entries = {
        name + ".npy": array_bytes(getattr(recipe, name))
        for name in ("reference", "mask", "background")
        if getattr(recipe, name) is not None
    }
    camera = (
        None
        if recipe.camera is None
        else dict(
            matrix=recipe.camera.matrix.tolist(),
            image_size=list(recipe.camera.image_size),
            distortion=list(recipe.camera.distortion),
            frame=recipe.camera.frame,
        )
    )
    laser = (
        None
        if recipe.laser is None
        else dict(
            normal=recipe.laser.normal.tolist(),
            offset_m=recipe.laser.offset_m,
            frame=recipe.laser.frame,
        )
    )
    manifest = dict(
        schema="simple_laser_profile_recipe/v1",
        settings=asdict(recipe.settings),
        camera=camera,
        laser=laser,
        metadata=recipe.metadata,
        sha256={name: hashlib.sha256(raw).hexdigest() for name, raw in entries.items()},
    )
    entries["recipe.json"] = (json.dumps(manifest, indent=2, allow_nan=False) + "\n").encode()
    if sum(map(len, entries.values())) > LIMIT:
        raise ValueError("Recipe expansion exceeds 128 MiB")
    with NamedTemporaryFile(dir=path.parent, prefix="." + path.name + ".", delete=False) as stream:
        temporary = Path(stream.name)
    try:
        with ZipFile(temporary, "w", compression=ZIP_DEFLATED) as archive:
            for name, raw in entries.items():
                archive.writestr(name, raw)
        if temporary.stat().st_size > LIMIT:
            raise ValueError("Recipe exceeds 128 MiB")
        os.link(temporary, path)  # Atomic, no replacement of an existing recipe.
    finally:
        temporary.unlink(missing_ok=True)
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_recipe(path, *, sha256=None):
    path = Path(path)
    if path.stat().st_size > LIMIT:
        raise ValueError("Recipe exceeds 128 MiB")
    raw = path.read_bytes()
    if len(raw) > LIMIT or (sha256 is not None and hashlib.sha256(raw).hexdigest() != sha256):
        raise ValueError("Recipe archive checksum/size differs")
    with ZipFile(io.BytesIO(raw)) as archive:
        infos = archive.infolist()
        names = [i.filename for i in infos]
        allowed = {"recipe.json", "reference.npy", "mask.npy", "background.npy"}
        if (
            set(names) - allowed
            or len(names) != len(set(names))
            or not {"recipe.json", "reference.npy"} <= set(names)
            or any(i.flag_bits & 1 for i in infos)
            or sum(i.file_size for i in infos) > LIMIT
            or archive.getinfo("recipe.json").file_size > 4 * 1024 * 1024
        ):
            raise ValueError("Invalid bounded recipe members")
        manifest = strict_json(archive.read("recipe.json"))
        if manifest.get("schema") != "simple_laser_profile_recipe/v1":
            raise ValueError("Unsupported laser-profile recipe schema")
        if set(manifest["sha256"]) != set(names) - {"recipe.json"}:
            raise ValueError("Recipe array manifest differs")
        arrays = {}
        for name in names:
            if name == "recipe.json":
                continue
            body = archive.read(name)
            if hashlib.sha256(body).hexdigest() != manifest["sha256"][name]:
                raise ValueError("Retained array checksum differs")
            arrays[name[:-4]] = read_array(body)
    camera = Camera(**manifest["camera"]) if manifest["camera"] is not None else None
    laser = Plane(**manifest["laser"]) if manifest["laser"] is not None else None
    return Recipe(
        StripeSettings(**manifest["settings"]),
        camera=camera,
        laser=laser,
        metadata=manifest["metadata"],
        **arrays,
    )
