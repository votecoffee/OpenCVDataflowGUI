"""Explicit offline teaching/replay. Saved recipes never select executable code."""

import argparse
import json
from pathlib import Path

import cv2
import numpy as np

from .geometry import Camera, Plane
from .profile import profile_image
from .recipe import load_recipe, save_recipe, strict_json, teach
from .render import write_cloud


def load_image(path):
    path = Path(path)
    if path.stat().st_size > 128 * 1024 * 1024:
        raise ValueError("Image file exceeds 128 MiB")
    # Bounds are checked on the header before OpenCV allocates the image.
    from PIL import Image

    with Image.open(path) as header:
        if max(header.size) > 16384 or header.width * header.height > 16_000_000:
            raise ValueError("Image expansion exceeds the declared pixel bound")
    image = cv2.imdecode(np.frombuffer(path.read_bytes(), np.uint8), cv2.IMREAD_UNCHANGED)
    if image is None:
        raise ValueError("Cannot decode source image")
    if image.ndim == 3 and image.shape[2] == 3:
        image = image[:, :, ::-1].copy()
    return image


def save_image(path, rgb):
    okay, raw = cv2.imencode(".png", rgb[:, :, ::-1])
    if not okay:
        raise ValueError("Cannot encode result image")
    with path.open("xb") as stream:
        stream.write(raw.tobytes())


def execute(recipe, image, *, graphics=True):
    if image.shape != recipe.reference.shape or image.dtype != recipe.reference.dtype:
        raise ValueError(
            "Execution image must match taught source dimensions, encoding and channels"
        )
    return profile_image(
        image,
        recipe.settings,
        mask=recipe.mask,
        background=recipe.background,
        camera=recipe.camera,
        laser=recipe.laser,
        graphics=graphics,
    )


def export_result(output, result):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    with (output / "report.json").open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(result["report"], indent=2, allow_nan=False) + "\n")
    if result["overlay"] is not None:
        save_image(output / "overlay.png", result["overlay"])
        save_image(output / "profile.png", result["chart"])
    if result["report"]["valid_metric_samples"]:
        write_cloud(output / "profile.ply", result)
    return output


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    train = commands.add_parser("train", help="Learn contrast/width from a retained reference")
    train.add_argument("reference", type=Path)
    train.add_argument("--recipe", type=Path, required=True)
    train.add_argument("--roi", type=int, nargs=4, metavar=("X", "Y", "WIDTH", "HEIGHT"))
    train.add_argument("--mask", type=Path)
    train.add_argument("--background", type=Path)
    train.add_argument("--calibration", type=Path)
    train.add_argument(
        "--channel",
        default="intensity",
        choices=["intensity", "red_excess", "green_excess", "blue_excess"],
    )
    train.add_argument("--direction", default="auto", choices=["auto", "columns", "rows"])
    run = commands.add_parser("run", help="Run frozen settings on an explicit new image")
    run.add_argument("recipe", type=Path)
    run.add_argument("image", type=Path)
    run.add_argument("--output", type=Path, required=True)
    run.add_argument("--sha256")
    run.add_argument("--no-graphics", action="store_true")
    inspect = commands.add_parser(
        "inspect", help="Read retained teaching without executing an inspection"
    )
    inspect.add_argument("recipe", type=Path)
    inspect.add_argument("--sha256")
    args = parser.parse_args(argv)
    if args.command == "train":
        reference = load_image(args.reference)
        mask = load_image(args.mask) if args.mask else None
        if args.roi is not None:
            x, y, w, h = args.roi
            if (
                min(x, y) < 0
                or min(w, h) <= 0
                or x + w > reference.shape[1]
                or y + h > reference.shape[0]
            ):
                raise ValueError("Select a rectangle within the original source image")
            box = np.zeros(reference.shape[:2], bool)
            box[y : y + h, x : x + w] = True
            mask = box if mask is None else box & (mask != 0)
        camera, laser, evidence = None, None, {}
        if args.calibration:
            if args.calibration.stat().st_size > 4 * 1024 * 1024:
                raise ValueError("Calibration metadata exceeds 4 MiB")
            evidence = strict_json(args.calibration.read_bytes())
            if evidence.get("schema") != "simple_laser_calibration/v1":
                raise ValueError("Use an explicit simple_laser_calibration/v1 definition")
            camera, laser = Camera(**evidence["camera"]), Plane(**evidence["laser"])
        recipe = teach(
            reference,
            mask=mask,
            background=load_image(args.background) if args.background else None,
            channel=args.channel,
            direction=args.direction,
            camera=camera,
            laser=laser,
            metadata=dict(calibration_evidence=evidence),
        )
        checked = execute(recipe, reference, graphics=False)
        if camera is not None and not checked["report"]["valid_metric_samples"]:
            raise ValueError("Reference has no valid metric samples; review calibration")
        digest = save_recipe(args.recipe, recipe)
        print(
            json.dumps(
                dict(
                    recipe=args.recipe.name,
                    sha256=digest,
                    calibrated=camera is not None,
                    training_health=recipe.metadata["training_health"],
                )
            )
        )
    else:
        recipe = load_recipe(args.recipe, sha256=args.sha256)
        if args.command == "inspect":
            print(
                json.dumps(
                    dict(
                        calibrated=recipe.camera is not None,
                        reference_shape=list(recipe.reference.shape),
                        reference_dtype=str(recipe.reference.dtype),
                        settings=recipe.settings.__dict__,
                        metadata=recipe.metadata,
                    ),
                    allow_nan=False,
                )
            )
        else:
            result = execute(recipe, load_image(args.image), graphics=not args.no_graphics)
            export_result(args.output, result)
            print(
                json.dumps(
                    {
                        k: result["report"][k]
                        for k in (
                            "calibrated",
                            "units",
                            "active_sample_count",
                            "valid_samples",
                            "reason_counts",
                        )
                    }
                )
            )


if __name__ == "__main__":
    main()
