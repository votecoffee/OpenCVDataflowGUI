"""Stripe-to-profile execution; calibrated geometry and pixel-only results stay explicit."""

import numpy as np

from .geometry import Camera, Plane, intersect_pixels
from .stripe import extract_stripe


def profile_image(
    image,
    settings,
    *,
    mask=None,
    background=None,
    camera=None,
    laser=None,
    depth_range_m=(0.001, 100.0),
    graphics=True,
    cancelled=lambda: False,
):
    if (camera is None) != (laser is None):
        raise ValueError("Supply both camera and laser plane, or use pixel-only mode")
    calibrated = camera is not None
    if calibrated and (
        not isinstance(camera, Camera)
        or not isinstance(laser, Plane)
        or tuple(camera.image_size) != tuple(np.asarray(image).shape[1::-1])
    ):
        raise ValueError("Camera calibration must match the original image dimensions")
    stripe = extract_stripe(image, settings, mask=mask, background=background, cancelled=cancelled)
    valid = stripe["valid"].copy()
    reasons = stripe["reason"].copy()
    xyz = np.full((len(valid), 3), np.nan) if calibrated else None
    geometry_valid = np.zeros(len(valid), bool)
    incidence = np.full(len(valid), np.nan)
    if calibrated:
        ids = np.flatnonzero(valid)
        hits = intersect_pixels(camera, laser, stripe["pixels"][ids], depth_range_m=depth_range_m)
        xyz[ids] = hits["xyz_m"]
        geometry_valid[ids] = hits["valid"]
        incidence[ids] = hits["incidence"]
        reasons[ids] = hits["reason"]
        valid &= geometry_valid
    if cancelled():
        raise RuntimeError("Laser profile cancelled; no result published")
    active = reasons != "outside_roi"
    rows = []
    for index in range(len(valid)):
        pixel = stripe["pixels"][index]
        rows.append(
            dict(
                bin=index,
                pixel=pixel.tolist() if np.isfinite(pixel).all() else None,
                stripe_valid=bool(stripe["valid"][index]),
                valid=bool(valid[index]),
                reason=str(reasons[index]),
                xyz_m=xyz[index].tolist() if calibrated and valid[index] else None,
                peak_contrast=float(stripe["peak"][index]),
                support_width_px=float(stripe["support_width_px"][index]),
                candidate_count=int(stripe["candidate_count"][index]),
                input_ceiling=bool(stripe["at_input_ceiling"][index]),
                incidence=float(incidence[index]) if np.isfinite(incidence[index]) else None,
            )
        )
    report = dict(
        schema="simple_laser_profile_result/v1",
        calibrated=calibrated,
        units="m" if calibrated else "pixels",
        frame=camera.frame if calibrated else None,
        direction=settings.direction,
        image_size=stripe["image_size"],
        settings=stripe["settings"],
        sample_count=len(valid),
        active_sample_count=int(active.sum()),
        valid_pixel_samples=int(stripe["valid"].sum()),
        valid_metric_samples=int(geometry_valid.sum()),
        valid_samples=int(valid.sum()),
        available=bool(valid.any()),
        coverage=float(valid.sum() / active.sum()) if active.any() else 0.0,
        reason_counts={
            str(reason): int(np.sum(reasons[active] == reason))
            for reason in np.unique(reasons[active])
        },
        samples=rows,
        candidates=stripe["candidates"],
        calibration=(
            dict(
                camera_matrix=camera.matrix.tolist(),
                distortion=list(camera.distortion),
                laser_normal=laser.normal.tolist(),
                laser_offset_m=laser.offset_m,
                depth_range_m=list(depth_range_m),
            )
            if calibrated
            else None
        ),
        method="Smoothed cross-section peak separation and positive-signal weighted centroid",
        scope="One identified laser sheet; invalid bins remain unavailable, with no gap filling",
    )
    result = dict(
        report=report,
        stripe=stripe,
        xyz_m=xyz,
        valid=valid,
        reason=reasons,
        overlay=None,
        chart=None,
    )
    if graphics:
        from .render import render_chart, render_overlay

        result["overlay"] = render_overlay(image, result, mask)
        result["chart"] = render_chart(result)
    return result
