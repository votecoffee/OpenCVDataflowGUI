"""Native fly-around review of frozen completed 3D localization, separate from training."""

import uuid
from pathlib import Path

from opencv_dataflow.cloud_viewer import CloudViewer
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
)

from .completed_review import LAYERS
from .review import rejection_lines


class CompletedLocationReviewDialog(CloudViewer):
    def __init__(self, parent, context, capture):
        super().__init__(None, parent)
        self.setWindowTitle("Completed 3D localization review")
        self.resize(1280, 940)
        self.snapshot = None
        self._capture = capture
        self._closed = False
        actions = QHBoxLayout()
        self.capture_button = QPushButton("Capture latest completed run")
        self.capture_button.clicked.connect(self.capture_latest)
        actions.addWidget(self.capture_button)
        self.export_button = QPushButton("Export frozen review…")
        self.export_button.setEnabled(False)
        self.export_button.clicked.connect(self.choose_export)
        actions.addWidget(self.export_button)
        close = QPushButton("Close review")
        close.clicked.connect(self.reject)
        actions.addWidget(close)
        self.layout().insertLayout(0, actions)
        self.identity, self.status, self.summary, self.legend, self.export_status = (
            QLabel() for _ in range(5)
        )
        for i, label in enumerate((self.identity, self.status, self.summary)):
            label.setTextFormat(Qt.TextFormat.PlainText)
            label.setWordWrap(True)
            self.layout().insertWidget(i + 1, label)
        self.selection = QComboBox()
        self.selection.currentIndexChanged.connect(self.show_selection)
        self.layout().insertWidget(4, self.selection)
        layers = QHBoxLayout()
        self.layers = {}
        for key, label in (
            ("scene", "Sampled measured scene"),
            ("axes", "Accepted pose axes"),
            ("alternatives", "Competing alternative"),
            ("supported", "Supported"),
            ("missing", "Missing"),
            ("hidden", "Self-hidden"),
            ("free_space", "Free space"),
        ):
            box = QCheckBox(label)
            box.setChecked(key != "alternatives")
            box.toggled.connect(self.show_selection)
            self.layers[key] = box
            layers.addWidget(box)
        self.layout().insertLayout(5, layers)
        self.legend.setText(
            "Gray: measured scene samples · Green: supported expected model · "
            "Red: missing model support · Blue-gray: self-hidden · "
            "Magenta: free-space contradictions · RGB: accepted model-frame axes. "
            "Orange: rejected/alternative expected model, "
            "never a detection or extra sensor return. "
            "Scores are geometric/projective fit, not probabilities. "
            "Per-ray maps were not retained; no verification is repeated."
        )
        self.legend.setWordWrap(True)
        self.layout().addWidget(self.legend)
        self.export_status.setWordWrap(True)
        self.layout().addWidget(self.export_status)
        self.finished.connect(lambda *_: setattr(self, "_closed", True))
        unsubscribe = context.subscribe_outputs(self.publication_changed)
        self.finished.connect(unsubscribe)
        self.destroyed.connect(unsubscribe)
        self.capture_latest()

    def publication_changed(self, revision):
        if self.snapshot is not None and not self._closed:
            self.status.setText(
                "Editor publication changed. This frozen review stays unchanged; "
                "capture latest explicitly."
            )

    def capture_latest(self):
        if self._closed:
            return
        try:
            snapshot = self._capture()
        except (ValueError, RuntimeError, KeyError) as error:
            self.status.setText(
                str(error)
                + (" Previous frozen frame remains displayed." if self.snapshot is not None else "")
            )
            return
        self.snapshot = snapshot
        report, p = snapshot.record.report, snapshot.provenance
        source = snapshot.input_cloud()
        self.identity.setText(
            f"{p['block_id']} · completion {p['execution_count']} · "
            f"recipe {snapshot.record.parameters['sha256'][:16]} · "
            f"{len(source.points):,} consumed points · {source.units} · frame {source.frame}"
        )
        self.status.setText(
            "Frozen completed inputs, executed recipe and recorded accepted/rejected evidence. "
            "No localization, ICP, verification or recipe reload. Training is unchanged. "
            "Declared capture IDs and software pairing do not prove physical synchronization."
        )
        self.selection.blockSignals(True)
        self.selection.clear()
        self.selection.addItem("All accepted fits + sampled measured scene", ("all", None))
        for i, row in enumerate(report["matches"]):
            self.selection.addItem(
                f"Accepted {i + 1} — score {row['score']:.3f}, support {row['coverage']:.1%}",
                ("accepted", i),
            )
        reviews = report["execution"].get("candidate_review", [])
        for i, row in enumerate(reviews):
            self.selection.addItem(
                f"REJECTED {row['candidate_index']} — {row['stage']}, not a detection",
                ("rejected", i),
            )
        self.selection.addItem(
            "Exact consumed scene (original colors/normals/pixel mapping)", ("input", "scene")
        )
        if "depth_scene" in snapshot.input_cloud_names:
            self.selection.addItem(
                "Exact consumed depth_scene (first-return context)", ("input", "depth_scene")
            )
        self.selection.blockSignals(False)
        self.export_button.setEnabled(True)
        self.show_selection()

    def display_options(self):
        return dict(
            scene=self.layers["scene"].isChecked(),
            axes=self.layers["axes"].isChecked(),
            alternatives=self.layers["alternatives"].isChecked(),
            layers=tuple(key for key in LAYERS if self.layers[key].isChecked()),
        )

    def show_selection(self, *_):
        if self.snapshot is None or self.selection.currentData() is None:
            return
        report = self.snapshot.record.report
        kind, index = self.selection.currentData()
        for box in self.layers.values():
            box.setEnabled(kind != "input")
        if kind == "input":
            cloud = self.snapshot.input_cloud(index)
            details = [
                f"Exact consumed {index}; original measured points, not expected model geometry."
            ]
        else:
            cloud = self.snapshot.display_cloud(kind, index, **self.display_options())
            selected = self.snapshot.selection(kind, index)
            details = [report["assessment"]["message"]]
            if kind == "rejected":
                details += ["REJECTED POSE — not a detection"] + rejection_lines(
                    selected["evidence"], report["units"]
                )
            elif kind == "accepted":
                item = selected["evidence"]
                details += [
                    f"Accepted {index + 1}: score {item['score']:.4f} · "
                    f"visible support {item['coverage']:.1%} · "
                    f"RMSE {item['rmse']:.5g} {report['units']}"
                ]
                for key in ("depth_verification", "projective_scoring", "boundary_verification"):
                    item_report = item.get(key)
                    status = (
                        item_report.get("status", "recorded")
                        if item_report
                        else "unavailable/not evaluated"
                    )
                    details.append(f"{key}: {status}")
            details.append(
                f"{len(report['matches'])} accepted · {report['tested_candidates']} tested · "
                f"{len(report['execution'].get('candidate_review', []))} "
                "retained rejected candidates (at most 8)"
            )
        self.summary.setText("\n".join(details))
        self.set_cloud(cloud)

    def select_evidence(self, kind, index=None):
        for row in range(self.selection.count()):
            if tuple(self.selection.itemData(row)) == (kind, index):
                self.selection.setCurrentIndex(row)
                return
        raise ValueError("Requested completed evidence is unavailable")

    def export_to(self, directory):
        if self.snapshot is None:
            raise ValueError("Capture a completed localization before exporting")
        kind, index = self.selection.currentData()
        input_view = index if kind == "input" else None
        if kind == "input":
            kind, index = "all", None
        target = self.snapshot.export(
            directory,
            kind,
            index,
            yaw=self.yaw.value(),
            pitch=self.pitch.value(),
            input_view=input_view,
            **self.display_options(),
        )
        self.export_status.setText(f"Exported frozen review: {target}")
        return target

    def choose_export(self):
        parent = QFileDialog.getExistingDirectory(
            self, "Choose parent folder for a new frozen review"
        )
        if parent:
            try:
                self.export_to(Path(parent) / f"locate3d-review-{uuid.uuid4().hex[:12]}")
            except (ValueError, OSError) as error:
                self.export_status.setText(str(error))
