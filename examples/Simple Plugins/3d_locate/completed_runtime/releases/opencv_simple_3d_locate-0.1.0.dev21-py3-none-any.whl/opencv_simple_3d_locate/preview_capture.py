"""Validate one private completed-input snapshot before changing a trainer draft."""

from dataclasses import dataclass

import numpy as np
from opencv_dataflow.pointclouds import PointCloud
from opencv_dataflow.tickets import ticket_key

from .model import _identity
from .observation import Camera


def _cloud(value, name):
    if not isinstance(value, PointCloud):
        raise ValueError(f"Processed {name} must be a PointCloud.")
    _identity(value.units, value.frame)
    points = np.asarray(value.points)
    if (
        points.ndim != 2
        or points.shape[1] != 3
        or len(points) > 2_000_000
        or not np.isfinite(points).all()
    ):
        raise ValueError(f"Processed {name} needs at most two million finite XYZ points.")
    if value.normals is not None:
        normals = np.asarray(value.normals)
        if (
            normals.shape != points.shape
            or not np.isfinite(normals).all()
            or np.any(np.linalg.norm(normals, axis=1) <= 1e-8)
        ):
            raise ValueError(f"Processed {name} has invalid surface normals.")
    return value


def _ticket(packet):
    value = packet.payload.get("ticket")
    if value is None:
        return None
    try:
        return ticket_key(value)
    except (ValueError, TypeError, KeyError, OverflowError):
        # Unknown metadata cannot prove a common acquisition. Preserve the
        # packet for inspection rather than interpreting another ticket format.
        return None


@dataclass(frozen=True)
class PreviewCapture:
    """Owns the host's copied bundle; its ID is not an acquisition identity."""

    bundle: object
    scene: PointCloud
    camera: Camera | None
    depth_scene: PointCloud | None
    pairing: str

    @property
    def summary(self):
        provided = ["search"]
        if self.camera is not None:
            provided.append("camera")
        if self.depth_scene is not None:
            provided.append("depth")
        judgment = "pass" if self.bundle.passed else "fail"
        pairing = {
            "not_applicable": "No separate depth input.",
            "matching_tickets": "Search/depth tickets agree; capture timing is unverified.",
            "different_tickets": "Search/depth tickets differ; pairing is unverified.",
            "mixed_tickets": "Mixed acquisition metadata; pairing is unverified.",
            "unverified": "Search/depth acquisition pairing is unverified.",
        }[self.pairing]
        return (
            f"Preview from completed run {self.bundle.execution_count} ({judgment}): "
            f"{', '.join(provided)}. {pairing}"
        )

    @property
    def details(self):
        lines = [
            f"Snapshot copy: {self.bundle.snapshot_id}",
            f"Block: {self.bundle.block_id}",
            f"Published output revision: {self.bundle.output_revision}",
        ]
        for name in ("scene", "depth_scene", "camera"):
            packet = self.bundle.inputs.get(name)
            key = None if packet is None else _ticket(packet)
            lines.append(f"{name} ticket: {str(key)[:240] if key is not None else 'unavailable'}")
        lines.append(
            "These are inputs from one completed execution, not proof of simultaneous capture. "
            "Camera calibration may be static. Per-port payloads remain in the private snapshot."
        )
        return "\n".join(lines)


def capture_processed(context):
    """One host call, no latest-value fallback, and no mutation of existing preview state.

    Omitting ports lets the host include provided optional inputs without
    treating their absence as an error. Validate every value before the caller
    commits the three preview inputs together. No additional cloud copies are
    needed: the host contract gives this caller a private owned bundle.
    """
    capture = getattr(context, "snapshot_processed_inputs", None)
    if not callable(capture):
        raise ValueError("This host does not support completed-input captures. Update the host.")
    bundle = capture()
    if bundle.block_id != context.block_id:
        raise ValueError("Processed inputs belong to a different block.")
    packets = bundle.inputs
    if "scene" not in packets:
        raise ValueError("No processed search scene is available. Run again in Debug profile.")
    scene = _cloud(packets["scene"].value, "scene")
    camera = Camera.from_record(packets["camera"].value) if "camera" in packets else None
    depth = (
        _cloud(packets["depth_scene"].value, "depth_scene") if "depth_scene" in packets else None
    )
    if camera is not None and (camera.units != scene.units or camera.frame != scene.frame):
        raise ValueError("Processed camera units/frame must match the search scene.")
    if depth is not None and (depth.units != scene.units or depth.frame != scene.frame):
        raise ValueError("Processed depth_scene units/frame must match the search scene.")
    pairing = "not_applicable"
    if depth is not None:
        measured = (packets["scene"], packets["depth_scene"])
        mixed = any(
            isinstance(packet.payload.get("coordination"), dict)
            and packet.payload["coordination"].get("mixed_tickets") is True
            for packet in measured
        )
        keys = tuple(_ticket(packet) for packet in measured)
        pairing = (
            "mixed_tickets"
            if mixed
            else (
                "unverified"
                if any(key is None for key in keys)
                else "matching_tickets"
                if keys[0] == keys[1]
                else "different_tickets"
            )
        )
    return PreviewCapture(bundle, scene, camera, depth, pairing)
