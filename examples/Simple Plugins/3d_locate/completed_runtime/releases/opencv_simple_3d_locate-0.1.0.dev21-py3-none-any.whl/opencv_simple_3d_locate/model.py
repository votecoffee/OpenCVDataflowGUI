"""Model preparation, portable settings, and oriented surface sampling."""

from dataclasses import dataclass, field
from numbers import Real

import cv2
import numpy as np

from .mesh import CADReference

MODEL_POINT_BUDGET = 2000
MODEL_CANDIDATE_BUDGET = 10000


@dataclass(frozen=True)
class Settings:
    sampling_distance: float = 0.03
    ppf_distance: float = 0.05
    angle_bins: int = 30
    scene_reference_step: float = 0.1
    normal_neighbors: int = 20
    model_viewpoint: tuple = (0.0, 0.0, 0.0)
    scene_viewpoint: tuple = (0.0, 0.0, 0.0)
    max_candidates: int = 24
    global_model_points: int = 384
    global_scene_points: int = 2048
    search_sampling: str = "uniform"
    refinement: str = "legacy"
    icp_iterations: int = 60
    icp_levels: int = 4
    distance_tolerance: float = 0.025
    max_rmse: float = 0.015
    min_coverage: float = 0.5
    normal_angle: float = 30.0
    min_normal_spread: float = 0.01
    min_unique_support: int = 20
    max_matches: int = 5
    overlap_threshold: float = 0.6
    overlap_metric: str = "combined"
    observation_mode: str = "surface"
    candidate_backend: str = "ppf"
    depth_verification: str = "auto"
    max_free_space: float = 0.1
    min_depth_coverage: float = 0.8
    execution_workers: int = 1
    pose_scoring: str = "geometric"
    boundary_verification: str = "off"

    def __post_init__(self):
        if self.boundary_verification not in ("off", "report", "auto"):
            raise ValueError("boundary_verification must be off, report, or auto.")
        if self.pose_scoring not in ("geometric", "projective"):
            raise ValueError("pose_scoring must be geometric or projective.")
        if self.depth_verification not in ("auto", "report", "off"):
            raise ValueError("depth_verification must be auto, report, or off.")
        if self.candidate_backend not in ("ppf", "ppf_planes", "ppf_features", "ppf_regions"):
            raise ValueError(
                "candidate_backend must be ppf, ppf_planes, ppf_features, or ppf_regions."
            )
        if self.observation_mode not in ("surface", "complete"):
            raise ValueError("observation_mode must be surface or complete.")
        if self.overlap_metric not in ("combined", "box", "scene_support"):
            raise ValueError("overlap_metric must be combined, box, or scene_support.")
        if self.search_sampling not in ("uniform", "geometry"):
            raise ValueError("search_sampling must be uniform or geometry.")
        if self.refinement not in ("legacy", "pyramid"):
            raise ValueError("refinement must be legacy or pyramid.")
        ranges = {
            "sampling_distance": (0.01, 0.2),
            "ppf_distance": (0.005, 0.2),
            "scene_reference_step": (0.02, 1),
            "distance_tolerance": (0.001, 0.2),
            "max_rmse": (0.0001, 0.2),
            "min_coverage": (0.05, 1),
            "normal_angle": (1, 89),
            "min_normal_spread": (0, 0.5),
            "overlap_threshold": (0, 1),
            "max_free_space": (0, 1),
            "min_depth_coverage": (0, 1),
        }
        for name, (low, high) in ranges.items():
            value = getattr(self, name)
            if (
                isinstance(value, bool)
                or not isinstance(value, Real)
                or not np.isfinite(value)
                or not low <= value <= high
            ):
                raise ValueError(f"{name} must be finite and within [{low}, {high}].")
        for name, low, high in (
            ("angle_bins", 8, 90),
            ("normal_neighbors", 6, 100),
            ("max_candidates", 1, 64),
            ("global_model_points", 100, 2000),
            ("global_scene_points", 128, 20000),
            ("icp_iterations", 1, 200),
            ("icp_levels", 1, 6),
            ("min_unique_support", 6, 2000),
            ("max_matches", 1, 20),
            ("execution_workers", 1, 8),
        ):
            if type(getattr(self, name)) is not int or not low <= getattr(self, name) <= high:
                raise ValueError(f"{name} must be an integer in [{low}, {high}].")
        for name in ("model_viewpoint", "scene_viewpoint"):
            point = np.asarray(getattr(self, name), float)
            if point.shape != (3,) or not np.isfinite(point).all():
                raise ValueError(f"{name} requires finite XYZ coordinates in cloud units.")
            object.__setattr__(self, name, tuple(point.tolist()))


def surface_module():
    module = getattr(cv2, "ppf_match_3d", None)
    if module is None:
        raise RuntimeError("Simple3DLocate requires an OpenCV contrib build with ppf_match_3d.")
    return module


def cloud(value):
    data = np.asarray(value, np.float32)
    if (
        data.ndim != 2
        or data.shape[1] not in (3, 6)
        or len(data) > 2_000_000
        or not np.isfinite(data).all()
    ):
        raise ValueError("Supply at most two million finite XYZ or XYZ/normal rows.")
    data = np.ascontiguousarray(data.copy())
    if data.shape[1] == 6 and len(data):
        lengths = np.linalg.norm(data[:, 3:], axis=1)
        if not np.isfinite(lengths).all() or np.any(lengths <= 1e-8):
            raise ValueError("Supplied surface normals must have finite nonzero lengths.")
        changed = np.abs(lengths - 1) > 1e-6
        data[changed, 3:] /= lengths[changed, None]
    return data


def rigid(value):
    pose = np.asarray(value, np.float64)
    if (
        pose.shape != (4, 4)
        or not np.isfinite(pose).all()
        or not np.allclose(pose[3], [0, 0, 0, 1], atol=1e-7, rtol=0)
        or not np.allclose(pose[:3, :3].T @ pose[:3, :3], np.eye(3), atol=1e-5, rtol=0)
        or not np.isclose(np.linalg.det(pose[:3, :3]), 1, atol=1e-5, rtol=0)
    ):
        raise ValueError("A pose requires a proper rigid 4 by 4 model-to-scene transform.")
    return pose


def transformed(data, pose):
    pose = rigid(pose)
    points = data[:, :3] @ pose[:3, :3].T + pose[:3, 3]
    return np.ascontiguousarray(np.c_[points, data[:, 3:] @ pose[:3, :3].T], np.float32)


def prepared(data, distance, neighbors, viewpoint, limit, *, bounded_model=False):
    if len(data) < 30:
        raise ValueError("A surface requires at least 30 points.")
    center = (data[:, :3].min(axis=0).astype(float) + data[:, :3].max(axis=0)) / 2
    cells = np.floor((data[:, :3].astype(float) - center) / distance)
    if np.max(np.abs(cells)) > 1e12:
        raise ValueError("Cloud extent exceeds the sampling range. Crop the scene first.")
    _, indices = np.unique(cells.astype(np.int64), axis=0, return_index=True)
    sampled = data[np.sort(indices)].copy()
    if len(sampled) < 30 or (len(sampled) > limit and not bounded_model):
        raise ValueError(
            f"Sampling produced {len(sampled)} points; require 30..{limit}. "
            "Adjust sampling distance or crop."
        )
    if bounded_model and len(sampled) > MODEL_CANDIDATE_BUDGET:
        from .geometry import search_indices

        sampled = np.ascontiguousarray(
            sampled[search_indices(sampled, MODEL_CANDIDATE_BUDGET, strategy="uniform")]
        )
    if sampled.shape[1] == 3:
        if len(sampled) <= neighbors:
            raise ValueError("Normal estimation requires more sampled points than neighbors.")
        status, sampled = surface_module().computeNormalsPC3d(sampled, neighbors, True, viewpoint)
        if status not in (0, 1) or sampled is None:
            raise ValueError("OpenCV could not estimate surface normals.")
        sampled = cloud(sampled)
    if bounded_model and len(sampled) > limit:
        from .geometry import search_indices

        sampled = sampled[search_indices(sampled, limit, strategy="geometry")]
    return np.ascontiguousarray(sampled, np.float32)


def normal_spread(normals):
    return float(np.linalg.eigvalsh(normals.astype(float).T @ normals / len(normals))[-2])


def _identity(units, frame):
    if (
        units not in ("m", "mm", "unitless")
        or not isinstance(frame, str)
        or not frame.strip()
        or len(frame) > 128
    ):
        raise ValueError(
            "Declare m/mm/unitless units and a nonempty coordinate frame of at most 128 characters."
        )


@dataclass(frozen=True)
class Recipe:
    reference: np.ndarray
    samples: np.ndarray
    settings: Settings
    units: str
    frame: str
    cad: CADReference | None = None
    _source_bytes: bytes | None = field(default=None, repr=False, compare=False)

    def __post_init__(self):
        _identity(self.units, self.frame)
        if self.cad is not None and not isinstance(self.cad, CADReference):
            raise ValueError("cad must be a CADReference or None.")
        if not isinstance(self.settings, Settings):
            raise ValueError("settings must be a Settings value.")
        for name in ("reference", "samples"):
            data = cloud(getattr(self, name))
            if len(data) < 30 or (name == "samples" and (len(data) > 2000 or data.shape[1] != 6)):
                raise ValueError("A trained model requires 30..2000 oriented sample points.")
            data.flags.writeable = False
            object.__setattr__(self, name, data)
        if not self.diameter > 1e-8 or normal_spread(self.samples[:, 3:]) < 0.005:
            raise ValueError(
                "The model needs distinct points and more than one surface-normal direction."
            )
        if np.any(np.ptp(self.samples[:, :3], axis=0) <= self.diameter * 1e-7):
            raise ValueError("The PPF model needs nonzero spatial extent on each coordinate axis.")

    @property
    def center(self):
        return (self.samples[:, :3].min(axis=0).astype(float) + self.samples[:, :3].max(axis=0)) / 2

    @property
    def diameter(self):
        return float(np.linalg.norm(np.ptp(self.samples[:, :3].astype(float), axis=0)))

    @property
    def health(self):
        center = (
            self.reference[:, :3].min(axis=0).astype(float) + self.reference[:, :3].max(axis=0)
        ) / 2
        diagonal = np.linalg.norm(np.ptp(self.reference[:, :3].astype(float), axis=0))
        occupied = None
        if diagonal > 1e-8:
            cells = np.floor(
                (self.reference[:, :3].astype(float) - center)
                / (self.settings.sampling_distance * diagonal)
            ).astype(np.int64)
            occupied = len(np.unique(cells, axis=0))
        report = {
            "reference_points": len(self.reference),
            "sample_points": len(self.samples),
            "bounding_diagonal": self.diameter,
            "normal_spread": normal_spread(self.samples[:, 3:]),
            "units": self.units,
            "frame": self.frame,
            "sampling_budget": {
                "voxel_points": occupied,
                "sample_budget": MODEL_POINT_BUDGET,
                "candidate_budget": MODEL_CANDIDATE_BUDGET,
                "reference_exceeds_budget": occupied > MODEL_POINT_BUDGET if occupied else None,
                "candidate_pool_reduction": occupied > MODEL_CANDIDATE_BUDGET if occupied else None,
                "trained_fraction_of_voxels": len(self.samples) / occupied if occupied else None,
                "assessment": "derived_from_retained_reference_and_settings",
            },
        }
        if self.cad is not None:
            report["cad"] = self.cad.mesh.health
        return report


def train(reference, *, units, frame="model", settings=Settings()):
    if not isinstance(settings, Settings):
        raise ValueError("settings must be a Settings value.")
    reference = cloud(reference)
    if len(reference) < 30:
        raise ValueError("Train with at least 30 reference points.")
    diameter = float(np.linalg.norm(np.ptp(reference[:, :3].astype(float), axis=0)))
    if diameter <= 1e-8:
        raise ValueError("The reference cloud has no spatial extent.")
    samples = prepared(
        reference,
        settings.sampling_distance * diameter,
        settings.normal_neighbors,
        settings.model_viewpoint,
        MODEL_POINT_BUDGET,
        bounded_model=True,
    )
    return Recipe(reference, samples, settings, units, frame)
