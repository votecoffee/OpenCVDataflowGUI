"""Local shape statistics and deterministic geometry-aware search reduction."""

from dataclasses import dataclass

import cv2
import numpy as np


@dataclass(frozen=True)
class Geometry:
    importance: np.ndarray
    planarity: np.ndarray
    curvature: np.ndarray
    normal_change: np.ndarray

    def report(self):
        return {
            "points": len(self.importance),
            "locally_planar_fraction": float(np.mean(self.planarity >= 0.7)),
            "strong_shape_change_fraction": float(np.mean(self.importance >= 0.15)),
            "mean_normal_change": float(np.mean(self.normal_change)),
            "mean_surface_variation": float(np.mean(self.curvature)),
        }


def analyze(data, neighbors=20):
    """PCA and normal variation on bounded oriented, prepared point clouds."""
    data = np.asarray(data, np.float32)
    if (
        data.ndim != 2
        or data.shape[1] != 6
        or not 6 <= len(data) <= 100000
        or not np.isfinite(data).all()
        or not np.allclose(np.linalg.norm(data[:, 3:], axis=1), 1, atol=1e-3)
    ):
        raise ValueError("Geometry analysis requires 6..100000 prepared XYZ/normal points.")
    if type(neighbors) is not int or not 6 <= neighbors <= 100:
        raise ValueError("Geometry analysis requires 6..100 neighbors.")
    count = min(neighbors, len(data))
    index = cv2.flann_Index(data[:, :3].copy(), {"algorithm": 4})
    importance, planarity, curvature, change, radius = (np.empty(len(data)) for _ in range(5))
    for start in range(0, len(data), 512):
        stop = min(start + 512, len(data))
        ids, distance = index.knnSearch(data[start:stop, :3].copy(), count, params={"checks": -1})
        local = data[ids, :3].astype(float)
        local -= local.mean(axis=1, keepdims=True)
        covariance = np.einsum("nki,nkj->nij", local, local) / count
        eigenvalues = np.maximum(np.linalg.eigvalsh(covariance), 0)
        largest = np.maximum(eigenvalues[:, 2], 1e-20)
        total = np.maximum(eigenvalues.sum(axis=1), 1e-20)
        planarity[start:stop] = (eigenvalues[:, 1] - eigenvalues[:, 0]) / largest
        curvature[start:stop] = eigenvalues[:, 0] / total
        change[start:stop] = np.clip(1 - np.linalg.norm(data[ids, 3:].mean(axis=1), axis=1), 0, 1)
        radius[start:stop] = np.sqrt(np.maximum(distance[:, -1], 0))
    # Isolated noise must not gain priority merely through high local variation.
    support = np.minimum(np.median(radius) / np.maximum(radius, 1e-10), 1)
    importance[:] = np.clip(change + 3 * curvature, 0, 1) * support
    arrays = [np.asarray(value, np.float32) for value in (importance, planarity, curvature, change)]
    for value in arrays:
        value.flags.writeable = False
    return Geometry(*arrays)


def search_indices(data, limit, *, strategy="uniform", geometry=None):
    if type(limit) is not int or not 12 <= limit <= 20000:
        raise ValueError("Search reduction requires an integer limit in [12,20000].")
    if strategy not in ("uniform", "geometry"):
        raise ValueError("Search sampling must be uniform or geometry.")
    if len(data) <= limit:
        return np.arange(len(data))
    anchors = np.unique(np.r_[np.argmin(data, axis=0), np.argmax(data, axis=0)])
    remaining = np.setdiff1d(np.arange(len(data)), anchors, assume_unique=True)
    rng = np.random.default_rng(0)
    if strategy == "uniform":
        return np.sort(np.r_[anchors, rng.choice(remaining, limit - len(anchors), replace=False)])
    geometry = analyze(data) if geometry is None else geometry
    # Half the budget preserves ordinary surface coverage. The other half
    # favors supported shape changes distributed across spatial/normal cells.
    uniform = rng.choice(remaining, max(0, limit // 2 - len(anchors)), replace=False)
    kept = np.r_[anchors, uniform]
    remaining = np.setdiff1d(remaining, uniform, assume_unique=True)
    span = np.maximum(np.ptp(data[:, :3], axis=0), 1e-10)
    resolution = max(2, int(np.ceil(limit ** (1 / 3))))
    cells = np.floor((data[:, :3] - data[:, :3].min(axis=0)) / span * resolution).astype(int)
    normals = np.floor(np.clip((data[:, 3:] + 1) * 2, 0, 3)).astype(int)
    keys = np.c_[cells, normals]
    order = remaining[np.argsort(-geometry.importance[remaining], kind="stable")]
    _, first = np.unique(keys[order], axis=0, return_index=True)
    diverse = order[np.sort(first)]
    needed = limit - len(kept)
    selected = diverse[:needed]
    if len(selected) < needed:
        extra = order[~np.isin(order, selected)][: needed - len(selected)]
        selected = np.r_[selected, extra]
    return np.sort(np.r_[kept, selected])


def voxel_level(data, distance):
    """Representative points at a model-relative resolution, retaining bounds."""
    low = data[:, :3].min(axis=0).astype(float)
    cells = np.floor((data[:, :3].astype(float) - low) / distance).astype(np.int64)
    # Opposed faces in one spatial cell retain separate normals.
    bins = np.floor(np.clip((data[:, 3:] + 1) * 2, 0, 3)).astype(int)
    _, first = np.unique(np.c_[cells, bins], axis=0, return_index=True)
    anchors = np.r_[np.argmin(data, axis=0), np.argmax(data, axis=0)]
    selected = np.unique(np.r_[first, anchors])
    return np.ascontiguousarray(data[selected]) if len(selected) >= 30 else data
