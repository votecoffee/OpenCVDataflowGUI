"""Camera-ray evidence separating free-space contradictions from occlusion."""

from dataclasses import dataclass

import numpy as np

from .model import _identity, cloud
from .observation import Camera


@dataclass(frozen=True)
class DepthScene:
    """Immutable XYZ evidence with explicit identity, independent of the search crop."""

    points: np.ndarray
    units: str
    frame: str

    def __post_init__(self):
        _identity(self.units, self.frame)
        raw = np.asarray(self.points)
        if raw.ndim != 2 or raw.shape[1] not in (3, 6) or len(raw) > 2_000_000:
            raise ValueError("DepthScene requires at most two million XYZ or XYZ/normal rows.")
        data = cloud(raw[:, :3])
        data.flags.writeable = False
        object.__setattr__(self, "points", data)

    def validate_for(self, units, frame):
        if self.units != units or self.frame != frame:
            raise ValueError(
                "Depth scene units/frame must match the search scene; "
                "convert or transform upstream."
            )


def _pixels(xyz, camera):
    z = np.maximum(xyz[:, 2], 1e-9)
    u = np.rint(camera.matrix[0, 0] * xyz[:, 0] / z + camera.matrix[0, 2])
    v = np.rint(camera.matrix[1, 1] * xyz[:, 1] / z + camera.matrix[1, 2])
    valid = (xyz[:, 2] > 1e-9) & (u >= 0) & (u < camera.size[0]) & (v >= 0) & (v < camera.size[1])
    # Out-of-view coordinates can be arbitrarily large. Do not cast them to int.
    return np.where(valid, u, -1).astype(np.int64), np.where(valid, v, -1).astype(np.int64), valid


@dataclass(frozen=True)
class DepthEvidence:
    visible: np.ndarray
    free_space: np.ndarray
    occluded: np.ndarray
    consistent: np.ndarray
    unknown: np.ndarray
    unique_known_rays: int

    def report(self, *, minimum_coverage, minimum_rays, maximum_free_space):
        visible = int(self.visible.sum())
        known = int((self.free_space | self.occluded | self.consistent).sum())
        coverage = known / visible if visible else 0.0
        fraction = float(self.free_space.sum() / known) if known else None
        checked = bool(
            visible
            and known
            and coverage >= minimum_coverage
            and self.unique_known_rays >= minimum_rays
        )
        return {
            "status": "checked" if checked else "insufficient_depth",
            "visible_model_points": visible,
            "known_points": known,
            "unique_known_rays": self.unique_known_rays,
            "consistent_points": int(self.consistent.sum()),
            "occluded_points": int(self.occluded.sum()),
            "free_space_points": int(self.free_space.sum()),
            "unknown_points": int(self.unknown.sum()),
            "depth_coverage": coverage,
            "free_space_fraction": fraction,
            "maximum_free_space": maximum_free_space,
            "minimum_depth_coverage": minimum_coverage,
            "minimum_known_rays": minimum_rays,
            "limit_exceeded": bool(checked and fraction > maximum_free_space),
        }


class DepthBuffer:
    """Sparse nearest-return depth index; no width*height-sized allocation.

    Values are optical-axis depth in scene units, with at most two million
    sorted camera pixel keys. Each lookup considers a conservative 3x3 patch.
    """

    def __init__(self, points, camera):
        self.camera = Camera.from_record(camera)
        raw = np.asarray(points)
        if raw.ndim != 2 or raw.shape[1] not in (3, 6) or len(raw) > 2_000_000:
            raise ValueError("Depth indexing requires at most two million XYZ or XYZ/normal rows.")
        # Depth uses XYZ only. Avoid copying/renormalizing an entire scene's normals.
        points = np.asarray(raw[:, :3], float)
        if not np.isfinite(points).all():
            raise ValueError("Depth indexing requires finite XYZ coordinates.")
        u, v, valid = _pixels(points, self.camera)
        keys = v[valid] * self.camera.size[0] + u[valid]
        depths = points[valid, 2]
        order = np.lexsort((depths, keys))
        ordered = keys[order]
        first = np.r_[True, np.diff(ordered) != 0] if len(order) else np.empty(0, bool)
        self._keys, self._depths = ordered[first], depths[order][first]
        self._keys.flags.writeable = self._depths.flags.writeable = False

    def sample_pixels(self, u, v):
        """Exact measured Z at bounded integer pixels; missing rays remain NaN."""
        u, v = np.asarray(u), np.asarray(v)
        if (
            u.ndim != 1
            or v.shape != u.shape
            or len(u) > 640 * 640
            or u.dtype.kind not in "iu"
            or v.dtype.kind not in "iu"
        ):
            raise ValueError("Depth lookup requires at most 640x640 integer pixel pairs.")
        values = np.full(len(u), np.nan)
        valid = (u >= 0) & (u < self.camera.size[0]) & (v >= 0) & (v < self.camera.size[1])
        ids = np.flatnonzero(valid)
        keys = v[ids].astype(np.int64) * self.camera.size[0] + u[ids].astype(np.int64)
        if len(self._keys):
            positions = np.minimum(np.searchsorted(self._keys, keys), len(self._keys) - 1)
            found = self._keys[positions] == keys
            values[ids[found]] = self._depths[positions[found]]
        return values

    def evidence(self, model, visible, *, tolerance):
        model = cloud(model)
        if model.shape[1] != 6 or len(model) > 2000:
            raise ValueError("Depth verification requires at most 2000 oriented model points.")
        visible = np.asarray(visible, bool)
        if visible.shape != (len(model),) or not np.isfinite(tolerance) or tolerance <= 0:
            raise ValueError("Supply a model visibility mask and positive physical tolerance.")
        xyz = model[:, :3].astype(float)
        u, v, in_view = _pixels(xyz, self.camera)
        measured = np.full(len(model), np.inf)
        if len(self._keys):
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    x, y = u + dx, v + dy
                    keys = y * self.camera.size[0] + x
                    indices = np.searchsorted(self._keys, keys)
                    valid = (
                        visible
                        & in_view
                        & (x >= 0)
                        & (x < self.camera.size[0])
                        & (y >= 0)
                        & (y < self.camera.size[1])
                        & (indices < len(self._keys))
                    )
                    indices = np.minimum(indices, len(self._keys) - 1)
                    valid &= self._keys[indices] == keys
                    measured = np.minimum(measured, np.where(valid, self._depths[indices], np.inf))
        # Correct depth-Z differences for surface incidence. A sloped surface's
        # Z discrepancy can be large while its normal displacement is small.
        z = np.maximum(xyz[:, 2], 1e-9)
        direction = xyz / z[:, None]
        factor = abs(np.einsum("ij,ij->i", model[:, 3:], direction))
        incidence = factor / np.maximum(np.linalg.norm(direction, axis=1), 1e-9)
        known = visible & in_view & np.isfinite(measured) & (incidence >= 0.1)
        residual = np.zeros(len(model))
        residual[known] = (measured[known] - xyz[known, 2]) * factor[known]
        free = known & (residual > tolerance)
        occluded = known & (residual < -tolerance)
        consistent = known & ~free & ~occluded
        unknown = visible & ~known
        unique = len(np.unique(v[known] * self.camera.size[0] + u[known]))
        masks = [visible.copy(), free, occluded, consistent, unknown]
        for mask in masks:
            mask.flags.writeable = False
        return DepthEvidence(*masks, unique)
