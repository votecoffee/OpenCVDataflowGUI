"""Native flyaround of retained camera-depth evidence, with no localization."""

import json
from pathlib import Path

import numpy as np
from opencv_dataflow.cloud_io import write_cloud
from opencv_dataflow.cloud_viewer import CloudViewer
from opencv_dataflow.pointclouds import PointCloud
from PySide6.QtWidgets import QCheckBox, QFileDialog, QHBoxLayout, QLabel, QPushButton

from .depth_review import RAY_STATES


def review_cloud(review, *, states=RAY_STATES[1:], scene=None, axes=True):
    xyz, rgb = review.expected_points(states)
    points, colors = [xyz], [rgb]
    if scene is not None:
        ids = np.linspace(0, len(scene) - 1, min(5000, len(scene)), dtype=int)
        points.append(scene[ids, :3])
        colors.append(np.full((len(ids), 3), 115, np.uint8))
    if axes:
        all_xyz, _ = review.expected_points(limit=1000)
        length = np.linalg.norm(np.ptp(all_xyz, axis=0)) * .2 if len(all_xyz) else 1.0
        for axis in range(3):
            line = np.zeros((32, 3))
            line[:, axis] = np.linspace(0, length, len(line))
            points.append(line @ review.pose[:3, :3].T + review.pose[:3, 3])
            color = np.zeros(3, np.uint8)
            color[axis] = 255
            colors.append(np.tile(color, (len(line), 1)))
    return PointCloud(np.concatenate(points), review.camera.units, review.camera.frame,
                      colors=np.ascontiguousarray(np.concatenate(colors), np.uint8))


class DepthReviewDialog(CloudViewer):
    def __init__(self, review, scene, provenance, parent=None):
        super().__init__(None, parent)
        self.review, self.provenance = review, dict(provenance)
        self.resize(1200, 780)
        ids = np.linspace(0, len(scene) - 1, min(5000, len(scene)), dtype=int)
        self.scene = np.ascontiguousarray(scene[ids, :3]).copy()
        self.scene.flags.writeable = False
        self.setWindowTitle(f"Camera-depth evidence · {provenance['selection']}")
        title = QLabel(
            f"{provenance['selection']} · cached pose review; not an acceptance decision.\n"
            "Colored points are expected CAD surfaces. Gray points are measured returns. "
            "Green ray agreement does not establish normal agreement or a valid pose."
        )
        title.setWordWrap(True)
        self.layout().insertWidget(0, title)
        counts = review.report["counts"]
        self.summary = QLabel(
            f"Depth {review.report['status']} · known {review.report['depth_coverage']:.1%} / "
            f"minimum {review.report['minimum_depth_coverage']:.1%} · "
            f"normal-distance tolerance {review.report['distance_tolerance']:.4g} "
            f"{review.camera.units}\n"
            f"Consistent {counts['consistent']} · Farther return {counts['free_space']} · "
            f"Nearer return {counts['occluded']} · Missing {counts['missing']} · "
            f"Grazing {counts['grazing']} · stride {review.stride}"
        )
        self.summary.setWordWrap(True)
        self.layout().insertWidget(1, self.summary)
        row = QHBoxLayout()
        self.layers = {}
        for name, label in (
            ("consistent", "Green: consistent"), ("free_space", "Red: farther return"),
            ("occluded", "Orange: nearer return"), ("missing", "Magenta: missing"),
            ("grazing", "Blue: grazing"), ("scene", "Measured scene"), ("axes", "Pose axes"),
        ):
            box = QCheckBox(label)
            box.setChecked(True)
            box.toggled.connect(self.refresh_layers)
            self.layers[name] = box
            row.addWidget(box)
        self.layout().insertLayout(2, row)
        button = QPushButton("Export evidence…")
        button.clicked.connect(self.choose_export)
        self.layout().addWidget(button)
        self.refresh_layers()

    def refresh_layers(self, *_):
        self.set_cloud(review_cloud(
            self.review,
            states=tuple(n for n in RAY_STATES[1:] if self.layers[n].isChecked()),
            scene=self.scene if self.layers["scene"].isChecked() else None,
            axes=self.layers["axes"].isChecked(),
        ))

    def export(self, folder):
        folder = Path(folder)
        folder.mkdir(parents=True, exist_ok=False)
        write_cloud(folder / "expected_and_measured.ply", self.cloud, binary=True)
        np.savez_compressed(
            folder / "camera_ray_maps.npz", expected=self.review.expected,
            measured=self.review.measured, residual=self.review.residual,
            states=self.review.states, stride=self.review.stride,
        )
        report = {**self.review.report, "camera": self.review.camera.record(),
                  "provenance": self.provenance,
                  "visible_layers": [n for n, b in self.layers.items() if b.isChecked()],
                  "state_codes": dict(enumerate(RAY_STATES)),
                  "display_sampling": "category-balanced expected rays; at most 5000 scene points"}
        (folder / "report.json").write_bytes(
            (json.dumps(report, indent=2, allow_nan=False) + "\n").encode("utf-8")
        )
        return folder

    def choose_export(self):
        parent = QFileDialog.getExistingDirectory(self, "Parent folder for a new evidence export")
        if not parent:
            return
        from datetime import datetime

        folder = Path(parent) / datetime.now().strftime("camera_depth_%Y%m%d_%H%M%S_%f")
        try:
            self.export(folder)
            self.summary.setText(f"Exported camera-ray maps, cloud and report to {folder}")
        except (OSError, ValueError) as error:
            self.summary.setText(str(error))
