"""Portable oriented-point recipes with checksums and atomic replacement."""

import hashlib
import io
import json
import os
from dataclasses import asdict
from pathlib import Path
from tempfile import NamedTemporaryFile
from zipfile import ZIP_DEFLATED, BadZipFile, ZipFile

import numpy as np

from .mesh import MAX_TRIANGLES, CADReference, TriangleMesh
from .model import Recipe, Settings


def read_array(raw, *, points=False, triangles=False):
    """Check the NPY header and byte count before NumPy allocates an array."""
    stream = io.BytesIO(raw)
    version = np.lib.format.read_magic(stream)
    if version == (1, 0):
        shape, _, dtype = np.lib.format.read_array_header_1_0(stream)
    elif version == (2, 0):
        shape, _, dtype = np.lib.format.read_array_header_2_0(stream)
    else:
        raise ValueError("Only NPY versions 1 and 2 are supported.")
    if triangles:
        if (
            len(shape) != 3
            or shape[1:] != (3, 3)
            or not 1 <= shape[0] <= MAX_TRIANGLES
            or dtype.str not in ("<f4", "<f8")
        ):
            raise ValueError("Expected a bounded floating-point triangle array.")
    elif points:
        if (
            len(shape) != 2
            or not 0 <= shape[0] <= 2_000_000
            or shape[1] not in (3, 6)
            or dtype.str not in ("<f4", "<f8")
        ):
            raise ValueError("Expected a bounded floating-point XYZ or XYZ/normal array.")
    elif shape != () or dtype.kind != "U" or dtype.itemsize > 512:
        raise ValueError("Expected a scalar coordinate label of at most 128 characters.")
    size = dtype.itemsize
    for value in shape:
        size *= value
    if size != len(raw) - stream.tell():
        raise ValueError("Array header and stored byte count disagree.")
    return np.load(io.BytesIO(raw), allow_pickle=False)


def save_recipe(path, recipe):
    entries = {}
    for name in ("reference", "samples"):
        stream = io.BytesIO()
        np.save(stream, getattr(recipe, name), allow_pickle=False)
        entries[name + ".npy"] = stream.getvalue()
    if recipe.cad is not None:
        stream = io.BytesIO()
        np.save(stream, recipe.cad.mesh.triangles, allow_pickle=False)
        entries["triangles.npy"] = stream.getvalue()
    manifest = {
        "version": 1 if recipe.cad is None else 2,
        "settings": asdict(recipe.settings),
        "units": recipe.units,
        "frame": recipe.frame,
        "sha256": {name: hashlib.sha256(raw).hexdigest() for name, raw in entries.items()},
    }
    if recipe.cad is not None:
        manifest["cad"] = {"count": recipe.cad.count, "seed": recipe.cad.seed}
    entries["recipe.json"] = json.dumps(manifest, allow_nan=False, indent=2).encode("utf-8")
    target = Path(path)
    with NamedTemporaryFile(dir=target.parent, prefix=f".{target.name}.", delete=False) as stream:
        temporary = Path(stream.name)
    try:
        with ZipFile(temporary, "w", compression=ZIP_DEFLATED) as archive:
            for name, raw in entries.items():
                archive.writestr(name, raw)
        os.replace(temporary, target)
    finally:
        temporary.unlink(missing_ok=True)
    return hashlib.sha256(target.read_bytes()).hexdigest()


def load_recipe(path, *, sha256=None, cached=None):
    path = Path(path)
    if path.stat().st_size > 64 * 1024 * 1024:
        raise ValueError("Recipe exceeds the 64 MiB budget.")
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if sha256 is not None and digest != sha256:
        raise ValueError("Recipe SHA-256 mismatch. Stage the intended recipe again.")
    if cached is not None and cached[0] == digest:
        return cached[1]
    try:
        with ZipFile(io.BytesIO(raw)) as archive:
            if sum(info.file_size for info in archive.infolist()) > 64 * 1024 * 1024:
                raise ValueError("Uncompressed recipe exceeds the 64 MiB budget.")
            if archive.getinfo("recipe.json").file_size > 1024 * 1024:
                raise ValueError("Recipe metadata exceeds 1 MiB.")
            manifest = json.loads(archive.read("recipe.json"))
            if type(manifest["version"]) is not int or manifest["version"] not in (1, 2):
                raise ValueError("Unsupported Simple3DLocate recipe version.")
            has_cad = manifest["version"] == 2
            expected = {"reference.npy", "samples.npy", "recipe.json"}
            if has_cad:
                expected.add("triangles.npy")
            if set(archive.namelist()) != expected or len(archive.namelist()) != len(expected):
                raise ValueError("Unexpected or duplicate recipe entries.")
            arrays = {}
            cad = None
            for name in ("reference", "samples", *(("triangles",) if has_cad else ())):
                data = archive.read(name + ".npy")
                if hashlib.sha256(data).hexdigest() != manifest["sha256"][name + ".npy"]:
                    raise ValueError("Recipe array checksum mismatch.")
                if name == "triangles":
                    mesh = TriangleMesh(read_array(data, triangles=True))
                    cad = CADReference(mesh, **manifest["cad"])
                else:
                    arrays[name] = read_array(data, points=True)
        # Releases before camera-surface mode deliberately used fused observations.
        settings = dict(manifest["settings"])
        settings.setdefault("observation_mode", "complete")
        settings.setdefault("depth_verification", "off")
        return Recipe(
            **arrays,
            settings=Settings(**settings),
            units=manifest["units"],
            frame=manifest["frame"],
            cad=cad,
            _source_bytes=raw,
        )
    except (BadZipFile, KeyError, TypeError, OSError) as error:
        raise ValueError(f"Invalid Simple3DLocate recipe. {error}") from error
