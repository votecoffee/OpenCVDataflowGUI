"""Retained-reference surface training and independent scene review."""

import ast
import hashlib
import json
import uuid
from dataclasses import fields
from pathlib import Path
from zipfile import BadZipFile

import cv2
import numpy as np
from opencv_dataflow.canvas import pixmap
from opencv_dataflow.cloud_io import read_cloud
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from opencv_dataflow.pointclouds import PointCloud, render_cloud
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from . import (
    CADReference,
    Locator,
    Settings,
    load_recipe,
    read_mesh,
    save_recipe,
    train,
    train_cad,
)
from .cli import read_npz
from .dataflow import depth_input, oriented, recipe_path
from .graphics import overlay, training_overlay
from .observation import Camera
from .optimization import ValidationScene
from .preview_capture import capture_processed
from .review import assessment, rejection_lines

_CLOUDS = "Point clouds (*.ply *.pcd *.npz);;All files (*)"


class CADImportDialog(QDialog):
    def __init__(self, parent=None, *, frame="model"):
        super().__init__(parent)
        self.setWindowTitle("Import surface mesh")
        layout = QFormLayout(self)
        self.units = QComboBox()
        self.units.addItems(["m", "mm", "unitless"])
        self.units.setCurrentIndex(-1)
        self.units.setPlaceholderText("Choose output units")
        self.frame = QLineEdit(frame)
        self.scale, self.seed = QLineEdit("1"), QLineEdit("0")
        self.count = QSpinBox()
        self.count.setRange(30, 200000)
        self.count.setValue(6000)
        self.flip = QCheckBox("Reverse triangle winding and normals")
        for label, widget in (
            ("Units after scale", self.units),
            ("Model frame", self.frame),
            ("Coordinate multiplier", self.scale),
            ("Surface samples", self.count),
            ("Sampling seed", self.seed),
            ("Normal orientation", self.flip),
        ):
            layout.addRow(label, widget)
        self.status = QLabel(
            "Mesh units are not assumed. Scaling changes XYZ; the chosen unit labels the result."
        )
        self.status.setWordWrap(True)
        layout.addRow(self.status)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

    def values(self):
        from .model import _identity

        units, frame = self.units.currentText(), self.frame.text()
        _identity(units, frame)
        scale, seed = float(self.scale.text()), int(self.seed.text())
        if not np.isfinite(scale) or not 1e-9 <= scale <= 1e9 or not 0 <= seed < 2**32:
            raise ValueError("Use a positive scale in [1e-9, 1e9] and an unsigned 32-bit seed.")
        return {
            "units": units,
            "frame": frame,
            "scale": scale,
            "seed": seed,
            "count": self.count.value(),
            "flip_normals": self.flip.isChecked(),
        }

    def _accept(self):
        try:
            self.values()
            self.accept()
        except ValueError as error:
            self.status.setText(str(error))


class LocateTrainingDialog(QDialog):
    def __init__(self, parent, parameters, context):
        super().__init__(parent)
        self.parameters, self.context = parameters, context
        self.reference = self.test_scene = self.recipe = self.locator = self.result = None
        self.cad = None
        self.camera = None
        self.depth_scene = None
        self.processed_capture = None
        self._selection_result = None
        self._depth_review_dialog = None
        self.setWindowTitle("Train Simple3DLocate")
        self.resize(1150, 760)
        layout = QVBoxLayout(self)
        actions = QHBoxLayout()
        for title, action in (
            ("Load model cloud…", self._load_reference),
            ("Import surface mesh…", self._import_stl),
            ("Load test scene…", self._load_scene),
        ):
            actions.addWidget(self._button(title, action))
        for title, action in (
            ("Capture model from scene input", self._capture_reference),
            ("Capture latest test scene", self._capture_scene),
        ):
            button = self._button(title, action)
            button.setEnabled(hasattr(context, "snapshot_input_cloud"))
            actions.addWidget(button)
        layout.addLayout(actions)
        cameras = QHBoxLayout()
        cameras.addWidget(self._button("Load scene camera JSON…", self._load_camera))
        button = self._button("Capture latest wired camera", self._capture_camera)
        button.setEnabled(hasattr(context, "snapshot_input_data"))
        cameras.addWidget(button)
        cameras.addWidget(self._button("Clear camera (use viewpoint rays)", self._clear_camera))
        layout.addLayout(cameras)
        depth_actions = QHBoxLayout()
        depth_actions.addWidget(
            self._button("Load verification depth cloud…", self._load_depth_scene)
        )
        button = self._button("Capture latest depth input", self._capture_depth_scene)
        button.setEnabled(hasattr(context, "snapshot_input_cloud"))
        depth_actions.addWidget(button)
        depth_actions.addWidget(self._button("Use search cloud for depth", self._clear_depth_scene))
        layout.addLayout(depth_actions)
        capture_actions = QHBoxLayout()
        self.capture_preview_button = self._button(
            "Capture last processed inputs", self._capture_processed
        )
        available = callable(getattr(context, "snapshot_processed_inputs", None))
        self.capture_preview_button.setEnabled(available)
        self.capture_preview_button.setToolTip(
            "Capture search, provided camera and depth from one completed block execution. "
            "Run in Debug profile first. This does not synchronize sensor acquisitions."
            if available
            else (
                "Update OpenCVDataflowGUI for completed-input capture. "
                "Manual captures remain available."
            )
        )
        capture_actions.addWidget(self.capture_preview_button)
        self.capture_status = QLabel("Preview inputs have not been captured together.")
        self.capture_status.setWordWrap(True)
        capture_actions.addWidget(self.capture_status, 1)
        layout.addLayout(capture_actions)
        hint = QLabel(
            "Teach one isolated rigid part. Crop the model below or upstream. "
            "Supplied normals must use the same orientation convention as the scene. "
            "XYZ-only clouds estimate normals toward the configured viewpoint."
        )
        hint.setWordWrap(True)
        layout.addWidget(hint)
        body = QHBoxLayout()
        self.viewer = FilmstripImageView(self)
        body.addWidget(self.viewer, 1)
        panel = QWidget()
        form = QFormLayout(panel)
        self.units = QComboBox()
        self.units.addItems(["m", "mm", "unitless"])
        self.units.currentTextChanged.connect(self._invalidate)
        self.frame = QLineEdit("model")
        self.frame.textChanged.connect(self._invalidate)
        form.addRow("Model units (no conversion)", self.units)
        form.addRow("Model frame", self.frame)
        self.cad_count, self.cad_seed = QSpinBox(), QLineEdit("0")
        self.cad_count.setRange(30, 200000)
        self.cad_count.setValue(6000)
        self.cad_count.valueChanged.connect(self._invalidate)
        self.cad_seed.textChanged.connect(self._invalidate)
        self.cad_count.setEnabled(False)
        self.cad_seed.setEnabled(False)
        form.addRow("CAD surface samples", self.cad_count)
        form.addRow("CAD sampling seed", self.cad_seed)
        self.crop_min, self.crop_max = QLineEdit(), QLineEdit()
        form.addRow("Crop minimum XYZ", self.crop_min)
        form.addRow("Crop maximum XYZ", self.crop_max)
        crop = self._button("Crop model to bounds", self._crop)
        crop.setToolTip("Cropping CAD samples creates a point-cloud reference.")
        form.addRow(crop)
        self.fields = {}
        for field in fields(Settings):
            choices = {
                "search_sampling": ["uniform", "geometry"],
                "refinement": ["legacy", "pyramid"],
                "observation_mode": ["surface", "complete"],
                "candidate_backend": ["ppf", "ppf_planes", "ppf_features", "ppf_regions"],
                "depth_verification": ["auto", "report", "off"],
                "boundary_verification": ["off", "report", "auto"],
                "pose_scoring": ["geometric", "projective"],
                "overlap_metric": ["combined", "box", "scene_support"],
            }.get(field.name)
            if choices:
                widget = QComboBox()
                widget.addItems(choices)
                if field.name == "candidate_backend":
                    widget.setToolTip(
                        "ppf_planes adds experimental plane candidates; ppf_features adds "
                        "local angular features and bounded RANSAC. "
                        "ppf_regions adds proposal-only support-plane removal and local PPF. "
                        "Compare independent scenes and count extra poses before use."
                    )
                elif field.name == "depth_verification":
                    widget.setToolTip(
                        "auto rejects camera-ray free-space contradictions when enough "
                        "depth is known; report measures only; off preserves legacy behavior."
                    )
                elif field.name == "pose_scoring":
                    widget.setToolTip(
                        "projective ranks geometrically verified candidates using rendered CAD "
                        "and calibrated camera depth. Requires CAD, surface observation and "
                        "enabled depth; otherwise all candidates use geometric scoring. "
                        "Missing rendered depth support rejects a projective candidate. "
                        "Compare held-out scenes before selecting it."
                    )
                elif field.name == "boundary_verification":
                    widget.setToolTip(
                        "Experimental mesh silhouette check. auto rejects measured surfaces "
                        "continuing beyond too much of the outline; report measures only. "
                        "Uses min_coverage, distance_tolerance and sampling_distance. Requires "
                        "CAD, a camera, surface mode and enabled depth verification. Unknown "
                        "pairs remain possible support. off preserves existing results."
                    )
                widget.currentTextChanged.connect(self._invalidate)
            else:
                widget = QLineEdit(str(getattr(Settings(), field.name)))
                if field.name == "execution_workers":
                    widget.setToolTip(
                        "1 preserves serial execution. Up to 8 workers can check candidates "
                        "concurrently, using more CPU and memory. Coordinate this limit with "
                        "other running blocks; compare plans before selecting it."
                    )
                widget.textChanged.connect(self._invalidate)
            form.addRow(field.name.replace("_", " ").capitalize(), widget)
            self.fields[field.name] = widget
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(panel)
        body.addWidget(scroll)
        layout.addLayout(body, 1)
        view = QHBoxLayout()
        self.mode = QComboBox()
        self.mode.addItems(
            [
                "Reference cloud",
                "Trained samples",
                "Test fit",
                "Training geometry",
                "Verification depth cloud",
                "Test search cloud",
                "Competing poses",
            ]
        )
        self.mode.currentIndexChanged.connect(lambda _: self._perform(self._show))
        view.addWidget(self.mode)
        self.yaw, self.pitch = QSpinBox(), QSpinBox()
        for title, widget, value in (("Yaw", self.yaw, 25), ("Pitch", self.pitch, -20)):
            widget.setRange(-180, 180)
            widget.setValue(value)
            widget.valueChanged.connect(lambda _: self._perform(self._show))
            view.addWidget(QLabel(title))
            view.addWidget(widget)
        layout.addLayout(view)
        review = QHBoxLayout()
        review.addWidget(QLabel("Result selection"))
        self.result_selection = QComboBox()
        self.result_selection.addItem("All accepted instances", None)
        self.result_selection.setEnabled(False)
        self.result_selection.currentIndexChanged.connect(lambda _: self._perform(self._show))
        review.addWidget(self.result_selection, 1)
        self.result_layers = {}
        for key, label in (
            ("scene", "Scene"), ("axes", "Axes"), ("supported", "Supported"),
            ("missing", "Missing"), ("hidden", "Hidden"), ("free_space", "Free space"),
        ):
            check = QCheckBox(label)
            check.setChecked(True)
            check.toggled.connect(lambda _: self._perform(self._show))
            self.result_layers[key] = check
            review.addWidget(check)
        layout.addLayout(review)
        self.depth_review_button = self._button("Review camera-depth evidence…", self._review_depth)
        self.depth_review_button.setToolTip(
            "Inspect exact measured camera rays for one cached accepted or rejected pose. "
            "No localization is repeated. Missing depth remains unknown."
        )
        layout.addWidget(self.depth_review_button)
        layout.addWidget(self._button("Review boundary evidence…",
                                      lambda: self._review_depth(boundary=True)))
        self.status = QLabel(
            "Load or capture one model, then train and test against a separate scene."
        )
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        actions = QHBoxLayout()
        for title, action in (
            ("Train surface model", self._train),
            ("Locate in test scene", self._preview),
            ("Stage recipe", self._stage),
            ("Optimize execution…", self._optimize),
        ):
            actions.addWidget(self._button(title, action))
        layout.addLayout(actions)
        self._perform(self._restore)

    def _button(self, title, action):
        button = QPushButton(title)
        button.clicked.connect(lambda: self._perform(action))
        return button

    def _perform(self, action):
        try:
            action()
        except (
            ValueError,
            OSError,
            TypeError,
            KeyError,
            SyntaxError,
            RuntimeError,
            cv2.error,
            BadZipFile,
        ) as error:
            self.status.setText(str(error))

    def _invalidate(self, *_):
        self.recipe = self.locator = self.result = None
        if hasattr(self, "status"):
            self.status.setText("Training changed. Train before testing or staging.")
        if hasattr(self, "result_selection"):
            self._refresh_result_selection()
            if self.mode.currentIndex() in (2, 6):
                self.viewer.set_image(QPixmap())

    def _read(self, path):
        if Path(path).suffix.lower() == ".npz":
            data, units, frame = read_npz(path)
            return PointCloud(
                data[:, :3], units, frame, normals=data[:, 3:] if data.shape[1] == 6 else None
            )
        return read_cloud(Path(path), units=self.units.currentText(), frame=self.frame.text())

    def _load_reference(self):
        path, _ = QFileDialog.getOpenFileName(self, "One-part model cloud", "", _CLOUDS)
        if path:
            self._set_reference(self._read(path))

    def _import_stl(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "One-part surface mesh", "", "Surface meshes (*.ply *.stl)"
        )
        if not path:
            return
        options = CADImportDialog(self, frame=self.frame.text())
        if options.exec() != QDialog.DialogCode.Accepted:
            return
        self._set_cad(path, **options.values())

    def _set_cad(self, path, *, units, frame, count, seed, scale, flip_normals):
        mesh = read_mesh(path, scale=scale, flip_normals=flip_normals)
        cad = CADReference(mesh, count, seed)
        data = cad.sample()
        self._set_reference(PointCloud(data[:, :3], units, frame, normals=data[:, 3:]), cad=cad)
        self.status.setText(
            f"Imported {len(mesh.triangles)} triangles and {count} surface samples. "
            f"Discarded {mesh.discarded_triangles} degenerate triangles. Train to compile."
        )

    def _load_scene(self):
        path, _ = QFileDialog.getOpenFileName(self, "Independent test scene", "", _CLOUDS)
        if path:
            self.test_scene = self._read(path)
            self._clear_depth_scene()
            self.status.setText(f"Loaded test scene with {len(self.test_scene.points)} points.")

    def _capture_reference(self):
        self._set_reference(self.context.snapshot_input_cloud("scene").value)

    def _capture_scene(self):
        self.test_scene = self.context.snapshot_input_cloud("scene").value
        self._clear_depth_scene()
        self.status.setText(f"Captured test scene with {len(self.test_scene.points)} points.")

    def _capture_processed(self):
        try:
            captured = capture_processed(self.context)
        except (ValueError, TypeError, RuntimeError, KeyError) as error:
            raise ValueError(
                f"Capture unavailable: {error} Previous preview inputs retained."
            ) from error
        self.test_scene, self.camera, self.depth_scene = (
            captured.scene,
            captured.camera,
            captured.depth_scene,
        )
        self.processed_capture, self.result = captured, None
        self.capture_status.setText(captured.summary)
        self.capture_status.setToolTip(captured.details)
        if self.mode.currentIndex() == 5:
            self._show()
        else:
            self.mode.setCurrentIndex(5)
        self.status.setText(
            "Captured completed inputs. The trained model is unchanged; preview to inspect fit."
        )

    def _forget_processed_capture(self):
        self._close_depth_review()
        self.processed_capture = None
        self.capture_status.setText(
            "Manual/latest preview inputs; acquisition pairing is unverified."
        )
        self.capture_status.setToolTip("")

    def _load_depth_scene(self):
        path, _ = QFileDialog.getOpenFileName(self, "Full-frame verification depth", "", _CLOUDS)
        if path:
            self._set_depth_scene(self._read(path))

    def _capture_depth_scene(self):
        self._set_depth_scene(self.context.snapshot_input_cloud("depth_scene").value)

    def _set_depth_scene(self, value):
        depth = depth_input(value)
        if depth is None:
            self._clear_depth_scene()
            return
        if self.test_scene is not None:
            depth.validate_for(self.test_scene.units, self.test_scene.frame)
        self.depth_scene, self.result = value, None
        self._forget_processed_capture()
        self._show_depth_scene()
        self.status.setText(
            f"Verification depth: {len(value.points)} points. "
            "Use the same capture as the search cloud."
        )

    def _clear_depth_scene(self):
        self.depth_scene = self.result = None
        self._forget_processed_capture()
        self._show_depth_scene()
        self.status.setText("Using the search cloud for camera-depth verification.")

    def _show_depth_scene(self):
        if self.mode.currentIndex() == 4:
            self._show()
        else:
            self.mode.setCurrentIndex(4)

    def _load_camera(self):
        path, _ = QFileDialog.getOpenFileName(self, "Rectified scene camera", "", "JSON (*.json)")
        if path:
            if Path(path).stat().st_size > 65536:
                raise ValueError("Camera JSON exceeds 64 KiB.")
            self._set_camera(json.loads(Path(path).read_text(encoding="utf-8")))

    def _capture_camera(self):
        self._set_camera(self.context.snapshot_input_data("camera").value)

    def _set_camera(self, value):
        self.camera = Camera.from_record(value)
        self.result = None
        self._forget_processed_capture()
        self.status.setText(
            f"Scene camera: {self.camera.size}, {self.camera.units}, {self.camera.frame}."
        )

    def _clear_camera(self):
        self.camera = self.result = None
        self._forget_processed_capture()
        self.status.setText(
            "Using approximate viewpoint rays for unorganized scenes."
            if self.depth_scene is None
            else "Camera cleared. Separate depth requires a camera when its check is enabled."
        )

    def _set_reference(self, value, *, cad=None):
        oriented(value)
        self._invalidate()
        self.reference = value
        self.cad = cad
        self.cad_count.setEnabled(cad is not None)
        self.cad_seed.setEnabled(cad is not None)
        if cad is not None:
            self.cad_count.setValue(cad.count)
            self.cad_seed.setText(str(cad.seed))
        self.units.setCurrentText(value.units)
        self.frame.setText(value.frame)
        self.mode.setCurrentIndex(0)
        self._show()

    def _crop(self):
        if self.reference is None:
            raise ValueError("Load a model before cropping.")
        low, high = (
            np.asarray(ast.literal_eval(widget.text()), float)
            for widget in (self.crop_min, self.crop_max)
        )
        if (
            low.shape != (3,)
            or high.shape != (3,)
            or not np.isfinite([low, high]).all()
            or np.any(low >= high)
        ):
            raise ValueError("Enter minimum and maximum XYZ triples with increasing finite bounds.")
        keep = np.all((self.reference.points >= low) & (self.reference.points <= high), axis=1)
        if keep.sum() < 30:
            raise ValueError("The crop needs at least 30 points.")
        self._set_reference(self.reference.subset(keep))
        self.crop_min.clear()
        self.crop_max.clear()

    def _settings(self):
        values = {}
        for name, widget in self.fields.items():
            default = getattr(Settings(), name)
            text = widget.currentText() if isinstance(widget, QComboBox) else widget.text()
            values[name] = (
                ast.literal_eval(text) if isinstance(default, tuple) else type(default)(text)
            )
        return Settings(**values)

    def _set_settings(self, settings):
        for name, widget in self.fields.items():
            value = str(getattr(settings, name))
            if isinstance(widget, QComboBox):
                widget.setCurrentText(value)
            else:
                widget.setText(value)

    def _optimize(self):
        from .qt_optimization import ExecutionDialog

        if self.recipe is None or self.test_scene is None:
            raise ValueError(
                "Train a model and load an independent test scene before comparing plans."
            )
        source = self.test_scene
        scenes = [
            ValidationScene(
                "Current test scene",
                oriented(source),
                source.units,
                source.frame,
                camera=self.camera,
                depth_scene=depth_input(self.depth_scene),
            )
        ]
        dialog = ExecutionDialog(self, self.recipe, scenes)
        if dialog.exec() == QDialog.DialogCode.Accepted and dialog.selected_recipe is not None:
            recipe = dialog.selected_recipe
            self._set_settings(recipe.settings)
            self.recipe, self.locator, self.result = recipe, None, None
            self.mode.setCurrentIndex(1)
            self._show()
            self.status.setText(
                "Execution plan updated in this draft. Preview, then Stage and Apply to keep it."
            )

    def _train(self):
        if self.reference is None:
            raise ValueError("Load one model before training.")
        common = {
            "units": self.units.currentText(),
            "frame": self.frame.text(),
            "settings": self._settings(),
        }
        if self.cad is None:
            recipe = train(oriented(self.reference), **common)
        else:
            recipe = train_cad(
                self.cad.mesh,
                count=self.cad_count.value(),
                seed=int(self.cad_seed.text()),
                **common,
            )
        locator = Locator(recipe)
        self.cad = recipe.cad
        data = recipe.reference
        self.reference = PointCloud(
            data[:, :3],
            recipe.units,
            recipe.frame,
            normals=data[:, 3:] if data.shape[1] == 6 else None,
        )
        self.recipe, self.locator, self.result = recipe, locator, None
        self.mode.setCurrentIndex(1)
        self._show()
        health = recipe.health
        budget = health["sampling_budget"]
        reduced = (
            f" · Model budget: {len(recipe.samples)} of {budget['voxel_points']} voxel points"
            if budget["reference_exceeds_budget"]
            else ""
        )
        self.status.setText(
            f"{len(recipe.samples)} trained samples · Normal spread "
            f"{health['normal_spread']:.3g} · Diagonal {recipe.diameter:.3g} {recipe.units}"
            + reduced
        )

    def _preview(self):
        if self.recipe is None or self.test_scene is None:
            raise ValueError("Train a model and load or capture an independent test scene.")
        if self.locator is None:
            self.locator = Locator(self.recipe)
        self.result = self.locator.locate(
            oriented(self.test_scene),
            units=self.test_scene.units,
            frame=self.test_scene.frame,
            camera=self.camera,
            depth_scene=depth_input(self.depth_scene),
        )
        self.mode.setCurrentIndex(2)
        self._show()
        depth = (self.result.execution or {}).get("depth_verification", {})
        reason = depth.get("reason")
        rejected = (self.result.execution or {}).get("depth_rejected", 0)
        note = {
            "disabled": "Depth check off.",
            "camera_missing": "Load/capture a camera to check depth.",
            "complete_observation": "Depth check inactive for complete observations.",
        }.get(
            reason,
            "Depth diagnostics only."
            if depth.get("mode") == "report"
            else f"Depth rejected {rejected} candidates.",
        )
        self.status.setText(
            assessment(self.result)["message"] + ". "
            + note
            + " Select an instance or rejected candidate to review its measurements. "
            "Orange rejected poses are not detections."
        )

    def _refresh_result_selection(self):
        if self._selection_result is self.result:
            return
        self._close_depth_review()
        self._selection_result = self.result
        self.result_selection.blockSignals(True)
        self.result_selection.clear()
        self.result_selection.addItem("All accepted instances", None)
        if self.result is not None:
            for index, match in enumerate(self.result.matches):
                self.result_selection.addItem(f"Instance {index + 1}: score {match.score:.1%}",
                                              ("match", index))
            for index, row in enumerate((self.result.execution or {}).get("candidate_review", [])):
                self.result_selection.addItem(
                    f"Rejected candidate {row['candidate_index']}: {row['stage']}",
                    ("rejected", index))
        self.result_selection.setEnabled(self.result_selection.count() > 1)
        self.result_selection.blockSignals(False)

    def _close_depth_review(self):
        dialog, self._depth_review_dialog = self._depth_review_dialog, None
        if dialog is not None:
            dialog.close()

    def done(self, result):
        self._close_depth_review()
        super().done(result)

    def _review_depth(self, *, boundary=False):
        if self.result is None or self.recipe is None or self.test_scene is None:
            raise ValueError("Locate in an independent test scene before reviewing depth.")
        if self.recipe.cad is None or self.recipe.settings.observation_mode != "surface":
            raise ValueError("Camera-depth review requires a CAD model in surface mode.")
        if self.camera is None:
            raise ValueError("Load or capture the rectified scene camera before reviewing depth.")
        selection = self.result_selection.currentData()
        if selection is None and len(self.result.matches) == 1:
            selection = ("match", 0)
        if selection is None:
            raise ValueError("Select one accepted instance or rejected candidate for depth review.")
        kind, index = selection
        if kind == "match":
            pose = self.result.matches[index].pose
            label = f"Accepted instance {index + 1}"
        else:
            row = (self.result.execution or {})["candidate_review"][index]
            if "source_to_target" not in row:
                raise ValueError("This rejected candidate has no retained pose to review.")
            pose = np.asarray(row["source_to_target"])
            label = f"REJECTED candidate {row['candidate_index']} - not a detection"
        from .depth import DepthBuffer, DepthScene
        from .depth_review import inspect_depth
        from .qt_depth_review import DepthReviewDialog

        depth = depth_input(self.depth_scene)
        if depth is None:
            depth = DepthScene(self.test_scene.points, self.test_scene.units, self.test_scene.frame)
        depth.validate_for(self.camera.units, self.camera.frame)
        if (self.test_scene.units != self.camera.units
                or self.test_scene.frame != self.camera.frame):
            raise ValueError("Scene and camera units/frame must agree for depth review.")
        settings = self.recipe.settings
        buffer = DepthBuffer(depth.points, self.camera)
        if boundary:
            from .boundary import inspect_boundary
            from .qt_boundary_review import BoundaryReviewDialog

            review = inspect_boundary(
                self.recipe.cad.mesh, pose, buffer,
                spacing=settings.sampling_distance * self.recipe.diameter,
                tolerance=settings.distance_tolerance * self.recipe.diameter,
                minimum_support=settings.min_coverage, minimum_rays=settings.min_unique_support,
            )
        else:
            review = inspect_depth(
                self.recipe.cad.mesh, pose, buffer,
                tolerance=settings.distance_tolerance * self.recipe.diameter,
                minimum_coverage=settings.min_depth_coverage,
                minimum_rays=settings.min_unique_support,
            )
        provenance = {
            "selection": label,
            "depth_source": "depth_scene" if self.depth_scene is not None else "search_scene",
            "depth_points_sha256": hashlib.sha256(depth.points.tobytes()).hexdigest(),
            "model_samples_sha256": hashlib.sha256(self.recipe.samples.tobytes()).hexdigest(),
            "model_mesh_sha256": hashlib.sha256(
                self.recipe.cad.mesh.triangles.tobytes()).hexdigest(),
            "completed_capture": None if self.processed_capture is None else
                                 self.processed_capture.summary,
        }
        self._close_depth_review()
        dialog_type = BoundaryReviewDialog if boundary else DepthReviewDialog
        dialog = dialog_type(review, depth.points, provenance, self)
        self._depth_review_dialog = dialog

        def released():
            if self._depth_review_dialog is dialog:
                self._depth_review_dialog = None

        dialog.destroyed.connect(released)
        dialog.show()

    def _show(self):
        self._refresh_result_selection()
        mode = self.mode.currentIndex()
        yaw, pitch = self.yaw.value(), self.pitch.value()
        if mode == 3:
            if self.recipe is None:
                return
            if self.locator is None:
                self.locator = Locator(self.recipe)
            data = self.recipe.samples
            image = training_overlay(self.recipe, self.locator, yaw=yaw, pitch=pitch)
            health = self.locator.geometry.report()
            self.status.setText(
                f"{len(self.locator.search_indices)} candidate points from {len(data)} samples. "
                f"Locally planar {health['locally_planar_fraction']:.0%}. "
                "These are neighborhood statistics, not exact corner or plane labels."
            )
        elif mode in (2, 6):
            if self.result is None or self.recipe is None:
                self.viewer.set_image(QPixmap())
                return
            selection = self.result_selection.currentData()
            match_index = selection[1] if selection and selection[0] == "match" else None
            rejected_index = selection[1] if selection and selection[0] == "rejected" else None
            image = overlay(
                self.recipe, self.result, yaw=yaw, pitch=pitch, alternatives=mode == 6,
                match_index=match_index, rejected_index=rejected_index,
                scene=self.result_layers["scene"].isChecked(),
                axes=self.result_layers["axes"].isChecked(),
                layers=tuple(name for name in ("supported", "missing", "hidden", "free_space")
                             if self.result_layers[name].isChecked()),
            )
            if rejected_index is not None:
                row = (self.result.execution or {})["candidate_review"][rejected_index]
                self.status.setText("REJECTED POSE, not a detection. " +
                                    " | ".join(rejection_lines(row, self.result.units)))
            else:
                self.status.setText(assessment(self.result)["message"])
        else:
            value = (
                (self.depth_scene if self.depth_scene is not None else self.test_scene)
                if mode == 4
                else self.test_scene
                if mode == 5
                else self.reference
            )
            if mode == 1:
                if self.recipe is None:
                    return
                value = PointCloud(self.recipe.samples[:, :3], self.recipe.units, self.recipe.frame)
            if value is None:
                self.viewer.set_image(QPixmap())
                return
            image = render_cloud(value, width=960, height=640, yaw=yaw, pitch=pitch, point_size=3)
        self.viewer.set_image(pixmap(image))

    def _restore(self):
        if not self.parameters["recipe_path"]:
            return
        recipe = load_recipe(
            recipe_path(self.context.project_dir, self.parameters["recipe_path"]),
            sha256=self.parameters["sha256"],
        )
        data = recipe.reference
        self._set_reference(
            PointCloud(
                data[:, :3],
                recipe.units,
                recipe.frame,
                normals=data[:, 3:] if data.shape[1] == 6 else None,
            ),
            cad=recipe.cad,
        )
        self._set_settings(recipe.settings)
        self.recipe = recipe
        self.mode.setCurrentIndex(1)
        self._show()
        budget = recipe.health["sampling_budget"]
        self.status.setText(
            f"Restored the reference cloud and {len(recipe.samples)} trained surface samples."
            + (" Retained CAD mesh is available for resampling." if recipe.cad is not None else "")
            + (
                f" Model budget: {len(recipe.samples)} of {budget['voxel_points']} voxel points."
                if budget["reference_exceeds_budget"]
                else ""
            )
        )

    def _stage(self):
        if self.recipe is None:
            raise ValueError("Train a model before staging.")
        relative = f"assets/3d_locate/{uuid.uuid4().hex}.s3l"
        path = recipe_path(self.context.project_dir, relative)
        path.parent.mkdir(parents=True, exist_ok=True)
        digest = save_recipe(path, self.recipe)
        self.parameters.update(recipe_path=relative, sha256=digest)
        self.accept()
