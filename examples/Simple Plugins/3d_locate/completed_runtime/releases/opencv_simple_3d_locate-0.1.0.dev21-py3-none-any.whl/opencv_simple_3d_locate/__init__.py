"""Train and locate rigid surfaces in clouds with explicit units and frames."""

from .depth import DepthScene
from .locate import Locator
from .mesh import CADReference, TriangleMesh, read_stl, train_cad
from .mesh_io import read_mesh, read_ply_mesh
from .model import Recipe, Settings, train
from .observation import Camera
from .optimization import ValidationScene, compare_profiles, profile_recipe
from .persistence import load_recipe, save_recipe

__all__ = [
    "CADReference",
    "Camera",
    "DepthScene",
    "ValidationScene",
    "Locator",
    "Recipe",
    "Settings",
    "TriangleMesh",
    "load_recipe",
    "read_stl",
    "read_mesh",
    "read_ply_mesh",
    "save_recipe",
    "train",
    "train_cad",
    "compare_profiles",
    "profile_recipe",
]
