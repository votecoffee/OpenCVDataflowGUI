"""Human-readable result assessment shared by reports, runtime and training."""


def assessment(result):
    execution = result.execution or {}
    counts = execution.get("rejection_counts", {})
    if result.matches:
        status = "located"
        message = f"{len(result.matches)} accepted 3D instances"
    elif execution.get("stop_reason") == "insufficient_scene_points":
        status = "insufficient_scene_points"
        message = (f"Not located: {execution['first_surface_points']} usable points; "
                   f"need at least {execution['minimum_scene_points']}")
    elif execution.get("stop_reason") == "degenerate_scene_geometry":
        status = "degenerate_scene_geometry"
        message = "Not located: scene geometry cannot constrain a rigid surface pose"
    elif result.tested_candidates == 0:
        status = "no_candidates"
        message = "Not located: no candidate poses generated"
    else:
        status = "verification_failed"
        message = f"Not located: none of {result.tested_candidates} tested candidates passed"
    return {"status": status, "message": message, "rejection_counts": dict(counts)}


def rejection_lines(row, units):
    """Measurements at the rejected stage, with the original gate limits."""
    lines = [f"Rejected candidate {row['candidate_index']}",
             f"Stage: {row['stage']} ({row.get('candidate_source', 'unknown')})"]
    limits = row.get("limits", {})
    if "coverage" in row:
        lines.append(f"Coverage {row['coverage']:.1%} / min {limits['min_coverage']:.1%}")
        lines.append(f"Unique support {row['unique_support']} / min {limits['min_unique_support']}")
        if "max_rmse" in limits:
            rmse = "unavailable" if row["rmse"] is None else f"{row['rmse']:.3g}"
            lines.append(f"RMSE {rmse} / max {limits['max_rmse']:.3g} {units}")
            lines.append(f"Normal spread {row['normal_spread']:.3g} / "
                         f"min {limits['min_normal_spread']:.3g}")
    depth = row.get("depth_verification")
    if depth:
        lines.append(f"Free space {depth['free_space_fraction']:.1%} / "
                     f"max {depth['maximum_free_space']:.1%}")
    projective = row.get("projective_scoring")
    if projective:
        lines.append(f"Rendered depth: {projective['status']}")
    boundary = row.get("boundary_verification")
    if boundary:
        lines.append(f"Boundary possible support {boundary['distinct_support_upper_bound']:.1%} "
                     f"/ min {boundary['minimum_support']:.1%}")
        lines.append(f"Measured continuation {boundary['counts']['continued']} pairs")
    lines.append("Failed: " + ", ".join(row["failed_checks"]))
    return lines
