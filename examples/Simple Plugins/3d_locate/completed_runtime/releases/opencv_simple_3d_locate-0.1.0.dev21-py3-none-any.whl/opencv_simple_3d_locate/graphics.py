"""Computational surface-fit views using the host's standard point-cloud renderer."""

import cv2
import numpy as np
from opencv_dataflow.pointclouds import PointCloud, render_cloud

from .model import transformed
from .review import assessment, rejection_lines


def training_overlay(recipe, locator, *, yaw=25, pitch=-20):
    data, score = recipe.samples, locator.geometry.importance
    colors = np.c_[255 * score, 50 + 70 * (1 - score), 240 * (1 - score)].astype(np.uint8)
    colors[locator.search_indices] = [245, 245, 245]
    value = PointCloud(data[:, :3], recipe.units, recipe.frame, colors=colors)
    image = np.full((640, 960, 3), (32, 25, 18), np.uint8)
    image[56:] = render_cloud(value, width=960, height=584, yaw=yaw, pitch=pitch, point_size=3)
    cv2.putText(
        image,
        "White: candidate points | Red: shape change | Blue: flatter surface",
        (14, 24),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.5,
        (240, 240, 240),
        1,
        cv2.LINE_AA,
    )
    return image


def fit_cloud(recipe, result, *, alternatives=False, match_index=None, rejected_index=None,
              scene=True, axes=True, layers=("supported", "missing", "hidden", "free_space")):
    """Build a display cloud; selected rejected poses never become detections."""
    if match_index is not None and rejected_index is not None:
        raise ValueError("Select an accepted instance or a rejected candidate, not both.")
    points = [result.scene[:, :3] if scene else np.empty((0, 3), np.float32)]
    colors = [np.full((len(points[0]), 3), 115, np.uint8)]
    matches = result.matches if match_index is None else (result.matches[match_index],)
    if rejected_index is not None:
        matches = ()
        rejected = (result.execution or {}).get("candidate_review", [])[rejected_index]
        if "source_to_target" in rejected:
            data = transformed(recipe.samples, np.asarray(rejected["source_to_target"]))
            points.append(data[:, :3])
            colors.append(np.tile([255, 170, 35], (len(data), 1)))
    for match in matches:
        competing = (match.pose_alternatives or {}).get("alternatives", [])
        if alternatives and competing:
            other = np.asarray(competing[0]["source_to_target"])
            data = transformed(recipe.samples, other)
            points.append(data[:, :3])
            colors.append(np.tile([255, 170, 35], (len(data), 1)))
            for axis in range(3) if axes else ():
                line = np.zeros((32, 3))
                line[:, axis] = np.linspace(0, recipe.diameter * 0.25, len(line))
                points.append(line @ other[:3, :3].T + other[:3, 3])
                colors.append(np.tile([255, 170, 35], (len(line), 1)))
        aligned = transformed(recipe.samples, match.pose)
        categories = np.full(len(aligned), 1, np.uint8)
        if match.visible_model is not None:
            categories[~match.visible_model] = 2
        categories[match.inlier_model] = 0
        if match.free_space_model is not None:
            categories[match.free_space_model] = 3
        palette = np.array(
            [[45, 235, 100], [245, 65, 65], [90, 115, 175], [235, 50, 220]], np.uint8
        )
        names = ("supported", "missing", "hidden", "free_space")
        keep = np.isin(categories, [i for i, name in enumerate(names) if name in layers])
        points.append(aligned[keep, :3])
        colors.append(palette[categories[keep]])
        # Model-frame origin and XYZ axes, transformed into the scene frame.
        for axis in range(3) if axes else ():
            line = np.zeros((32, 3))
            line[:, axis] = np.linspace(0, recipe.diameter * 0.2, len(line))
            points.append(line @ match.pose[:3, :3].T + match.pose[:3, 3])
            color = np.zeros(3, np.uint8)
            color[axis] = 255
            colors.append(np.tile(color, (len(line), 1)))
    return PointCloud(
        np.concatenate(points),
        result.units,
        result.target_frame,
        colors=np.asarray(np.concatenate(colors), np.uint8),
    )


def _text(image, text, point, *, width=930, scale=.5, color=(240, 240, 240)):
    text = str(text).encode("ascii", errors="replace").decode("ascii")[:300]
    if cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, scale, 1)[0][0] > width:
        while text and cv2.getTextSize(
            text + "...", cv2.FONT_HERSHEY_SIMPLEX, scale, 1
        )[0][0] > width:
            text = text[:-1]
        text += "..."
    cv2.putText(image, text, point, cv2.FONT_HERSHEY_SIMPLEX, scale, color, 1, cv2.LINE_AA)


def overlay(recipe, result, *, yaw=25, pitch=-20, alternatives=False, match_index=None,
            rejected_index=None, scene=True, axes=True,
            layers=("supported", "missing", "hidden", "free_space")):
    """960x640 assessment with a separate cloud viewport, legend and detail panel."""
    image = np.full((640, 960, 3), (32, 25, 18), np.uint8)
    image[56:576, :624] = render_cloud(
        fit_cloud(recipe, result, alternatives=alternatives, match_index=match_index,
                  rejected_index=rejected_index, scene=scene, axes=axes, layers=layers),
        width=624,
        height=520,
        yaw=yaw,
        pitch=pitch,
        point_size=3,
    )
    status = assessment(result)
    title = "LOCATED" if result.matches else "NO MATCH"
    _text(image, f"{title} | {status['message']}", (14, 24), scale=.6,
          color=(130, 240, 160) if result.matches else (130, 160, 255))
    _text(image, f"{result.source_frame} -> {result.target_frame} | {result.units} | "
          f"yaw {yaw}, pitch {pitch} | display projection", (14, 46), scale=.46)
    cv2.line(image, (632, 56), (632, 638), (90, 75, 62), 1)
    for index, (label, color) in enumerate([
        ("Supported", (100, 235, 45)), ("Missing", (65, 65, 245)),
        ("Self-hidden", (175, 115, 90)), ("Free space", (220, 50, 235)),
        ("Scene", (115, 115, 115)), ("XYZ axes = RGB", (235, 235, 235)),
    ]):
        x, y = 14 + (index % 3) * 200, 599 + (index // 3) * 25
        cv2.rectangle(image, (x, y - 9), (x + 8, y - 1), color, -1)
        _text(image, label, (x + 13, y), width=180, scale=.43)
    execution = result.execution or {}
    lines = [f"Scene samples: {len(result.scene)}",
             f"Hypotheses: {result.candidate_count}; tested: {result.tested_candidates}"]
    for stage, count in execution.get("rejection_counts", {}).items():
        lines.append(f"Rejected at {stage}: {count}")
    lines.append(f"Overlap removed: {execution.get('overlap_rejected', 0)}")
    if rejected_index is not None:
        lines.extend(["", "ORANGE = REJECTED, not a detection"])
        lines.extend(rejection_lines(execution["candidate_review"][rejected_index], result.units))
    elif not result.matches:
        reviews = execution.get("candidate_review", [])
        if reviews:
            lines.extend(["", "Most advanced rejected stage:"])
            lines.extend(rejection_lines(reviews[0], result.units))
        else:
            lines.append("No candidate pose available for review.")
    if alternatives:
        lines.append("Orange: overlapping alternative; not another detection")
    shown = list(enumerate(result.matches)) if match_index is None else [
        (match_index, result.matches[match_index])
    ]
    if rejected_index is not None:
        shown = []
    for index, match in shown[:2]:
        lines.extend(["", f"Instance {index + 1} | score {match.score:.1%}"])
        lines.append(
            f"Visible support {match.coverage:.1%} | RMSE {match.rmse:.3g} {result.units}"
        )
        depth = match.depth_verification
        projective = match.projective_scoring
        if projective:
            lines.append(
                f"   CAD ray fit | {projective['known_rays']} known rays | "
                f"stride {projective['render_stride']} | score is not probability"
            )
        if depth and depth["status"] in ("checked", "insufficient_depth"):
            fraction = depth["free_space_fraction"]
            free = "unknown" if fraction is None else f"{fraction:.1%}"
            lines.append(
                f"   Depth {depth['status']}: free space {free} | "
                f"known {depth['depth_coverage']:.1%}"
            )
        competing = match.pose_alternatives
        boundary = match.boundary_verification
        if boundary:
            upper = boundary.get("distinct_support_upper_bound")
            text = "unknown" if upper is None else f"{upper:.1%}"
            lines.append(f"   Boundary {boundary['status']}: possible support {text}")
        if competing:
            margin = competing["relative_score_margin"]
            text = "unavailable" if margin is None else f"{margin:.1%}"
            lines.append(f"   Distinct alternatives: {competing['count']} | score margin {text}")
    if len(shown) > 2:
        lines.append(f"{len(shown) - 2} more instances: select in trainer or inspect Report")
    lines.append("Fit scores are not probabilities.")
    wrapped_lines = []
    for line in lines:
        # Wrap within the dedicated detail panel; never cover the cloud.
        words = line.split()
        wrapped = ""
        for word in words:
            trial = (wrapped + " " + word).strip()
            if wrapped and cv2.getTextSize(trial, cv2.FONT_HERSHEY_SIMPLEX, .45, 1)[0][0] > 294:
                wrapped_lines.append(wrapped)
                wrapped = word
            else:
                wrapped = trial
        wrapped_lines.append(wrapped)
    for row, line in enumerate(wrapped_lines[:26]):
        _text(image, line, (646, 78 + 21 * row), width=300, scale=.45)
    if len(wrapped_lines) > 26:
        _text(image, "More detail: Report / training selection", (646, 632), width=300, scale=.4)
    return image
