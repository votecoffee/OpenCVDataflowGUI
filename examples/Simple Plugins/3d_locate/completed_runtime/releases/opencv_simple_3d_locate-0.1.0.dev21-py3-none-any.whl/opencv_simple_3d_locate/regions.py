"""Bounded proposal-only support-plane removal and local surface grouping."""

import cv2
import numpy as np

from .geometry import search_indices
from .model import normal_spread


def find_regions(data, spacing, *, limit=12):
    """Return immutable original-row indices; never alter verification evidence.

    Coordinates use model-diagonal units. Four normal-guided plane rounds,
    128 seeds/round and 12 nearest neighbors/point bound analysis. Plane support
    must span over two model diagonals before being removed from proposals.
    """
    data = np.asarray(data, np.float32)
    if (
        data.ndim != 2
        or data.shape[1] != 6
        or not 30 <= len(data) <= 100000
        or not np.isfinite(data).all()
        or not np.allclose(np.linalg.norm(data[:, 3:], axis=1), 1, atol=1e-3)
        or not 0.01 <= spacing <= 0.2
        or type(limit) is not int
        or not 1 <= limit <= 12
    ):
        raise ValueError(
            "Regional search requires 30..100000 normalized surface rows and 1..12 regions."
        )
    available = np.ones(len(data), bool)
    rng = np.random.default_rng(0)
    plane_count = 0
    for _ in range(4):
        remaining = np.flatnonzero(available)
        if len(remaining) < 30:
            break
        seeds = rng.choice(remaining, min(128, len(remaining)), replace=False)
        normals = data[seeds, 3:]
        offsets = np.einsum("ij,ij->i", data[seeds, :3], normals)
        counts = []
        for start in range(0, len(seeds), 16):
            selected = (
                abs(
                    data[remaining, :3] @ normals[start : start + 16].T
                    - offsets[start : start + 16]
                )
                < spacing * 0.75
            ) & (data[remaining, 3:] @ normals[start : start + 16].T > 0.94)
            counts.extend(selected.sum(axis=0))
        found = False
        for candidate in np.argsort(-np.asarray(counts), kind="stable")[:16]:
            normal, offset = normals[candidate], offsets[candidate]
            selected = (
                available
                & (abs(data[:, :3] @ normal - offset) < spacing * 0.75)
                & (data[:, 3:] @ normal > 0.94)
            )
            points = data[selected, :3]
            if len(points) < 30:
                continue
            _, _, axes = np.linalg.svd(points - points.mean(axis=0), full_matrices=False)
            if np.linalg.norm(np.ptp(points @ axes[:2].T, axis=0)) > 2:
                available[selected] = False
                plane_count += 1
                found = True
                break
        if not found:
            break
    original_ids = np.flatnonzero(available)
    groups = []
    if len(original_ids) >= 30:
        left = data[original_ids]
        index = cv2.flann_Index(left[:, :3].copy(), {"algorithm": 4})
        neighbors, squared = index.knnSearch(
            left[:, :3].copy(), min(12, len(left)), params={"checks": -1}
        )
        unvisited = np.ones(len(left), bool)
        for first in range(len(left)):
            if not unvisited[first]:
                continue
            unvisited[first] = False
            queue = [first]
            for point in queue:
                linked = neighbors[point][
                    (squared[point] < (spacing * 2.5) ** 2) & unvisited[neighbors[point]]
                ]
                unvisited[linked] = False
                queue.extend(linked.tolist())
            if len(queue) >= 30:
                groups.append(np.sort(original_ids[queue]))
    groups.sort(key=lambda group: -len(group))
    regions, windows, duplicates = [], 0, 0
    for group in groups:
        local = data[group]
        if normal_spread(local[:, 3:]) < 1e-8:
            continue
        extent = np.linalg.norm(np.ptp(local[:, :3], axis=0))
        if extent <= 1.5:
            if len(group) == len(data):
                duplicates += 1  # The existing global call already searches these rows.
            else:
                regions.append(group)
        else:
            centers = []
            anchors = search_indices(local, min(len(local), 128))
            for anchor in anchors:
                center = local[anchor, :3]
                if any(np.linalg.norm(center - prior) < 0.6 for prior in centers):
                    continue
                selected = np.all(abs(local[:, :3] - center) <= 0.65, axis=1)
                if selected.sum() < 30:
                    continue
                centers.append(center)
                regions.append(group[selected])
                windows += 1
                if len(regions) >= limit:
                    break
        if len(regions) >= limit:
            break
    for ids in regions:
        ids.flags.writeable = False
    return tuple(regions), {
        "input_points": len(data),
        "background_planes": plane_count,
        "proposal_only_removed_points": int((~available).sum()),
        "components": len(groups),
        "largest_component_sizes": [len(group) for group in groups[:32]],
        "region_points": [len(ids) for ids in regions],
        "window_regions": windows,
        "skipped_global_duplicates": duplicates,
        "region_limit": limit,
    }
