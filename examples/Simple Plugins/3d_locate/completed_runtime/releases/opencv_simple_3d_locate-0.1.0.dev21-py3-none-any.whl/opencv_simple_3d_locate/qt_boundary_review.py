"""Native flyaround of cached-pose boundary evidence, without another search."""

import json
from pathlib import Path

import numpy as np
from opencv_dataflow.cloud_io import write_cloud
from opencv_dataflow.cloud_viewer import CloudViewer
from opencv_dataflow.pointclouds import PointCloud
from PySide6.QtWidgets import QCheckBox, QFileDialog, QHBoxLayout, QLabel, QPushButton

from .boundary import BOUNDARY_STATES


def boundary_cloud(review, *, states=BOUNDARY_STATES, scene=None, axes=True):
    xyz, rgb = review.display_points(states)
    points, colors = [xyz], [rgb]
    if scene is not None:
        ids = np.linspace(0, len(scene) - 1, min(5000, len(scene)), dtype=int)
        points.append(scene[ids, :3])
        colors.append(np.full((len(ids), 3), 115, np.uint8))
    if axes:
        length = review.report["probe_distance"] * 2
        for axis in range(3):
            line = np.zeros((32, 3))
            line[:, axis] = np.linspace(0, length, len(line))
            points.append(line @ review.pose[:3, :3].T + review.pose[:3, 3])
            color = np.zeros(3, np.uint8)
            color[axis] = 255
            colors.append(np.tile(color, (len(line), 1)))
    return PointCloud(np.concatenate(points), review.camera.units, review.camera.frame,
                      colors=np.ascontiguousarray(np.concatenate(colors), np.uint8))


class BoundaryReviewDialog(CloudViewer):
    def __init__(self, review, scene, provenance, parent=None):
        super().__init__(None, parent)
        self.review, self.provenance = review, dict(provenance)
        self.resize(1200, 780)
        ids = np.linspace(0, len(scene) - 1, min(5000, len(scene)), dtype=int)
        self.scene = np.ascontiguousarray(scene[ids, :3]).copy()
        self.scene.flags.writeable = False
        self.setWindowTitle(f"Boundary evidence · {provenance['selection']}")
        title = QLabel(
            f"{provenance['selection']} · experimental outline review, not a correctness score.\n"
            "Orange: measured surface continues past the model outline. Green: measured "
            "depth changes. Magenta: unknown. Colored inner points are expected geometry; "
            "outer points are actual returns. Gray is the measured scene."
        )
        title.setWordWrap(True)
        self.layout().insertWidget(0, title)
        report, counts = review.report, review.report["counts"]
        upper = report["distinct_support_upper_bound"]
        text = "unknown" if upper is None else f"{upper:.1%}"
        self.summary = QLabel(
            f"{report['status']} · possible distinctive support at most {text}; "
            f"required {report['minimum_support']:.1%}. Unknown pairs count as possible support.\n"
            f"Continued {counts['continued']} · Changed {counts['discontinuous']} · "
            f"Unknown {counts['unknown']} · {report['sampled_boundary_pairs']} / "
            f"{report['total_boundary_pairs']} outline probes · "
            f"{report['distance_tolerance']:.4g} {review.camera.units} tolerance"
        )
        self.summary.setWordWrap(True)
        self.layout().insertWidget(1, self.summary)
        row, self.layers = QHBoxLayout(), {}
        for name, label in (("continued", "Orange: continuation"),
                            ("discontinuous", "Green: depth change"),
                            ("unknown", "Magenta: unknown"),
                            ("scene", "Measured scene"), ("axes", "Pose axes")):
            box = QCheckBox(label)
            box.setChecked(True)
            box.toggled.connect(self.refresh_layers)
            self.layers[name] = box
            row.addWidget(box)
        self.layout().insertLayout(2, row)
        button = QPushButton("Export boundary evidence…")
        button.clicked.connect(self.choose_export)
        self.layout().addWidget(button)
        self.refresh_layers()

    def refresh_layers(self, *_):
        self.set_cloud(boundary_cloud(
            self.review, states=tuple(n for n in BOUNDARY_STATES if self.layers[n].isChecked()),
            scene=self.scene if self.layers["scene"].isChecked() else None,
            axes=self.layers["axes"].isChecked(),
        ))

    def export(self, folder):
        folder = Path(folder)
        folder.mkdir(parents=True, exist_ok=False)
        write_cloud(folder / "boundary_and_measured.ply", self.cloud, binary=True)
        np.savez_compressed(
            folder / "boundary_pairs.npz", inside_pixels=self.review.inside_pixels,
            outside_pixels=self.review.outside_pixels, expected_depth=self.review.expected_depth,
            measured_depth=self.review.measured_depth, residual=self.review.residual,
            states=self.review.states,
        )
        report = {**self.review.report, "camera": self.review.camera.record(),
                  "source_to_target": self.review.pose.tolist(), "provenance": self.provenance,
                  "visible_layers": [n for n, b in self.layers.items() if b.isChecked()],
                  "state_codes": dict(enumerate(BOUNDARY_STATES)),
                  "review_only": True, "search_executed": False}
        (folder / "report.json").write_bytes(
            (json.dumps(report, indent=2, allow_nan=False) + "\n").encode("utf-8")
        )
        return folder

    def choose_export(self):
        parent = QFileDialog.getExistingDirectory(self, "Parent folder for a new evidence export")
        if not parent:
            return
        from datetime import datetime

        folder = Path(parent) / datetime.now().strftime("boundary_%Y%m%d_%H%M%S_%f")
        try:
            self.export(folder)
            self.summary.setText(f"Exported boundary probes, native cloud and report to {folder}")
        except (OSError, ValueError) as error:
            self.summary.setText(str(error))
