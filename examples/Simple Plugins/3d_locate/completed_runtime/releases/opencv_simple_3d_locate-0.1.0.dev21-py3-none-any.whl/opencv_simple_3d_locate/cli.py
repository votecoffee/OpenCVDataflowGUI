"""Bounded NPZ interchange and a host-independent training/execution CLI."""

import argparse
import json
from dataclasses import replace
from pathlib import Path
from zipfile import BadZipFile, ZipFile

from . import DepthScene, Locator, Settings, load_recipe, read_mesh, save_recipe, train, train_cad
from .model import cloud
from .optimization import compare_profiles, profile_recipe, read_validation_scenes
from .persistence import read_array


def read_npz(path):
    path = Path(path)
    if path.stat().st_size > 64 * 1024 * 1024:
        raise ValueError("Cloud archive exceeds 64 MiB.")
    with ZipFile(path) as archive:
        expected = {"points_normals.npy", "units.npy", "frame.npy"}
        if set(archive.namelist()) != expected or len(archive.namelist()) != 3:
            raise ValueError("Cloud archive requires points_normals, units, and frame arrays.")
        if sum(item.file_size for item in archive.infolist()) > 64 * 1024 * 1024:
            raise ValueError("Uncompressed cloud archive exceeds 64 MiB.")
        data = cloud(read_array(archive.read("points_normals.npy"), points=True))
        units = str(read_array(archive.read("units.npy")).item())
        frame = str(read_array(archive.read("frame.npy")).item())
    return data, units, frame


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Train an oriented point cloud and locate its rigid 3D instances."
    )
    commands = parser.add_subparsers(dest="command", required=True)
    training = commands.add_parser("train")
    training.add_argument("cloud", type=Path)
    training.add_argument("recipe", type=Path)
    training.add_argument("--observation-mode", choices=("surface", "complete"), default="surface")
    training.add_argument(
        "--candidate-backend",
        choices=("ppf", "ppf_planes", "ppf_features", "ppf_regions"),
        default="ppf",
    )
    training.add_argument("--depth-verification", choices=("auto", "report", "off"), default="auto")
    training.add_argument("--workers", type=int, default=1)
    training.add_argument("--boundary-verification", choices=("off", "report", "auto"),
                          default="off")
    training.add_argument(
        "--pose-scoring", choices=("geometric", "projective"), default="geometric"
    )
    cad = commands.add_parser(
        "train-mesh", aliases=["train-stl"],
        help="Sample a triangle PLY or STL surface and train a rigid model."
    )
    cad.add_argument("mesh", type=Path)
    cad.add_argument("recipe", type=Path)
    cad.add_argument(
        "--units",
        choices=("m", "mm", "unitless"),
        required=True,
        help="Units of the coordinates after applying --scale.",
    )
    cad.add_argument("--frame", default="model")
    cad.add_argument("--scale", type=float, default=1.0)
    cad.add_argument("--samples", type=int, default=6000)
    cad.add_argument("--seed", type=int, default=0)
    cad.add_argument("--flip-normals", action="store_true")
    cad.add_argument("--observation-mode", choices=("surface", "complete"), default="surface")
    cad.add_argument(
        "--candidate-backend",
        choices=("ppf", "ppf_planes", "ppf_features", "ppf_regions"),
        default="ppf",
    )
    cad.add_argument("--depth-verification", choices=("auto", "report", "off"), default="auto")
    cad.add_argument("--workers", type=int, default=1)
    cad.add_argument("--boundary-verification", choices=("off", "report", "auto"), default="off")
    cad.add_argument("--pose-scoring", choices=("geometric", "projective"), default="geometric")
    locating = commands.add_parser("locate")
    locating.add_argument("recipe", type=Path)
    locating.add_argument("cloud", type=Path)
    locating.add_argument("--output", type=Path)
    locating.add_argument("--camera", type=Path, help="Rectified camera_model_v1 JSON.")
    locating.add_argument("--depth-cloud", type=Path, help="Separate full-frame depth XYZ NPZ.")
    locating.add_argument(
        "--workers", type=int, help="Override candidate worker count for this run."
    )
    locating.add_argument("--pose-scoring", choices=("geometric", "projective"))
    locating.add_argument("--boundary-verification", choices=("off", "report", "auto"))
    comparison = commands.add_parser(
        "compare", help="Benchmark execution plans on validation scenes."
    )
    comparison.add_argument("recipe", type=Path)
    comparison.add_argument("manifest", type=Path)
    comparison.add_argument("--output", type=Path)
    comparison.add_argument("--save-recipe", type=Path)
    comparison.add_argument("--repeats", type=int, default=2)
    comparison.add_argument("--position-tolerance", type=float)
    comparison.add_argument("--angle-tolerance", type=float, default=1.0)
    args = parser.parse_args(argv)
    try:
        if args.command == "compare":
            recipe = load_recipe(args.recipe)
            report = compare_profiles(
                recipe,
                read_validation_scenes(args.manifest),
                repeats=args.repeats,
                position_tolerance=args.position_tolerance,
                angle_tolerance=args.angle_tolerance,
            )
            if args.save_recipe:
                if report["recommended"] is None:
                    raise ValueError(
                        "No plan passes validation with a positive reference. Recipe was not saved."
                    )
                report["saved_recipe_sha256"] = save_recipe(
                    args.save_recipe, profile_recipe(recipe, report["recommended"])
                )
        elif args.command in ("train", "train-stl", "train-mesh"):
            if args.command in ("train-stl", "train-mesh"):
                mesh = read_mesh(args.mesh, scale=args.scale, flip_normals=args.flip_normals)
                recipe = train_cad(
                    mesh,
                    units=args.units,
                    frame=args.frame,
                    count=args.samples,
                    seed=args.seed,
                    settings=Settings(
                        observation_mode=args.observation_mode,
                        candidate_backend=args.candidate_backend,
                        depth_verification=args.depth_verification,
                        execution_workers=args.workers,
                        pose_scoring=args.pose_scoring,
                        boundary_verification=args.boundary_verification,
                    ),
                )
            else:
                data, units, frame = read_npz(args.cloud)
                recipe = train(
                    data,
                    units=units,
                    frame=frame,
                    settings=Settings(
                        observation_mode=args.observation_mode,
                        candidate_backend=args.candidate_backend,
                        depth_verification=args.depth_verification,
                        execution_workers=args.workers,
                        pose_scoring=args.pose_scoring,
                        boundary_verification=args.boundary_verification,
                    ),
                )
            report = {"sha256": save_recipe(args.recipe, recipe), "health": recipe.health}
        else:
            data, units, frame = read_npz(args.cloud)
            depth = None if args.depth_cloud is None else DepthScene(*read_npz(args.depth_cloud))
            camera = None
            if args.camera:
                if args.camera.stat().st_size > 65536:
                    raise ValueError("Camera JSON exceeds 64 KiB.")
                camera = json.loads(args.camera.read_bytes())
            recipe = load_recipe(args.recipe)
            if args.workers is not None:
                recipe = replace(
                    recipe, settings=replace(recipe.settings, execution_workers=args.workers)
                )
            if args.pose_scoring is not None:
                recipe = replace(
                    recipe, settings=replace(recipe.settings, pose_scoring=args.pose_scoring)
                )
            if args.boundary_verification is not None:
                recipe = replace(recipe, settings=replace(
                    recipe.settings, boundary_verification=args.boundary_verification))
            report = (
                Locator(recipe)
                .locate(data, units=units, frame=frame, camera=camera, depth_scene=depth)
                .report()
            )
        text = json.dumps(report, indent=2, allow_nan=False) + "\n"
        if getattr(args, "output", None):
            args.output.write_bytes(text.encode("utf-8"))
        else:
            print(text, end="")
    except (ValueError, OSError, KeyError, BadZipFile) as error:
        parser.exit(2, f"{error}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
