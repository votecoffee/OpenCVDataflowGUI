"""Bounded triangle-PLY import alongside the existing STL reader."""

from numbers import Real
from pathlib import Path

import numpy as np

from .mesh import MAX_TRIANGLES, TriangleMesh, read_stl

MAX_MESH_BYTES = 64 * 1024 * 1024
MAX_VERTICES = 200000
_TYPES = {
    "char": "i1", "int8": "i1", "uchar": "u1", "uint8": "u1",
    "short": "i2", "int16": "i2", "ushort": "u2", "uint16": "u2",
    "int": "i4", "int32": "i4", "uint": "u4", "uint32": "u4",
    "float": "f4", "float32": "f4", "double": "f8", "float64": "f8",
}


def _dtype(name, endian="<"):
    if name not in _TYPES:
        raise ValueError(f"Unsupported PLY scalar type: {name}")
    return np.dtype(endian + _TYPES[name])


def _header(stream):
    if stream.readline(16).strip() != b"ply":
        raise ValueError("A PLY mesh must start with ply.")
    elements, fmt = [], None
    for _ in range(512):
        line = stream.readline(4097)
        if not line or len(line) > 4096:
            raise ValueError("Truncated or oversized PLY header.")
        try:
            parts = line.decode("ascii").split()
        except UnicodeError as error:
            raise ValueError("PLY header must be ASCII.") from error
        if not parts or parts[0] in ("comment", "obj_info"):
            continue
        if parts == ["end_header"]:
            break
        if parts[0] == "format":
            if len(parts) != 3 or parts[2] != "1.0" or fmt is not None:
                raise ValueError("Supply one PLY format declaration, version 1.0.")
            fmt = parts[1]
        elif parts[0] == "element":
            if len(parts) != 3 or parts[1] not in ("vertex", "face"):
                raise ValueError("Triangle PLY import supports vertex and face elements only.")
            if any(element[0] == parts[1] for element in elements):
                raise ValueError("Duplicate PLY element.")
            count = int(parts[2])
            limit = MAX_VERTICES if parts[1] == "vertex" else MAX_TRIANGLES
            if not 1 <= count <= limit:
                raise ValueError(f"PLY {parts[1]} count exceeds the supported budget.")
            elements.append((parts[1], count, []))
        elif parts[0] == "property":
            if not elements or len(elements[-1][2]) == 64:
                raise ValueError("Missing PLY element or property budget exceeded.")
            if len(parts) == 3:
                dtype = _dtype(parts[1])
                prop = (parts[2], None, dtype)
            elif len(parts) == 5 and parts[1] == "list":
                count, dtype = _dtype(parts[2]), _dtype(parts[3])
                if count.kind not in "iu":
                    raise ValueError("PLY list counts must use integer types.")
                prop = (parts[4], count, dtype)
            else:
                raise ValueError("Invalid PLY property declaration.")
            if any(p[0] == prop[0] for p in elements[-1][2]):
                raise ValueError("Duplicate PLY property.")
            elements[-1][2].append(prop)
        else:
            raise ValueError("Unknown PLY header directive.")
    else:
        raise ValueError("PLY header exceeds 512 lines.")
    if fmt not in ("ascii", "binary_little_endian", "binary_big_endian"):
        raise ValueError("Unsupported or missing PLY format.")
    if {e[0] for e in elements} != {"vertex", "face"}:
        raise ValueError("A mesh requires both PLY vertex and face elements.")
    for name, _, props in elements:
        if not props:
            raise ValueError("PLY elements require properties.")
        if name == "vertex":
            if any(p[1] is not None for p in props) or not {"x", "y", "z"} <= {p[0] for p in props}:
                raise ValueError("PLY vertices require scalar x, y and z properties.")
        else:
            indices = [p for p in props if p[0] in ("vertex_index", "vertex_indices")]
            if len(indices) != 1 or indices[0][1] is None or indices[0][2].kind not in "iu":
                raise ValueError("PLY faces require one integer vertex_indices list.")
    return fmt, elements


def _read_exact(stream, size):
    if size > MAX_MESH_BYTES:
        raise ValueError("Declared PLY record block exceeds 64 MiB.")
    data = stream.read(size)
    if len(data) != size:
        raise ValueError("Truncated PLY body.")
    return data


def _ascii_value(token, dtype):
    if dtype.kind in "iu":
        value = int(token)
        limits = np.iinfo(dtype)
        if not limits.min <= value <= limits.max:
            raise ValueError("PLY integer exceeds its declared scalar range.")
        return value
    return float(token)


def _record(stream, props, *, binary, endian):
    values = {}
    if not binary:
        line = stream.readline(65537)
        if not line or len(line) > 65536:
            raise ValueError("Truncated or oversized PLY body record.")
        try:
            tokens = iter(line.decode("ascii").split())
        except UnicodeError as error:
            raise ValueError("ASCII PLY body contains non-ASCII data.") from error
        try:
            for name, count_type, dtype in props:
                if count_type is None:
                    values[name] = _ascii_value(next(tokens), dtype)
                else:
                    count = _ascii_value(next(tokens), count_type)
                    if not 0 <= count <= 64:
                        raise ValueError("PLY property list exceeds 64 values.")
                    values[name] = [_ascii_value(next(tokens), dtype) for _ in range(count)]
            if next(tokens, None) is not None:
                raise ValueError("Extra values in PLY record.")
        except StopIteration as error:
            raise ValueError("Truncated PLY record.") from error
    else:
        for name, count_type, dtype in props:
            if count_type is None:
                values[name] = np.frombuffer(_read_exact(stream, dtype.itemsize),
                                             dtype=dtype.newbyteorder(endian))[0]
            else:
                count = int(np.frombuffer(_read_exact(stream, count_type.itemsize),
                                         dtype=count_type.newbyteorder(endian))[0])
                if not 0 <= count <= 64:
                    raise ValueError("PLY property list exceeds 64 values.")
                values[name] = np.frombuffer(_read_exact(stream, count * dtype.itemsize),
                                             dtype=dtype.newbyteorder(endian)).tolist()
    return values


def read_ply_mesh(path, *, scale=1.0, flip_normals=False):
    """Read ASCII or either-endian binary triangle PLY, ignoring extra attributes.

    Face winding defines normals; supplied vertex normals/colors are not taught
    as geometry. Coordinates have caller-declared units. Polygons must first be
    triangulated upstream; no fan is invented for potentially concave faces.
    """
    if (isinstance(scale, bool) or not isinstance(scale, Real) or not np.isfinite(scale)
            or not 1e-9 <= scale <= 1e9):
        raise ValueError("Mesh scale must be finite and within [1e-9, 1e9].")
    if type(flip_normals) is not bool:
        raise ValueError("flip_normals must be boolean.")
    path = Path(path)
    if path.stat().st_size > MAX_MESH_BYTES:
        raise ValueError("PLY mesh exceeds 64 MiB.")
    vertices, faces = None, None
    with path.open("rb") as stream:
        fmt, elements = _header(stream)
        binary = fmt != "ascii"
        endian = ">" if fmt == "binary_big_endian" else "<"
        for name, count, props in elements:
            if name == "vertex":
                vertices = np.empty((count, 3), float)
                if binary:
                    dtype = np.dtype([(p[0], p[2].newbyteorder(endian)) for p in props])
                    raw = np.frombuffer(_read_exact(stream, count * dtype.itemsize), dtype)
                    vertices[:] = np.column_stack([raw[n] for n in ("x", "y", "z")])
                else:
                    for index in range(count):
                        row = _record(stream, props, binary=False, endian=endian)
                        vertices[index] = [row[n] for n in ("x", "y", "z")]
            else:
                faces = np.empty((count, 3), np.int64)
                index_name = next(p[0] for p in props
                                  if p[0] in ("vertex_index", "vertex_indices"))
                if binary and len(props) == 1:
                    _, count_type, index_type = props[0]
                    dtype = np.dtype([("count", count_type.newbyteorder(endian)),
                                      ("indices", index_type.newbyteorder(endian), (3,))])
                    raw = np.frombuffer(_read_exact(stream, count * dtype.itemsize), dtype)
                    if np.any(raw["count"] != 3):
                        raise ValueError(
                            "PLY faces must be triangles; triangulate polygons upstream."
                        )
                    faces[:] = raw["indices"]
                else:
                    for index in range(count):
                        indices = _record(stream, props, binary=binary, endian=endian)[index_name]
                        if len(indices) != 3:
                            raise ValueError("PLY faces must be triangles; triangulate upstream.")
                        faces[index] = indices
        while tail := stream.read(65536):
            if tail.strip():
                raise ValueError("Unexpected data after the PLY mesh.")
    if not np.isfinite(vertices).all() or np.any(faces < 0) or np.any(faces >= len(vertices)):
        raise ValueError("PLY mesh needs finite vertices and valid face indices.")
    triangles = vertices[faces] * scale
    if flip_normals:
        triangles = triangles[:, [0, 2, 1]]
    return TriangleMesh(triangles)


def read_mesh(path, *, scale=1.0, flip_normals=False):
    """Dispatch supported mesh formats without importing a GUI or new dependency."""
    reader = {".ply": read_ply_mesh, ".stl": read_stl}.get(Path(path).suffix.lower())
    if reader is None:
        raise ValueError("Select a triangle PLY or STL mesh.")
    return reader(path, scale=scale, flip_normals=flip_normals)
