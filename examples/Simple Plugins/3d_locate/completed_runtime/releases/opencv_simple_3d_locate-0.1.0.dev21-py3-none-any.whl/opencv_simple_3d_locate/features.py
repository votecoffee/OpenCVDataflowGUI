"""Bounded local angular descriptors and geometric-consistency RANSAC proposals.

This is an independent NumPy/OpenCV implementation, not a PCL/Open3D binding or
an interchangeable FPFH signature. All coordinates use the model diagonal as
unit length. Descriptors propose poses; normal, support, depth and overlap
verification remain the locator's responsibility.
"""

from dataclasses import dataclass

import cv2
import numpy as np


@dataclass(frozen=True)
class FeatureHypothesis:
    pose: np.ndarray
    error: float
    numVotes: int
    source: str = "features"


def _surface(value, limit):
    data = np.asarray(value)
    if (
        data.ndim != 2
        or data.shape[1] != 6
        or not 6 <= len(data) <= limit
        or not np.isfinite(data).all()
        or not np.allclose(np.linalg.norm(data[:, 3:], axis=1), 1, atol=1e-3)
    ):
        raise ValueError(f"Feature analysis requires 6..{limit} finite oriented surface points.")
    return np.ascontiguousarray(data, np.float32)


def descriptors(data, spacing):
    """Two radius-limited angular histograms with inverse-distance aggregation.

    Up to 64 neighbors per point, radii of 4 and 8 sampling cells, 11 soft bins
    per angular coordinate. Blocked accumulation bounds temporary arrays. Empty
    neighborhoods yield zero signatures, never NaNs. Normals must be consistently
    oriented; no sign-invariance or missing-surface invariance is claimed.
    """
    data = _surface(data, 100000)
    if isinstance(spacing, bool) or not np.isfinite(spacing) or not 0.01 <= spacing <= 0.2:
        raise ValueError("Feature spacing must be within [0.01,0.2] model diagonals.")
    index = cv2.flann_Index(data[:, :3].copy(), {"algorithm": 4})
    ids, squared = index.knnSearch(data[:, :3].copy(), min(65, len(data)), params={"checks": -1})
    distance = np.sqrt(np.maximum(squared, 0))
    output = []
    for radius in (spacing * 4, spacing * 8):
        local_histogram = np.zeros((len(data), 33), np.float32)
        for start in range(0, len(data), 256):
            stop = min(start + 256, len(data))
            neighbors = ids[start:stop]
            direction = data[neighbors, :3] - data[start:stop, None, :3]
            length = distance[start:stop]
            valid = (length > 1e-7) & (length <= radius)
            direction /= np.maximum(length[:, :, None], 1e-7)
            u = data[start:stop, None, 3:]
            v = np.cross(direction, u)
            norm = np.linalg.norm(v, axis=2)
            valid &= norm > 1e-6
            v /= np.maximum(norm[:, :, None], 1e-7)
            w = np.cross(u, v)
            target = data[neighbors, 3:]
            angles = (
                np.einsum("nki,nki->nk", v, target),
                np.einsum("nki,nki->nk", u, direction),
                np.arctan2(
                    np.einsum("nki,nki->nk", w, target),
                    np.einsum("nki,nki->nk", u, target),
                )
                / np.pi,
            )
            rows = np.broadcast_to(np.arange(start, stop)[:, None], neighbors.shape)
            for channel, values in enumerate(angles):
                # Theta is periodic: +pi and -pi must not create different
                # signatures after a rigid coordinate change near the wrap.
                bins = (
                    np.remainder((values + 1) * 5.5, 11)
                    if channel == 2
                    else np.clip((values + 1) * 5, 0, 10)
                )
                low = bins.astype(int)
                fraction = bins - low
                for columns, weights in (
                    (low, 1 - fraction),
                    ((low + 1) % 11 if channel == 2 else np.minimum(low + 1, 10), fraction),
                ):
                    np.add.at(
                        local_histogram,
                        (rows[valid], (channel * 11 + columns)[valid]),
                        weights[valid],
                    )
        local_histogram /= np.maximum(local_histogram.sum(axis=1, keepdims=True), 1)
        result = np.zeros_like(local_histogram)
        for start in range(0, len(data), 256):
            stop = min(start + 256, len(data))
            length = distance[start:stop]
            weights = ((length > 1e-7) & (length <= radius)) / np.maximum(length, 1e-7)
            weights /= np.maximum(weights.sum(axis=1, keepdims=True), 1e-10)
            result[start:stop] = local_histogram[start:stop] + np.einsum(
                "nk,nkf->nf", weights, local_histogram[ids[start:stop]]
            )
        result /= np.maximum(result.sum(axis=1, keepdims=True), 1e-10)
        output.append(np.sqrt(result))
    result = np.ascontiguousarray(np.concatenate(output, axis=1))
    result.flags.writeable = False
    return result


def _signature(value, count):
    data = np.asarray(value)
    if (
        data.shape != (count, 66)
        or not np.isfinite(data).all()
        or np.any(data < 0)
        or np.any(data > 1)
    ):
        raise ValueError("Supply finite nonnegative 66-value angular signatures per point.")
    return np.ascontiguousarray(data, np.float32)


def hypotheses(model, scene, model_features, scene_features, *, limit=128, trials=4096):
    """Deterministic guided RANSAC with bounded descriptor correspondences.

    At most 2048 correspondences, a 2048 squared boolean consistency graph,
    4096 triplets and 128 distinct proposals. A scene keypoint can match two
    model points, allowing repeated instances without requiring mutual matches.
    Rigid edge lengths, normal-pair angles, noncollinearity and rotated normals
    prune triplets. There is no scale fitting, pose seed, truth or symmetry input.
    """
    model, scene = _surface(model, 2000), _surface(scene, 20000)
    mf, sf = _signature(model_features, len(model)), _signature(scene_features, len(scene))
    if type(limit) is not int or not 1 <= limit <= 128:
        raise ValueError("Feature proposals require an integer limit in [1,128].")
    if type(trials) is not int or not 1 <= trials <= 4096:
        raise ValueError("Feature RANSAC requires an integer trial limit in [1,4096].")
    # A zero descriptor has no usable angular neighborhood.
    model_ids, scene_ids = np.flatnonzero(mf.any(axis=1)), np.flatnonzero(sf.any(axis=1))
    report = {
        "descriptor": "multiscale_angular_histogram_v1",
        "model_keypoints": len(model_ids),
        "scene_keypoints": len(scene_ids),
        "correspondences": 0,
        "trial_limit": trials,
        "valid_triplets": 0,
        "coarse_proposals": 0,
    }
    if len(model_ids) < 3 or len(scene_ids) < 3:
        return (), report
    index = cv2.flann_Index(mf[model_ids].copy(), {"algorithm": 4})
    ids, squared = index.knnSearch(sf[scene_ids].copy(), 2, params={"checks": -1})
    pairs = np.c_[model_ids[ids.ravel()], np.repeat(scene_ids, 2)]
    rank = np.argsort(squared.ravel(), kind="stable")[:2048]
    a, b = model[pairs[rank, 0]], scene[pairs[rank, 1]]
    count = len(rank)
    report["correspondences"] = count
    graph = np.zeros((count, count), bool)
    for start in range(0, count, 64):
        stop = min(start + 64, count)
        dm = np.linalg.norm(a[start:stop, None, :3] - a[None, :, :3], axis=2)
        ds = np.linalg.norm(b[start:stop, None, :3] - b[None, :, :3], axis=2)
        normal = abs(a[start:stop, 3:] @ a[:, 3:].T - b[start:stop, 3:] @ b[:, 3:].T)
        graph[start:stop] = (abs(dm - ds) < 0.04) & (dm > 0.1) & (ds > 0.1) & (normal < 0.2)
    rng, candidates = np.random.default_rng(0), []
    for _ in range(trials):
        one = rng.integers(count)
        linked = np.flatnonzero(graph[one])
        if not len(linked):
            continue
        two = rng.choice(linked)
        thirds = np.flatnonzero(graph[one] & graph[two])
        if not len(thirds):
            continue
        chosen = [one, two, rng.choice(thirds)]
        x, y = a[chosen, :3].astype(float), b[chosen, :3].astype(float)
        xc, yc = x.mean(axis=0), y.mean(axis=0)
        u, singular, vt = np.linalg.svd((x - xc).T @ (y - yc))
        if singular[1] < 1e-4:
            continue
        correction = np.eye(3)
        correction[2, 2] = np.linalg.det(vt.T @ u.T)
        rotation = vt.T @ correction @ u.T
        translation = yc - rotation @ xc
        if np.min(np.einsum("ni,ni->n", a[chosen, 3:] @ rotation.T, b[chosen, 3:])) < 0.8:
            continue
        report["valid_triplets"] += 1
        residual = np.linalg.norm(a[:, :3] @ rotation.T + translation - b[:, :3], axis=1)
        support = residual < 0.05
        votes = int(support.sum())
        if votes < 6:
            continue
        pose = np.eye(4)
        pose[:3, :3], pose[:3, 3] = rotation, translation
        pose.flags.writeable = False
        candidates.append(FeatureHypothesis(pose, float(np.mean(residual[support])), votes))
    candidates.sort(key=lambda candidate: (-candidate.numVotes, candidate.error))
    selected = []
    for candidate in candidates:
        if any(
            np.linalg.norm(candidate.pose[:3, 3] - prior.pose[:3, 3]) < 0.05
            and np.trace(candidate.pose[:3, :3] @ prior.pose[:3, :3].T) > 2.97
            for prior in selected
        ):
            continue
        selected.append(candidate)
        if len(selected) >= limit:
            break
    report["coarse_proposals"] = len(selected)
    return tuple(selected), report
