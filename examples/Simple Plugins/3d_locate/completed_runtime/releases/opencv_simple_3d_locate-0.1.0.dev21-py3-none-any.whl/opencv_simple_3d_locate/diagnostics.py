"""Offline supplied-pose evidence; diagnostic poses never become detections."""

from dataclasses import dataclass

import cv2
import numpy as np

from .model import cloud, normal_spread, prepared, rigid, transformed
from .observation import Observation, first_surface

MAX_DIAGNOSTIC_POINTS = 10000
MAX_TRIANGLE_RAY_PAIRS = 100_000_000
RAY_BATCH = 64
TRIANGLE_BATCH = 4096

PALETTE = {
    "supported": [45, 235, 100],
    "distance_rejected": [245, 65, 65],
    "normal_rejected": [255, 170, 35],
    "hidden": [90, 115, 175],
    "visibility_unresolved": [235, 50, 220],
}


@dataclass(frozen=True)
class TriangleVisibility:
    visible: np.ndarray
    resolved: np.ndarray
    nearest_fraction: np.ndarray
    triangle_ray_pairs: int


def triangle_visibility(mesh, samples, pose, *, viewpoint=(0, 0, 0)):
    """Test every triangle on each sample ray, in bounded temporary batches.

    Both triangle sides occlude; sample normals alone select front-facing
    samples. Ray t=1 is the supplied sample. Missing intersections are explicitly
    unresolved, never assumed visible. This diagnostic is not used by locate().
    """
    samples, pose = cloud(samples), rigid(pose)
    if samples.shape[1] != 6 or not 1 <= len(samples) <= MAX_DIAGNOSTIC_POINTS:
        raise ValueError("Triangle diagnostics require 1..10000 oriented samples.")
    pairs = len(samples) * len(mesh.triangles)
    if pairs > MAX_TRIANGLE_RAY_PAIRS:
        raise ValueError("Diagnostic triangle-ray work budget exceeded.")
    view = np.asarray(viewpoint, float)
    if view.shape != (3,) or not np.isfinite(view).all():
        raise ValueError("Diagnostic viewpoint requires finite XYZ coordinates.")
    # Intersect in model coordinates: avoid rounding transformed float32 samples.
    origin = (view - pose[:3, 3]) @ pose[:3, :3]
    directions = samples[:, :3].astype(float) - origin
    facing = np.einsum("ij,ij->i", samples[:, 3:], -directions) > 0
    nearest = np.full(len(samples), np.inf)
    extent = float(np.linalg.norm(np.ptp(mesh.triangles.reshape(-1, 3), axis=0)))
    # Normalize model coordinates for identical numerical behavior in mm and m.
    directions /= extent
    for start in range(0, len(samples), RAY_BATCH):
        stop = min(start + RAY_BATCH, len(samples))
        rays = directions[start:stop, None]
        result = np.full(stop - start, np.inf)
        for face in range(0, len(mesh.triangles), TRIANGLE_BATCH):
            tri = (mesh.triangles[face:face + TRIANGLE_BATCH] - origin) / extent
            a, b, c = tri.transpose(1, 0, 2)
            edge1, edge2 = b - a, c - a
            cross = np.cross(rays, edge2)
            determinant = np.einsum("ij,nij->ni", edge1, cross)
            usable = abs(determinant) > 1e-14
            inverse = np.divide(
                1.0, determinant, out=np.zeros_like(determinant), where=usable
            )
            u = np.einsum("ij,nij->ni", -a, cross) * inverse
            q = np.cross(-a, edge1)
            v = np.einsum("nij,ij->ni", rays, q) * inverse
            t = np.einsum("ij,ij->i", edge2, q) * inverse
            hit = usable & (u >= -1e-6) & (v >= -1e-6) & (u + v <= 1 + 1e-6) & (t > 0)
            result = np.minimum(result, np.min(np.where(hit, t, np.inf), axis=1))
        nearest[start:stop] = result
    resolved = np.isfinite(nearest)
    visible = facing & resolved & (nearest >= 1 - 1e-5)
    for value in (visible, resolved, nearest):
        value.flags.writeable = False
    return TriangleVisibility(visible, resolved, nearest, pairs)


@dataclass(frozen=True)
class PoseDiagnostic:
    report: dict
    scene: np.ndarray
    model: np.ndarray
    visible: np.ndarray
    supported: np.ndarray
    categories: np.ndarray
    colors: np.ndarray


def diagnose_pose(locator, points, pose, *, camera=None, variant="runtime_baseline"):
    """Explain a supplied pose without search, ICP, suppression or acceptance output.

    The fixed variants ablate one preparation step, retaining model settings,
    normalization, physical tolerances and geometry gates. The full-voxel variant
    can exceed the runtime model budget, so it is exclusively an offline control.
    """
    variants = (
        "runtime_baseline", "full_model_voxels", "dense_scene_normals",
        "six_normal_neighbors", "dense_scene", "triangle_visibility",
        "triangle_visibility_full_model",
    )
    if variant not in variants:
        raise ValueError(f"Unknown pose diagnostic variant: {variant}")
    recipe, settings = locator.recipe, locator.recipe.settings
    if settings.observation_mode != "surface" or recipe.cad is None:
        raise ValueError("Visibility diagnostics require a CAD recipe in surface mode.")
    pose = rigid(pose)
    if camera is not None:
        from .observation import Camera

        camera = Camera.from_record(camera)
        if camera.units != recipe.units:
            raise ValueError("Camera and model units must match for diagnostics.")
    raw = cloud(points)
    raw = raw[first_surface(
        raw, camera=camera, viewpoint=settings.scene_viewpoint,
        spacing=settings.sampling_distance * recipe.diameter,
    )]
    if len(raw) < 30:
        raise ValueError("Pose diagnostics require at least 30 first-surface points.")
    if variant in ("dense_scene_normals", "dense_scene") and len(raw) > 100000:
        raise ValueError("Dense diagnostics require at most 100000 first-surface points.")
    spacing = settings.sampling_distance * recipe.diameter
    neighbors = 6 if variant == "six_normal_neighbors" else settings.normal_neighbors
    if variant in ("dense_scene_normals", "dense_scene") and raw.shape[1] == 3:
        if len(raw) <= neighbors:
            raise ValueError("Dense normal diagnostics require more points than normal neighbors.")
        status, raw = cv2.ppf_match_3d.computeNormalsPC3d(
            raw, neighbors, True, settings.scene_viewpoint
        )
        if status not in (0, 1) or raw is None:
            raise ValueError("Diagnostic dense normal estimation failed.")
        raw = cloud(raw)
    if variant == "dense_scene":
        if not 30 <= len(raw) <= 100000:
            raise ValueError("Dense diagnostic requires 30..100000 first-surface points.")
        scene = raw.copy()
    else:
        scene = prepared(raw, spacing, neighbors, settings.scene_viewpoint, 100000)
    physical_scene = scene.copy()
    center = (scene[:, :3].min(0).astype(float) + scene[:, :3].max(0)) / 2
    scene[:, :3] = (scene[:, :3] - center) / recipe.diameter
    model = locator._model
    physical_model = recipe.samples
    if variant in ("full_model_voxels", "triangle_visibility_full_model"):
        diagonal = np.linalg.norm(np.ptp(recipe.reference[:, :3].astype(float), axis=0))
        physical_model = prepared(
            recipe.reference, settings.sampling_distance * diagonal,
            settings.normal_neighbors, settings.model_viewpoint, MAX_DIAGNOSTIC_POINTS,
        )
        model = physical_model.copy()
        model[:, :3] = (model[:, :3] - recipe.center) / recipe.diameter
    normalized_pose = pose.copy()
    normalized_pose[:3, 3] = (
        pose[:3, :3] @ recipe.center + pose[:3, 3] - center
    ) / recipe.diameter
    observation = Observation(
        center, recipe.diameter, settings.scene_viewpoint, spacing, camera
    )
    index = cv2.flann_Index(scene[:, :3].copy(), {"algorithm": 4})
    evidence = locator._evidence(
        scene, index, normalized_pose, model=model, observation=observation
    )
    aligned = evidence[5]
    ids, _ = index.knnSearch(aligned[:, :3].copy(), 1, params={"checks": -1})
    ids = ids[:, 0]
    dot = np.einsum("ij,ij->i", aligned[:, 3:], scene[ids, 3:])
    close = evidence[6] <= settings.distance_tolerance
    agreement = dot >= np.cos(np.deg2rad(settings.normal_angle))
    visible, resolved = evidence[7].copy(), np.ones(len(model), bool)
    visibility_report = {"method": "runtime_sampled_points", "triangle_ray_pairs": 0}
    if variant.startswith("triangle_visibility"):
        rays = triangle_visibility(
            recipe.cad.mesh, physical_model, pose,
            viewpoint=(0, 0, 0) if camera else settings.scene_viewpoint,
        )
        physical_aligned = transformed(physical_model, pose)
        if camera:
            from .depth import _pixels

            _, _, in_view = _pixels(physical_aligned[:, :3], camera)
        else:
            in_view = np.ones(len(model), bool)
        visible, resolved = rays.visible & in_view, rays.resolved
        visibility_report = {
            "method": "all_triangle_sample_rays", "triangle_ray_pairs": rays.triangle_ray_pairs,
            "unresolved_rays": int((~resolved).sum()),
            "sampled_false_visible": int((evidence[7] & ~visible & resolved).sum()),
            "sampled_false_hidden": int((~evidence[7] & visible).sum()),
        }
    supported = visible & close & agreement
    residual = np.einsum("ij,ij->i", aligned[:, :3] - scene[ids, :3], scene[ids, 3:])
    rmse = float(np.sqrt(np.mean(residual[supported] ** 2))) if supported.any() else None
    coverage = float(supported.sum() / visible.sum()) if visible.any() else 0.0
    spread = normal_spread(aligned[supported, 3:]) if supported.any() else 0.0
    unique = len(np.unique(ids[supported]))
    gates = {
        "coverage": {"value": coverage, "minimum": settings.min_coverage},
        "rmse": {"value": None if rmse is None else rmse * recipe.diameter,
                 "maximum": settings.max_rmse * recipe.diameter},
        "normal_spread": {"value": spread, "minimum": settings.min_normal_spread},
        "unique_support": {"value": unique, "minimum": settings.min_unique_support},
    }
    passes = (
        coverage >= settings.min_coverage and rmse is not None and rmse <= settings.max_rmse
        and spread >= settings.min_normal_spread and unique >= settings.min_unique_support
    )
    categories = np.full(len(model), "hidden", dtype="U24")
    categories[~resolved] = "visibility_unresolved"
    categories[visible & ~close] = "distance_rejected"
    categories[visible & close & ~agreement] = "normal_rejected"
    categories[supported] = "supported"
    colors = np.array([PALETTE[name] for name in categories], np.uint8)
    report = {
        "scope": "SUPPLIED_POSE_ONLY_NOT_A_DETECTION", "variant": variant,
        "search_executed": False, "units": recipe.units,
        "source_to_target": pose.tolist(), "gates_unchanged": True,
        "geometry_pass": bool(passes), "gates": gates,
        "model_points": len(model), "scene_points": len(scene),
        "visible_model_points": int(visible.sum()),
        "distance_only_coverage": float(close[visible].mean()) if visible.any() else None,
        "distance_tolerance": settings.distance_tolerance * recipe.diameter,
        "normal_angle_degrees": settings.normal_angle,
        "categories": {name: int((categories == name).sum()) for name in PALETTE},
        "visibility": visibility_report,
    }
    return PoseDiagnostic(
        report, physical_scene, transformed(physical_model, pose), visible,
        supported, categories, colors,
    )
