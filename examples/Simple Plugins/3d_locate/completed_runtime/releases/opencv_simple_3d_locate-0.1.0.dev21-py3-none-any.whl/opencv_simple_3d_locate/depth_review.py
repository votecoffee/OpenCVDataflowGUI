"""Explicit camera-ray review, independent of localization and GUI execution."""

from dataclasses import dataclass

import numpy as np

from .depth import DepthBuffer
from .model import rigid
from .projective import render_depth

RAY_STATES = ("outside", "consistent", "free_space", "occluded", "missing", "grazing")
RAY_COLORS = np.array(
    [[0, 0, 0], [45, 235, 100], [245, 65, 65], [255, 170, 35],
     [235, 50, 220], [90, 115, 175]], np.uint8,
)


@dataclass(frozen=True)
class DepthReview:
    camera: object
    pose: np.ndarray
    expected: np.ndarray
    measured: np.ndarray
    residual: np.ndarray
    states: np.ndarray
    stride: int
    report: dict

    def expected_points(self, states=RAY_STATES[1:], *, limit=20000):
        """Category-balanced display samples of expected geometry, not sensor returns."""
        if type(limit) is not int or not 1 <= limit <= 100000:
            raise ValueError("Use a display-point limit in 1..100000.")
        if any(name not in RAY_STATES[1:] for name in states):
            raise ValueError("Choose known camera-ray state names.")
        groups = [np.flatnonzero(self.states == RAY_STATES.index(name))
                  for name in dict.fromkeys(states)]
        groups = [g for g in groups if len(g)]
        budget = max(1, limit // max(1, len(groups)))
        ids = np.concatenate([g[np.linspace(0, len(g) - 1, min(budget, len(g)), dtype=int)]
                              for g in groups]) if groups else np.empty(0, int)
        ids = ids[:limit]
        y, x = np.unravel_index(ids, self.states.shape)
        z = self.expected[y, x]
        k = self.camera.matrix
        xyz = np.c_[(x * self.stride - k[0, 2]) * z / k[0, 0],
                    (y * self.stride - k[1, 2]) * z / k[1, 1], z]
        return np.ascontiguousarray(xyz, np.float32), RAY_COLORS[self.states[y, x]].copy()


def inspect_depth(mesh, pose, buffer, *, tolerance, minimum_coverage, minimum_rays):
    """Classify exact measured camera pixels against rendered first-surface CAD.

    No search, ICP, interpolation or nearest-pixel filling. This explicit review
    does not affect acceptance and is never called by the execution path.
    """
    if not isinstance(buffer, DepthBuffer):
        raise ValueError("Depth review requires a calibrated DepthBuffer.")
    if isinstance(tolerance, bool) or not np.isfinite(tolerance) or tolerance <= 0:
        raise ValueError("Use a positive finite physical distance tolerance.")
    if (isinstance(minimum_coverage, bool) or not np.isfinite(minimum_coverage)
            or not 0 <= minimum_coverage <= 1):
        raise ValueError("Minimum depth coverage must be in 0..1.")
    if type(minimum_rays) is not int or not 1 <= minimum_rays <= 2000:
        raise ValueError("Minimum known rays must be an integer in 1..2000.")
    pose = rigid(pose).copy()
    expected, factors, stride, reason = render_depth(mesh, pose, buffer.camera)
    y, x = np.nonzero(np.isfinite(expected))
    k = buffer.camera.matrix
    directions = np.c_[(x * stride - k[0, 2]) / k[0, 0],
                       (y * stride - k[1, 2]) / k[1, 1], np.ones(len(x))]
    incidence = factors[y, x] / np.linalg.norm(directions, axis=1)
    eligible = incidence >= 0.1
    measured = np.full(expected.shape, np.nan)
    residual = np.full(expected.shape, np.nan)
    states = np.zeros(expected.shape, np.uint8)
    actual = buffer.sample_pixels(x * stride, y * stride)
    measured[y, x] = actual
    states[y[~eligible], x[~eligible]] = RAY_STATES.index("grazing")
    y, x = y[eligible], x[eligible]
    actual = actual[eligible]
    known = np.isfinite(actual)
    values = (actual[known] - expected[y[known], x[known]]) * factors[y[known], x[known]]
    residual[y[known], x[known]] = values
    states[y, x] = RAY_STATES.index("missing")
    labels = np.full(int(known.sum()), RAY_STATES.index("consistent"), np.uint8)
    labels[values > tolerance] = RAY_STATES.index("free_space")
    labels[values < -tolerance] = RAY_STATES.index("occluded")
    states[y[known], x[known]] = labels
    coverage = float(known.mean()) if len(known) else 0.0
    checked = reason is None and known.sum() >= minimum_rays and coverage >= minimum_coverage
    report = {
        "scope": "POSE_REVIEW_ONLY_NOT_AN_ACCEPTANCE_DECISION",
        "status": "unavailable" if reason is not None else
                  "checked" if checked else "insufficient_depth",
        "reason": reason if reason else "no_eligible_surface" if not len(x) else None,
        "units": buffer.camera.units, "frame": buffer.camera.frame,
        "source_to_target": pose.tolist(), "render_stride": stride,
        "rendered_rays": int(len(x)), "known_rays": int(known.sum()),
        "depth_coverage": coverage, "minimum_depth_coverage": minimum_coverage,
        "minimum_known_rays": minimum_rays, "distance_tolerance": tolerance,
        "counts": {name: int((states == index).sum())
                   for index, name in enumerate(RAY_STATES) if index},
        "score": float(np.mean(np.exp(-0.5 * (values / tolerance) ** 2))) if checked else None,
        "score_type": "projective_depth_fit_not_probability",
        "residual_percentiles": {
            str(p): float(np.percentile(values, p)) for p in (5, 25, 50, 75, 95)
        } if len(values) else None,
    }
    for value in (pose, expected, measured, residual, states):
        value.flags.writeable = False
    return DepthReview(buffer.camera, pose, expected, measured, residual, states, stride, report)
