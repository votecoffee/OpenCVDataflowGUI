"""Bounded measured-surface continuation tests around a rendered mesh silhouette."""

from dataclasses import dataclass
from numbers import Real

import numpy as np

from .depth import DepthBuffer
from .model import rigid
from .projective import render_depth

MAX_BOUNDARY_PAIRS = 8192
BOUNDARY_STATES = ("unknown", "continued", "discontinuous")
BOUNDARY_COLORS = np.array([[235, 50, 220], [255, 170, 35], [45, 235, 100]], np.uint8)


@dataclass(frozen=True)
class BoundaryEvidence:
    camera: object
    pose: np.ndarray
    inside_pixels: np.ndarray
    outside_pixels: np.ndarray
    expected_depth: np.ndarray
    measured_depth: np.ndarray
    residual: np.ndarray
    states: np.ndarray
    report: dict

    def display_points(self, states=BOUNDARY_STATES):
        """Expected inner rays and actual outer returns; never invent sensor depth."""
        if any(name not in BOUNDARY_STATES for name in states):
            raise ValueError("Choose known boundary evidence states.")
        selected = np.isin(self.states, [BOUNDARY_STATES.index(name) for name in states])
        outer = selected & np.isfinite(self.measured_depth)
        pixels = np.r_[self.inside_pixels[selected], self.outside_pixels[outer]]
        depth = np.r_[self.expected_depth[selected], self.measured_depth[outer]]
        k = self.camera.matrix
        xyz = np.c_[(pixels[:, 0] - k[0, 2]) * depth / k[0, 0],
                    (pixels[:, 1] - k[1, 2]) * depth / k[1, 1], depth]
        colors = BOUNDARY_COLORS[np.r_[self.states[selected], self.states[outer]]]
        return np.ascontiguousarray(xyz, np.float32), colors.copy()


def _pairs(mask):
    """Genuine in-view silhouette edges; probes beyond the camera remain unknown."""
    y, x = np.nonzero(mask)
    height, width = mask.shape
    groups = []
    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        u, v = x + dx, y + dy
        ids = np.flatnonzero((u >= 0) & (u < width) & (v >= 0) & (v < height))
        ids = ids[~mask[v[ids], u[ids]]]
        groups.append((ids, dx, dy))
    total = sum(len(ids) for ids, _, _ in groups)
    selected = np.linspace(0, total - 1, min(total, MAX_BOUNDARY_PAIRS), dtype=int)
    pixels, directions, offset = [], [], 0
    for ids, dx, dy in groups:
        local = selected[(selected >= offset) & (selected < offset + len(ids))] - offset
        chosen = ids[local]
        pixels.append(np.c_[x[chosen], y[chosen]])
        directions.append(np.tile([dx, dy], (len(chosen), 1)))
        offset += len(ids)
    return np.concatenate(pixels), np.concatenate(directions), total


def inspect_boundary(mesh, pose, buffer, *, spacing, tolerance, minimum_support, minimum_rays):
    """Test continuation of *measured* local planes outside the mesh silhouette.

    Three inside returns define a plane; an outer return on that plane is
    evidence that the measured surface extends beyond the predicted outline.
    Unknown pairs optimistically count as possible distinctive support. Thus
    rejection requires enough actual continuation evidence, never missing data.
    This is an experimental geometric test, not a correctness probability.
    """
    if not isinstance(buffer, DepthBuffer):
        raise ValueError("Boundary inspection requires a calibrated DepthBuffer.")
    for name, value in (("spacing", spacing), ("tolerance", tolerance)):
        if isinstance(value, bool) or not isinstance(value, Real) or not np.isfinite(value) \
                or value <= 0:
            raise ValueError(f"Boundary {name} must be positive and finite.")
    if (isinstance(minimum_support, bool) or not isinstance(minimum_support, Real)
            or not np.isfinite(minimum_support) or not 0 <= minimum_support <= 1):
        raise ValueError("Minimum boundary support must be in 0..1.")
    if type(minimum_rays) is not int or not 1 <= minimum_rays <= 2000:
        raise ValueError("Minimum boundary rays must be an integer in 1..2000.")
    pose = rigid(pose).copy()
    rendered, _, stride, reason = render_depth(mesh, pose, buffer.camera)
    mask = np.isfinite(rendered)
    inside, direction, total = _pairs(mask)
    height, width = mask.shape
    camera, k = buffer.camera, buffer.camera.matrix
    # Leave one sampling cell plus the two endpoint distance uncertainties.
    probe_distance = spacing + 2 * tolerance
    if not np.isfinite(probe_distance):
        raise ValueError("Boundary probe distance exceeds numeric range.")
    with np.errstate(over="ignore", invalid="ignore"):
        projected = (min(k[0, 0], k[1, 1]) * probe_distance
                     / max(float(np.median(rendered[mask])) if mask.any() else 1, 1e-12)
                     / stride)
    step = (max(width, height) + 1 if not np.isfinite(projected) else
            min(max(width, height) + 1, max(1, int(np.ceil(projected)))))
    outside, back = inside + direction * step, inside - direction * step
    perpendicular = np.c_[-direction[:, 1], direction[:, 0]] * step
    side = inside + perpendicular

    def in_mask(pixels):
        x, y = pixels.T
        bounds = (x >= 0) & (x < width) & (y >= 0) & (y < height)
        result = np.zeros(len(x), bool)
        result[bounds] = mask[y[bounds], x[bounds]]
        return result

    alternate = inside - perpendicular
    side = np.where(in_mask(side)[:, None], side, alternate)
    interior = in_mask(back) & in_mask(side)
    pixels = [p * stride for p in (inside, outside, back, side)]
    depths = [buffer.sample_pixels(p[:, 0], p[:, 1]) for p in pixels]

    def rays(p):
        return np.c_[(p[:, 0] - k[0, 2]) / k[0, 0],
                     (p[:, 1] - k[1, 2]) / k[1, 1], np.ones(len(p))]

    ri, ro, rb, rs = [rays(p) for p in pixels]
    zi, zo, zb, zs = depths
    # Normalize before the cross product to keep meter/mm decisions equivalent.
    scale = max(spacing, tolerance)
    with np.errstate(invalid="ignore", divide="ignore", over="ignore"):
        p0 = ri * (zi / scale)[:, None]
        normal = np.cross(rb * (zb / scale)[:, None] - p0,
                          rs * (zs / scale)[:, None] - p0)
        lengths = np.linalg.norm(normal, axis=1)
        normal /= np.maximum(lengths, 1e-12)[:, None]
        fi, fo = [np.einsum("ij,ij->i", normal, r) for r in (ri, ro)]
        z = rendered[inside[:, 1], inside[:, 0]]
        observable = (interior & np.isfinite(zi) & np.isfinite(zo) & np.isfinite(zb)
                      & np.isfinite(zs) & (lengths > 1e-12)
                      & (abs(fi) / np.linalg.norm(ri, axis=1) >= .1)
                      & (abs(fo) / np.linalg.norm(ro, axis=1) >= .1)
                      & (abs((zi - z) * fi) <= tolerance))
        predicted = np.divide(zi * fi, fo, out=np.full(len(zi), np.nan), where=abs(fo) > 0)
        observable &= np.isfinite(predicted) & (predicted > 0)
        residual = np.full(len(zi), np.nan)
        residual[observable] = (zo[observable] - predicted[observable]) * fo[observable]
    states = np.zeros(len(zi), np.uint8)
    states[observable] = np.where(abs(residual[observable]) <= tolerance, 1, 2)
    continued = int((states == 1).sum())
    unique = len(np.unique(pixels[1][observable], axis=0))
    upper = float(1 - continued / len(states)) if len(states) else None
    checked = reason is None and unique >= minimum_rays
    report = {
        "model": "measured_boundary_continuation_v1",
        "status": "unavailable" if reason else "checked" if checked else "insufficient_depth",
        "reason": reason or ("no_silhouette" if not len(states) else None),
        "render_stride": stride, "probe_step_pixels": step * stride,
        "probe_distance": probe_distance, "distance_tolerance": tolerance,
        "total_boundary_pairs": total, "sampled_boundary_pairs": len(states),
        "pair_budget": MAX_BOUNDARY_PAIRS, "unique_known_outer_rays": unique,
        "minimum_known_rays": minimum_rays,
        "counts": {name: int((states == index).sum())
                   for index, name in enumerate(BOUNDARY_STATES)},
        "distinct_support_upper_bound": upper, "minimum_support": minimum_support,
        "limit_exceeded": bool(checked and upper < minimum_support),
        "scope": "sampled_mesh_silhouette_not_a_pose_probability",
    }
    for value in (pose, *pixels[:2], z, zo, residual, states):
        value.flags.writeable = False
    return BoundaryEvidence(camera, pose, pixels[0], pixels[1], z, zo, residual, states, report)
