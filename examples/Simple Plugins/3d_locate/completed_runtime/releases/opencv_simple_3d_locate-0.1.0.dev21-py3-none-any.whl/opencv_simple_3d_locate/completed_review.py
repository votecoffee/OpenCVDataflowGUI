"""Exact completed-cloud evidence; rendering never repeats localization or verification."""

import copy
import hashlib
import json
from dataclasses import dataclass, field, is_dataclass
from numbers import Integral
from pathlib import Path

import cv2
import numpy as np
from opencv_dataflow.pointclouds import PointCloud

from .graphics import fit_cloud, overlay

BINDING = "locate_3d_completed_review"
LAYERS = ("supported", "missing", "hidden", "free_space")


def _json(value):
    return json.dumps(value, sort_keys=True, allow_nan=False).encode("utf-8")


def _readonly(array):
    array = np.asarray(array)
    return np.frombuffer(array.tobytes(), dtype=array.dtype).reshape(array.shape)


def _freeze(value):
    if isinstance(value, np.ndarray):
        return _readonly(value)
    if is_dataclass(value):
        # Copy stored/derived members without constructors that could resample CAD,
        # estimate normals, validate a new recipe or otherwise recompute evidence.
        target = object.__new__(type(value))
        for name, item in vars(value).items():
            object.__setattr__(target, name, _freeze(item))
        return target
    if isinstance(value, dict):
        return {key: _freeze(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return type(value)(_freeze(item) for item in value)
    return copy.deepcopy(value)


def _public_cloud(value):
    return PointCloud(
        value.points,
        value.units,
        value.frame,
        colors=value.colors,
        normals=value.normals,
        pixels=value.pixels,
        source_size=value.source_size,
        metadata=copy.deepcopy(value.metadata),
    )


def describe_cloud(value):
    return dict(
        units=value.units,
        frame=value.frame,
        source_size=value.source_size,
        metadata=copy.deepcopy(value.metadata),
        arrays={
            name: dict(
                shape=list(array.shape),
                dtype=array.dtype.str,
                sha256=hashlib.sha256(array.tobytes()).hexdigest(),
            )
            for name in ("points", "normals", "colors", "pixels")
            if (array := getattr(value, name)) is not None
        },
    )


@dataclass(frozen=True)
class CompletedLocationRecord:
    identifier: str
    report_json: bytes
    poses_json: bytes
    parameters_json: bytes
    _recipe: object = field(repr=False, compare=False)
    _result: object = field(repr=False, compare=False)
    _fit: PointCloud = field(repr=False, compare=False)

    @classmethod
    def create(cls, identifier, recipe, result, report, poses, parameters, fit):
        return cls(identifier, _json(report), _json(poses), _json(parameters), recipe, result, fit)

    @property
    def report(self):
        return json.loads(self.report_json)

    @property
    def parameters(self):
        return json.loads(self.parameters_json)

    def __deepcopy__(self, memo):
        return self


@dataclass(frozen=True)
class CompletedLocationCapture:
    record: CompletedLocationRecord
    _recipe: object = field(repr=False, compare=False)
    _result: object = field(repr=False, compare=False)
    _clouds: dict = field(repr=False, compare=False)
    _data: dict = field(repr=False, compare=False)
    _fit: PointCloud = field(repr=False, compare=False)
    _provenance: dict = field(repr=False, compare=False)

    @property
    def provenance(self):
        return copy.deepcopy(self._provenance)

    @property
    def input_cloud_names(self):
        return tuple(self._clouds)

    @property
    def recipe_bytes(self):
        return getattr(self._recipe, "_source_bytes", None)

    def input_cloud(self, name="scene"):
        return _public_cloud(self._clouds[name])

    def selection(self, kind="all", index=None):
        report = self.record.report
        if kind == "all":
            if index is not None:
                raise ValueError("Overview has no selected index")
            return dict(kind=kind, index=None, status=report["assessment"]["status"])
        if kind not in ("accepted", "rejected"):
            raise ValueError("Select accepted, rejected or all evidence")
        rows = (
            report["matches"]
            if kind == "accepted"
            else report["execution"].get("candidate_review", [])
        )
        if isinstance(index, bool) or not isinstance(index, Integral) or not 0 <= index < len(rows):
            raise ValueError("Select a valid zero-based candidate index")
        return dict(
            kind=kind,
            index=int(index),
            evidence=rows[index],
            status="accepted" if kind == "accepted" else "rejected_not_a_detection",
        )

    def options(
        self, kind="all", index=None, *, scene=True, axes=True, alternatives=False, layers=LAYERS
    ):
        self.selection(kind, index)
        if any(type(value) is not bool for value in (scene, axes, alternatives)):
            raise ValueError("Display switches must be boolean")
        if isinstance(layers, str) or any(name not in LAYERS for name in layers):
            raise ValueError("Choose known fit layers")
        return dict(
            match_index=index if kind == "accepted" else None,
            rejected_index=index if kind == "rejected" else None,
            scene=scene,
            axes=axes,
            alternatives=alternatives,
            layers=tuple(layers),
        )

    def display_cloud(self, kind="all", index=None, **display):
        options = self.options(kind, index, **display)
        if (
            kind == "all"
            and all(options[n] for n in ("scene", "axes"))
            and (not options["alternatives"] and options["layers"] == LAYERS)
        ):
            return _public_cloud(self._fit)
        return fit_cloud(self._recipe, self._result, **options)

    def assessment(self, kind="all", index=None, *, yaw=25, pitch=-20, **display):
        return overlay(
            self._recipe, self._result, yaw=yaw, pitch=pitch, **self.options(kind, index, **display)
        )

    def report(self, kind="all", index=None, **display):
        options = self.options(kind, index, **display)
        return dict(
            model="simple_3d_locate_completed_review_v1",
            execution_binding=self.record.identifier,
            completed_result=self.record.report,
            executed_parameters=self.record.parameters,
            selected=self.selection(kind, index),
            display=options,
            input_clouds={name: describe_cloud(value) for name, value in self._clouds.items()},
            input_data=copy.deepcopy(self._data),
            default_fit=describe_cloud(self._fit),
            provenance=self.provenance,
            score_semantics="Geometric/projective fit is not a calibrated probability",
            geometry_semantics=(
                "Gray = sampled measured scene; green/red/blue-gray/magenta = "
                "expected model support/missing/self-hidden/free-space; RGB = model pose axes"
            ),
            rejected_semantics=(
                "Orange rejected/alternative model geometry is not a detection or sensor return"
            ),
            ray_map_availability=(
                "Per-ray depth/boundary maps were not retained; review does not reconstruct them"
            ),
            identity_scope=(
                "Software pairing and declared capture IDs do not prove physical synchronization"
            ),
            inference_reexecuted=False,
            verification_reexecuted=False,
            recipe_reloaded=False,
            training_changed=False,
        )

    def export(
        self, directory, kind="all", index=None, *, yaw=25, pitch=-20, input_view=None, **display
    ):
        from opencv_dataflow.cloud_io import write_cloud

        document = self.report(kind, index, **display)
        if input_view is not None and input_view not in self._clouds:
            raise ValueError("Choose a retained input cloud")
        target = Path(directory)
        target.mkdir(parents=True, exist_ok=False)
        if self.recipe_bytes is not None:
            (target / "executed_recipe.s3l").write_bytes(self.recipe_bytes)
            document["exported_recipe_sha256"] = hashlib.sha256(self.recipe_bytes).hexdigest()
        else:
            document["exported_recipe_sha256"] = None
        for name, value in {**self._clouds, "default_fit": self._fit}.items():
            for member in ("points", "normals", "colors", "pixels"):
                array = getattr(value, member)
                if array is not None:
                    np.save(target / f"{name}_{member}.npy", array, allow_pickle=False)
            write_cloud(target / f"{name}.ply", value, binary=True)
        np.save(target / "sampled_scene.npy", self._result.scene, allow_pickle=False)
        for i, match in enumerate(self._result.matches):
            for name in (
                "pose",
                "inlier_model",
                "scene_indices",
                "visible_model",
                "free_space_model",
            ):
                array = getattr(match, name)
                if array is not None:
                    np.save(target / f"accepted_{i}_{name}.npy", array, allow_pickle=False)
        cloud = (
            self.display_cloud(kind, index, **display)
            if input_view is None
            else self.input_cloud(input_view)
        )
        write_cloud(target / "selected_display.ply", cloud, binary=True)
        if input_view is None:
            image = self.assessment(kind, index, yaw=yaw, pitch=pitch, **display)
        else:
            from opencv_dataflow.pointclouds import render_cloud

            image = render_cloud(cloud, width=960, height=640, yaw=yaw, pitch=pitch)
        document["displayed_input_cloud"] = input_view
        ok, png = cv2.imencode(".png", image)
        if not ok:
            raise ValueError("Could not encode completed 3D assessment")
        (target / "assessment.png").write_bytes(png.tobytes())
        document["assessment_projection"] = dict(
            yaw=yaw, pitch=pitch, scope="Display projection only"
        )
        document["ply_scope"] = (
            "PLY keeps XYZ/RGB/normals/units/frame; "
            "native NPY and JSON retain pixel mappings/metadata"
        )
        (target / "review.json").write_text(
            json.dumps(document, indent=2, allow_nan=False) + "\n", encoding="utf-8"
        )
        return target


def capture_completed(record, bundle):
    if record is None:
        raise ValueError("No retained completed localization; execute in Debug before reviewing")
    if any(
        bundle.outputs[name].payload.get(BINDING, {}).get("id") != record.identifier
        for name in ("report", "poses", "count", "fit")
    ):
        raise ValueError("Completed model/result evidence changed; capture the latest run again")
    if (
        _json(bundle.outputs["report"].value) != record.report_json
        or _json(bundle.outputs["poses"].value) != record.poses_json
        or bundle.outputs["count"].value != len(record._result.matches)
    ):
        raise ValueError("Completed report/poses changed; capture the latest run again")
    source = bundle.inputs["scene"].value
    fit = bundle.outputs["fit"].value
    if (
        not isinstance(fit, PointCloud)
        or fit.units != record._fit.units
        or fit.frame != record._fit.frame
    ):
        raise ValueError("Completed fit cloud frame/units changed")
    for name in ("points", "colors", "normals", "pixels"):
        actual, expected = getattr(fit, name), getattr(record._fit, name)
        if (actual is None) != (expected is None) or (
            actual is not None and not np.array_equal(actual, expected)
        ):
            raise ValueError("Completed fit cloud evidence changed")
    if source.units != record._result.units or source.frame != record._result.target_frame:
        raise ValueError("Completed source frame/units disagree with its result")
    return CompletedLocationCapture(
        record,
        _freeze(record._recipe),
        _freeze(record._result),
        {
            name: _freeze(packet.value)
            for name, packet in bundle.inputs.items()
            if isinstance(packet.value, PointCloud)
        },
        {
            name: copy.deepcopy(packet.value)
            for name, packet in bundle.inputs.items()
            if not isinstance(packet.value, PointCloud)
        },
        _freeze(bundle.outputs["fit"].value),
        dict(
            snapshot_id=bundle.snapshot_id,
            block_id=bundle.block_id,
            output_revision=bundle.output_revision,
            execution_count=bundle.execution_count,
            passed=bool(bundle.passed),
            score=bundle.score,
            message=bundle.message,
            inputs={name: copy.deepcopy(packet.payload) for name, packet in bundle.inputs.items()},
            outputs={
                name: copy.deepcopy(packet.payload) for name, packet in bundle.outputs.items()
            },
        ),
    )
