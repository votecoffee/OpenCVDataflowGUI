"""Bounded STL import and reproducible, area-weighted CAD surface sampling."""

from dataclasses import dataclass, replace
from numbers import Real
from pathlib import Path

import numpy as np

MAX_TRIANGLES = 200_000
_RECORD = np.dtype([("normal", "<f4", 3), ("vertices", "<f4", (3, 3)), ("attribute", "<u2")])


@dataclass(frozen=True)
class TriangleMesh:
    triangles: np.ndarray

    def __post_init__(self):
        data = np.array(self.triangles, dtype=np.float64, copy=True, order="C")
        if (
            data.ndim != 3
            or data.shape[1:] != (3, 3)
            or not 1 <= len(data) <= MAX_TRIANGLES
            or not np.isfinite(data).all()
        ):
            raise ValueError(f"Mesh requires 1..{MAX_TRIANGLES} finite XYZ triangles.")
        diameter = float(np.linalg.norm(np.ptp(data.reshape(-1, 3), axis=0)))
        if not np.isfinite(diameter) or diameter <= 1e-12:
            raise ValueError("Mesh has no usable spatial extent.")
        cross = np.cross((data[:, 1] - data[:, 0]) / diameter, (data[:, 2] - data[:, 0]) / diameter)
        lengths = np.linalg.norm(cross, axis=1)
        keep = lengths > np.finfo(float).eps * 16
        if not keep.any():
            raise ValueError("Mesh has no nondegenerate triangles.")
        data, cross, lengths = data[keep], cross[keep], lengths[keep]
        normals = cross / lengths[:, None]
        areas = lengths * (diameter * diameter / 2)
        if not np.isfinite(areas).all() or not np.isfinite(areas.sum()):
            raise ValueError("Mesh surface area exceeds numeric range.")
        for value in (data, normals, areas):
            value.flags.writeable = False
        object.__setattr__(self, "triangles", data)
        object.__setattr__(self, "normals", normals)
        object.__setattr__(self, "areas", areas)
        object.__setattr__(self, "discarded_triangles", int((~keep).sum()))

    def sample(self, count=6000, seed=0):
        _sampling(count, seed)
        rng = np.random.default_rng(seed)
        faces = rng.choice(len(self.triangles), count, p=self.areas / self.areas.sum())
        triangles = self.triangles[faces]
        uv = rng.random((count, 2))
        root = np.sqrt(uv[:, 0])
        weights = np.c_[1 - root, root * (1 - uv[:, 1]), root * uv[:, 1]]
        points = np.einsum("ni,nij->nj", weights, triangles)
        result = np.ascontiguousarray(np.c_[points, self.normals[faces]], np.float32)
        if not np.isfinite(result).all():
            raise ValueError(
                "Mesh samples exceed float32 cloud coordinates. Rescale the CAD model."
            )
        return result

    @property
    def health(self):
        return {
            "triangles": len(self.triangles),
            "surface_area": float(self.areas.sum()),
            "discarded_triangles": self.discarded_triangles,
        }


def _sampling(count, seed):
    if type(count) is not int or not 30 <= count <= 200_000:
        raise ValueError("CAD surface sample count must be an integer in [30, 200000].")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("CAD sampling seed must be an unsigned 32-bit integer.")


@dataclass(frozen=True)
class CADReference:
    mesh: TriangleMesh
    count: int = 6000
    seed: int = 0

    def __post_init__(self):
        if not isinstance(self.mesh, TriangleMesh):
            raise ValueError("CAD reference requires a TriangleMesh.")
        _sampling(self.count, self.seed)

    def sample(self):
        return self.mesh.sample(self.count, self.seed)


def _ascii_triangles(path):
    """Read the single-solid ASCII grammar without an unbounded token list."""
    triangles = np.empty((MAX_TRIANGLES, 3, 3), np.float64)
    count = 0
    with path.open("r", encoding="ascii", newline="") as stream:

        def line():
            while True:
                value = stream.readline(4097)
                if not value:
                    return []
                if len(value) > 4096:
                    raise ValueError("STL text line exceeds 4096 characters.")
                parts = value.lower().split()
                if parts:
                    return parts

        if (line() or [""])[0] != "solid":
            raise ValueError("ASCII STL must start with solid.")
        while True:
            parts = line()
            if parts and parts[0] == "endsolid":
                if line():
                    raise ValueError("Unexpected data after the STL solid.")
                break
            if len(parts) != 5 or parts[:2] != ["facet", "normal"]:
                raise ValueError("Expected STL facet normal or endsolid.")
            if not np.isfinite([float(value) for value in parts[2:]]).all():
                raise ValueError("STL facet normal must be finite.")
            if count == MAX_TRIANGLES:
                raise ValueError("STL triangle budget exceeded.")
            if line() != ["outer", "loop"]:
                raise ValueError("Expected STL outer loop.")
            for corner in range(3):
                vertex = line()
                if len(vertex) != 4 or vertex[0] != "vertex":
                    raise ValueError("Expected exactly three STL vertices per facet.")
                triangles[count, corner] = [float(value) for value in vertex[1:]]
            if line() != ["endloop"] or line() != ["endfacet"]:
                raise ValueError("Expected STL endloop and endfacet.")
            count += 1
    return triangles[:count]


def read_stl(path, *, scale=1.0, flip_normals=False):
    """Read little-endian binary or ASCII STL. Units are declared by the caller."""
    if (
        isinstance(scale, bool)
        or not isinstance(scale, Real)
        or not np.isfinite(scale)
        or not 1e-9 <= scale <= 1e9
    ):
        raise ValueError("CAD coordinate scale must be finite and within [1e-9, 1e9].")
    if type(flip_normals) is not bool:
        raise ValueError("flip_normals must be boolean.")
    path = Path(path)
    size = path.stat().st_size
    if size > 64 * 1024 * 1024:
        raise ValueError("STL exceeds the 64 MiB input budget.")
    with path.open("rb") as stream:
        header = stream.read(84)
        count = int.from_bytes(header[80:84], "little") if len(header) == 84 else 0
        if len(header) == 84 and size == 84 + count * 50:
            if not 1 <= count <= MAX_TRIANGLES:
                raise ValueError("STL triangle count exceeds the supported budget.")
            raw = stream.read()
            triangles = np.frombuffer(raw, _RECORD, count=count)["vertices"].astype(np.float64)
        else:
            if not header.lstrip().lower().startswith(b"solid"):
                raise ValueError("Binary STL triangle count and file size disagree.")
            try:
                triangles = _ascii_triangles(path)
            except UnicodeError as error:
                raise ValueError("Invalid STL text or truncated binary STL.") from error
    triangles = triangles * scale
    if flip_normals:
        triangles = triangles[:, [0, 2, 1]]
    return TriangleMesh(triangles)


def train_cad(mesh, *, units, frame="model", count=6000, seed=0, settings=None):
    from .model import Settings, train

    cad = CADReference(mesh, count, seed)
    recipe = train(
        cad.sample(),
        units=units,
        frame=frame,
        settings=Settings() if settings is None else settings,
    )
    return replace(recipe, cad=cad)
