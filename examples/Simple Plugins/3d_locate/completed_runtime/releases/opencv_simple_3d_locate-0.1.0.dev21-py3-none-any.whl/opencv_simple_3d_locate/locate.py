"""Global PPF hypotheses, local ICP refinement, and geometric verification."""

import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass

import cv2
import numpy as np

from .alternatives import describe as describe_alternatives
from .boundary import inspect_boundary
from .depth import DepthBuffer, DepthScene
from .features import descriptors
from .features import hypotheses as feature_hypotheses
from .geometry import analyze, search_indices, voxel_level
from .model import (
    Recipe,
    _identity,
    cloud,
    normal_spread,
    prepared,
    rigid,
    surface_module,
    transformed,
)
from .observation import Camera, Observation, first_surface
from .overlap import suppress
from .planes import Hypothesis, hypotheses, patches
from .projective import score as projective_score
from .regions import find_regions
from .review import assessment


@dataclass(frozen=True)
class Match:
    pose: np.ndarray
    coverage: float
    rmse: float
    normal_spread: float
    votes: int
    inlier_model: np.ndarray
    scene_indices: np.ndarray
    refined: bool
    score: float = 0.0
    visible_model: np.ndarray | None = None
    candidate_source: str = "ppf"
    depth_verification: dict | None = None
    free_space_model: np.ndarray | None = None
    pose_alternatives: dict | None = None
    projective_scoring: dict | None = None
    boundary_verification: dict | None = None

    def report(self):
        report = {
            "source_to_target": self.pose.tolist(),
            "coverage": self.coverage,
            "score": self.score,
            "score_type": "geometric_fit_not_probability"
            if self.projective_scoring is None
            else "projective_depth_fit_not_probability",
            "projective_scoring": self.projective_scoring,
            "rmse": self.rmse,
            "normal_spread": self.normal_spread,
            "votes": self.votes,
            "model_inliers": int(self.inlier_model.sum()),
            "unique_scene_inliers": len(self.scene_indices),
            "refined": self.refined,
            "candidate_source": self.candidate_source,
            "pose_alternatives": self.pose_alternatives,
            "depth_verification": self.depth_verification,
            "visible_model_points": len(self.inlier_model)
            if self.visible_model is None
            else int(self.visible_model.sum()),
        }
        if self.boundary_verification is not None:
            report["boundary_verification"] = self.boundary_verification
        return report


@dataclass(frozen=True)
class LocationResult:
    matches: tuple
    scene: np.ndarray
    units: str
    source_frame: str
    target_frame: str
    candidate_count: int
    tested_candidates: int
    search_model_points: int = 0
    search_scene_points: int = 0
    execution: dict | None = None

    @property
    def passed(self):
        return bool(self.matches)

    def report(self):
        return {
            "model": "simple_3d_locate_v1",
            "units": self.units,
            "source_frame": self.source_frame,
            "target_frame": self.target_frame,
            "matches": [match.report() for match in self.matches],
            "candidate_count": self.candidate_count,
            "tested_candidates": self.tested_candidates,
            "sampled_scene_points": len(self.scene),
            "search_model_points": self.search_model_points,
            "search_scene_points": self.search_scene_points,
            "passed": self.passed,
            "execution": {} if self.execution is None else self.execution,
            "assessment": assessment(self),
        }


@dataclass
class _CandidateResult:
    match: Match | None = None
    depth_rejected: dict | None = None
    coarse_rejected: int = 0
    icp_calls: int = 0
    depth_seconds: float = 0.0
    projective_rejected: dict | None = None
    projective_seconds: float = 0.0
    rejection: dict | None = None
    boundary_seconds: float = 0.0


class Locator:
    def __init__(self, recipe):
        started = time.perf_counter()
        if not isinstance(recipe, Recipe):
            raise ValueError("Train or load a Recipe before constructing the locator.")
        self.recipe = recipe
        self._lock = threading.RLock()
        self._center, self._diameter = recipe.center, recipe.diameter
        self._model = recipe.samples.copy()
        self._model[:, :3] = (self._model[:, :3] - self._center) / self._diameter
        settings = recipe.settings
        self.geometry = analyze(self._model, settings.normal_neighbors)
        self._detector = surface_module().PPF3DDetector(
            settings.sampling_distance, settings.ppf_distance, settings.angle_bins
        )
        self.search_indices = search_indices(
            self._model,
            settings.global_model_points,
            strategy=settings.search_sampling,
            geometry=self.geometry,
        )
        self.search_indices.flags.writeable = False
        search_model = np.ascontiguousarray(self._model[self.search_indices])
        self._search_model_points = len(search_model)
        self._detector.trainModel(search_model)
        self._regional_detector = None
        self._pyramid = tuple(
            voxel_level(self._model, settings.sampling_distance * factor) for factor in (4, 2)
        ) + (self._model,)
        self._planes = (
            patches(self._model, settings.sampling_distance, limit=12)
            if settings.candidate_backend == "ppf_planes"
            else ()
        )
        feature_started = time.perf_counter()
        self._features = (
            descriptors(self._model, settings.sampling_distance)
            if settings.candidate_backend == "ppf_features"
            else None
        )
        self.feature_compile_seconds = (
            time.perf_counter() - feature_started if self._features is not None else 0.0
        )
        self.compile_seconds = time.perf_counter() - started

    def _evidence(
        self, scene, index, pose, *, model=None, distance=None, angle=None, observation=None
    ):
        aligned = transformed(self._model if model is None else model, pose)
        indices, squared = index.knnSearch(aligned[:, :3].copy(), 1, params={"checks": -1})
        ids, distances = indices[:, 0], np.sqrt(np.maximum(squared[:, 0], 0))
        dot = np.einsum("ij,ij->i", aligned[:, 3:], scene[ids, 3:])
        settings = self.recipe.settings
        visible = (
            np.ones(len(aligned), bool) if observation is None else observation.visible(aligned)
        )
        inliers = (
            visible
            & (distances <= (settings.distance_tolerance if distance is None else distance))
            & (dot >= np.cos(np.deg2rad(settings.normal_angle if angle is None else angle)))
        )
        coverage = float(inliers.sum() / visible.sum()) if visible.any() else 0.0
        # Independent samples differ along a surface even at the correct pose.
        # Measure fit along the scene normal, retaining Euclidean gating for coverage.
        residual = np.einsum("ij,ij->i", aligned[:, :3] - scene[ids, :3], scene[ids, 3:])
        rmse = float(np.sqrt(np.mean(residual[inliers] ** 2))) if inliers.any() else float("inf")
        spread = normal_spread(aligned[inliers, 3:]) if inliers.any() else 0.0
        quality = float(np.clip(dot[inliers], 0, 1).mean()) if inliers.any() else 0.0
        score = coverage * np.exp(-0.5 * (rmse / settings.max_rmse) ** 2) * quality
        return (
            coverage,
            rmse,
            spread,
            inliers,
            np.unique(ids[inliers]),
            aligned,
            distances,
            visible,
            float(score),
        )

    def _refine(self, scene, pose, evidence):
        aligned, distances = evidence[5:7]
        selected = (distances <= 0.1) & evidence[7]
        low, high = aligned[:, :3].min(axis=0) - 0.1, aligned[:, :3].max(axis=0) + 0.1
        region = np.all((scene[:, :3] >= low) & (scene[:, :3] <= high), axis=1)
        if selected.sum() < 30 or region.sum() < 30:
            return None
        settings = self.recipe.settings
        levels = settings.icp_levels
        if settings.refinement == "pyramid":
            levels = min(levels, max(1, int(np.log2(min(selected.sum(), region.sum()) / 30)) + 1))
        icp = surface_module().ICP(settings.icp_iterations, 0.005, 2.5, levels)
        try:
            status, residual, delta = icp.registerModelToScene(
                aligned[selected].copy(), scene[region].copy()
            )
        except cv2.error:
            return None
        if status != 0 or not np.isfinite(residual):
            return None
        try:
            return rigid(rigid(delta) @ pose)
        except ValueError:
            return None

    def _passes(self, evidence):
        settings = self.recipe.settings
        return (
            evidence[0] >= settings.min_coverage
            and evidence[1] <= settings.max_rmse
            and evidence[2] >= settings.min_normal_spread
            and len(evidence[4]) >= settings.min_unique_support
        )

    def _rejection(self, candidate, pose, evidence, center, *, coarse=False):
        """Retain the existing gate measurements, without repeating verification."""
        settings = self.recipe.settings
        coverage, rmse, spread = evidence[:3]
        support = len(evidence[4])
        limits = {
            "min_coverage": settings.min_coverage / 4 if coarse else settings.min_coverage,
            "min_unique_support": 6 if coarse else settings.min_unique_support,
        }
        failed = []
        if coverage < limits["min_coverage"]:
            failed.append("coverage")
        if support < limits["min_unique_support"]:
            failed.append("unique_support")
        if not coarse:
            limits.update(max_rmse=settings.max_rmse * self._diameter,
                          min_normal_spread=settings.min_normal_spread)
            if rmse > settings.max_rmse:
                failed.append("rmse")
            if spread < settings.min_normal_spread:
                failed.append("normal_spread")
        physical = pose.copy()
        physical[:3, 3] = self._diameter * pose[:3, 3] + center - pose[:3, :3] @ self._center
        return {
            "stage": "coarse" if coarse else "geometry",
            "candidate_source": getattr(candidate, "source", "ppf"),
            "source_to_target": rigid(physical).tolist(),
            "score": evidence[8],
            "coverage": coverage,
            "rmse": rmse * self._diameter if np.isfinite(rmse) else None,
            "normal_spread": spread,
            "unique_support": support,
            "limits": limits,
            "failed_checks": failed,
        }

    def _plane_candidates(self, scene, index, observation):
        settings = self.recipe.settings
        if len(self._planes) < 2:
            return (), {
                "model_patches": len(self._planes),
                "scene_patches": 0,
                "coarse_proposals": 0,
            }
        scene_planes = patches(scene, settings.sampling_distance)
        proposals = hypotheses(self._planes, scene_planes)
        return self._rank_candidates(scene, index, observation, proposals), {
            "model_patches": len(self._planes),
            "scene_patches": len(scene_planes),
            "coarse_proposals": len(proposals),
        }

    def _feature_candidates(self, scene, index, observation):
        if self._features is None:
            return (), {"coarse_proposals": 0}
        settings = self.recipe.settings
        started = time.perf_counter()
        features = descriptors(scene, settings.sampling_distance)
        ids = search_indices(scene, settings.global_scene_points, strategy="geometry")
        described_at = time.perf_counter()
        proposals, report = feature_hypotheses(
            self._model, scene[ids], self._features, features[ids]
        )
        proposed_at = time.perf_counter()
        selected = self._rank_candidates(scene, index, observation, proposals)
        report["scene_descriptor_points"] = len(scene)
        report["seconds"] = {
            "model_compile": self.feature_compile_seconds,
            "scene_descriptors": described_at - started,
            "consensus": proposed_at - described_at,
            "coarse_ranking": time.perf_counter() - proposed_at,
        }
        return selected, report

    def _new_regional_detector(self):
        settings = self.recipe.settings
        detector = surface_module().PPF3DDetector(
            settings.sampling_distance, settings.ppf_distance, settings.angle_bins
        )
        detector.trainModel(np.ascontiguousarray(self._model[self.search_indices]))
        return detector

    def _region_candidates(self, scene, index, observation):
        settings = self.recipe.settings
        if settings.candidate_backend != "ppf_regions":
            return (), {"enabled": False, "coarse_proposals": 0}
        if settings.max_candidates < 2:
            return (), {
                "enabled": True,
                "coarse_proposals": 0,
                "skipped_reason": "candidate_budget_below_two",
            }
        analysis_started = time.perf_counter()
        regions, report = find_regions(scene, settings.sampling_distance)
        analyzed_at = time.perf_counter()
        proposals, region_points = [], []
        failures, malformed, compilations = 0, 0, 0
        compile_seconds = 0.0
        for ids in regions:
            data = _search_sample(
                scene[ids], settings.global_scene_points, strategy=settings.search_sampling
            )
            if normal_spread(data[:, 3:]) < 1e-8 or np.any(np.ptp(data[:, :3], axis=0) <= 1e-7):
                continue
            region_points.append(len(data))
            with self._lock:
                if self._regional_detector is None:
                    compile_started = time.perf_counter()
                    self._regional_detector = self._new_regional_detector()
                    compile_seconds += time.perf_counter() - compile_started
                    compilations += 1
                try:
                    found = self._regional_detector.match(
                        data, settings.scene_reference_step, settings.sampling_distance
                    )
                except cv2.error:
                    # Failed native state is never reused, or shared with global PPF.
                    self._regional_detector = None
                    failures += 1
                    continue
            for item in sorted(found, key=lambda candidate: -candidate.numVotes)[:32]:
                try:
                    pose = rigid(item.pose).copy()
                except ValueError:
                    malformed += 1
                    continue
                proposals.append(Hypothesis(pose, 0.0, int(item.numVotes), "regions"))
        searched_at = time.perf_counter()
        selected = self._rank_candidates(scene, index, observation, proposals)
        report.update(
            enabled=True,
            search_region_points=region_points,
            native_failures=failures,
            malformed_hypotheses=malformed,
            detector_compilations=compilations,
            coarse_proposals=len(proposals),
            selected_proposals=len(selected),
            seconds={
                "analysis": analyzed_at - analysis_started,
                "native_and_compile": searched_at - analyzed_at,
                "model_compile": compile_seconds,
                "coarse_ranking": time.perf_counter() - searched_at,
            },
        )
        return selected, report

    def _rank_candidates(self, scene, index, observation, proposals):
        settings = self.recipe.settings
        ranked = []
        for candidate in proposals:
            evidence = self._evidence(
                scene,
                index,
                candidate.pose,
                model=self._pyramid[0],
                observation=observation,
                distance=0.07,
                angle=45,
            )
            ranked.append((evidence[0], candidate))
        ranked.sort(key=lambda item: (-item[0], item[1].error))
        selected = []
        # Avoid spending the refinement budget on nearly identical proposals.
        for _, candidate in ranked:

            def same_pose(prior):
                delta = candidate.pose[:3, :3] @ prior.pose[:3, :3].T
                cosine = np.clip((np.trace(delta) - 1) / 2, -1, 1)
                return (
                    cosine > np.cos(0.1)
                    and np.linalg.norm(candidate.pose[:3, 3] - prior.pose[:3, 3]) < 0.05
                )

            if not any(same_pose(prior) for prior in selected):
                selected.append(candidate)
            if len(selected) >= max(1, settings.max_candidates // 2):
                break
        return tuple(selected)

    def _verify_candidate(
        self,
        candidate,
        normalized,
        index,
        observation,
        center,
        scene_levels,
        level_indices,
        depth_buffer,
        depth_status,
        projective=False,
    ):
        settings = self.recipe.settings
        checked_candidate = _CandidateResult()
        try:
            pose = rigid(candidate.pose)
            if scene_levels:
                gate = self._evidence(
                    scene_levels[0],
                    level_indices[0],
                    pose,
                    model=self._pyramid[0],
                    distance=max(0.1, settings.distance_tolerance * 4),
                    angle=60,
                    observation=observation,
                )
                if gate[0] < settings.min_coverage / 4 or len(gate[4]) < 6:
                    checked_candidate.coarse_rejected = 1
                    checked_candidate.rejection = self._rejection(
                        candidate, pose, gate, center, coarse=True
                    )
                    return checked_candidate
            evidence = self._evidence(normalized, index, pose, observation=observation)
            improved = False
            # Rebuild correspondences once near the solution to polish
            # coarse pyramid estimates at full verification resolution.
            levels = (
                zip(self._pyramid, scene_levels, level_indices)
                if scene_levels
                else ((self._model, normalized, index), (self._model, normalized, index))
            )
            for level_model, level_scene, level_index in levels:
                local = (
                    evidence
                    if level_model is self._model and level_scene is normalized
                    else self._evidence(
                        level_scene,
                        level_index,
                        pose,
                        model=level_model,
                        observation=observation,
                    )
                )
                checked_candidate.icp_calls += 1
                refined = self._refine(level_scene, pose, local)
                if refined is None:
                    if not scene_levels:
                        break
                    continue
                checked = self._evidence(normalized, index, refined, observation=observation)
                if (self._passes(checked) and not self._passes(evidence)) or (
                    checked[1] < evidence[1]
                    and (self._passes(checked) or not self._passes(evidence))
                ):
                    pose, evidence, improved = refined, checked, True
                else:
                    if not scene_levels:
                        break
                    continue
            coverage, rmse, spread, inliers, scene_ids = evidence[:5]
            if not self._passes(evidence):
                checked_candidate.rejection = self._rejection(candidate, pose, evidence, center)
                return checked_candidate
            physical = pose.copy()
            physical[:3, 3] = self._diameter * pose[:3, 3] + center - pose[:3, :3] @ self._center
            depth_report, free_space = dict(depth_status), None
            if depth_buffer is not None:
                depth_started = time.perf_counter()
                aligned = evidence[5].copy()
                aligned[:, :3] = aligned[:, :3] * self._diameter + center
                depth_evidence = depth_buffer.evidence(
                    aligned, evidence[7], tolerance=settings.distance_tolerance * self._diameter
                )
                depth_report.update(
                    depth_evidence.report(
                        minimum_coverage=settings.min_depth_coverage,
                        minimum_rays=settings.min_unique_support,
                        maximum_free_space=settings.max_free_space,
                    )
                )
                free_space = depth_evidence.free_space
                checked_candidate.depth_seconds += time.perf_counter() - depth_started
            depth_report["applied"] = (
                settings.depth_verification == "auto" and depth_report["status"] == "checked"
            )
            if depth_report["applied"] and depth_report["limit_exceeded"]:
                checked_candidate.depth_rejected = {
                    "source_to_target": rigid(physical).tolist(),
                    "candidate_source": getattr(candidate, "source", "ppf"),
                    "score": evidence[8],
                    "depth_verification": depth_report,
                }
                checked_candidate.rejection = {
                    **checked_candidate.depth_rejected,
                    "stage": "depth", "failed_checks": ["free_space"],
                }
                return checked_candidate
            scoring, score = None, evidence[8]
            if projective:
                projective_started = time.perf_counter()
                scoring = projective_score(
                    self.recipe.cad.mesh,
                    physical,
                    depth_buffer,
                    tolerance=settings.distance_tolerance * self._diameter,
                    minimum_coverage=settings.min_depth_coverage,
                    minimum_rays=settings.min_unique_support,
                )
                scoring["geometric_score"] = evidence[8]
                checked_candidate.projective_seconds = time.perf_counter() - projective_started
                if scoring["score"] is None:
                    checked_candidate.projective_rejected = scoring
                    checked_candidate.rejection = {
                        "stage": "projective", "failed_checks": ["rendered_depth_support"],
                        "candidate_source": getattr(candidate, "source", "ppf"),
                        "source_to_target": rigid(physical).tolist(),
                        "score": evidence[8], "projective_scoring": scoring,
                    }
                    return checked_candidate
                score = scoring["score"]
            boundary = None
            if settings.boundary_verification != "off":
                boundary = {"mode": settings.boundary_verification, "status": "unavailable",
                            "reason": "cad_required" if self.recipe.cad is None else
                                      depth_status.get("reason") or "depth_required",
                            "applied": False}
                if self.recipe.cad is not None and depth_buffer is not None:
                    boundary_started = time.perf_counter()
                    boundary = {"mode": settings.boundary_verification, **inspect_boundary(
                        self.recipe.cad.mesh, physical, depth_buffer,
                        spacing=settings.sampling_distance * self._diameter,
                        tolerance=settings.distance_tolerance * self._diameter,
                        minimum_support=settings.min_coverage,
                        minimum_rays=settings.min_unique_support,
                    ).report}
                    checked_candidate.boundary_seconds = time.perf_counter() - boundary_started
                    boundary["applied"] = (settings.boundary_verification == "auto"
                                           and boundary["status"] == "checked")
                    if boundary["applied"] and boundary["limit_exceeded"]:
                        checked_candidate.rejection = {
                            "stage": "boundary", "failed_checks": ["surface_continuation"],
                            "candidate_source": getattr(candidate, "source", "ppf"),
                            "source_to_target": rigid(physical).tolist(),
                            "score": score, "boundary_verification": boundary,
                        }
                        return checked_candidate
            checked_candidate.match = Match(
                rigid(physical),
                coverage,
                rmse * self._diameter,
                spread,
                int(candidate.numVotes),
                inliers,
                scene_ids,
                improved,
                score,
                evidence[7],
                getattr(candidate, "source", "ppf"),
                depth_report,
                free_space,
                projective_scoring=scoring,
                boundary_verification=boundary,
            )
            return checked_candidate
        except ValueError:
            # Reject a malformed hypothesis and continue checking the remaining candidates.
            checked_candidate.rejection = {
                "stage": "invalid", "failed_checks": ["invalid_hypothesis"],
                "candidate_source": getattr(candidate, "source", "ppf"),
            }
            return checked_candidate

    def locate(self, scene, *, units, frame="scene", camera=None, depth_scene=None):
        started = time.perf_counter()
        _identity(units, frame)
        if units != self.recipe.units:
            raise ValueError("Scene and model units must match. Convert units before matching.")
        settings = self.recipe.settings
        if depth_scene is not None:
            if not isinstance(depth_scene, DepthScene):
                raise ValueError(
                    "Supply separate depth evidence as DepthScene(points, units, frame)."
                )
            depth_scene.validate_for(units, frame)
            if (
                camera is None
                and settings.depth_verification != "off"
                and settings.observation_mode == "surface"
            ):
                raise ValueError("Separate depth evidence requires a calibrated camera.")
        if camera is not None:
            camera = Camera.from_record(camera)
            if camera.units != units or camera.frame != frame:
                raise ValueError(
                    "Camera units/frame must match the scene; transform the cloud first."
                )
        raw = cloud(scene)
        input_points = len(raw)
        if settings.observation_mode == "surface" and len(raw):
            raw = raw[
                first_surface(
                    raw,
                    camera=camera,
                    viewpoint=settings.scene_viewpoint,
                    spacing=settings.sampling_distance * self._diameter,
                )
            ]
        if len(raw) < 30:
            return LocationResult((), raw, units, self.recipe.frame, frame, 0, 0,
                                  execution={"stop_reason": "insufficient_scene_points",
                                             "input_points": input_points,
                                             "first_surface_points": len(raw),
                                             "minimum_scene_points": 30})
        depth_buffer = None
        depth_started = time.perf_counter()
        reason = None
        if settings.depth_verification == "off":
            reason = "disabled"
        elif settings.observation_mode == "complete":
            reason = "complete_observation"
        elif camera is None:
            reason = "camera_missing"
        else:
            depth_buffer = DepthBuffer(raw if depth_scene is None else depth_scene.points, camera)
        depth_status = {
            "mode": settings.depth_verification,
            "status": "available" if depth_buffer is not None else "unavailable",
            "reason": reason,
            "source": "scene" if depth_scene is None else "depth_scene",
            "input_points": len(raw) if depth_scene is None else len(depth_scene.points),
        }
        scoring_reason = (
            "geometric_requested"
            if settings.pose_scoring == "geometric"
            else "cad_required"
            if self.recipe.cad is None
            else reason
        )
        projective = settings.pose_scoring == "projective" and scoring_reason is None
        depth_prepare_seconds = (
            time.perf_counter() - depth_started if depth_buffer is not None else 0.0
        )
        sampled = prepared(
            raw,
            settings.sampling_distance * self._diameter,
            settings.normal_neighbors,
            settings.scene_viewpoint,
            100000,
        )
        # A single normal direction cannot constrain a rigid surface pose.
        # It also triggers degenerate scene sampling in native PPF builds.
        if normal_spread(sampled[:, 3:]) < 1e-8 or np.any(
            np.ptp(sampled[:, :3], axis=0) <= self._diameter * 1e-7
        ):
            return LocationResult((), sampled, units, self.recipe.frame, frame, 0, 0,
                                  execution={"stop_reason": "degenerate_scene_geometry",
                                             "input_points": input_points,
                                             "first_surface_points": len(raw)})
        center = (sampled[:, :3].min(axis=0).astype(float) + sampled[:, :3].max(axis=0)) / 2
        normalized = sampled.copy()
        normalized[:, :3] = (normalized[:, :3] - center) / self._diameter
        # A single reference view is an incomplete surface template, not a closed
        # solid. Do not let rotating it away from the camera shrink its denominator
        # into an easy match on a small unrelated patch. Only CAD proves back faces.
        observation = (
            None
            if (settings.observation_mode == "complete" or self.recipe.cad is None)
            else Observation(
                center,
                self._diameter,
                settings.scene_viewpoint,
                settings.sampling_distance * self._diameter,
                camera,
            )
        )
        # Native detector instances retain state. Serialize their matching calls.
        search_scene = _search_sample(
            normalized, settings.global_scene_points, strategy=settings.search_sampling
        )
        prepared_at = time.perf_counter()
        with self._lock:
            found = self._detector.match(
                search_scene, settings.scene_reference_step, settings.sampling_distance
            )
        ppf_at = time.perf_counter()
        candidates = sorted(found, key=lambda candidate: -candidate.numVotes)[
            : settings.max_candidates
        ]
        index = cv2.flann_Index(normalized[:, :3].copy(), {"algorithm": 4})
        plane_started = time.perf_counter()
        planes, plane_report = self._plane_candidates(normalized, index, observation)
        plane_seconds = time.perf_counter() - plane_started if self._planes else 0.0
        feature_started = time.perf_counter()
        features, feature_report = self._feature_candidates(normalized, index, observation)
        feature_seconds = (
            time.perf_counter() - feature_started if self._features is not None else 0.0
        )
        region_started = time.perf_counter()
        regions, region_report = self._region_candidates(normalized, index, observation)
        region_seconds = time.perf_counter() - region_started if region_report["enabled"] else 0.0
        proposals = (*planes, *features, *regions)
        candidates = [*proposals, *candidates[: settings.max_candidates - len(proposals)]]
        candidate_at = time.perf_counter()
        scene_levels = ()
        if settings.refinement == "pyramid":
            scene_levels = tuple(
                voxel_level(normalized, settings.sampling_distance * factor) for factor in (4, 2)
            ) + (normalized,)
        level_indices = tuple(
            index if data is normalized else cv2.flann_Index(data[:, :3].copy(), {"algorithm": 4})
            for data in scene_levels
        )
        worker_limit = min(settings.execution_workers, len(candidates))
        resources = threading.local()
        resource_lock = threading.Lock()
        available = [(index, level_indices)]
        resource_count = 0
        index_seconds = 0.0

        def evaluate(candidate):
            nonlocal resource_count, index_seconds
            if not hasattr(resources, "indices"):
                prepared_start = time.perf_counter()
                # Give the existing index to exactly one worker. Other workers
                # build private indices; concurrent queries never share one.
                with resource_lock:
                    prior = available.pop() if available else None
                if prior is None:
                    own_index = cv2.flann_Index(normalized[:, :3].copy(), {"algorithm": 4})
                    prior = (
                        own_index,
                        tuple(
                            own_index
                            if data is normalized
                            else cv2.flann_Index(data[:, :3].copy(), {"algorithm": 4})
                            for data in scene_levels
                        ),
                    )
                resources.indices = prior
                with resource_lock:
                    resource_count += 1
                    index_seconds += time.perf_counter() - prepared_start
            own_index, own_levels = resources.indices
            return self._verify_candidate(
                candidate,
                normalized,
                own_index,
                observation,
                center,
                scene_levels,
                own_levels,
                depth_buffer,
                depth_status,
                projective,
            )

        if worker_limit > 1:
            with ThreadPoolExecutor(
                max_workers=worker_limit, thread_name_prefix="simple3d"
            ) as pool:
                checked = list(pool.map(evaluate, candidates))
        else:
            checked = [evaluate(candidate) for candidate in candidates]
        rejected = sum(row.coarse_rejected for row in checked)
        icp_calls = sum(row.icp_calls for row in checked)
        accepted = [row.match for row in checked if row.match is not None]
        depth_rejected = [row.depth_rejected for row in checked if row.depth_rejected is not None]
        depth_verify_seconds = sum(row.depth_seconds for row in checked)
        projective_rejected = [
            row.projective_rejected for row in checked if row.projective_rejected is not None
        ]
        reviews = []
        rejection_counts = {}
        for candidate_index, row in enumerate(checked, 1):
            if row.rejection is not None:
                stage = row.rejection["stage"]
                rejection_counts[stage] = rejection_counts.get(stage, 0) + 1
                reviews.append({"candidate_index": candidate_index, **row.rejection})
        # Prefer candidates that reached a later gate, then score. Coarse and
        # final scores use different probe sets and must not be ranked together.
        stage_order = {"boundary": 0, "projective": 0, "depth": 0, "geometry": 1,
                       "coarse": 2, "invalid": 3}
        reviews.sort(key=lambda row: (stage_order[row["stage"]], -row.get("score", 0),
                                      row["candidate_index"]))
        bounds = np.array(
            [self.recipe.samples[:, :3].min(axis=0), self.recipe.samples[:, :3].max(axis=0)]
        )
        suppression_records = []
        suppression_started = time.perf_counter()
        matches, suppressed = suppress(accepted, bounds, settings, records=suppression_records)
        alternatives_started = time.perf_counter()
        matches = describe_alternatives(
            matches,
            suppression_records,
            center=self._center,
            distance=settings.distance_tolerance * self._diameter,
            angle=360 / settings.angle_bins,
        )
        alternatives_seconds = time.perf_counter() - alternatives_started
        return LocationResult(
            tuple(matches),
            sampled,
            units,
            self.recipe.frame,
            frame,
            len(found)
            + plane_report["coarse_proposals"]
            + feature_report["coarse_proposals"]
            + region_report["coarse_proposals"],
            len(candidates),
            self._search_model_points,
            len(search_scene),
            {
                "sampling": settings.search_sampling,
                "candidate_backend": settings.candidate_backend,
                "plane_search": plane_report,
                "feature_search": feature_report,
                "region_search": region_report,
                "refinement": settings.refinement,
                "pose_scoring": {
                    "requested": settings.pose_scoring,
                    "active": "projective" if projective else "geometric",
                    "fallback_reason": scoring_reason,
                    "rejected_candidates": projective_rejected,
                },
                "observation_mode": settings.observation_mode,
                "projection": "pinhole" if camera else "angular_viewpoint",
                "input_points": input_points,
                "first_surface_points": len(raw),
                "depth_verification": depth_status,
                "depth_rejected": len(depth_rejected),
                "depth_rejected_candidates": sorted(depth_rejected, key=lambda p: -p["score"]),
                "overlap_metric": settings.overlap_metric,
                "overlap_threshold": settings.overlap_threshold,
                "overlap_rejected": suppressed,
                "verified_candidates": len(accepted),
                "rejection_counts": rejection_counts,
                "candidate_review": reviews[:8],
                "candidate_review_limit": 8,
                "match_limit_discarded": sum(
                    row.reason == "match_limit" for row in suppression_records
                ),
                "coarse_rejected": rejected,
                "icp_calls": icp_calls,
                "execution_workers": settings.execution_workers,
                "active_candidate_workers": resource_count,
                "candidate_timing_aggregation": "worker_intervals_may_overlap",
                "model_levels": [len(level) for level in self._pyramid]
                if scene_levels
                else [len(self._model)],
                "scene_levels": [len(level) for level in scene_levels]
                if scene_levels
                else [len(normalized)],
                "seconds": {
                    "preprocess": prepared_at - started,
                    "candidate_search": candidate_at - prepared_at,
                    "ppf_search": ppf_at - prepared_at,
                    "plane_search": plane_seconds,
                    "feature_search": feature_seconds,
                    "region_search": region_seconds,
                    "depth_prepare": depth_prepare_seconds,
                    "depth_verify": depth_verify_seconds,
                    "projective_score_sum": sum(row.projective_seconds for row in checked),
                    **({"boundary_verify_sum": sum(row.boundary_seconds for row in checked)}
                       if settings.boundary_verification != "off" else {}),
                    "worker_index_prepare_sum": index_seconds,
                    "suppression": alternatives_started - suppression_started,
                    "pose_alternatives": alternatives_seconds,
                    "refine_verify": time.perf_counter() - candidate_at,
                    "total": time.perf_counter() - started,
                },
            },
        )


def _search_sample(data, limit, *, strategy="uniform"):
    """Bound candidate generation while keeping verification at full trained resolution."""
    return np.ascontiguousarray(data[search_indices(data, limit, strategy=strategy)])
