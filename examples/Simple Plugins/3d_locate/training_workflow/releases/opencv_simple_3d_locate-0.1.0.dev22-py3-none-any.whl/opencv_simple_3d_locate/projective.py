"""Bounded first-surface CAD rendering and calibrated depth-fit scoring."""

import numpy as np

from .model import rigid

MAX_RENDER_SIZE = 640
MAX_RASTER_PAIRS = 4_000_000
RASTER_BATCH = 65_536


def render_depth(mesh, pose, camera):
    """Rasterize outward-facing triangles using perspective-correct optical Z.

    Integer pixel rays are subsampled at a fixed full-image stride. Each cell
    retains its nearest triangle and incidence factor; no hidden surfaces or
    depth holes are filled. Arrays never exceed 640 by 640 cells.
    """
    pose = rigid(pose)
    triangles = mesh.triangles @ pose[:3, :3].T + pose[:3, 3]
    normals = mesh.normals @ pose[:3, :3].T
    stride = max(1, int(np.ceil(max(camera.size) / MAX_RENDER_SIZE)))
    width, height = (int(np.ceil(value / stride)) for value in camera.size)
    depth = np.full((height, width), np.inf)
    factor = np.zeros_like(depth)
    if not np.isfinite(triangles).all():
        return depth, factor, stride, "nonfinite_projection"
    z = triangles[:, :, 2]
    if np.any((z.min(axis=1) <= 1e-9) & (z.max(axis=1) > 1e-9)):
        # A clipped solid needs near-plane caps; do not score an incomplete render.
        return depth, factor, stride, "mesh_crosses_camera_plane"
    facing = (z > 1e-9).all(axis=1) & (np.einsum("ni,ni->n", normals, -triangles.mean(1)) > 0)
    triangles, normals = triangles[facing], normals[facing]
    projected = triangles @ camera.matrix.T
    full_pixels = projected[:, :, :2] / projected[:, :, 2:]
    if not np.isfinite(full_pixels).all():
        return depth, factor, stride, "nonfinite_projection"
    # Bound triangle/pixel work as well as image memory. Keep every triangle;
    # complex overlapping projections reduce the ray-grid resolution instead.
    while True:
        width, height = (int(np.ceil(value / stride)) for value in camera.size)
        pixels = full_pixels / stride
        lo, hi = pixels.min(1), pixels.max(1)
        eligible = np.all(hi >= 0, axis=1) & np.all(lo <= [width - 1, height - 1], axis=1)
        low = np.ceil(np.clip(lo, 0, [width - 1, height - 1])).astype(np.int64)
        high = np.floor(np.clip(hi, 0, [width - 1, height - 1])).astype(np.int64)
        extent = np.maximum(high - low + 1, 0)
        counts = np.prod(extent, axis=1) * eligible
        if counts.sum() <= MAX_RASTER_PAIRS:
            break
        stride *= 2
    depth = np.full((height, width), np.inf)
    factor = np.zeros_like(depth)
    ends = np.cumsum(counts)
    starts = ends - counts
    for start in range(0, int(counts.sum()), RASTER_BATCH):
        pairs = np.arange(start, min(start + RASTER_BATCH, int(counts.sum())))
        ids = np.searchsorted(ends, pairs, side="right")
        offset = pairs - starts[ids]
        x = low[ids, 0] + offset % extent[ids, 0]
        y = low[ids, 1] + offset // extent[ids, 0]
        pixel = pixels[ids]
        denominator = (pixel[:, 1, 1] - pixel[:, 2, 1]) * (pixel[:, 0, 0] - pixel[:, 2, 0]) + (
            pixel[:, 2, 0] - pixel[:, 1, 0]
        ) * (pixel[:, 0, 1] - pixel[:, 2, 1])
        usable = abs(denominator) >= 1e-10
        denominator = np.where(usable, denominator, 1)
        a = (
            (pixel[:, 1, 1] - pixel[:, 2, 1]) * (x - pixel[:, 2, 0])
            + (pixel[:, 2, 0] - pixel[:, 1, 0]) * (y - pixel[:, 2, 1])
        ) / denominator
        b = (
            (pixel[:, 2, 1] - pixel[:, 0, 1]) * (x - pixel[:, 2, 0])
            + (pixel[:, 0, 0] - pixel[:, 2, 0]) * (y - pixel[:, 2, 1])
        ) / denominator
        c = 1 - a - b
        inside = usable & (a >= -1e-8) & (b >= -1e-8) & (c >= -1e-8)
        ids, x, y = ids[inside], x[inside], y[inside]
        triangle = triangles[ids]
        inverse = (
            a[inside] / triangle[:, 0, 2]
            + b[inside] / triangle[:, 1, 2]
            + c[inside] / triangle[:, 2, 2]
        )
        z = np.divide(1, inverse, out=np.full(len(inverse), np.inf), where=inverse > 0)
        keys = y * width + x
        order = np.lexsort((ids, z, keys))
        first = np.r_[True, np.diff(keys[order]) != 0] if len(order) else np.empty(0, bool)
        selected = order[first]
        ids, x, y, z = ids[selected], x[selected], y[selected], z[selected]
        closer = z < depth[y, x]
        ids, x, y, z = ids[closer], x[closer], y[closer], z[closer]
        depth[y, x] = z
        ray = np.c_[
            (x * stride - camera.matrix[0, 2]) / camera.matrix[0, 0],
            (y * stride - camera.matrix[1, 2]) / camera.matrix[1, 1],
            np.ones(len(x)),
        ]
        factor[y, x] = abs(np.einsum("ij,ij->i", ray, normals[ids]))
    return depth, factor, stride, None


def score(mesh, pose, buffer, *, tolerance, minimum_coverage, minimum_rays):
    """Soft incidence-corrected depth agreement; a fit score, not probability."""
    rendered, factors, stride, reason = render_depth(mesh, pose, buffer.camera)
    v, u = np.nonzero(np.isfinite(rendered))
    camera = buffer.camera
    directions = np.c_[
        (u * stride - camera.matrix[0, 2]) / camera.matrix[0, 0],
        (v * stride - camera.matrix[1, 2]) / camera.matrix[1, 1],
        np.ones(len(u)),
    ]
    incidence = factors[v, u] / np.linalg.norm(directions, axis=1)
    eligible = incidence >= 0.1
    u, v = u[eligible], v[eligible]
    measured = buffer.sample_pixels(u * stride, v * stride)
    known = np.isfinite(measured)
    coverage = float(known.mean()) if len(known) else 0.0
    checked = reason is None and known.sum() >= minimum_rays and coverage >= minimum_coverage
    residual = (measured[known] - rendered[v[known], u[known]]) * factors[v[known], u[known]]
    fit = float(np.mean(np.exp(-0.5 * (residual / tolerance) ** 2))) if checked else None
    return {
        "model": "cad_projective_score_v1",
        "status": "checked" if checked else "insufficient_depth",
        "reason": reason,
        "score": fit,
        "score_type": "projective_depth_fit_not_probability",
        "render_stride": stride,
        "rendered_rays": int(len(u)),
        "known_rays": int(known.sum()),
        "depth_coverage": coverage,
        "free_space_rays": int((residual > tolerance).sum()),
        "occluded_rays": int((residual < -tolerance).sum()),
        "consistent_rays": int((abs(residual) <= tolerance).sum()),
    }
