"""Score-ordered suppression using scene support and oriented model boxes."""

from dataclasses import dataclass
from itertools import combinations

import numpy as np

_TRIPLES = np.asarray(list(combinations(range(12), 3)))


def box_overlap(bounds, first, second):
    """Intersection volume / smaller volume for two rigid copies of one box.

    Intersect the twelve halfspaces, then integrate the resulting convex faces.
    Work in box-sized coordinates to avoid unit- and translation-sensitive tests.
    This is a box proxy, not the solid intersection of hollow CAD geometry.
    """
    low, high = np.asarray(bounds, float)
    scale = np.linalg.norm(high - low)
    half = (high - low) / (2 * scale)
    center = (high + low) / 2
    centers = [pose[:3, :3] @ center + pose[:3, 3] for pose in (first, second)]
    if np.linalg.norm(centers[1] - centers[0]) >= scale:
        return 0.0
    normals, offsets = [], []
    for pose, location in zip((first, second), centers):
        rotation = pose[:3, :3]
        axes = np.r_[rotation.T, -rotation.T]
        normals.extend(axes)
        offsets.extend(np.tile(half, 2) + axes @ ((location - centers[0]) / scale))
    normals, offsets = np.asarray(normals), np.asarray(offsets)
    matrices = normals[_TRIPLES]
    keep = np.abs(np.linalg.det(matrices)) > 1e-10
    vertices = np.linalg.solve(matrices[keep], offsets[_TRIPLES[keep]][..., None])[..., 0]
    vertices = vertices[np.all(vertices @ normals.T <= offsets + 1e-8, axis=1)]
    vertices = np.unique(np.round(vertices, 9), axis=0)
    if len(vertices) < 4:
        return 0.0
    # Coincident faces must contribute only once (identical poses are common).
    planes = np.unique(np.round(np.c_[normals, offsets], 9), axis=0)
    volume = 0.0
    for plane in planes:
        normal, offset = plane[:3], plane[3]
        face = vertices[np.abs(vertices @ normal - offset) < 2e-8]
        if len(face) < 3:
            continue
        origin = face.mean(axis=0)
        u = face[0] - origin
        u /= np.linalg.norm(u)
        v = np.cross(normal, u)
        angles = np.arctan2((face - origin) @ v, (face - origin) @ u)
        face = face[np.argsort(angles)] - origin
        area = abs(np.cross(face, np.roll(face, -1, axis=0)).sum(axis=0) @ normal) / 2
        volume += area * offset / 3
    return float(np.clip(volume / np.prod(2 * half), 0, 1))


@dataclass(frozen=True)
class SuppressionRecord:
    candidate: object
    retained: object | None
    reason: str
    overlap: float | None


def suppress(matches, bounds, settings, *, records=None):
    """Retain the highest fit score when overlap exceeds the configured limit."""
    ordered = sorted(matches, key=lambda m: (-m.score, -m.coverage, m.rmse, -m.votes))
    kept, rejected = [], 0
    for match in ordered:
        duplicate = False
        for prior in kept:
            support = 0.0
            if settings.overlap_metric != "box":
                denominator = min(len(match.scene_indices), len(prior.scene_indices))
                if denominator:
                    support = (
                        len(np.intersect1d(match.scene_indices, prior.scene_indices)) / denominator
                    )
            overlap = support
            if settings.overlap_metric != "scene_support":
                overlap = max(overlap, box_overlap(bounds, match.pose, prior.pose))
            if overlap > settings.overlap_threshold:
                duplicate = True
                rejected += 1
                if records is not None:
                    records.append(SuppressionRecord(match, prior, "overlap", float(overlap)))
                break
        if not duplicate and len(kept) < settings.max_matches:
            kept.append(match)
        elif not duplicate and records is not None:
            records.append(SuppressionRecord(match, None, "match_limit", None))
    return tuple(kept), rejected
