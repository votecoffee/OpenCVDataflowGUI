"""Describe distinct verified poses discarded by the existing overlap decision."""

from dataclasses import replace

import numpy as np


def separation(first, second, center):
    rotation = first[:3, :3] @ second[:3, :3].T
    angle = float(np.degrees(np.arccos(np.clip((np.trace(rotation) - 1) / 2, -1, 1))))
    # Use the physical model center, independent of where its taught origin lies.
    locations = [pose[:3, :3] @ center + pose[:3, 3] for pose in (first, second)]
    return float(np.linalg.norm(locations[0] - locations[1])), angle


def describe(matches, records, *, center, distance, angle):
    """Annotate retained matches without changing their order, scores or fit.

    Only candidates already passing geometric/depth checks and suppressed by
    a retained match are eligible. Greedy separation groups nearly identical
    estimates; up to three highest-scoring distinct alternatives are exported.
    Absence of a competitor is not proof of a unique pose or exhaustive search.
    """

    def similar(first, second):
        displacement, degrees = separation(first, second, center)
        return displacement <= distance and degrees <= angle

    annotated = []
    for match in matches:
        group = sorted(
            (row for row in records if row.retained is match and row.reason == "overlap"),
            key=lambda row: (
                -row.candidate.score,
                -row.candidate.coverage,
                row.candidate.rmse,
                -row.candidate.votes,
            ),
        )
        selected = []
        for record in group:
            candidate = record.candidate
            if similar(match.pose, candidate.pose):
                continue
            if any(similar(prior.candidate.pose, candidate.pose) for prior in selected):
                continue
            selected.append(record)
        alternatives = []
        for record in selected[:3]:
            other = record.candidate
            displacement, degrees = separation(match.pose, other.pose, center)
            alternatives.append(
                {
                    "source_to_target": other.pose.tolist(),
                    "score": other.score,
                    "score_type": other.report()["score_type"],
                    "coverage": other.coverage,
                    "rmse": other.rmse,
                    "candidate_source": other.candidate_source,
                    "center_displacement": displacement,
                    "orientation_difference_degrees": degrees,
                    "overlap": record.overlap,
                }
            )
        competitor = selected[0].candidate if selected else None
        gap = None if competitor is None else float(max(0, match.score - competitor.score))
        report = {
            "model": "geometric_pose_alternatives_v1",
            "status": "alternatives_observed" if selected else "none_observed",
            "count": len(selected),
            "suppressed_candidates": len(group),
            "score_gap": gap,
            "relative_score_margin": gap / match.score
            if gap is not None and match.score > 0
            else None,
            "margin_type": "geometric_score_gap_not_probability",
            "score_type": match.report()["score_type"],
            "minimum_center_separation": distance,
            "minimum_orientation_separation_degrees": angle,
            "alternatives": alternatives,
            "truncated": len(selected) > len(alternatives),
            "exhaustive": False,
        }
        annotated.append(replace(match, pose_alternatives=report))
    return tuple(annotated)
