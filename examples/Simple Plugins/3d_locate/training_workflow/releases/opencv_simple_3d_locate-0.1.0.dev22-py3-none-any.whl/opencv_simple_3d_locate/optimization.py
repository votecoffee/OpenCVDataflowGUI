"""Compare fixed execution plans without changing training or acceptance limits."""

import copy
import hashlib
import json
import os
import platform
import time
from dataclasses import asdict, dataclass, replace
from pathlib import Path, PurePosixPath

import cv2
import numpy as np

from .depth import DepthScene
from .locate import Locator
from .model import _identity, cloud, rigid
from .observation import Camera

PROFILES = (
    "current",
    "geometry",
    "pyramid",
    "compact",
    "planes",
    "features",
    "parallel",
    "projective",
    "regions",
)


class ComparisonCancelled(Exception):
    pass


@dataclass(frozen=True)
class ValidationScene:
    name: str
    data: np.ndarray
    units: str
    frame: str = "scene"
    truth: tuple | None = None
    camera: Camera | None = None
    symmetries: tuple = ()
    depth_scene: DepthScene | None = None

    def __post_init__(self):
        _identity(self.units, self.frame)
        if self.depth_scene is not None:
            if not isinstance(self.depth_scene, DepthScene):
                raise ValueError("Validation depth_scene requires a DepthScene value.")
            self.depth_scene.validate_for(self.units, self.frame)
        if self.camera is not None:
            camera = Camera.from_record(self.camera)
            if camera.units != self.units or camera.frame != self.frame:
                raise ValueError("Validation camera units/frame must match its scene.")
            object.__setattr__(self, "camera", camera)
        if not isinstance(self.name, str) or not self.name or len(self.name) > 128:
            raise ValueError("Name each validation scene with at most 128 characters.")
        data = cloud(self.data)
        if len(self.symmetries) > 64:
            raise ValueError("Validation supports at most 64 discrete symmetries.")
        symmetries = tuple(rigid(value).copy() for value in self.symmetries)
        for value in symmetries:
            value.flags.writeable = False
        object.__setattr__(self, "symmetries", symmetries)
        data.flags.writeable = False
        object.__setattr__(self, "data", data)
        if self.truth is not None:
            if len(self.truth) > 20:
                raise ValueError("Validation supports at most 20 expected instances per scene.")
            poses = tuple(rigid(value).copy() for value in self.truth)
            for pose in poses:
                pose.flags.writeable = False
            object.__setattr__(self, "truth", poses)


def profile_recipe(recipe, name):
    if name not in PROFILES:
        raise ValueError("Unknown execution profile.")
    if name == "current":
        return recipe
    if name == "projective":
        return replace(recipe, settings=replace(recipe.settings, pose_scoring="projective"))
    if name == "regions":
        return replace(recipe, settings=replace(recipe.settings, candidate_backend="ppf_regions"))
    if name == "planes":
        return replace(recipe, settings=replace(recipe.settings, candidate_backend="ppf_planes"))
    if name == "features":
        return replace(recipe, settings=replace(recipe.settings, candidate_backend="ppf_features"))
    if name == "parallel":
        return replace(
            recipe, settings=replace(recipe.settings, execution_workers=min(4, os.cpu_count() or 1))
        )
    changes = {
        "search_sampling": "geometry",
        "refinement": "pyramid" if name in ("pyramid", "compact") else "legacy",
    }
    if name == "compact":
        changes.update(
            global_model_points=min(192, recipe.settings.global_model_points),
            global_scene_points=min(1024, recipe.settings.global_scene_points),
        )
    return replace(recipe, settings=replace(recipe.settings, **changes))


def pose_agreement(actual, expected, *, position_tolerance, angle_degrees=1.0, symmetries=()):
    """Maximum one-to-one matching within validation-only pose tolerances."""
    edges, errors = [], {}
    for row, pose in enumerate(actual):
        available = []
        for column, target in enumerate(expected):
            alternatives = []
            for symmetry in (np.eye(4), *symmetries):
                equivalent = target @ symmetry
                distance = float(np.linalg.norm(pose[:3, 3] - equivalent[:3, 3]))
                angle = float(
                    np.degrees(
                        np.linalg.norm(cv2.Rodrigues(pose[:3, :3] @ equivalent[:3, :3].T)[0])
                    )
                )
                alternatives.append((distance, angle))
            distance, angle = min(
                alternatives, key=lambda e: max(e[0] / position_tolerance, e[1] / angle_degrees)
            )
            if distance <= position_tolerance and angle <= angle_degrees:
                available.append(column)
                errors[row, column] = distance, angle
        edges.append(
            sorted(
                available,
                key=lambda col: max(
                    errors[row, col][0] / position_tolerance, errors[row, col][1] / angle_degrees
                ),
            )
        )
    owners = {}

    def assign(row, visited):
        for column in edges[row]:
            if column in visited:
                continue
            visited.add(column)
            if column not in owners or assign(owners[column], visited):
                owners[column] = row
                return True
        return False

    for row in range(len(actual)):
        assign(row, set())
    paired = [errors[row, col] for col, row in owners.items()]
    return {
        "matched": len(owners),
        "missed": len(expected) - len(owners),
        "extra": len(actual) - len(owners),
        "max_position_error": max((error[0] for error in paired), default=0.0),
        "max_angle_error_degrees": max((error[1] for error in paired), default=0.0),
    }


def compare_profiles(
    recipe,
    scenes,
    *,
    repeats=2,
    profiles=PROFILES,
    cancel=None,
    progress=None,
    position_tolerance=None,
    angle_tolerance=1.0,
):
    scenes = tuple(scenes)
    if (
        not 1 <= len(scenes) <= 12
        or type(repeats) is not int
        or not 1 <= repeats <= 5
        or not profiles
        or profiles[0] != "current"
        or len(set(profiles)) != len(profiles)
        or any(name not in PROFILES for name in profiles)
    ):
        raise ValueError(
            "Compare 1..12 scenes, 1..5 repeats, starting with the unique current profile."
        )
    if any(scene.units != recipe.units for scene in scenes):
        raise ValueError("Validation scene and model units must match.")
    position_tolerance = (
        recipe.diameter * 0.005 if position_tolerance is None else position_tolerance
    )
    if (
        isinstance(position_tolerance, bool)
        or isinstance(angle_tolerance, bool)
        or not np.isfinite([position_tolerance, angle_tolerance]).all()
        or position_tolerance <= 0
        or not 0 < angle_tolerance <= 180
    ):
        raise ValueError(
            "Use a positive physical position tolerance and an angle tolerance in (0,180]."
        )
    baseline, reports = [], []
    measured = {}
    positive_reference = False

    def checkpoint(message):
        if cancel is not None and cancel.is_set():
            raise ComparisonCancelled()
        if progress is not None:
            progress(message)

    for name in profiles:
        checkpoint(f"Compiling {name}")
        selected = profile_recipe(recipe, name)
        if selected.settings in measured:
            reused = copy.deepcopy(measured[selected.settings])
            reused["measurements_reused_from"] = reused["profile"]
            reused["profile"] = name
            reports.append(reused)
            continue
        compile_start = time.perf_counter()
        locator = Locator(selected)
        report = {
            "profile": name,
            "settings": asdict(selected.settings),
            "compile_seconds": time.perf_counter() - compile_start,
            "search_model_points": locator._search_model_points,
            "scenes": [],
        }
        for index, scene in enumerate(scenes):
            elapsed, runs = [], []
            expected = scene.truth
            basis = "ground_truth" if expected is not None else "current_profile_agreement"
            for repeat in range(repeats):
                checkpoint(f"{name} Â· {scene.name} Â· run {repeat + 1}/{repeats}")
                start = time.perf_counter()
                result = locator.locate(
                    scene.data,
                    units=scene.units,
                    frame=scene.frame,
                    camera=scene.camera,
                    depth_scene=scene.depth_scene,
                )
                elapsed.append(time.perf_counter() - start)
                poses = tuple(match.pose for match in result.matches)
                if expected is None:
                    expected = poses if name == "current" and repeat == 0 else baseline[index]
                positive_reference |= bool(expected)
                agreement = pose_agreement(
                    poses,
                    expected,
                    position_tolerance=position_tolerance,
                    angle_degrees=angle_tolerance,
                    symmetries=scene.symmetries,
                )
                runs.append(
                    {
                        "count": len(poses),
                        "matches": [match.report() for match in result.matches],
                        "seconds": elapsed[-1],
                        **agreement,
                        "execution": result.execution or {},
                    }
                )
            if name == "current":
                baseline.append(expected)
            report["scenes"].append(
                {
                    "name": scene.name,
                    "frame": scene.frame,
                    "basis": basis,
                    "expected": len(expected),
                    "median_seconds": float(np.median(elapsed)),
                    "min_seconds": min(elapsed),
                    "max_seconds": max(elapsed),
                    "compatible": all(run["missed"] == run["extra"] == 0 for run in runs),
                    "runs": runs,
                }
            )
        report["compatible"] = all(scene["compatible"] for scene in report["scenes"])
        report["median_scene_seconds"] = float(
            np.mean([scene["median_seconds"] for scene in report["scenes"]])
        )
        reports.append(report)
        measured[selected.settings] = report
    checkpoint("Comparison complete")
    eligible = [report for report in reports if report["compatible"]] if positive_reference else []
    best = min(eligible, key=lambda report: report["median_scene_seconds"]) if eligible else None
    return {
        "model": "simple_3d_execution_comparison_v1",
        "units": recipe.units,
        "source_frame": recipe.frame,
        "trained_samples_sha256": hashlib.sha256(
            recipe.samples.astype("<f4", copy=False).tobytes()
        ).hexdigest(),
        "runtime": {
            "python": platform.python_version(),
            "opencv": cv2.__version__,
            "numpy": np.__version__,
        },
        "repeats": repeats,
        "position_tolerance": position_tolerance,
        "angle_tolerance_degrees": angle_tolerance,
        "qualification": "ground_truth"
        if all(scene.truth is not None for scene in scenes)
        else "includes_current_profile_agreement",
        "profiles": reports,
        "recommended": best["profile"] if best is not None else None,
        "scope": "Execution comparison on supplied scenes. "
        "Acceptance thresholds and trained samples are unchanged.",
    }


def read_validation_scenes(path):
    """Load bounded, project-relative NPZ validation scenes and optional truth."""
    from .cli import read_npz

    path = Path(path)
    if path.stat().st_size > 8 * 1024 * 1024:
        raise ValueError("Validation manifest exceeds 8 MiB.")

    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"Duplicate validation key: {key}")
            result[key] = value
        return result

    def constant(value):
        raise ValueError(f"Nonfinite validation number: {value}")

    manifest = json.loads(path.read_bytes(), object_pairs_hook=unique, parse_constant=constant)
    if (
        not isinstance(manifest, dict)
        or set(manifest) != {"version", "scenes"}
        or type(manifest["version"]) is not int
        or manifest["version"] != 1
        or not isinstance(manifest["scenes"], list)
        or not 1 <= len(manifest["scenes"]) <= 12
    ):
        raise ValueError("Expected validation manifest version 1 with 1..12 scenes.")
    base, scenes = path.parent.resolve(), []

    def read_cloud_file(relative):
        if not isinstance(relative, str):
            raise ValueError("Validation clouds require relative .npz paths.")
        portable = PurePosixPath(relative)
        if (
            portable.is_absolute()
            or ".." in portable.parts
            or "\\" in relative
            or ":" in relative
            or portable.suffix.lower() != ".npz"
        ):
            raise ValueError(
                "Validation clouds must be relative .npz paths within the manifest folder."
            )
        cloud_path = (base / relative).resolve()
        if not cloud_path.is_relative_to(base):
            raise ValueError("Validation cloud resolves outside the manifest folder.")
        return read_npz(cloud_path)

    for item in manifest["scenes"]:
        if (
            not isinstance(item, dict)
            or set(item) - {"name", "cloud", "truth", "camera", "symmetries", "depth_cloud"}
            or not isinstance(item.get("cloud"), str)
        ):
            raise ValueError("Each validation scene requires a relative cloud path.")
        data, units, frame = read_cloud_file(item["cloud"])
        depth = None
        if "depth_cloud" in item:
            depth = DepthScene(*read_cloud_file(item["depth_cloud"]))
        scenes.append(
            ValidationScene(
                item.get("name", PurePosixPath(item["cloud"]).name),
                data,
                units,
                frame,
                item.get("truth"),
                item.get("camera"),
                tuple(item.get("symmetries", ())),
                depth,
            )
        )
    return tuple(scenes)
