"""Responsive comparison of execution plans using private validation snapshots."""

import json
import threading
from pathlib import Path
from zipfile import BadZipFile

from opencv_dataflow.cloud_io import read_cloud
from PySide6.QtCore import QObject, QRunnable, Qt, QThreadPool, Signal
from PySide6.QtWidgets import (
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QPushButton,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from .cli import read_npz
from .optimization import (
    ComparisonCancelled,
    ValidationScene,
    compare_profiles,
    profile_recipe,
    read_validation_scenes,
)


class _Signals(QObject):
    progress = Signal(str)
    completed = Signal(object)
    failed = Signal(str)


class _Compare(QRunnable):
    def __init__(self, recipe, scenes, *, repeats, position_tolerance, angle_tolerance):
        super().__init__()
        self.recipe, self.scenes = recipe, scenes
        self.options = dict(
            repeats=repeats, position_tolerance=position_tolerance, angle_tolerance=angle_tolerance
        )
        self.cancel = threading.Event()
        self.signals = _Signals()

    def run(self):
        try:
            report = compare_profiles(
                self.recipe,
                self.scenes,
                cancel=self.cancel,
                progress=lambda message: self._emit("progress", message),
                **self.options,
            )
            self._emit("completed", report)
        except ComparisonCancelled:
            self._emit("failed", "Comparison cancelled.")
        except Exception as error:
            self._emit("failed", str(error))

    def _emit(self, name, value):
        try:
            getattr(self.signals, name).emit(value)
        except RuntimeError:
            # Application shutdown can destroy the signal source before a
            # native call returns. The worker must stop without touching Qt.
            self.cancel.set()


class ExecutionDialog(QDialog):
    def __init__(self, parent, recipe, scenes):
        super().__init__(parent)
        self.recipe, self.scenes = recipe, list(scenes)
        self.report = self.worker = self.selected_recipe = None
        self.setWindowTitle("Compare 3D execution profiles")
        self.resize(980, 600)
        layout = QVBoxLayout(self)
        text = QLabel(
            "Compare fixed execution plans on independent scenes. Without ground-truth poses, "
            "this checks agreement with the current recipe. Review result overlays and "
            "representative "
            "positive and negative scenes before choosing a plan."
        )
        text.setWordWrap(True)
        layout.addWidget(text)
        self.list = QListWidget()
        self.list.setMaximumHeight(105)
        self._refresh_scenes()
        layout.addWidget(self.list)
        actions = QHBoxLayout()
        self.add = QPushButton("Add validation clouds…")
        self.manifest = QPushButton("Load validation manifest…")
        self.remove = QPushButton("Remove selected")
        self.add.clicked.connect(self._add)
        self.manifest.clicked.connect(self._load_manifest)
        self.remove.clicked.connect(self._remove)
        actions.addWidget(self.add)
        actions.addWidget(self.manifest)
        actions.addWidget(self.remove)
        layout.addLayout(actions)
        form = QFormLayout()
        self.repeats = QSpinBox()
        self.repeats.setRange(1, 5)
        self.repeats.setValue(2)
        self.position = QLineEdit(f"{recipe.diameter * 0.005:.6g}")
        self.angle = QLineEdit("1")
        form.addRow("Timed repeats per scene", self.repeats)
        form.addRow(f"Allowed position error/change ({recipe.units})", self.position)
        form.addRow("Allowed orientation error/change (degrees)", self.angle)
        layout.addLayout(form)
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            [
                "Profile",
                "Mean scene median (s)",
                "Compile (s)",
                "Missed / Extra",
                "Max pose error",
                "Compatible",
            ]
        )
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.table.itemSelectionChanged.connect(self._select)
        layout.addWidget(self.table, 1)
        self.status = QLabel(
            "Add scenes and compare. The full trained model and acceptance limits are preserved."
        )
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        actions = QHBoxLayout()
        self.run_button, self.cancel_button = (
            QPushButton("Compare plans"),
            QPushButton("Cancel comparison"),
        )
        self.use, self.export = QPushButton("Use selected plan"), QPushButton("Export comparison…")
        self.run_button.clicked.connect(self._start)
        self.cancel_button.clicked.connect(self._cancel)
        self.use.clicked.connect(self._apply)
        self.export.clicked.connect(self._export)
        for button in (self.run_button, self.cancel_button, self.use, self.export):
            actions.addWidget(button)
        layout.addLayout(actions)
        self.cancel_button.setEnabled(False)
        self.use.setEnabled(False)
        self.export.setEnabled(False)
        for field in (self.position, self.angle):
            field.textChanged.connect(self._invalidate)
        self.repeats.valueChanged.connect(self._invalidate)

    def _refresh_scenes(self):
        self.list.clear()
        self.list.addItems(
            [
                f"{scene.name} · {len(scene.data)} search points"
                + (
                    f" · {len(scene.depth_scene.points)} depth points"
                    if scene.depth_scene is not None
                    else ""
                )
                for scene in self.scenes
            ]
        )

    def _invalidate(self, *_):
        self.report = None
        self.table.setRowCount(0)
        self.use.setEnabled(False)
        self.export.setEnabled(False)

    def _add(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Validation clouds", "", "Clouds (*.npz *.ply *.pcd)"
        )
        try:
            if len(paths) + len(self.scenes) > 12:
                raise ValueError("Use at most 12 validation scenes.")
            added = []
            for path in paths:
                if Path(path).suffix.lower() == ".npz":
                    data, units, frame = read_npz(path)
                else:
                    from .dataflow import oriented

                    value = read_cloud(Path(path), units=self.recipe.units, frame="scene")
                    data, units, frame = oriented(value), value.units, value.frame
                if units != self.recipe.units:
                    raise ValueError("Validation cloud and recipe units must match.")
                added.append(ValidationScene(Path(path).name, data, units, frame))
            self.scenes.extend(added)
            self._invalidate()
            self._refresh_scenes()
        except (ValueError, OSError, BadZipFile) as error:
            self.status.setText(str(error))

    def _remove(self):
        row = self.list.currentRow()
        if row >= 0:
            del self.scenes[row]
            self._invalidate()
            self._refresh_scenes()

    def _load_manifest(self):
        path, _ = QFileDialog.getOpenFileName(self, "Validation manifest", "", "JSON (*.json)")
        if path:
            try:
                self._add_manifest(path)
            except (ValueError, OSError, BadZipFile) as error:
                self.status.setText(str(error))

    def _add_manifest(self, path):
        scenes = read_validation_scenes(path)
        if len(scenes) + len(self.scenes) > 12:
            raise ValueError("Use at most 12 validation scenes.")
        if any(scene.units != self.recipe.units for scene in scenes):
            raise ValueError("Validation cloud and recipe units must match.")
        self.scenes.extend(scenes)
        self._invalidate()
        self._refresh_scenes()
        self.status.setText(
            "Loaded validation scenes with their cameras and optional pose annotations."
        )

    def _busy(self, value):
        for control in (
            self.add,
            self.manifest,
            self.remove,
            self.repeats,
            self.position,
            self.angle,
            self.run_button,
        ):
            control.setEnabled(not value)
        self.cancel_button.setEnabled(value)

    def _start(self):
        try:
            position, angle = float(self.position.text()), float(self.angle.text())
            if not self.scenes or not 0 < position < float("inf") or not 0 < angle <= 180:
                raise ValueError("Add scenes and enter positive finite pose tolerances.")
            self._invalidate()
            self.worker = _Compare(
                self.recipe,
                tuple(self.scenes),
                repeats=self.repeats.value(),
                position_tolerance=position,
                angle_tolerance=angle,
            )
            signals = self.worker.signals
            signals.progress.connect(self.status.setText)
            signals.completed.connect(self._complete)
            signals.failed.connect(self._failed)
            cancel = self.worker.cancel
            self.destroyed.connect(lambda _=None: cancel.set())
            self._busy(True)
            QThreadPool.globalInstance().start(self.worker)
        except ValueError as error:
            self.status.setText(str(error))

    def _cancel(self):
        if self.worker is not None:
            self.worker.cancel.set()
            self.status.setText("Cancelling after the current native operation.")

    def _failed(self, message):
        self.worker = None
        self._busy(False)
        self.status.setText(message)

    def _complete(self, report):
        if self.worker is not None and self.worker.cancel.is_set():
            self._failed("Comparison cancelled.")
            return
        self.worker = None
        self.report = report
        self._busy(False)
        self.table.setRowCount(len(report["profiles"]))
        for row, item in enumerate(report["profiles"]):
            runs = [run for scene in item["scenes"] for run in scene["runs"]]
            missed, extra = sum(run["missed"] for run in runs), sum(run["extra"] for run in runs)
            position = max(run["max_position_error"] for run in runs)
            angle = max(run["max_angle_error_degrees"] for run in runs)
            values = [
                item["profile"],
                f"{item['median_scene_seconds']:.4f}",
                f"{item['compile_seconds']:.4f}",
                f"{missed} / {extra}",
                f"{position:.4g} {self.recipe.units}, {angle:.3g} deg",
                "Yes" if item["compatible"] else "No",
            ]
            for column, value in enumerate(values):
                cell = QTableWidgetItem(value)
                cell.setFlags(cell.flags() & ~Qt.ItemFlag.ItemIsEditable)
                self.table.setItem(row, column, cell)
            if item["profile"] == report["recommended"]:
                self.table.selectRow(row)
        self.table.resizeColumnsToContents()
        self.export.setEnabled(True)
        self.status.setText(
            f"Recommended on these scenes: {report['recommended'] or 'none'}. "
            f"Validation basis: {report['qualification']}. Compile time is separate from execution."
        )
        self._select()

    def _select(self):
        row = self.table.currentRow()
        compatible = (
            self.report is not None and row >= 0 and self.report["profiles"][row]["compatible"]
        )
        self.use.setEnabled(bool(compatible and self.report["recommended"] is not None))

    def _apply(self):
        if not self.use.isEnabled() or self.report is None:
            return
        name = self.report["profiles"][self.table.currentRow()]["profile"]
        self.selected_recipe = profile_recipe(self.recipe, name)
        self.accept()

    def _export(self):
        path, _ = QFileDialog.getSaveFileName(self, "Execution comparison", "", "JSON (*.json)")
        if path and self.report is not None:
            try:
                Path(path).write_bytes(
                    (json.dumps(self.report, indent=2, allow_nan=False) + "\n").encode("utf-8")
                )
            except OSError as error:
                self.status.setText(str(error))

    def done(self, result):
        self._cancel()
        super().done(result)
