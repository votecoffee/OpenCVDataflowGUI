"""Acquisition declarations for the host adapter; independent of matching/graphics."""


def capture_id(value):
    if (
        not isinstance(value, str)
        or not value.strip()
        or len(value) > 256
        or any(ord(c) < 32 for c in value)
    ):
        raise ValueError("Capture ID must be a nonempty string of at most 256 characters")
    return value


def bind_capture(explicit, clouds):
    """Validate all connected clouds together; metadata equality is not a timing proof."""
    tagged, missing = {}, []
    for name, metadata in clouds.items():
        if not isinstance(metadata, dict):
            raise ValueError("Point-cloud capture metadata must be an object")
        if "capture_id" in metadata:
            tagged[name] = capture_id(metadata["capture_id"])
        else:
            missing.append(name)
    if explicit is not None:
        explicit = capture_id(explicit)
    if tagged and missing:
        raise ValueError(
            "Partially tagged cloud pair: every connected scene/depth cloud needs a capture ID"
        )
    if len(set(tagged.values())) > 1:
        raise ValueError("Scene and depth cloud belong to different captures")
    embedded = next(iter(tagged.values()), None)
    if explicit is not None and embedded is not None and explicit != embedded:
        raise ValueError("Capture input differs from scene/depth cloud capture metadata")
    identity = explicit if explicit is not None else embedded
    if identity is None:
        return None, None
    method = (
        "explicit_input_and_matching_cloud_metadata"
        if explicit is not None and tagged
        else "matching_cloud_metadata"
        if tagged
        else "explicit_input_declaration"
    )
    return identity, dict(
        model="locator_capture_binding_v1",
        method=method,
        cloud_inputs=list(tagged),
        scope="Caller declarations; equality does not prove exposure/robot-time synchronization",
    )
