"""Optional bounded candidates from spatial plane patches and normal pairs.

Coordinates are normalized by the trained model diagonal. This proposes poses;
it never changes the full-resolution geometric acceptance checks.
"""

from dataclasses import dataclass
from itertools import permutations

import cv2
import numpy as np


@dataclass(frozen=True)
class Patch:
    normal: np.ndarray
    center: np.ndarray
    points: np.ndarray


@dataclass(frozen=True)
class Hypothesis:
    pose: np.ndarray
    error: float
    numVotes: int = 0
    source: str = "planes"


def patches(data, spacing, *, limit=32):
    """Deterministic normal-guided consensus, PCA refit and connected components.

    At most 24 consensus rounds, 256 seed hypotheses/round, 12 neighbors/point,
    and 32 returned patches. Working matrices use blocks of 32 seed hypotheses.
    Oversized support planes are ineligible as object patches; original scene
    points remain available for PPF and final verification.
    """
    data = np.asarray(data, np.float32)
    if (
        data.ndim != 2
        or data.shape[1] != 6
        or not 6 <= len(data) <= 100000
        or not np.isfinite(data).all()
        or not np.allclose(np.linalg.norm(data[:, 3:], axis=1), 1, atol=1e-3)
        or not 0.01 <= spacing <= 0.2
        or type(limit) is not int
        or not 1 <= limit <= 32
    ):
        raise ValueError("Plane analysis requires bounded normalized XYZ/normal samples.")
    index = cv2.flann_Index(data[:, :3].copy(), {"algorithm": 4})
    nn, squared = index.knnSearch(data[:, :3].copy(), min(12, len(data)), params={"checks": -1})
    available, output = np.ones(len(data), bool), []
    rng = np.random.default_rng(0)
    for _ in range(24):
        remain = np.flatnonzero(available)
        if len(remain) < 15:
            break
        seeds = rng.choice(remain, min(256, len(remain)), replace=False)
        normals = data[seeds, 3:]
        offsets = np.einsum("ij,ij->i", data[seeds, :3], normals)
        counts = []
        for start in range(0, len(seeds), 32):
            delta = abs(
                data[remain, :3] @ normals[start : start + 32].T - offsets[start : start + 32]
            )
            support = (delta < spacing * 0.5) & (
                data[remain, 3:] @ normals[start : start + 32].T > 0.94
            )
            counts.extend(support.sum(axis=0))
        best = seeds[int(np.argmax(counts))]
        if max(counts) < 15:
            break
        normal, center = data[best, 3:].astype(float), data[best, :3].astype(float)
        selected = np.zeros(len(data), bool)
        for _ in range(3):
            selected = (
                available
                & (abs((data[:, :3] - center) @ normal) < spacing * 0.5)
                & (data[:, 3:] @ normal > 0.94)
            )
            if selected.sum() < 15:
                break
            points = data[selected, :3].astype(float)
            center = np.median(points, axis=0)
            _, _, axes = np.linalg.svd(points - center, full_matrices=False)
            fitted = axes[-1]
            normal = fitted * (1 if fitted @ normal >= 0 else -1)
        ids = np.flatnonzero(selected)
        available[ids] = False
        unvisited = selected.copy()
        for seed in ids:
            if not unvisited[seed]:
                continue
            component, queue = [], [seed]
            unvisited[seed] = False
            for point in queue:
                component.append(point)
                neighbors = nn[point][
                    (squared[point] < (spacing * 2.5) ** 2) & unvisited[nn[point]]
                ]
                unvisited[neighbors] = False
                queue.extend(neighbors.tolist())
            if len(component) < 15:
                continue
            points = data[component, :3].astype(float)
            center = points.mean(axis=0)
            _, singular, axes = np.linalg.svd(points - center, full_matrices=False)
            # Exclude line-like patches and planes larger than the model scale.
            if (
                singular[1] / np.sqrt(len(points)) < spacing
                or singular[0] / np.sqrt(len(points)) > 1
            ):
                continue
            fitted = axes[-1]
            fitted *= 1 if fitted @ normal >= 0 else -1
            for array in (fitted, center, points):
                array.flags.writeable = False
            output.append(Patch(fitted, center, points))
    return tuple(sorted(output, key=lambda p: -len(p.points))[:limit])


def _basis(first, second):
    cross = np.cross(first, second)
    cross /= np.linalg.norm(cross)
    return np.asarray([first, np.cross(cross, first), cross]).T


def hypotheses(model, scene, *, limit=512):
    """Match nonparallel plane pairs, solve rigid poses and cap coarse proposals.

    A pair fixes rotation and two translation components. Patch centroids provide
    the remaining translation along their intersection; ICP must verify/refine it.
    """
    if len(model) > 12 or len(scene) > 32 or type(limit) is not int or not 1 <= limit <= 512:
        raise ValueError("Use at most 12 model patches, 32 scene patches and 512 proposals.")
    if len(model) < 2 or len(scene) < 2:
        return ()
    pairs = list(permutations(scene, 2))
    a, b = np.asarray([p.normal for p, _ in pairs]), np.asarray([p.normal for _, p in pairs])
    first, second = (
        np.asarray([p.center for p, _ in pairs]),
        np.asarray([p.center for _, p in pairs]),
    )
    dot = np.einsum("ij,ij->i", a, b)
    centers = first - second
    local = np.linalg.norm(centers, axis=1) <= 1.1
    result = []
    for one, two in permutations(model, 2):
        model_dot = one.normal @ two.normal
        if abs(model_dot) > 0.8:
            continue
        selected = np.flatnonzero(local & (abs(dot - model_dot) <= 0.15))
        for idx in selected:
            rotation = _basis(a[idx], b[idx]) @ _basis(one.normal, two.normal).T
            cross = np.cross(a[idx], b[idx])
            cross /= np.linalg.norm(cross)
            right = np.asarray(
                [
                    a[idx] @ (first[idx] - rotation @ one.center),
                    b[idx] @ (second[idx] - rotation @ two.center),
                    cross @ ((first[idx] + second[idx] - rotation @ (one.center + two.center)) / 2),
                ]
            )
            translation = np.linalg.solve(np.asarray([a[idx], b[idx], cross]), right)
            pose = np.eye(4)
            pose[:3, :3], pose[:3, 3] = rotation, translation
            error = float(np.linalg.norm(centers[idx] - rotation @ (one.center - two.center)))
            pose.flags.writeable = False
            result.append(Hypothesis(pose, error))
    # Cheap finite-patch consistency precedes bounded coarse surface scoring.
    return tuple(sorted(result, key=lambda candidate: candidate.error)[:limit])
