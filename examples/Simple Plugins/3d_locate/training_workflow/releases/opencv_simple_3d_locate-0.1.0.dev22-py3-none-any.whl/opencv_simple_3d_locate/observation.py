"""Single-view first-surface observations, independent of the GUI host."""

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class Camera:
    matrix: np.ndarray
    size: tuple
    units: str = "mm"
    frame: str = "camera"

    def __post_init__(self):
        from .model import _identity

        _identity(self.units, self.frame)
        matrix = np.asarray(self.matrix, float).copy()
        if (
            matrix.shape != (3, 3)
            or not np.isfinite(matrix).all()
            or matrix[0, 0] <= 0
            or matrix[1, 1] <= 0
            or not np.allclose(matrix[2], [0, 0, 1])
            or abs(matrix[0, 1]) > 1e-9
            or abs(matrix[1, 0]) > 1e-9
        ):
            raise ValueError("Supply a rectified pinhole camera with positive focal lengths.")
        if len(self.size) != 2 or any(type(x) is not int or not 1 <= x <= 10000 for x in self.size):
            raise ValueError("Camera image size requires integer width/height in 1..10000.")
        matrix.flags.writeable = False
        object.__setattr__(self, "matrix", matrix)
        object.__setattr__(self, "size", tuple(self.size))

    @classmethod
    def from_record(cls, value):
        if isinstance(value, cls):
            return value
        if (
            not isinstance(value, dict)
            or value.get("model") != "camera_model_v1"
            or value.get("lens", "pinhole") != "pinhole"
            or np.any(np.asarray(value.get("distortion", []), float) != 0)
        ):
            raise ValueError("Connect a rectified pinhole camera_model_v1 (zero distortion).")
        return cls(
            value["camera_matrix"], tuple(value["image_size"]), value["units"], value["frame"]
        )

    def record(self):
        return {
            "model": "camera_model_v1",
            "camera_matrix": self.matrix.tolist(),
            "image_size": list(self.size),
            "units": self.units,
            "frame": self.frame,
            "lens": "pinhole",
            "distortion": [],
        }

    def backproject(self, depth, *, scale=1.0):
        """One XYZ point per valid depth pixel; depth is optical-axis Z, not ray range."""
        depth = np.asarray(depth)
        if depth.shape != (self.size[1], self.size[0]) or not np.isfinite(scale) or scale <= 0:
            raise ValueError("Depth dimensions must match the camera; use a positive finite scale.")
        v, u = np.nonzero(np.isfinite(depth) & (depth > 0))
        z = depth[v, u].astype(float) * scale
        x = (u - self.matrix[0, 2]) * z / self.matrix[0, 0]
        y = (v - self.matrix[1, 2]) * z / self.matrix[1, 1]
        return np.ascontiguousarray(np.c_[x, y, z], np.float32)


def first_surface(points, *, camera=None, viewpoint=(0, 0, 0), spacing=1.0, slack=0.0):
    """Point z-buffer. Calibrated pixels, or approximate angular bins without intrinsics.

    slack=0 retains exactly one nearest return per pixel/ray bin. Positive slack
    accounts for sparse model sampling during visibility scoring, not acquisition.
    """
    xyz = np.asarray(points, float)[:, :3]
    delta = xyz - (np.zeros(3) if camera else np.asarray(viewpoint))
    ranges = np.linalg.norm(delta, axis=1)
    valid = ranges > 1e-9
    if camera:
        valid &= delta[:, 2] > 1e-9
        z = np.maximum(delta[:, 2], 1e-9)
        u = np.rint(camera.matrix[0, 0] * delta[:, 0] / z + camera.matrix[0, 2])
        v = np.rint(camera.matrix[1, 1] * delta[:, 1] / z + camera.matrix[1, 2])
        valid &= (u >= 0) & (u < camera.size[0]) & (v >= 0) & (v < camera.size[1])
        # A model sample represents a surface patch; acquisition uses exact pixels.
        footprint = (
            max(
                1.0,
                min(camera.matrix[0, 0], camera.matrix[1, 1])
                * spacing
                / max(np.median(z[valid]) if valid.any() else 1, 1e-9),
            )
            if slack
            else 1.0
        )
        cells = np.c_[np.floor(u / footprint), np.floor(v / footprint)]
        depths = delta[:, 2]
    else:
        step = np.clip(
            spacing / max(np.median(ranges[valid]) if valid.any() else 1, 1e-9), 1e-7, 0.2
        )
        azimuth = np.arctan2(delta[:, 1], delta[:, 0])
        elevation = np.arctan2(delta[:, 2], np.hypot(delta[:, 0], delta[:, 1]))
        cells = np.floor(np.c_[azimuth, elevation] / step)
        depths = ranges
    ids = np.flatnonzero(valid)
    result = np.zeros(len(xyz), bool)
    if not len(ids):
        return result
    _, groups = np.unique(cells[ids].astype(np.int64), axis=0, return_inverse=True)
    nearest = np.full(groups.max() + 1, np.inf)
    np.minimum.at(nearest, groups, depths[ids])
    if slack:
        result[ids] = depths[ids] <= nearest[groups] + slack
    else:
        order = np.lexsort((ids, depths[ids], groups))
        ordered = ids[order]
        result[ordered[np.r_[True, np.diff(groups[order]) != 0]]] = True
    return result


@dataclass(frozen=True)
class Observation:
    center: np.ndarray
    diameter: float
    viewpoint: tuple
    spacing: float
    camera: Camera | None

    def visible(self, aligned):
        xyz = aligned[:, :3] * self.diameter + self.center
        view = np.zeros(3) if self.camera else np.asarray(self.viewpoint)
        facing = np.einsum("ij,ij->i", aligned[:, 3:], view - xyz) > 0
        visible = np.zeros(len(aligned), bool)
        # Back-facing surfaces cannot occlude front-facing ones in a closed, oriented model.
        visible[facing] = first_surface(
            xyz[facing],
            camera=self.camera,
            viewpoint=view,
            spacing=self.spacing,
            slack=self.spacing,
        )
        return visible
