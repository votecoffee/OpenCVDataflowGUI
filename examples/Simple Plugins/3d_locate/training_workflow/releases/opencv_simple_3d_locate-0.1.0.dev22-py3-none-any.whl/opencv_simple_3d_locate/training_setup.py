"""Training-only crop displays and bounded worker jobs; matching is unchanged."""

from concurrent.futures import CancelledError
from itertools import product

import numpy as np
from opencv_dataflow.pointclouds import PointCloud

from . import Locator, train, train_cad


def crop_selection(reference, low, high):
    low, high = np.asarray(low, float), np.asarray(high, float)
    if (
        low.shape != (3,)
        or high.shape != (3,)
        or not np.isfinite([low, high]).all()
        or np.any(low >= high)
    ):
        raise ValueError("Enter minimum and maximum XYZ triples with increasing finite bounds.")
    if np.max(np.abs([low, high])) > np.finfo(np.float32).max:
        raise ValueError("Crop bounds exceed float32 cloud coordinates.")
    return np.all((reference.points >= low) & (reference.points <= high), axis=1)


def crop_display(reference, low, high):
    """Color real source points and a separately identified, derived bounds glyph.

    Display sampling is bounded and balanced by category. Training/crop selection
    always uses all source points; the orange bounds samples never train a model.
    """
    keep = crop_selection(reference, low, high)
    points, colors = [], []
    for selected, color in ((keep, [40, 220, 230]), (~keep, [105, 105, 105])):
        indices = np.flatnonzero(selected)
        if len(indices) > 9000:
            indices = indices[np.linspace(0, len(indices) - 1, 9000, dtype=int)]
        points.append(reference.points[indices])
        colors.append(np.tile(color, (len(indices), 1)))
    corners = np.array(list(product(*zip(low, high))), dtype=float)
    edges = [
        np.linspace(a, b, 20)
        for i, a in enumerate(corners)
        for b in corners[i + 1 :]
        if np.count_nonzero(a != b) == 1
    ]
    bounds = np.concatenate(edges)
    points.append(bounds)
    colors.append(np.tile([255, 170, 35], (len(bounds), 1)))
    return PointCloud(
        np.concatenate(points),
        reference.units,
        reference.frame,
        colors=np.concatenate(colors).astype(np.uint8),
    ), keep


def _check(cancelled):
    if cancelled():
        raise CancelledError("3D training/test job cancelled.")


def prepare_model(reference, cad, common, count, seed, cancelled):
    _check(cancelled)
    recipe = (
        train(reference, **common)
        if cad is None
        else train_cad(
            cad.mesh,
            count=count,
            seed=seed,
            **common,
        )
    )
    _check(cancelled)
    locator = Locator(recipe)
    _check(cancelled)
    health = recipe.health
    _check(cancelled)
    return recipe, locator, health


def compile_model(recipe, cancelled):
    _check(cancelled)
    locator = Locator(recipe)
    _check(cancelled)
    return locator


def test_model(recipe, locator, scene, options, cancelled):
    _check(cancelled)
    if locator is None:
        locator = Locator(recipe)
    _check(cancelled)
    result = locator.locate(scene, **options)
    _check(cancelled)
    return locator, result
