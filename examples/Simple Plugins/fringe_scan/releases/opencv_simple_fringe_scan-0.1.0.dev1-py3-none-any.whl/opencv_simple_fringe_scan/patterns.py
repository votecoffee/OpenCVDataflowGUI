"""Explicit projector pixels, complementary Gray ordering and N-step phase patterns."""

from dataclasses import dataclass

import numpy as np


def frozen(value, dtype=None):
    result = np.array(value, dtype=dtype, order="C", copy=True)
    result.flags.writeable = False
    return result


def size_pair(value):
    result = tuple(value)
    if len(result) != 2 or any(type(v) is not int or not 2 <= v <= 8192 for v in result):
        raise ValueError("Declare bounded projector width and height in pixels")
    return result


@dataclass(frozen=True)
class PatternPlan:
    projector_size: tuple
    period_px: tuple = (16.0, 16.0)
    phase_steps: int = 4

    def __post_init__(self):
        size = size_pair(self.projector_size)
        period = np.asarray(self.period_px)
        if (
            period.dtype.kind not in "iuf"
            or period.shape != (2,)
            or not (np.isfinite(period).all() and np.all((period >= 4) & (period <= 32768)))
        ):
            raise ValueError("Use two phase periods of 4..32768 projector pixels")
        if type(self.phase_steps) is not int or not 3 <= self.phase_steps <= 32:
            raise ValueError("Use 3..32 evenly spaced phase steps")
        if size[0] * size[1] * len(self.pattern_ids) > 16_000_000:
            raise ValueError("Generated pattern stack exceeds 16 million samples")
        object.__setattr__(self, "projector_size", size)
        object.__setattr__(self, "period_px", tuple(float(v) for v in period))

    @property
    def gray_ids(self):
        return tuple(
            f"gray:{axis}:{bit}:{polarity}"
            for axis, extent in zip(("x", "y"), self.projector_size)
            for bit in range((extent - 1).bit_length() - 1, -1, -1)
            for polarity in ("positive", "inverse")
        )

    @property
    def pattern_ids(self):
        return (
            ("black", "white")
            + self.gray_ids
            + tuple(
                f"phase:{axis}:{index}" for axis in ("x", "y") for index in range(self.phase_steps)
            )
        )

    @property
    def phase_angles(self):
        return np.arange(self.phase_steps, dtype=np.float64) * (2 * np.pi / self.phase_steps)


def generate(plan, *, gray_backend="auto"):
    if not isinstance(plan, PatternPlan):
        raise ValueError("Use a validated projector PatternPlan")
    if gray_backend not in ("auto", "opencv", "numpy"):
        raise ValueError("Choose auto, opencv or numpy for Gray pattern generation")
    width, height = plan.projector_size
    xx, yy = np.meshgrid(np.arange(width), np.arange(height))
    planes = [np.zeros((height, width), np.uint8), np.full((height, width), 255, np.uint8)]
    import cv2

    native_available = hasattr(cv2, "structured_light")
    if gray_backend == "opencv" and not native_available:
        raise ValueError("This OpenCV build lacks optional structured_light contrib")
    if gray_backend != "numpy" and native_available:
        native = cv2.structured_light.GrayCodePattern_create(width, height)
        okay, gray_patterns = native.generate()
        if not okay or len(gray_patterns) != len(plan.gray_ids):
            raise ValueError("OpenCV Gray generator did not return the declared pattern count")
        planes.extend(gray_patterns)
    else:
        for coordinate, extent in ((xx, width), (yy, height)):
            gray = coordinate ^ (coordinate >> 1)
            for bit in range((extent - 1).bit_length() - 1, -1, -1):
                positive = (((gray >> bit) & 1) * 255).astype(np.uint8)
                planes.extend((positive, 255 - positive))
    for coordinate, period in zip((xx, yy), plan.period_px):
        for shift in plan.phase_angles:
            planes.append(
                np.rint(127.5 * (1 + np.cos(2 * np.pi * coordinate / period + shift))).astype(
                    np.uint8
                )
            )
    return frozen(np.stack(planes))


@dataclass(frozen=True)
class Capture:
    plan: PatternPlan
    images: np.ndarray
    observed_ids: tuple
    capture_id: str
    pixel_grid: str
    response: str
    exposure_s: float
    mask: np.ndarray | None = None

    def __post_init__(self):
        if (
            not isinstance(self.plan, PatternPlan)
            or tuple(self.observed_ids) != self.plan.pattern_ids
        ):
            raise ValueError("Capture IDs/order must exactly match the entire projected plan")
        if self.response != "linear":
            raise ValueError("Declare linear camera response; gamma correction is not inferred")
        if type(self.exposure_s) not in (int, float) or not (
            np.isfinite(self.exposure_s) and 0 < self.exposure_s <= 3600
        ):
            raise ValueError("Declare a common positive exposure in seconds for the complete stack")
        if any(
            not isinstance(v, str) or not 0 < len(v.strip()) <= 128
            for v in (self.capture_id, self.pixel_grid)
        ):
            raise ValueError("Name the capture group and original camera pixel grid")
        raw = np.asarray(self.images)
        if (
            raw.dtype.str not in ("<f4", "<f8")
            or raw.ndim != 3
            or (
                raw.shape[0] != len(self.observed_ids)
                or min(raw.shape[1:]) < 2
                or max(raw.shape[1:]) > 16384
                or raw.size > 16_000_000
            )
        ):
            raise ValueError("Use a bounded N×H×W normalized floating monochrome stack")
        if np.any(np.isfinite(raw) & ((raw < 0) | (raw > 1))):
            raise ValueError("Source codes must be in 0..1; nonfinite samples stay unavailable")
        mask = np.ones(raw.shape[1:], bool)
        if self.mask is not None:
            mask = np.asarray(self.mask)
            if mask.shape != raw.shape[1:] or mask.dtype.kind not in "bui" or np.any(mask < 0):
                raise ValueError("Inspection mask must match the original camera pixels")
            mask = mask != 0
        object.__setattr__(self, "images", frozen(raw))
        object.__setattr__(self, "observed_ids", tuple(self.observed_ids))
        object.__setattr__(self, "mask", frozen(mask, bool))
