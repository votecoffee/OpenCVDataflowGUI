"""N-step diffuse sinusoidal fit; wrapped phase never implies absolute depth."""

from dataclasses import dataclass

import numpy as np

from .patterns import frozen

PHASE_REASONS = (
    "valid",
    "outside_roi",
    "nonfinite",
    "input_ceiling",
    "low_modulation",
    "poor_sinusoidal_fit",
)


@dataclass(frozen=True)
class PhaseSettings:
    minimum_amplitude: float = 0.03
    maximum_relative_rms: float = 0.15
    input_ceiling: float = 1.0

    def __post_init__(self):
        for name in ("minimum_amplitude", "maximum_relative_rms", "input_ceiling"):
            value = getattr(self, name)
            if type(value) not in (int, float) or not np.isfinite(value) or not 0 < value <= 1:
                raise ValueError("Use a finite positive " + name + " at most one")


@dataclass(frozen=True)
class PhaseResult:
    wrapped: np.ndarray
    amplitude: np.ndarray
    background: np.ndarray
    relative_rms: np.ndarray
    valid: np.ndarray
    reason: np.ndarray
    steps: tuple


def demodulate(images, phase_angles, *, settings=None, mask=None):
    settings = settings or PhaseSettings()
    if not isinstance(settings, PhaseSettings):
        raise ValueError("Use validated phase settings")
    raw, angles = np.asarray(images), np.asarray(phase_angles)
    if (
        raw.ndim != 3
        or raw.dtype.kind != "f"
        or not 3 <= raw.shape[0] <= 32
        or (min(raw.shape[1:]) < 2 or raw.size > 16_000_000 or max(raw.shape[1:]) > 16384)
    ):
        raise ValueError("Use a bounded normalized N×H×W floating phase stack")
    if (
        angles.dtype.kind not in "iuf"
        or angles.shape != (len(raw),)
        or not np.isfinite(angles).all()
    ):
        raise ValueError("Declare one finite phase shift in radians per observed image")
    design = np.c_[np.ones(len(angles)), np.cos(angles), np.sin(angles)]
    singular = np.linalg.svd(design, compute_uv=False)
    if singular[-1] / singular[0] < 1e-3:
        raise ValueError("Phase steps must independently constrain background, cosine and sine")
    finite = np.isfinite(raw)
    if np.any(finite & ((raw < 0) | (raw > 1))):
        raise ValueError("Phase source codes must be normalized to 0..1")
    selected = np.ones(raw.shape[1:], bool)
    if mask is not None:
        candidate = np.asarray(mask)
        if (
            candidate.shape != selected.shape
            or candidate.dtype.kind not in "bui"
            or (np.any(candidate < 0))
        ):
            raise ValueError("Phase mask must match source pixels")
        selected = candidate != 0
    available = finite.all(axis=0) & (raw < settings.input_ceiling).all(axis=0)
    values = np.where(finite, raw, 0).astype(np.float64).reshape(len(raw), -1)
    parameters = np.linalg.pinv(design) @ values
    amplitude = np.hypot(parameters[1], parameters[2]).reshape(selected.shape)
    phase = np.mod(np.arctan2(-parameters[2], parameters[1]), 2 * np.pi).reshape(selected.shape)
    rms = np.sqrt(np.mean((design @ parameters - values) ** 2, axis=0)).reshape(selected.shape)
    relative = rms / np.maximum(amplitude, 1e-12)
    reason = np.zeros(selected.shape, np.uint8)
    reason[relative > settings.maximum_relative_rms] = 5
    reason[amplitude < settings.minimum_amplitude] = 4
    reason[(raw >= settings.input_ceiling).any(axis=0)] = 3
    reason[~finite.all(axis=0)] = 2
    reason[~selected] = 1
    valid = selected & available & (reason == 0)
    phase[~valid] = np.nan
    background = parameters[0].reshape(selected.shape)
    # Preserve useful evidence, but never display a fabricated fit for missing observations.
    for array in (amplitude, background, relative):
        array[~available | ~selected] = np.nan
    return PhaseResult(
        *(frozen(v) for v in (phase, amplitude, background, relative, valid, reason)),
        tuple(float(v) for v in angles),
    )
