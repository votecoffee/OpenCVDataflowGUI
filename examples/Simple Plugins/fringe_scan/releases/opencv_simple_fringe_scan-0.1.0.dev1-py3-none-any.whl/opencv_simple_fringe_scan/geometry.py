"""Known camera/projector calibration, metric ray evidence and unavailable correspondences."""

from dataclasses import dataclass

import cv2
import numpy as np

from .patterns import frozen

GEOMETRY_REASONS = (
    "valid",
    "unavailable_correspondence",
    "outside_image",
    "undistort_failed",
    "poor_ray_angle",
    "behind_device",
    "outside_depth_range",
    "ray_gap",
    "reprojection_error",
)


def numeric(value, shape, label):
    raw = np.asarray(value)
    if raw.dtype.kind not in "iuf" or raw.shape != shape or not np.isfinite(raw).all():
        raise ValueError("Declare finite numeric " + label)
    return frozen(raw, np.float64)


@dataclass(frozen=True)
class Pinhole:
    matrix: np.ndarray
    image_size: tuple
    frame: str
    distortion: tuple = ()

    def __post_init__(self):
        matrix = numeric(self.matrix, (3, 3), "pinhole intrinsics")
        size = tuple(self.image_size)
        if min(matrix[0, 0], matrix[1, 1]) <= 0 or not np.allclose(
            matrix[[0, 1, 2, 2, 2], [1, 0, 0, 1, 2]], [0, 0, 0, 0, 1], atol=1e-12, rtol=0
        ):
            raise ValueError("Use positive pinhole focal lengths and zero skew")
        if len(size) != 2 or any(type(v) is not int or not 2 <= v <= 16384 for v in size):
            raise ValueError("Declare bounded original source width and height")
        coefficients = np.asarray(self.distortion)
        if coefficients.ndim != 1 or len(coefficients) not in (0, 4, 5, 8, 12, 14):
            raise ValueError("Use supported OpenCV pinhole distortion coefficients")
        coefficients = numeric(coefficients, coefficients.shape, "distortion coefficients")
        if not isinstance(self.frame, str) or not 0 < len(self.frame.strip()) <= 128:
            raise ValueError("Name the physical device frame")
        object.__setattr__(self, "matrix", matrix)
        object.__setattr__(self, "image_size", size)
        object.__setattr__(self, "distortion", tuple(coefficients))


@dataclass(frozen=True)
class Calibration:
    camera: Pinhole
    projector: Pinhole
    rotation_cp: np.ndarray
    translation_cp_m: np.ndarray

    def __post_init__(self):
        if not isinstance(self.camera, Pinhole) or not isinstance(self.projector, Pinhole):
            raise ValueError("Retain both camera and projector pinhole models")
        if self.camera.frame == self.projector.frame:
            raise ValueError("Name distinct camera and projector physical frames")
        rotation = numeric(self.rotation_cp, (3, 3), "camera-to-projector rotation")
        translation = numeric(
            self.translation_cp_m, (3,), "camera-to-projector translation in meters"
        )
        if not np.allclose(rotation.T @ rotation, np.eye(3), atol=1e-8, rtol=0) or not (
            np.isclose(np.linalg.det(rotation), 1, atol=1e-8, rtol=0)
        ):
            raise ValueError("Use a proper rigid rotation, not reflection or scale")
        if not 1e-6 <= np.linalg.norm(translation) <= 100:
            raise ValueError("Declare a nonzero metric camera/projector baseline within 100 m")
        object.__setattr__(self, "rotation_cp", rotation)
        object.__setattr__(self, "translation_cp_m", translation)


@dataclass(frozen=True)
class GeometrySettings:
    minimum_ray_angle_deg: float = 0.25
    maximum_ray_gap_m: float = 0.0005
    maximum_reprojection_px: float = 0.75
    minimum_depth_m: float = 0.001
    maximum_depth_m: float = 100.0

    def __post_init__(self):
        for name, maximum in (
            ("minimum_ray_angle_deg", 90),
            ("maximum_ray_gap_m", 100),
            ("maximum_reprojection_px", 100),
            ("minimum_depth_m", 100),
            ("maximum_depth_m", 100),
        ):
            value = getattr(self, name)
            if (
                type(value) not in (int, float)
                or not np.isfinite(value)
                or not 0 < value <= maximum
            ):
                raise ValueError("Bound the finite positive " + name)
        if self.minimum_depth_m >= self.maximum_depth_m:
            raise ValueError("Use ordered positive axial depth limits")


def rays(device, pixels):
    distortion = np.asarray(device.distortion) if device.distortion else None
    criteria = (cv2.TERM_CRITERIA_COUNT | cv2.TERM_CRITERIA_EPS, 50, 1e-12)
    if hasattr(cv2, "undistortPointsIter"):
        uv = cv2.undistortPointsIter(
            pixels[:, None], device.matrix, distortion, None, None, criteria
        )[:, 0]
    else:
        uv = cv2.undistortPoints(pixels[:, None], device.matrix, distortion, criteria=criteria)[
            :, 0
        ]
    vector = np.c_[uv, np.ones(len(uv))]
    return vector / np.linalg.norm(vector, axis=1, keepdims=True)


def project(device, points):
    return cv2.projectPoints(
        points,
        np.zeros(3),
        np.zeros(3),
        device.matrix,
        np.asarray(device.distortion) if device.distortion else None,
    )[0][:, 0]


def triangulate(calibration, camera_pixels, projector_pixels, settings=None):
    if not isinstance(calibration, Calibration):
        raise ValueError("Metric reconstruction requires known camera/projector calibration")
    settings = settings or GeometrySettings()
    if not isinstance(settings, GeometrySettings):
        raise ValueError("Use validated triangulation settings")
    observed = [np.asarray(value) for value in (camera_pixels, projector_pixels)]
    if (
        any(v.dtype.kind not in "iuf" or v.ndim != 2 or v.shape[1:] != (2,) for v in observed)
        or observed[0].shape != observed[1].shape
        or len(observed[0]) > 1_000_000
    ):
        raise ValueError("Use up to one million aligned camera/projector pixel pairs")
    count = len(observed[0])
    output = dict(
        xyz_m=np.full((count, 3), np.nan),
        reason=np.zeros(count, np.uint8),
        ray_angle_deg=np.full(count, np.nan),
        ray_gap_m=np.full(count, np.nan),
        camera_error_px=np.full(count, np.nan),
        projector_error_px=np.full(count, np.nan),
    )
    reason = output["reason"]
    finite = np.isfinite(observed[0]).all(axis=1) & np.isfinite(observed[1]).all(axis=1)
    reason[~finite] = 1
    for pixels, device in zip(observed, (calibration.camera, calibration.projector)):
        inside = np.all((pixels >= -0.5) & (pixels < np.array(device.image_size) - 0.5), axis=1)
        reason[finite & ~inside] = 2
    ids = np.flatnonzero(reason == 0)
    if len(ids):
        camera = rays(calibration.camera, observed[0][ids].astype(np.float64))
        projector = rays(calibration.projector, observed[1][ids].astype(np.float64))
        # X_projector = R_cp @ X_camera + t_cp; all geometry is computed in camera meters.
        projector = projector @ calibration.rotation_cp
        center = -calibration.rotation_cp.T @ calibration.translation_cp_m
        dot = np.einsum("ij,ij->i", camera, projector)
        angle = np.degrees(np.arccos(np.clip(np.abs(dot), 0, 1)))
        stable_angle = np.isfinite(angle) & (angle >= settings.minimum_ray_angle_deg)
        # Reject parallel geometry before dividing; a tiny denominator is not measured depth.
        denominator = np.where(stable_angle, 1 - dot * dot, 1.0)
        ca, cb = camera @ center, projector @ center
        a, b = (ca - dot * cb) / denominator, (dot * ca - cb) / denominator
        first, second = a[:, None] * camera, center + b[:, None] * projector
        point = (first + second) * 0.5
        gap = np.linalg.norm(first - second, axis=1)
        numerical = np.isfinite(point).all(axis=1) & np.isfinite(gap)
        local = np.zeros(len(ids), np.uint8)
        local[~np.isfinite(angle)] = 3
        local[(local == 0) & ~stable_angle] = 4
        local[(local == 0) & ~numerical] = 3
        gap[~stable_angle] = np.nan
        point_p = point @ calibration.rotation_cp.T + calibration.translation_cp_m
        local[(local == 0) & ((point[:, 2] <= 0) | (point_p[:, 2] <= 0) | (a <= 0) | (b <= 0))] = 5
        local[
            (local == 0)
            & ((point[:, 2] < settings.minimum_depth_m) | (point[:, 2] > settings.maximum_depth_m))
        ] = 6
        local[(local == 0) & (gap > settings.maximum_ray_gap_m)] = 7
        safe = np.flatnonzero(stable_angle & numerical & (point[:, 2] != 0) & (point_p[:, 2] != 0))
        error_c, error_p = np.full(len(ids), np.nan), np.full(len(ids), np.nan)
        if len(safe):
            error_c[safe] = np.linalg.norm(
                project(calibration.camera, point[safe]) - observed[0][ids[safe]], axis=1
            )
            error_p[safe] = np.linalg.norm(
                project(calibration.projector, point_p[safe]) - observed[1][ids[safe]], axis=1
            )
        local[
            (local == 0)
            & (
                ~np.isfinite(error_c)
                | ~np.isfinite(error_p)
                | (error_c > settings.maximum_reprojection_px)
                | (error_p > settings.maximum_reprojection_px)
            )
        ] = 8
        reason[ids] = local
        output["xyz_m"][ids[local == 0]] = point[local == 0]
        for name, value in (
            ("ray_angle_deg", angle),
            ("ray_gap_m", gap),
            ("camera_error_px", error_c),
            ("projector_error_px", error_p),
        ):
            output[name][ids] = value
    output.update(
        valid=reason == 0,
        camera_pixels=frozen(observed[0], np.float64),
        projector_pixels=frozen(observed[1], np.float64),
    )
    output = {name: frozen(value) for name, value in output.items()}
    output["report"] = dict(
        schema="simple_fringe_geometry/v1",
        frame=calibration.camera.frame,
        units="m",
        transform="X_projector = R_cp @ X_camera + translation_cp_m",
        samples=count,
        valid_samples=int(output["valid"].sum()),
        reason_counts={
            name: int((reason == i).sum())
            for i, name in enumerate(GEOMETRY_REASONS)
            if np.any(reason == i)
        },
        scope="Known-calibration ray fit; residuals do not qualify physical measurement accuracy",
    )
    return output
