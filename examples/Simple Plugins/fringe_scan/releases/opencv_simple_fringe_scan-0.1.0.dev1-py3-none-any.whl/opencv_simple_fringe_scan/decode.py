"""Complementary Gray decoding and per-pixel absolute phase order from coarse codes."""

from dataclasses import dataclass, field

import numpy as np

from .patterns import Capture, frozen
from .phase import PhaseSettings, demodulate

REASONS = (
    "valid",
    "outside_roi",
    "nonfinite",
    "input_ceiling",
    "not_illuminated",
    "weak_gray_pair",
    "projector_code_outside",
    "weak_phase",
    "poor_phase_fit",
    "gray_phase_disagreement",
)


@dataclass(frozen=True)
class DecodeSettings:
    minimum_illumination: float = 0.08
    minimum_gray_contrast: float = 0.15
    maximum_gray_phase_error_px: float = 0.75
    phase: PhaseSettings = field(default_factory=PhaseSettings)

    def __post_init__(self):
        for name, limit in (
            ("minimum_illumination", 1),
            ("minimum_gray_contrast", 1),
            ("maximum_gray_phase_error_px", 1),
        ):
            value = getattr(self, name)
            if type(value) not in (int, float) or not np.isfinite(value) or not 0 < value <= limit:
                raise ValueError("Bound the finite positive " + name)
        if not isinstance(self.phase, PhaseSettings):
            raise ValueError("Use validated phase settings")


@dataclass(frozen=True)
class DecodeResult:
    projector_pixels: np.ndarray
    coarse_pixels: np.ndarray
    wrapped_phase: np.ndarray
    amplitude: np.ndarray
    relative_rms: np.ndarray
    minimum_gray_contrast: np.ndarray
    gray_phase_error_px: np.ndarray
    valid: np.ndarray
    reason: np.ndarray
    report: dict


def decode(capture, settings=None, *, cancelled=lambda: False):
    if not isinstance(capture, Capture):
        raise ValueError("Use an ordered, validated projected-pattern capture")
    settings = settings or DecodeSettings()
    if not isinstance(settings, DecodeSettings):
        raise ValueError("Use validated structured-light decode settings")
    if cancelled():
        raise RuntimeError("Fringe decode cancelled; no result published")
    raw, plan = capture.images, capture.plan
    shape = raw.shape[1:]
    illumination = raw[1] - raw[0]
    reason = np.zeros(shape, np.uint8)
    reason[illumination < settings.minimum_illumination] = 4
    coarse, coordinates, phases, amplitudes, rms, errors = [], [], [], [], [], []
    minimum_contrast = np.full(shape, np.inf)
    index = 2
    for extent in plan.projector_size:
        value, binary = np.zeros(shape, np.uint16), np.zeros(shape, bool)
        for bit in range((extent - 1).bit_length() - 1, -1, -1):
            difference = raw[index] - raw[index + 1]
            contrast = np.abs(difference) / np.maximum(illumination, 1e-12)
            minimum_contrast = np.minimum(minimum_contrast, contrast)
            reason[(reason == 0) & (contrast < settings.minimum_gray_contrast)] = 5
            binary ^= difference > 0
            value |= binary.astype(np.uint16) << bit
            index += 2
        coarse.append(value)
        reason[(reason == 0) & (value >= extent)] = 6
    for axis, (extent, period) in enumerate(zip(plan.projector_size, plan.period_px)):
        fit = demodulate(
            raw[index : index + plan.phase_steps],
            plan.phase_angles,
            settings=settings.phase,
            mask=capture.mask,
        )
        index += plan.phase_steps
        phases.append(fit.wrapped)
        amplitudes.append(fit.amplitude)
        rms.append(fit.relative_rms)
        reason[(reason == 0) & (fit.reason == 4)] = 7
        reason[(reason == 0) & (fit.reason == 5)] = 8
        fractional = fit.wrapped * (period / (2 * np.pi))
        # Coarse projector pixels identify the nearest period independently at every pixel.
        order = np.rint((coarse[axis].astype(np.float64) - fractional) / period)
        absolute = fractional + order * period
        error = np.abs(absolute - coarse[axis])
        errors.append(error)
        coordinates.append(absolute)
        reason[(reason == 0) & (error > settings.maximum_gray_phase_error_px)] = 9
        # Integer coordinates name pixel centers; half-pixel borders bound the illuminated field.
        # Keep small signed phase errors at pixel zero rather than clamping measured evidence.
        reason[(reason == 0) & ((absolute < -0.5) | (absolute >= extent - 0.5))] = 6
        if cancelled():
            raise RuntimeError("Fringe decode cancelled; no result published")
    reason[(raw >= settings.phase.input_ceiling).any(axis=0)] = 3
    reason[~np.isfinite(raw).all(axis=0)] = 2
    reason[~capture.mask] = 1
    valid = reason == 0
    pixels = np.stack(coordinates, axis=-1)
    # An unavailable phase can otherwise propagate NaN comparisons without setting a reason.
    bad = valid & ~np.isfinite(pixels).all(axis=-1)
    reason[bad], valid[bad] = 8, False
    pixels[~valid] = np.nan
    active = int(capture.mask.sum())
    report = dict(
        schema="simple_fringe_decode/v1",
        capture_id=capture.capture_id,
        pixel_grid=capture.pixel_grid,
        image_size=list(shape[::-1]),
        projector_size=list(plan.projector_size),
        valid_pixels=int(valid.sum()),
        active_pixels=active,
        coverage=float(valid.sum() / max(1, active)),
        phase_steps=plan.phase_steps,
        no_phase_redundancy=plan.phase_steps == 3,
        reason_counts={
            name: int((reason == i).sum()) for i, name in enumerate(REASONS) if np.any(reason == i)
        },
        scope="Decoded projector correspondence, not metric height or verified acquisition timing",
    )
    return DecodeResult(
        *(
            frozen(value)
            for value in (
                pixels,
                np.stack(coarse, axis=-1),
                np.stack(phases, axis=-1),
                np.stack(amplitudes, axis=-1),
                np.stack(rms, axis=-1),
                minimum_contrast,
                np.stack(errors, axis=-1),
                valid,
                reason,
            )
        ),
        report,
    )
