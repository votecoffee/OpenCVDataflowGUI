"""Bounded NumPy first-return geometry rasterization without RGB shading.

Uses the original sibling CPU renderer's pixel, perspective, near-plane and
edge conventions. Triangle/pixel work is batched; equal-depth ties retain the
earlier face. This is geometry execution, not mesh decimation or scene filling.
"""

import numpy as np

SAMPLE_BUDGET = 131072
BACKEND = "numpy_batched_first_return_v1"


def render_xyz(mesh, pose, camera, transform=None, shape=(160, 160), *, cancelled=lambda: False):
    if cancelled():
        raise RuntimeError("Geometry rendering cancelled; no result published")
    h, w = shape
    if min(h, w) < 1 or h * w > 2_000_000:
        raise ValueError("Bound the raster to 1..2 million pixels")
    vertices = (mesh.vertices - mesh.center) @ pose[:3, :3].T + pose[:3, 3]
    projected = vertices @ camera.T
    projected = projected[:, :2] / np.maximum(projected[:, 2:3], 1e-20)
    if transform is not None:
        projected = np.c_[projected, np.ones(len(projected))] @ transform.T
        projected = projected[:, :2] * 160 / 159 - 0.5
    faces = mesh.faces
    points = vertices[faces]
    valid = np.all(points[:, :, 2] >= 0.1, axis=1)
    points, pixels = points[valid], projected[faces[valid]]
    low = np.maximum(0, np.ceil(pixels.min(axis=1))).astype(np.int64)
    high = np.minimum([w - 1, h - 1], np.floor(pixels.max(axis=1))).astype(np.int64)
    a, b, c = pixels[:, 0], pixels[:, 1], pixels[:, 2]
    denominator = (b[:, 1] - c[:, 1]) * (a[:, 0] - c[:, 0]) + (c[:, 0] - b[:, 0]) * (
        a[:, 1] - c[:, 1]
    )
    valid = np.all(high >= low, axis=1) & (np.abs(denominator) >= 1e-12)
    points, a, b, c, denominator, low, high = (
        value[valid] for value in (points, a, b, c, denominator, low, high)
    )
    widths = high[:, 0] - low[:, 0] + 1
    areas = widths * (high[:, 1] - low[:, 1] + 1)
    ends = np.cumsum(areas)
    starts = ends - areas
    zbuffer = np.full(h * w, np.inf, np.float64)
    xyz = np.zeros((h * w, 3), np.float32)
    # Face/pixel ordinals are increasing even when a huge triangle spans chunks.
    for begin in range(0, int(ends[-1]) if len(ends) else 0, SAMPLE_BUDGET):
        if cancelled():
            raise RuntimeError("Geometry rendering cancelled; no result published")
        offsets = np.arange(begin, min(begin + SAMPLE_BUDGET, int(ends[-1])))
        owner = np.searchsorted(ends, offsets, side="right")
        local = offsets - starts[owner]
        x = low[owner, 0] + local % widths[owner]
        y = low[owner, 1] + local // widths[owner]
        aa, bb, cc = a[owner], b[owner], c[owner]
        l0 = (
            (bb[:, 1] - cc[:, 1]) * (x - cc[:, 0]) + (cc[:, 0] - bb[:, 0]) * (y - cc[:, 1])
        ) / denominator[owner]
        l1 = (
            (cc[:, 1] - aa[:, 1]) * (x - cc[:, 0]) + (aa[:, 0] - cc[:, 0]) * (y - cc[:, 1])
        ) / denominator[owner]
        bary = np.stack((l0, l1, 1 - l0 - l1), axis=-1)
        reciprocal = bary / points[owner, :, 2]
        depth = 1 / np.maximum(reciprocal.sum(axis=-1), 1e-20)
        pixel = y * w + x
        inside = (bary.min(axis=-1) >= -1e-8) & (depth < zbuffer[pixel])
        if not inside.any():
            continue
        selected = np.flatnonzero(inside)
        np.minimum.at(zbuffer, pixel[selected], depth[selected])
        selected = selected[depth[selected] == zbuffer[pixel[selected]]]
        # Stable first occurrence chooses the original face order on exact depth ties.
        _, first = np.unique(pixel[selected], return_index=True)
        selected = selected[first]
        weights = reciprocal[selected] * depth[selected, None]
        values = (weights[:, None, :] @ points[owner[selected]])[:, 0, :]
        xyz[pixel[selected]] = values
    return xyz.reshape(h, w, 3)


def visible_fit(mesh, frame, pose, settings, *, cancelled=lambda: False):
    """Keep the existing metric assessment on exactly the same cropped sensor rays."""
    from opencv_simple_foundation_pose.preprocess import crop_transform
    from opencv_simple_foundation_pose.render import fit_evidence

    xyz = render_xyz(
        mesh,
        pose,
        frame.camera,
        crop_transform(pose, mesh.diameter, frame.camera, 1.1),
        cancelled=cancelled,
    )
    return fit_evidence(mesh, frame, pose, settings, rendered=xyz)
