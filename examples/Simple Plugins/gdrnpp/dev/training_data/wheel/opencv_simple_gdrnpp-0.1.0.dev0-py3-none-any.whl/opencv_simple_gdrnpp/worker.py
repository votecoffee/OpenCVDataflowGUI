"""Private, explicitly installed worker endpoint. It never loads code selected by a recipe."""

import argparse
import hashlib
import json
import re
import sys
import time
import uuid
from dataclasses import replace
from pathlib import Path

from .estimate import Detection
from .review import candidate_gallery, review_arrays
from .runtime import TorchModel
from .selection import describe_review
from .setup import Capture, ExecutionSettings, binding, describe, load_recipe, save_recipe
from .wire import read_packet, strict_json, write_packet
from .workflow import create_setup, load_capture, run_recipe


def implementation_digest():
    digest = hashlib.sha256()
    for name in (
        "estimate.py",
        "execution.py",
        "geometry.py",
        "network.py",
        "overlap.py",
        "preprocess.py",
        "refinement.py",
        "review.py",
        "rotation.py",
        "runtime.py",
        "selection.py",
        "setup.py",
        "wire.py",
        "worker.py",
        "workflow.py",
    ):
        digest.update(name.encode() + b"\0" + Path(__file__).with_name(name).read_bytes())
    return digest.hexdigest()


class Service:
    def __init__(self):
        self.model = None
        self.model_key = None
        self.loads = 0
        self.inference_requests = 0
        self.last = None
        self.session = uuid.uuid4().hex
        self.recipe_key = None
        self.recipe_value = None
        self.recipe_hit = False
        self.implementation = implementation_digest()

    @staticmethod
    def model_signatures(models):
        return tuple(
            (s.st_mtime_ns, s.st_size, s.st_ctime_ns)
            for s in [
                (models / name).stat() for name in ("checkpoint.json", "model_final_wo_optim.pth")
            ]
        )

    def ensure_model(self, recipe, model_directory):
        """Publish a cached model only after validation/loading finishes on unchanged files."""
        try:
            models = Path(model_directory).resolve(strict=True)
            signatures = self.model_signatures(models)
            key = (str(models), recipe.settings.threads, signatures)
            if self.model is not None and key == self.model_key:
                return True
            self.model = self.model_key = None
            candidate = TorchModel(models, threads=recipe.settings.threads)
            if self.model_signatures(models) != signatures:
                raise ValueError("Model files changed during resource preparation")
            self.model, self.model_key = candidate, key
            self.loads += 1
            return False
        except BaseException:
            self.model = self.model_key = None
            raise

    def worker_info(self, model_hit):
        return dict(
            session=self.session,
            model_cache_hit=model_hit,
            model_load_count=self.loads,
            recipe_cache_hit=self.recipe_hit,
            implementation_sha256=self.implementation,
            inference_request_count=self.inference_requests,
        )

    def recipe(self, data, arrays):
        base = data["base"]
        if base["kind"] == "recipe":
            path = Path(base["path"]).resolve(strict=True)
            stat = path.stat()
            key = (str(path), base.get("sha256"), stat.st_mtime_ns, stat.st_size, stat.st_ctime_ns)
            self.recipe_hit = key == self.recipe_key
            if not self.recipe_hit:
                self.recipe_value = load_recipe(path, sha256=base.get("sha256") or None)
                self.recipe_key = key
            recipe = self.recipe_value
        elif base["kind"] == "definition":
            recipe = create_setup(base["path"])
            self.recipe_hit = False
        else:
            raise ValueError("Choose a recipe archive or setup definition")
        draft = data.get("draft", {})
        if set(draft) - {"name", "settings", "detections"}:
            raise ValueError("Unknown setup draft fields")
        reference = (
            self.current(recipe, {"current": data["reference"]}, arrays)
            if data.get("reference")
            else recipe.reference
        )
        if not draft and not data.get("reference"):
            return recipe
        if "detections" in draft:
            reference = replace(
                reference, detections=tuple(Detection(**d) for d in draft["detections"])
            )
        return replace(
            recipe,
            name=draft.get("name", recipe.name),
            reference=reference,
            settings=ExecutionSettings(
                **{**describe(recipe)["settings"], **draft.get("settings", {})}
            ),
        )

    def current(self, recipe, data, arrays):
        current = data.get("current")
        if current is None:
            return None
        if current["kind"] == "request":
            return load_capture(current["path"])
        if current["kind"] != "arrays":
            raise ValueError("Choose current RGB-D or an explicit capture request")
        from opencv_simple_foundation_pose.specs import Frame

        info = current["metadata"]
        if set(info) != {"capture_id", "model_frame", "camera_frame", "detections"}:
            raise ValueError("Unexpected current-capture metadata")
        prefix = current.get("array_prefix", "")
        if prefix not in ("", "reference_", "current_"):
            raise ValueError("Invalid capture array namespace")
        names = {"rgb", "depth", "camera", "mask"}
        if not {prefix + n for n in names}.issubset(arrays):
            raise ValueError("Connect complete RGB-D arrays")
        arrays = {name: arrays[prefix + name] for name in names}
        return Capture(
            Frame(
                arrays["rgb"],
                arrays["depth"],
                arrays["camera"],
                arrays["mask"],
                info["camera_frame"],
            ),
            tuple(Detection(**d) for d in info["detections"]),
            info["capture_id"],
            info["model_frame"] or recipe.mesh.frame,
        )

    def graphics(self, number=0, *, image=True, cloud=True, gallery=False):
        if type(gallery) is not bool:
            raise ValueError("Gallery request must be boolean")
        token, recipe, frame, report = self.last
        selection, table = describe_review(report, number)
        index = selection["candidate_index"]
        started = time.perf_counter()
        arrays = review_arrays(
            recipe.mesh, frame, report, index or 0, image=image or gallery, cloud=cloud
        )
        if gallery:
            arrays["gallery"] = candidate_gallery(
                recipe.mesh, frame, report, index, arrays.get("overlay")
            )
        if not image:
            arrays.pop("overlay", None)
        return dict(
            token=token,
            report=report,
            candidate_index=index,
            review=selection,
            candidate_table=table,
            graphics_profile=dict(
                seconds=time.perf_counter() - started,
                image_requested=image,
                cloud_requested=cloud,
                gallery_requested=gallery,
            ),
        ), arrays

    def handle(self, operation, data, arrays):
        if operation == "render":
            if self.last is None or data["token"] != self.last[0]:
                raise ValueError("Preview has expired")
            index = data["index"]
            if type(index) is not int or not 0 <= index < max(1, len(self.last[3]["candidates"])):
                raise ValueError("Unknown result candidate")
            return self.graphics(
                index + 1 if self.last[3]["candidates"] else 0,
                gallery=data.get("want_gallery", False),
            )
        self.last = None
        started = time.perf_counter()
        if operation == "prepare":
            base = data.get("base", {})
            if (
                set(data) != {"base", "models_dir"}
                or arrays
                or set(base) != {"kind", "path", "sha256"}
                or base.get("kind") != "recipe"
                or not isinstance(base.get("sha256"), str)
                or re.fullmatch("[0-9a-f]{64}", base["sha256"]) is None
            ):
                raise ValueError(
                    "Prepare a pinned applied recipe and model directory without captures or drafts"
                )
        recipe = self.recipe(data, arrays)
        recipe_done = time.perf_counter()
        if operation == "prepare":
            hit = self.ensure_model(recipe, data["models_dir"])
            finished = time.perf_counter()
            return dict(
                prepared=dict(
                    schema="simple_gdrnpp_preparation/v1",
                    ready=True,
                    recipe_content_sha256=recipe.content_sha256,
                    recipe_archive_sha256=data["base"]["sha256"],
                    binding=binding(),
                    worker=self.worker_info(hit),
                    inspection_performed=False,
                    seconds=dict(
                        recipe_lookup=recipe_done - started,
                        model_prepare=finished - recipe_done,
                        total=finished - started,
                    ),
                    scope=(
                        "Validated model/recipe resources only; no capture, "
                        "network forward or inspection result"
                    ),
                )
            ), {}
        if operation == "inspect":
            f = recipe.reference.frame
            return dict(setup=describe(recipe)), dict(
                rgb=f.rgb, depth=f.depth, camera=f.camera, mask=f.mask
            )
        if operation == "stage":
            from .bridge import project_recipe_path

            relative = data["relative_asset"]
            target = project_recipe_path(data["project_dir"], relative)
            target.parent.mkdir(parents=True, exist_ok=True)
            digest = save_recipe(target, recipe)
            return dict(recipe_path=relative, sha256=digest, setup=describe(recipe)), {}
        if operation != "preview":
            raise ValueError("Unknown GDRNPP operation")
        current = self.current(recipe, data, arrays)
        number = data.get("review_candidate", 0)
        if type(number) is not int or not 0 <= number <= 64:
            raise ValueError("Review candidate must be 0 (best available) or a number in 1..64")
        if number > len((current or recipe.reference).detections):
            raise ValueError("Requested review candidate is unavailable for this capture")
        if type(data.get("want_gallery", False)) is not bool:
            raise ValueError("Gallery request must be boolean")
        capture_done = time.perf_counter()
        hit = self.ensure_model(recipe, data["models_dir"])
        model_done = time.perf_counter()
        self.inference_requests += 1
        report, _ = run_recipe(recipe, self.model, capture=current)
        numeric_done = time.perf_counter()
        report["worker"] = self.worker_info(hit)
        frame = (current or recipe.reference).frame
        token = uuid.uuid4().hex
        self.last = (token, recipe, frame, report)
        if data.get("graphics", True):
            result = self.graphics(
                number,
                image=data.get("want_image", True),
                cloud=data.get("want_cloud", True),
                gallery=data.get("want_gallery", False),
            )
        else:
            selection, table = describe_review(report, number)
            result = (
                dict(
                    token=token,
                    report=report,
                    candidate_index=selection["candidate_index"],
                    review=selection,
                    candidate_table=table,
                ),
                {},
            )
        finished = time.perf_counter()
        report["execution_profile"] = dict(
            recipe_lookup_seconds=recipe_done - started,
            capture_prepare_seconds=capture_done - recipe_done,
            model_prepare_seconds=model_done - capture_done,
            numeric_seconds=numeric_done - model_done,
            graphics_seconds=finished - numeric_done,
            worker_handle_seconds=finished - started,
            graphics_requested=bool(data.get("graphics", True)),
            scope="Worker handler only; packet transfer and process/import startup are separate",
        )
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    root = parser.parse_args().root.resolve(strict=True)
    service = Service()
    while raw := sys.stdin.buffer.readline(65537):
        identifier = None
        try:
            if len(raw) > 65536:
                raise ValueError("Oversized worker request")
            request = strict_json(raw)
            identifier = request["id"]
            if re.fullmatch("[0-9a-f]{32}", identifier) is None:
                raise ValueError("Invalid request identity")
            job = (root / identifier).resolve(strict=True)
            if not job.is_relative_to(root):
                raise ValueError("Request escaped private worker storage")
            started = time.perf_counter()
            data, arrays = read_packet(job)
            read_done = time.perf_counter()
            metadata, result = service.handle(request["op"], data, arrays)
            handle_done = time.perf_counter()
            output = job / "result"
            output.mkdir()
            write_packet(output, metadata, result)
            finished = time.perf_counter()
            reply = dict(
                id=identifier,
                ok=True,
                timing=dict(
                    packet_read_seconds=read_done - started,
                    handler_seconds=handle_done - read_done,
                    packet_write_seconds=finished - handle_done,
                    worker_request_seconds=finished - started,
                ),
            )
        except Exception as error:
            reply = dict(id=identifier, ok=False, error=f"{type(error).__name__}: {error}")
        print(json.dumps(reply, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
