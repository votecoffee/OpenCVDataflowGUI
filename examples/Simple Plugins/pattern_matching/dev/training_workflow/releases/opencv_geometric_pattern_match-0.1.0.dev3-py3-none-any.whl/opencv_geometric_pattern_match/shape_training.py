"""Build the ordinary geometric pattern from directed lines and circular arcs."""

from __future__ import annotations

import json
import math
from collections.abc import Iterable
from dataclasses import dataclass
from numbers import Real
from pathlib import Path

import numpy as np

from .feature_weights import _validate_weights
from .locator import (
    FeatureDiagnostics, Pattern, TrainingDiagnostics, _coarse_factors, _validate_training_options, _weak_dofs,
)

Point = tuple[float, float]


@dataclass(frozen=True)
class Line:
    """A line directed from start to end, with brighter pixels on its left."""

    start: Point
    end: Point
    weight: float = 1.0


@dataclass(frozen=True)
class CircularArc:
    """A directed circular arc. Positive sweeps turn counterclockwise on the image."""

    center: Point
    radius: float
    start_deg: float
    sweep_deg: float
    weight: float = 1.0


def _number(value) -> bool:
    if not isinstance(value, Real) or isinstance(value, bool):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def _point(value, label):
    if not isinstance(value, (tuple, list)) or len(value) != 2 or not all(map(_number, value)):
        raise ValueError(f"{label} must contain two finite numbers.")
    return np.asarray(value, dtype=float)


def _in_frame(points: np.ndarray, size: tuple[int, int]):
    # Account for tiny rounding errors at the extrema of an arc.
    if not np.all((points >= -1e-8) & (points <= np.asarray(size) - 1 + 1e-8)):
        raise ValueError("Primitive extends outside the shape frame.")


def _segment(primitive, size):
    if isinstance(primitive, Line):
        start = _point(primitive.start, "Line start")
        end = _point(primitive.end, "Line end")
        _in_frame(np.stack((start, end)), size)
        delta = end - start
        length = float(np.linalg.norm(delta))
        if length == 0:
            raise ValueError("Line endpoints must be different.")
        normal = np.array([delta[1], -delta[0]]) / length

        def sample(fractions):
            points = start + fractions[:, None] * delta
            return points, np.broadcast_to(normal, points.shape)

        return length, sample

    if isinstance(primitive, CircularArc):
        center = _point(primitive.center, "Arc center")
        radius, start, sweep = primitive.radius, primitive.start_deg, primitive.sweep_deg
        if not all(map(_number, (radius, start, sweep))) or radius <= 0 or not 0 < abs(sweep) <= 360:
            raise ValueError("Arc needs a positive finite radius and a finite sweep with magnitude in (0, 360].")
        start %= 360
        cardinal = np.array([0, 90, 180, 270])
        direction = 1 if sweep > 0 else -1
        extrema = cardinal[((cardinal - start) * direction) % 360 <= abs(sweep)]

        def radial(degrees):
            radians = np.deg2rad(degrees)
            return np.column_stack((np.cos(radians), -np.sin(radians)))

        _in_frame(center + radius * radial(np.r_[start, start + sweep, extrema]), size)
        length = radius * math.radians(abs(sweep))
        if length <= 0 or not math.isfinite(length):
            raise ValueError("Arc length must be positive and finite.")

        def sample(fractions):
            rays = radial(start + fractions * sweep)
            return center + radius * rays, -direction * rays

        return length, sample

    raise ValueError("Shape training supports Line and CircularArc primitives.")


def _sample_level(segments, ends, shape_weights, spacing, limit, center):
    detected = max(1, math.ceil(ends[-1] / spacing))
    count = min(detected, limit)
    positions = (np.arange(count) + 0.5) * (ends[-1] / count)
    stops = np.searchsorted(positions, ends)
    points, normals = [], []
    first, offset = 0, 0.0
    for (length, sample), stop, end in zip(segments, stops, ends):
        if first < stop:
            p, n = sample((positions[first:stop] - offset) / length)
            points.append(p)
            normals.append(n)
        first, offset = stop, end
    p = np.concatenate(points) - center
    n = np.concatenate(normals)
    weights = np.repeat(shape_weights, np.diff(stops, prepend=0))
    weak = _weak_dofs(p, n) if count >= 12 else ()
    return p, n, weights, FeatureDiagnostics(detected, detected, count, weak)


def train_shapes(
    primitives: Iterable[Line | CircularArc],
    size: tuple[int, int],
    *,
    origin: Point | None = None,
    edge_threshold: float = 45.0,
    coarse_factor: int | None = None,
    fine_sigma: float = 0.85,
    ignore_polarity: bool = False,
    input_scale: float = 1.0,
) -> Pattern:
    """Sample directed edges in a pixel frame, without extracting training features from an image."""
    if (not isinstance(size, (tuple, list)) or len(size) != 2
            or any(type(value) is not int or not 8 <= value <= 2**30 for value in size)):
        raise ValueError("Shape frame width and height must be integers from 8 through 2^30.")
    if not _number(edge_threshold) or not _number(fine_sigma):
        raise ValueError("Shape training requires numeric edge threshold and fine sigma.")
    if coarse_factor is not None and type(coarse_factor) is not int:
        raise ValueError("Coarse factor must be a whole number from 1 through 8.")
    if not _number(input_scale) or not 0 < input_scale <= 1:
        raise ValueError("Input scale must be greater than 0 and at most 1.")
    datum = None if origin is None else tuple(map(float, _point(origin, "Training origin")))
    _validate_training_options(edge_threshold, coarse_factor, fine_sigma, datum)
    width, height = size
    anchor = ((width - 1) / 2, (height - 1) / 2)
    primitives = tuple(primitives)
    segments = [_segment(primitive, (width, height)) for primitive in primitives]
    if not segments:
        raise ValueError("Provide at least one directed primitive.")
    if not all(_number(primitive.weight) for primitive in primitives):
        raise ValueError("Shape weights must be finite numbers.")
    shape_weights = np.array([primitive.weight for primitive in primitives], dtype=float)
    _validate_weights(shape_weights, len(segments))
    ends = np.cumsum([length for length, _ in segments])
    if not math.isfinite(ends[-1]):
        raise ValueError("Total primitive length must be finite.")
    points, normals, weights, fine = _sample_level(segments, ends, shape_weights, 1, 480, anchor)
    if fine.retained < 12:
        raise ValueError("Too few fine shape samples. Supply more geometry or use a larger pixel frame.")
    chosen = None
    fewest_lost = math.inf
    for factor in _coarse_factors(width, height, coarse_factor):
        coarse_points, coarse_normals, coarse_weights, coarse = _sample_level(segments, ends, shape_weights, factor, 96, anchor)
        if coarse.retained < 12:
            continue
        lost = len(set(coarse.weak_dofs) - set(fine.weak_dofs))
        if lost < fewest_lost:
            chosen = factor, coarse_points, coarse_normals, coarse_weights, coarse
            fewest_lost = lost
        if lost == 0:
            break
    if chosen is None:
        raise ValueError("Too few coarse shape samples. Choose a smaller coarse factor or add geometry.")
    factor, coarse_points, coarse_normals, coarse_weights, coarse = chosen
    if np.all(coarse_weights == 1) and np.all(weights == 1):
        coarse_weights = weights = None
    diagnostics = TrainingDiagnostics(False, coarse_factor is None, False, coarse, fine)
    return Pattern(datum if datum is not None else anchor, anchor, (0, 0, width, height), factor,
                   coarse_points, coarse_normals, points, normals, float(edge_threshold), float(fine_sigma),
                   bool(ignore_polarity), None, diagnostics, float(input_scale), coarse_weights, weights)


def _train_shape_file(path: Path, **options) -> Pattern:
    definition = json.loads(path.read_text(encoding="utf-8-sig"))
    required = {"size", "primitives"}
    if not isinstance(definition, dict) or not required <= definition.keys() <= required | {"origin", "input_scale"}:
        raise ValueError("Shape file needs size and primitives, with optional origin and input_scale.")
    if not isinstance(definition["primitives"], list):
        raise ValueError("Shape primitives must be a JSON array.")
    primitives = []
    for item in definition["primitives"]:
        if not isinstance(item, dict):
            raise ValueError("Each primitive must be a JSON object.")
        fields = item.keys() - {"weight"}
        weight = item.get("weight", 1.0)
        if item.get("type") == "line" and fields == {"type", "start", "end"}:
            primitives.append(Line(item["start"], item["end"], weight))
        elif item.get("type") == "arc" and fields == {"type", "center", "radius", "start_deg", "sweep_deg"}:
            primitives.append(CircularArc(item["center"], item["radius"], item["start_deg"], item["sweep_deg"], weight))
        else:
            raise ValueError("Use a line with start and end, or an arc with center, radius, start_deg and sweep_deg.")
    return train_shapes(primitives, definition["size"], origin=definition.get("origin"),
                        input_scale=definition.get("input_scale", 1.0), **options)
