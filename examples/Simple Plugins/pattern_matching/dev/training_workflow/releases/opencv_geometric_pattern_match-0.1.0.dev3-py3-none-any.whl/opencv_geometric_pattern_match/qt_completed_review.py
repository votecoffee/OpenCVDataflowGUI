"""Read-only native review of one captured completion; no training or matcher calls."""

from pathlib import Path
import uuid

import cv2
import numpy as np
from PySide6.QtCore import QRectF, QSignalBlocker, Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
)

from opencv_dataflow.images import ImageArray

from .locator import DEFAULT_FIT_LAYERS, FIT_LAYERS, draw_matches, draw_rejections
from .qt_training import _ImageView
from .result_review import candidate_bounds, candidate_report


class CompletedPatternReviewDialog(QDialog):
    def __init__(self, parent, context, capture):
        super().__init__(parent)
        self._capture = capture
        self.snapshot = None
        self._visible = []
        self._closed = False
        self.setWindowTitle("Completed pattern match · read only")
        self.resize(1300, 950)
        layout = QVBoxLayout(self)
        actions = QHBoxLayout()
        self.capture_button = QPushButton("Capture latest completed run")
        self.capture_button.clicked.connect(self.capture_latest)
        actions.addWidget(self.capture_button)
        self.overview_button = QPushButton("All returned instances")
        self.overview_button.clicked.connect(self.overview)
        actions.addWidget(self.overview_button)
        self.focus_button = QPushButton("Focus selected")
        self.focus_button.clicked.connect(self.focus)
        actions.addWidget(self.focus_button)
        self.export_button = QPushButton("Export frozen review…")
        self.export_button.clicked.connect(self.choose_export)
        actions.addWidget(self.export_button)
        layout.addLayout(actions)
        self.identity = QLabel("No completed execution captured")
        self.identity.setWordWrap(True)
        layout.addWidget(self.identity)
        self.status = QLabel("Run in Debug to retain completed inputs and results.")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        filters = QHBoxLayout()
        self.kind = QComboBox()
        self.kind.currentIndexChanged.connect(self.fill)
        filters.addWidget(self.kind)
        self.layers = {}
        for name in FIT_LAYERS:
            check = QCheckBox(name.capitalize())
            check.setChecked(name in DEFAULT_FIT_LAYERS)
            check.toggled.connect(self.render)
            filters.addWidget(check)
            self.layers[name] = check
        self.area = QCheckBox("Inspection area")
        self.area.setChecked(True)
        self.area.toggled.connect(self.render)
        filters.addWidget(self.area)
        layout.addLayout(filters)
        self.table = QTableWidget(0, 9)
        self.table.setHorizontalHeaderLabels(
            [
                "Result",
                "Score",
                "Input X",
                "Input Y",
                "Angle °",
                "Scale",
                "Aspect",
                "Found edges",
                "Reason",
            ]
        )
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.itemSelectionChanged.connect(self.render)
        self.table.setMaximumHeight(190)
        layout.addWidget(self.table)
        self.tabs = QTabWidget()
        self.fit_view = _ImageView("No completed fit available")
        self.source_view = _ImageView("No consumed input available")
        self.tabs.addTab(self.fit_view, "Fit in working pixels")
        self.tabs.addTab(self.source_view, "Exact consumed input")
        layout.addWidget(self.tabs, 1)
        self.details = QLabel("Cyan pose · green found · red missing · amber outside/unmeasured")
        self.details.setWordWrap(True)
        layout.addWidget(self.details)
        self.measurements = QTableWidget(0, 4)
        self.measurements.setHorizontalHeaderLabels(["Measurement", "Value", "Minimum", "Meaning"])
        self.measurements.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.measurements.setMaximumHeight(160)
        layout.addWidget(self.measurements)
        close = QPushButton("Close review")
        close.clicked.connect(self.reject)
        layout.addWidget(close)
        self.finished.connect(lambda *_: setattr(self, "_closed", True))
        subscribe = getattr(context, "subscribe_outputs", None)
        if subscribe is not None:
            unsubscribe = subscribe(self.publication_changed)
            self.finished.connect(unsubscribe)
            self.destroyed.connect(unsubscribe)
        self.capture_latest()

    def publication_changed(self, revision):
        if self.snapshot is not None and not self._closed:
            self.status.setText(
                "Editor publication changed. This frozen review stays unchanged; "
                "capture latest explicitly to replace it."
            )

    def capture_latest(self):
        if self._closed:
            return
        try:
            snapshot = self._capture()
        except (ValueError, RuntimeError, KeyError) as error:
            previous = (
                " Previous frozen frame remains displayed." if self.snapshot is not None else ""
            )
            self.status.setText(str(error) + previous)
            self.export_button.setEnabled(self.snapshot is not None)
            return
        self.snapshot = snapshot
        record = snapshot.record
        provenance = snapshot.provenance
        self.identity.setText(
            f"{provenance['block_id']} · completion count {provenance['execution_count']} · "
            f"{'passed' if provenance['passed'] else 'failed inspection'} · "
            f"model {record.model.model_id[:16]} · input SHA-256 {snapshot.source_sha256[:16]} · "
            f"{snapshot.source_pixels.shape[1]}×{snapshot.source_pixels.shape[0]} {snapshot.source_format}"
        )
        self.status.setText(
            f"Frozen last completed run: {len(record.matches)} returned, {len(record.rejected)} "
            "retained rejected candidates. No new search or recipe reload. "
            + (
                "Rejection diagnostics were not retained. "
                if not record.rejections_retained
                else ""
            )
            + (
                "Correspondences were not retained; amber means unmeasured."
                if not record.fit_captured
                else ""
            )
        )
        self.source_view.set_image(
            ImageArray(snapshot.source_pixels, snapshot.source_format), reset_view=True
        )
        with QSignalBlocker(self.kind):
            self.kind.clear()
            self.kind.addItem("Returned instances", ("accepted", None))
            if record.rejected:
                self.kind.addItem("All retained rejections", ("rejected", None))
                for reason, count in record.rejection_counts:
                    self.kind.addItem(f"{reason.replace('_', ' ')} ({count})", ("rejected", reason))
                if not record.matches:
                    self.kind.setCurrentIndex(1)
        self.export_button.setEnabled(True)
        self.fill()
        self.fit_view.viewer.fit_image()

    def fill(self):
        if self.snapshot is None:
            return
        kind, reason = self.kind.currentData()
        record, pattern = self.snapshot.record, self.snapshot.recipe.pattern
        self._visible = list(
            record.matches
            if kind == "accepted"
            else (item for item in record.rejected if reason is None or item.reason == reason)
        )
        self.table.blockSignals(True)
        self.table.setRowCount(len(self._visible))
        mapping = self.snapshot.scene.working_to_source()
        for row, item in enumerate(self._visible):
            x, y = mapping @ [item.pose.x, item.pose.y, 1.0]
            values = (
                str(row + 1),
                "coarse only" if item.score is None else f"{item.score:.4f}",
                f"{x:.3f}",
                f"{y:.3f}",
                f"{item.pose.angle_deg:.3f}",
                f"{item.pose.scale:.5f}",
                f"{item.pose.aspect:.5f}",
                "unmeasured"
                if item.edge_matches is None
                else f"{len(item.edge_matches)}/{len(pattern.points)}",
                getattr(item, "reason", "returned"),
            )
            for column, value in enumerate(values):
                self.table.setItem(row, column, QTableWidgetItem(value))
        self.table.blockSignals(False)
        self.table.resizeColumnsToContents()
        if self._visible:
            self.table.selectRow(0)
        else:
            self.render()

    def selected(self):
        rows = self.table.selectionModel().selectedRows()
        return self._visible[rows[0].row()] if rows else None

    def visible_layers(self):
        return tuple(name for name, check in self.layers.items() if check.isChecked())

    def overview(self):
        with QSignalBlocker(self.kind):
            self.kind.setCurrentIndex(0)
        self.fill()
        self.table.clearSelection()
        self.render()

    def render(self):
        if self.snapshot is None:
            return
        selected = self.selected()
        recipe, scene = self.snapshot.recipe, self.snapshot.scene
        image = scene.pixels
        if self.area.isChecked():
            image = np.array(image, copy=True)
            image[~self.snapshot.inspected] //= 3
        kind, _ = self.kind.currentData()
        candidates = self._visible if selected is None else [selected]
        draw = draw_matches if kind == "accepted" else draw_rejections
        self.fit_view.set_image(
            draw(image, recipe.pattern, candidates, layers=self.visible_layers())
        )
        self.focus_button.setEnabled(selected is not None)
        self.measurements.setRowCount(0)
        message = "Cyan pose · green found · red missing · amber outside/unmeasured. "
        if selected is not None:
            report = candidate_report(
                recipe.pattern, selected, recipe.search, working_to_source=scene.working_to_source()
            )
            message += report["explanation"]
            self.measurements.setRowCount(len(report["metrics"]))
            for row, metric in enumerate(report["metrics"]):
                values = (
                    metric["name"],
                    "unmeasured" if metric["value"] is None else f"{metric['value']:.5g}",
                    "—" if metric["minimum"] is None else f"{metric['minimum']:.5g}",
                    metric["status"],
                )
                for column, value in enumerate(values):
                    cell = QTableWidgetItem(value)
                    cell.setToolTip(metric["units"])
                    self.measurements.setItem(row, column, cell)
            self.measurements.resizeColumnsToContents()
        elif not self._visible:
            message += "No returned or retained candidates in this selection. No pose is invented."
        self.details.setText(message)

    def focus(self):
        selected = self.selected()
        if selected is not None:
            bounds = candidate_bounds(
                self.snapshot.scene.pixels, self.snapshot.recipe.pattern, selected
            )
            self.fit_view.viewer.fitInView(QRectF(*bounds), Qt.AspectRatioMode.KeepAspectRatio)
            self.fit_view.viewer._fitted = False

    def export_to(self, directory):
        if self.snapshot is None:
            raise ValueError("Capture a completed execution before exporting")
        return self.snapshot.export(directory, self.selected(), layers=self.visible_layers())

    def choose_export(self):
        directory = QFileDialog.getExistingDirectory(self, "Directory for a new completed review")
        if directory:
            try:
                target = self.export_to(
                    Path(directory) / f"completed-pattern-{uuid.uuid4().hex[:12]}"
                )
                self.status.setText(f"Exported frozen review to {target}. Training unchanged.")
            except (OSError, ValueError, cv2.error) as error:
                self.status.setText(str(error))
