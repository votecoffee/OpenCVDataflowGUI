"""Training diagnostics and recorded refinement displays, without another search."""

from dataclasses import dataclass

import cv2
import numpy as np

from .locator import Pattern, draw_matches, draw_training
from .refinement import TrainingRefinement
from .training_draft import ImageSnapshot


def training_health(pattern: Pattern) -> str:
    """Describe measured model properties; these are not an accuracy score."""
    text = (
        f"Fine edges: {len(pattern.points)} · Coarse edges: {len(pattern.coarse_points)}\n"
        f"Working scale: {pattern.input_scale:g} · Coarse factor: {pattern.factor}\n"
        f"Edge threshold: {pattern.edge_threshold:g} · Smoothing: {pattern.fine_sigma:g}"
    )
    diagnostics = pattern.diagnostics
    if diagnostics is None:
        return text + "\nConstraint diagnostics unavailable in this model."
    for name in ("fine", "coarse"):
        band = getattr(diagnostics, name)
        weak = ", ".join(band.weak_dofs) or "none reported"
        text += f"\n{name.capitalize()} weak axes: {weak}"
    auto = [
        name
        for name, enabled in (
            ("threshold", diagnostics.auto_edge_threshold),
            ("coarse factor", diagnostics.auto_coarse_factor),
            ("smoothing", diagnostics.auto_fine_sigma),
        )
        if enabled
    ]
    if auto:
        text += "\nAutomatic settings: " + ", ".join(auto)
    if pattern.weights is not None:
        weights = np.asarray(pattern.weights)
        text += f"\nFine weights: {weights.min():g} to {weights.max():g}"
    return text + "\nCheck separate images for misses and look-alike accepts."


@dataclass(frozen=True)
class RefinementComparison:
    """Keep the actual two fixed-pose fits and their captured image for review."""

    previous: Pattern
    result: TrainingRefinement
    scene: ImageSnapshot
    reference: ImageSnapshot | None

    def image(self, mode: str) -> np.ndarray:
        if mode == "Feature changes":
            return self.feature_changes()
        if mode == "Before":
            pattern, fit = self.previous, self.result.before
        elif mode == "After":
            pattern, fit = self.result.pattern, self.result.after
        else:
            raise ValueError("Unknown refinement comparison view")
        return draw_matches(self.scene.pixels, pattern, [fit])

    def feature_changes(self) -> np.ndarray:
        old, new = self.previous, self.result.pattern
        image = None if self.reference is None else self.reference.pixels
        overlay = draw_training(image, new)
        if image is None:
            # The ordinary geometry-only view uses the same bounded mapping.
            x, y, width, height = new.training_roi
            scale = min(1.0, 1023 / (max(width, height) - 1))
            offset = np.array((x, y))

            def project(points):
                return (points + new.anchor - offset) * scale + 12
        else:

            def project(points):
                return points + new.anchor

        original, refined = project(old.points), project(new.points)
        moved = np.linalg.norm(new.points - old.points, axis=1) >= 0.001
        before_weights = np.ones(len(old.points)) if old.weights is None else old.weights
        after_weights = np.ones(len(new.points)) if new.weights is None else new.weights
        for before, after in zip(original[moved], refined[moved]):
            p, q = tuple(np.rint(before).astype(int)), tuple(np.rint(after).astype(int))
            cv2.circle(overlay, p, 2, (230, 80, 230), 1, cv2.LINE_AA)
            cv2.line(overlay, p, q, (230, 230, 230), 1, cv2.LINE_AA)
            cv2.circle(overlay, q, 1, (94, 231, 83), -1, cv2.LINE_AA)
        for point in refined[after_weights < before_weights]:
            cv2.circle(overlay, tuple(np.rint(point).astype(int)), 3, (0, 180, 255), 1, cv2.LINE_AA)
        return overlay

    def summary(self) -> str:
        before, after = self.result.before, self.result.after
        pose = before.pose
        return (
            f"Recorded fixed pose: X {pose.x:.6g}, Y {pose.y:.6g}, "
            f"angle {pose.angle_deg:.6g}° · {self.result.moved} moved, "
            f"{self.result.downweighted} downweighted fine edges.\n"
            f"Score {before.score:.6g} → {after.score:.6g} · "
            f"Coverage {before.coverage:.2%} → {after.coverage:.2%} · "
            f"Fit RMS {before.fit_error_px:.6g} → {after.fit_error_px:.6g} working px.\n"
            "This is the refinement image at the same pose, not held-out validation. "
            "Run preview on separate images before Stage → Apply.\n"
            "Before/After show the captured refinement scene. Feature changes show the "
            "training reference, or a neutral geometry view if its photo is unavailable."
        )
