"""Prepare file inputs consistently for training and search."""

from pathlib import Path

import cv2
import numpy as np


def _decode(path: Path, flags: int) -> np.ndarray:
    image = cv2.imdecode(np.frombuffer(path.read_bytes(), dtype=np.uint8), flags)
    if image is None:
        raise ValueError(f"Could not decode {path}.")
    return image


def read_gray(path: Path) -> np.ndarray:
    return _decode(path, cv2.IMREAD_GRAYSCALE | cv2.IMREAD_ANYDEPTH)


def input_scale(shape: tuple[int, int], max_side: int | None) -> float:
    if max_side is None:
        return 1.0
    if max_side < 8:
        raise ValueError("Maximum working side must be at least 8 pixels.")
    return min(1.0, max_side / max(shape))


def prepare_image(image: np.ndarray, scale: float) -> np.ndarray:
    if image.ndim != 2 or image.dtype not in (np.uint8, np.uint16):
        raise ValueError("Expected an 8-bit or 16-bit grayscale image.")
    if not 0 < scale <= 1:
        raise ValueError("Input scale must be greater than 0 and at most 1.")
    width, height = (round(side * scale) for side in image.shape[::-1])
    if min(width, height) < 8:
        raise ValueError("The working image must be at least 8 by 8 pixels.")
    if (height, width) != image.shape:
        image = cv2.resize(image, (width, height), interpolation=cv2.INTER_AREA)
    if image.dtype == np.uint16:
        return (image >> 8).astype(np.uint8)
    return image


def read_mask(path: Path, source_shape: tuple[int, int], working_shape: tuple[int, int], *,
              training: bool = False) -> np.ndarray:
    return prepare_mask(_decode(path, cv2.IMREAD_UNCHANGED), source_shape, working_shape, training=training)


def prepare_mask(mask: np.ndarray, source_shape: tuple[int, int], working_shape: tuple[int, int], *,
                 training: bool = False) -> np.ndarray:
    """Align a categorical mask to the working grid without mixing its bands."""
    if mask.shape != source_shape or mask.dtype != np.uint8:
        raise ValueError("Mask must be 8-bit grayscale and match the source image size.")
    if training and np.any((mask >= 128) & (mask < 192)):
        raise ValueError("Training mask values 128 through 191 are reserved.")
    if working_shape != source_shape:
        mask = cv2.resize(mask, working_shape[::-1], interpolation=cv2.INTER_NEAREST_EXACT)
    return mask


def working_to_source(source_shape: tuple[int, int], working_shape: tuple[int, int]) -> np.ndarray:
    """Map working pixel centers back to source pixel centers."""
    sx, sy = np.divide(source_shape[::-1], working_shape[::-1])
    return np.array([[sx, 0, (sx - 1) / 2], [0, sy, (sy - 1) / 2]])
