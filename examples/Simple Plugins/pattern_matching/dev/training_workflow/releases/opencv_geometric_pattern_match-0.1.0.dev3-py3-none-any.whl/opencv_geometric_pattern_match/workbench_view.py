"""Fit a working image to a Tk canvas and map pointer positions back to pixels."""

import base64
import tkinter as tk

import cv2


class ImageView(tk.Canvas):
    def __init__(self, parent):
        super().__init__(parent, background="#21262d", highlightthickness=0)
        self.image = None
        self.photo = None
        self.viewport = None
        self.bind("<Configure>", lambda _: self.paint())

    def show(self, image):
        self.image = image
        self.paint()

    def paint(self):
        self.delete("all")
        self.viewport = None
        self.photo = None
        width, height = self.winfo_width(), self.winfo_height()
        if self.image is None or min(width, height) < 2:
            return
        rows, cols = self.image.shape[:2]
        scale = min(width / cols, height / rows)
        w, h = max(1, round(cols * scale)), max(1, round(rows * scale))
        left, top = (width - w) // 2, (height - h) // 2
        interpolation = cv2.INTER_AREA if scale < 1 else cv2.INTER_NEAREST
        display = cv2.resize(self.image, (w, h), interpolation=interpolation)
        png = cv2.imencode(".png", display)[1]
        self.photo = tk.PhotoImage(master=self, data=base64.b64encode(png))
        self.create_image(left, top, image=self.photo, anchor="nw")
        self.viewport = (left, top, w, h)

    def pixel_at(self, x, y, *, clamp=False):
        if self.viewport is None:
            return None
        left, top, width, height = self.viewport
        if not clamp and not (left <= x < left + width and top <= y < top + height):
            return None
        rows, cols = self.image.shape[:2]
        px = (x - left) * cols // width
        py = (y - top) * rows // height
        return min(cols - 1, max(0, px)), min(rows - 1, max(0, py))
