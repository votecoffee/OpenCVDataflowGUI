"""Independent, read-only Results review of a completed classification."""

import uuid
from pathlib import Path

from opencv_dataflow.canvas import pixmap
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from opencv_dataflow.images import ImageArray
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
)


class CompletedClassificationReviewDialog(QDialog):
    def __init__(self, parent, context, capture):
        super().__init__(parent)
        self.resize(1240, 900)
        self.setWindowTitle("Completed classification review")
        self.snapshot = None
        self._capture = capture
        self._closed = False
        layout = QVBoxLayout(self)
        actions = QHBoxLayout()
        self.capture_button = QPushButton("Capture latest completed run")
        self.capture_button.clicked.connect(self.capture_latest)
        actions.addWidget(self.capture_button)
        for label, method in (("Fit", "fit_image"), ("100%", "actual_size")):
            button = QPushButton(label)
            button.clicked.connect(
                lambda checked=False, name=method: [getattr(v, name)() for v in self.views]
            )
            actions.addWidget(button)
        self.export_button = QPushButton("Export frozen review…")
        self.export_button.clicked.connect(self.choose_export)
        actions.addWidget(self.export_button)
        close = QPushButton("Close review")
        close.clicked.connect(self.reject)
        actions.addWidget(close)
        layout.addLayout(actions)
        self.identity, self.status, self.summary = (QLabel() for _ in range(3))
        for label in (self.identity, self.status, self.summary):
            label.setTextFormat(Qt.TextFormat.PlainText)
            label.setWordWrap(True)
            layout.addWidget(label)
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Rank", "Class", "Score (%)", "Gap from winner (pp)"])
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setMaximumHeight(200)
        layout.addWidget(self.table)
        self.tabs = QTabWidget()
        self.source_view, self.assessment_view = FilmstripImageView(self), FilmstripImageView(self)
        self.views = (self.source_view, self.assessment_view)
        self.tabs.addTab(self.source_view, "Exact consumed input")
        self.tabs.addTab(self.assessment_view, "Ranked assessment display")
        layout.addWidget(self.tabs, 1)
        legend = QLabel(
            "Class scores total 100% and are uncalibrated. Confusion = 100 × runner-up / winner; "
            "lower means more separation. No unknown class or quality gate is inferred. "
            "Scores describe the whole image, not individual pixels. Scroll to zoom; drag to pan. "
            "Full candidate labels are in the table/export; "
            "the raster chart is limited to 20 candidates."
        )
        legend.setWordWrap(True)
        layout.addWidget(legend)
        self.export_status = QLabel()
        self.export_status.setWordWrap(True)
        layout.addWidget(self.export_status)
        self.finished.connect(lambda *_: setattr(self, "_closed", True))
        unsubscribe = context.subscribe_outputs(self.publication_changed)
        self.finished.connect(unsubscribe)
        self.destroyed.connect(unsubscribe)
        self.capture_latest()

    def publication_changed(self, revision):
        if self.snapshot is not None and not self._closed:
            self.status.setText(
                "Editor publication changed. This frozen review stays unchanged; "
                "capture latest explicitly."
            )

    def capture_latest(self):
        if self._closed:
            return
        try:
            snapshot = self._capture()
        except (ValueError, RuntimeError, KeyError) as error:
            self.status.setText(
                str(error)
                + (" Previous frozen frame remains displayed." if self.snapshot is not None else "")
            )
            self.export_button.setEnabled(self.snapshot is not None)
            return
        self.snapshot = snapshot
        report, prediction = snapshot.report(), snapshot.record.prediction
        p = snapshot.provenance
        self.identity.setText(
            f"{p['block_id']} · completion {p['execution_count']} · "
            f"input {snapshot.source_sha256[:16]} · "
            f"{snapshot.source_pixels.shape[1]}×{snapshot.source_pixels.shape[0]} "
            f"{snapshot.source_format} · "
            f"profile {report['profile'] or 'unavailable'}"
        )
        self.summary.setText(
            f"Winner: {prediction['label']} · {prediction['score']:.4f}% · "
            f"confusion {prediction['confusion']:.4f}% · "
            f"runner-up: {report['runner_up']['label']} · "
            f"gap {report['winning_gap_percentage_points']:.4f} pp"
        )
        self.status.setText(
            "Frozen completed input, scores and exact executed model bytes. "
            "No inference or recipe reload. Training is unchanged."
        )
        self.table.setRowCount(len(prediction["probabilities"]))
        for i, row in enumerate(prediction["probabilities"]):
            for column, value in enumerate(
                (
                    i + 1,
                    row["label"],
                    f"{row['score']:.8g}",
                    f"{prediction['score'] - row['score']:.8g}",
                )
            ):
                item = QTableWidgetItem(str(value))
                item.setToolTip(str(value))
                self.table.setItem(i, column, item)
        self.table.resizeColumnsToContents()
        self.table.selectRow(0)
        self.source_view.set_image(
            pixmap(ImageArray(snapshot.source_pixels, snapshot.source_format))
        )
        self.assessment_view.set_image(pixmap(ImageArray(snapshot.assessment(), "bgr")))
        self.export_button.setEnabled(True)

    def export_to(self, directory):
        if self.snapshot is None:
            raise ValueError("Capture a completed classification before exporting")
        selected = self.table.currentRow()
        target = self.snapshot.export(directory, None if selected < 0 else selected)
        self.export_status.setText(f"Exported frozen review: {target}")
        return target

    def choose_export(self):
        parent = QFileDialog.getExistingDirectory(
            self, "Choose parent folder for a new frozen review"
        )
        if parent:
            try:
                self.export_to(Path(parent) / f"classification-review-{uuid.uuid4().hex[:12]}")
            except (ValueError, OSError) as error:
                self.export_status.setText(str(error))
