"""OpenCVDataflowGUI block for a saved classifier recipe."""

from uuid import uuid4

from opencv_dataflow.core import Block, Port, Result
from opencv_dataflow.images import opencv_image
from opencv_dataflow.payloads import NO_VALUE, frame

from .completed_review import BINDING, CompletedClassificationRecord, capture_completed
from .graphics import draw_assessment
from .model import SURFACE_TEXTURE, _project_path, load_classifier, read_manifest


class ClassifyImage(Block):
    type_id, title, category = "inspect.simple_classify_image", "Classify image", "Inspection"
    block_type, subtype = "Inspection", "Classification"
    parallel_safe = True
    process_inputs_readonly = True
    inputs = (Port("image"),)
    outputs = (
        Port("label", "text"),
        Port("score", "number"),
        Port("confusion", "number"),
        Port("probabilities", "data"),
        Port("overlay", required=False),
    )
    defaults = {"model": "", "render_overlay": True}
    parameter_help = {
        "model": "Project-relative manifest staged by the classifier trainer.",
        "render_overlay": "Show the input, ranked scores and confusion in a result chart. "
        "Disable to skip rendering; scores do not change.",
    }
    plugin_dialog_label = "Train image classifier…"
    plugin_review_dialog_label = "Review completed classification…"
    project_asset_parameters = ("model",)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._model_key = None
        self._model = None
        self._completed_review = None

    def project_assets(self):
        assets = super().project_assets()
        if not assets or self.project_dir is None:
            return assets
        path, root, data = read_manifest(self.project_dir, self.parameters["model"])
        model = path.parent / (
            "surface.npz" if data["profile"] == SURFACE_TEXTURE else "forest.yml"
        )
        assets.append(model.relative_to(root).as_posix())
        for entry in data["classes"]:
            for row in entry["images"]:
                assets.append(_project_path(root, row["path"]).relative_to(root).as_posix())
        return list(dict.fromkeys(assets))

    def copy_runtime_from(self, other):
        super().copy_runtime_from(other)
        self._completed_review = other._completed_review

    def reset_runtime(self):
        super().reset_runtime()
        self._completed_review = None

    def close(self):
        self._completed_review = self._model = self._model_key = None
        super().close()

    def capture_completed_review(self, context):
        snapshot = getattr(context, "snapshot_processed_execution", None)
        if snapshot is None:
            raise ValueError("Completed review needs the host's paired execution-snapshot API")
        return capture_completed(
            self._completed_review,
            snapshot(
                input_ports=("image",),
                output_ports=("label", "score", "confusion", "probabilities"),
            ),
        )

    def create_plugin_review_dialog(self, parent, context):
        from .qt_completed_review import CompletedClassificationReviewDialog

        return CompletedClassificationReviewDialog(
            parent, context, lambda: self.capture_completed_review(context)
        )

    def create_plugin_dialog(self, parent, parameters, context):
        from .qt_training import ClassifierTrainer

        return ClassifierTrainer(parent, parameters, context)

    @property
    def preview_image_port(self):
        return "overlay" if self.parameters["render_overlay"] else None

    filmstrip_output = preview_image_port

    def validate_parameters(self, parameters=None):
        super().validate_parameters(parameters)
        values = self.parameters if parameters is None else parameters
        if type(values["render_overlay"]) is not bool:
            raise ValueError("render_overlay must be boolean.")

    def process(self, inputs):
        self._completed_review = None
        manifest = self.parameters["model"]
        if not manifest or self.project_dir is None:
            raise ValueError("Save the project and train the image classifier before running it")
        key = self.project_dir, manifest
        if key != self._model_key:
            self._model = load_classifier(*key)
            self._model_key = key
        prediction = self._model.predict(opencv_image(inputs["image"]))
        label, score = prediction["label"], prediction["score"]
        image = NO_VALUE
        payloads = {}
        if self.parameters["render_overlay"]:
            image = draw_assessment(opencv_image(inputs["image"]), prediction)
            # Even if input and chart sizes happen to match, calibration and
            # source pixel coordinates do not apply to this dashboard.
            payloads["overlay"] = {
                "spatial": frame(list(image.shape[1::-1]), f"{self.id}:class_scores")
            }
        if self.run_profile.input_previews and self.run_profile.output_previews:
            record = CompletedClassificationRecord.create(
                uuid4().hex,
                prediction,
                self.parameters,
                getattr(self._model, "source_assets", ()),
            )
            self._completed_review = record
            for port in ("label", "score", "confusion", "probabilities"):
                payloads[port] = {BINDING: {"id": record.identifier}}
        return Result(
            {**prediction, "overlay": image},
            score=score / 100,
            message=f"{label} ({score:.2f}%) · confusion {prediction['confusion']:.2f}%",
            payloads=payloads,
            event_data={"filmstrip_priority": -1} if self.parameters["render_overlay"] else {},
        )


def register(registry):
    registry.register(ClassifyImage)
