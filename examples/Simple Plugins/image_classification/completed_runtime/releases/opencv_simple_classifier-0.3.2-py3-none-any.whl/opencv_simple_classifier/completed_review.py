"""Frozen completed-image classification evidence; no training or inference."""

import copy
import hashlib
import json
from dataclasses import dataclass, field
from numbers import Integral
from pathlib import Path

import cv2
import numpy as np

from .graphics import draw_assessment
from .model import image_pixels

BINDING = "classification_completed_review"
PORTS = ("label", "score", "confusion", "probabilities")


def _json(value):
    return json.dumps(value, sort_keys=True, allow_nan=False).encode("utf-8")


def _readonly(array):
    array = np.asarray(array)
    return np.frombuffer(array.tobytes(), dtype=array.dtype).reshape(array.shape)


@dataclass(frozen=True)
class CompletedClassificationRecord:
    identifier: str
    prediction_json: bytes
    parameters_json: bytes
    assets: tuple = field(repr=False)

    @classmethod
    def create(cls, identifier, prediction, parameters, assets):
        return cls(identifier, _json(prediction), _json(parameters), tuple(assets))

    @property
    def prediction(self):
        return json.loads(self.prediction_json)

    @property
    def parameters(self):
        return json.loads(self.parameters_json)

    @property
    def asset_hashes(self):
        return {name: hashlib.sha256(content).hexdigest() for name, content in self.assets}

    def __deepcopy__(self, memo):
        return self


@dataclass(frozen=True)
class CompletedClassificationCapture:
    record: CompletedClassificationRecord
    source_pixels: np.ndarray = field(repr=False, compare=False)
    image: np.ndarray = field(repr=False, compare=False)
    source_format: str
    _provenance: dict = field(repr=False, compare=False)

    @property
    def provenance(self):
        return copy.deepcopy(self._provenance)

    @property
    def source_sha256(self):
        return hashlib.sha256(self.source_pixels.tobytes()).hexdigest()

    def report(self, candidate=None):
        prediction = self.record.prediction
        rows = prediction["probabilities"]
        if candidate is not None and (
            isinstance(candidate, bool)
            or not isinstance(candidate, Integral)
            or not 0 <= candidate < len(rows)
        ):
            raise ValueError("Select a valid zero-based ranked candidate index")
        manifest = dict(self.record.assets).get("manifest.json")
        training = None if manifest is None else json.loads(manifest)
        profile = None if training is None else training.get("profile", "appearance")
        return dict(
            model="simple_classify_completed_review_v1",
            state="classified",
            execution_binding=self.record.identifier,
            prediction=prediction,
            score_total=sum(row["score"] for row in rows),
            runner_up=rows[1],
            winning_gap_percentage_points=rows[0]["score"] - rows[1]["score"],
            selected=None
            if candidate is None
            else dict(rank=int(candidate) + 1, **rows[candidate]),
            executed_parameters=self.record.parameters,
            profile=profile,
            score_semantics=(
                "Uncalibrated normalized tree votes"
                if profile == "appearance"
                else "Uncalibrated normalized nearest-exemplar distance evidence"
                if profile == "surface_texture"
                else "Uncalibrated normalized class evidence; recipe bytes unavailable"
            ),
            confusion_semantics=(
                "100 * runner_up_score / winning_score; tie = 100%, lower = more separation"
            ),
            judgment_scope=(
                "Classification is not a quality acceptance gate; "
                "no unknown/reject class is inferred"
            ),
            spatial_scope=(
                "Whole-image scores have no pixel-level localization; "
                "assessment uses its own display grid"
            ),
            chart_scope=(
                "Raster chart shows at most 20 candidates and ASCII labels; "
                "full labels/scores are in this report and the table"
            ),
            training_health_scope=(
                "Stored held-out report belongs to training; it is not this image's confidence "
                "or independent accuracy proof"
            ),
            source_image=dict(
                shape=list(self.source_pixels.shape),
                dtype=self.source_pixels.dtype.str,
                format=self.source_format,
                sha256=self.source_sha256,
            ),
            classifier_input=dict(
                shape=list(self.image.shape), dtype=self.image.dtype.str, format="bgr"
            ),
            asset_sha256=self.record.asset_hashes,
            assets_available=bool(self.record.assets),
            provenance=self.provenance,
            identity_scope=(
                "Software completion identifiers do not establish physical exposure identity"
            ),
            inference_reexecuted=False,
            recipe_reloaded=False,
            training_changed=False,
        )

    def assessment(self):
        return draw_assessment(self.image, self.record.prediction)

    def export(self, directory, candidate=None):
        document = self.report(candidate)
        target = Path(directory)
        target.mkdir(parents=True, exist_ok=False)
        np.save(target / "consumed_input.npy", self.source_pixels, allow_pickle=False)
        np.save(target / "classifier_input.npy", self.image, allow_pickle=False)
        assets = target / "executed_recipe"
        if self.record.assets:
            assets.mkdir()
        for name, content in self.record.assets:
            (assets / name).write_bytes(content)
        # Recipe assignment paths are historical provenance, not a portable training bundle.
        # Training images are not read or collected during completed review.
        document["export_scope"] = (
            "Exact inference manifest/model; training image paths are provenance only, "
            "not a portable training bundle. Save As preserves full training assets."
        )
        for name, pixels in (("input.png", self.image), ("assessment.png", self.assessment())):
            ok, encoded = cv2.imencode(".png", pixels)
            if not ok:
                raise ValueError("Could not encode classifier review image")
            (target / name).write_bytes(encoded.tobytes())
        (target / "review.json").write_text(
            json.dumps(document, indent=2, ensure_ascii=False, allow_nan=False) + "\n",
            encoding="utf-8",
        )
        return target


def capture_completed(record, bundle):
    from opencv_dataflow.images import image_format, opencv_image

    if record is None:
        raise ValueError("No retained completed classification; execute in Debug before reviewing")
    if any(
        bundle.outputs[name].payload.get(BINDING, {}).get("id") != record.identifier
        for name in PORTS
    ):
        raise ValueError("Completed model/result evidence changed; capture the latest run again")
    if _json({name: bundle.outputs[name].value for name in PORTS}) != record.prediction_json:
        raise ValueError("Completed scores changed; capture the latest run again")
    source = bundle.inputs["image"].value
    image = image_pixels(opencv_image(source))
    provenance = dict(
        snapshot_id=bundle.snapshot_id,
        block_id=bundle.block_id,
        output_revision=bundle.output_revision,
        execution_count=bundle.execution_count,
        passed=bool(bundle.passed),
        score=bundle.score,
        message=bundle.message,
        inputs={name: copy.deepcopy(packet.payload) for name, packet in bundle.inputs.items()},
        outputs={name: copy.deepcopy(packet.payload) for name, packet in bundle.outputs.items()},
    )
    return CompletedClassificationCapture(
        record,
        _readonly(source),
        _readonly(image),
        image_format(source),
        provenance,
    )
