"""Current assignment checks using the classifier's existing decoded-pixel split rules."""

import hashlib
from concurrent.futures import CancelledError
from dataclasses import dataclass, replace
from pathlib import Path

import cv2

from .model import read_image


@dataclass(frozen=True)
class AuditSample:
    class_index: int
    image_index: int
    path: Path
    shape: tuple | None
    fingerprint: str | None
    validation: bool
    error: str | None = None


@dataclass(frozen=True)
class AuditClass:
    label: str
    assigned: int
    readable: int
    training: int
    validation: int


@dataclass(frozen=True)
class AuditIssue:
    codes: tuple[str, ...]
    class_index: int | None
    image_index: int | None
    message: str


@dataclass(frozen=True)
class DatasetAudit:
    split: str
    classes: tuple[AuditClass, ...]
    samples: tuple[AuditSample, ...]
    issues: tuple[AuditIssue, ...]

    @property
    def ready(self):
        return not self.issues


def audit_assignments(assignments, *, cancelled=lambda: False):
    """Read all assignments without extracting features, fitting or predicting.

    Split counts are provisional if any images are invalid or duplicated.
    Exact normalized pixels are compared; similar views/physical specimens are
    not identified by this check.
    """

    def check():
        if cancelled():
            raise CancelledError("Dataset check cancelled")

    labels = list(assignments)
    issues, samples, classes = [], [], []
    if len(labels) < 2:
        issues.append(AuditIssue(("classes",), None, None, "Create at least two classes."))
    if any(not label or label != label.strip() for label in labels) or len(
        {label.casefold() for label in labels}
    ) != len(labels):
        issues.append(
            AuditIssue(("classes",), None, None, "Class names must be trimmed and unique.")
        )
    explicit = any(example.validation for rows in assignments.values() for example in rows)
    for class_index, (label, examples) in enumerate(assignments.items()):
        rows = []
        for image_index, example in enumerate(examples):
            check()
            try:
                pixels = read_image(example.path)
                digest = hashlib.sha256(str(pixels.shape).encode())
                digest.update(memoryview(pixels))
                fingerprint = digest.hexdigest()
                row = AuditSample(
                    class_index,
                    image_index,
                    example.path,
                    tuple(pixels.shape),
                    fingerprint,
                    example.validation,
                )
            except (OSError, ValueError, cv2.error) as error:
                row = AuditSample(
                    class_index,
                    image_index,
                    example.path,
                    None,
                    None,
                    example.validation,
                    str(error),
                )
                issues.append(
                    AuditIssue(
                        ("unreadable",),
                        class_index,
                        image_index,
                        "Cannot read/decode this image. Remove its assignment "
                        "or add a repaired image.",
                    )
                )
            rows.append(row)
            check()
        readable = [row for row in rows if row.error is None]
        if explicit:
            held_out = {row.image_index for row in readable if row.validation}
        else:
            ordered = sorted(readable, key=lambda row: row.fingerprint)
            held_out = {row.image_index for row in ordered[: max(1, len(ordered) // 5)]}
        rows = [
            replace(row, validation=row.image_index in held_out) if row.error is None else row
            for row in rows
        ]
        training, validation = len(readable) - len(held_out), len(held_out)
        classes.append(AuditClass(label, len(rows), len(readable), training, validation))
        if not training or not validation:
            issues.append(
                AuditIssue(
                    ("split",),
                    class_index,
                    None,
                    "Each class needs at least one readable training and one held-out image.",
                )
            )
        samples.extend(rows)

    groups = {}
    for sample in samples:
        if sample.fingerprint is not None:
            groups.setdefault(sample.fingerprint, []).append(sample)
    for group in groups.values():
        if len(group) < 2:
            continue
        codes = ["duplicate"]
        if len({row.class_index for row in group}) > 1:
            codes.append("label_conflict")
        if len({row.validation for row in group}) > 1:
            codes.append("split_leakage")
        members = "; ".join(
            f"{labels[row.class_index]}/{row.path.name} "
            f"({'held out' if row.validation else 'training'})"
            for row in group[:6]
        )
        if len(group) > 6:
            members += f"; and {len(group) - 6} more assignments"
        for sample in group:
            issues.append(
                AuditIssue(
                    tuple(codes),
                    sample.class_index,
                    sample.image_index,
                    "Identical normalized pixels: " + members,
                )
            )
    check()
    return DatasetAudit(
        "explicit" if explicit else "automatic", tuple(classes), tuple(samples), tuple(issues)
    )
