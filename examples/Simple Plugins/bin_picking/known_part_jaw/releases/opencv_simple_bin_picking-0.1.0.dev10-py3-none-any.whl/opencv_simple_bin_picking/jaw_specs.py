"""Metric CAD-taught jaw geometry; independent of suction settings and robot motion."""

import copy
import json
from dataclasses import asdict, dataclass, field

import numpy as np

from .jaw_mesh import PartMesh
from .specs import Recipe, label, number, rigid


def frozen(value):
    result = np.array(value, dtype=np.float64, copy=True, order="C")
    result.flags.writeable = False
    return result


def acquisition_id(value):
    if (
        not isinstance(value, str)
        or not value.strip()
        or len(value) > 256
        or any(ord(c) < 32 for c in value)
    ):
        raise ValueError("Use a nonempty current capture ID of at most 256 characters")
    return value


@dataclass(frozen=True)
class PartSurface:
    points: np.ndarray = field(repr=False, compare=False)
    normals: np.ndarray = field(repr=False, compare=False)
    frame: str = "part"

    def __post_init__(self):
        points, normals = np.asarray(self.points), np.asarray(self.normals)
        if (
            points.ndim != 2
            or points.shape[1:] != (3,)
            or not 4 <= len(points) <= 50_000
            or normals.shape != points.shape
            or not np.isfinite(points).all()
            or not np.isfinite(normals).all()
            or np.max(np.abs(points)) > 100
            or not np.allclose(np.linalg.norm(normals, axis=1), 1, atol=1e-5, rtol=0)
        ):
            raise ValueError(
                "Retain 4..50000 finite metric CAD surface points and outward unit normals"
            )
        if np.linalg.norm(np.ptp(points, axis=0)) < 1e-5:
            raise ValueError("Part surface must have physical extent")
        label(self.frame)
        object.__setattr__(self, "points", frozen(points))
        object.__setattr__(self, "normals", frozen(normals))


@dataclass(frozen=True)
class JawGrasp:
    name: str
    part_from_grasp: np.ndarray = field(repr=False, compare=False)
    span: float

    def __post_init__(self):
        label(self.name)
        object.__setattr__(self, "part_from_grasp", rigid(self.part_from_grasp))
        object.__setattr__(self, "span", number(self.span, "Taught contact span (m)", 1e-5, 2))

    def record(self):
        return dict(name=self.name, part_from_grasp=self.part_from_grasp.tolist(), span=self.span)

    @classmethod
    def from_contacts(cls, name, first, second, retract):
        """Two authored CAD contacts define jaw X; +Z is the projected retract direction."""
        points = np.asarray([first, second], float)
        z = np.array(retract, dtype=float, copy=True)
        if (
            points.shape != (2, 3)
            or z.shape != (3,)
            or not np.isfinite([*points.ravel(), *z]).all()
        ):
            raise ValueError("Use two finite part-frame contacts and a retract vector")
        delta = points[1] - points[0]
        span = float(np.linalg.norm(delta))
        if span < 1e-5:
            raise ValueError("Contacts must be distinct")
        x = delta / span
        z -= x * (x @ z)
        if np.linalg.norm(z) < 1e-8:
            raise ValueError("Retract direction must not be parallel to jaw closing X")
        z /= np.linalg.norm(z)
        matrix = np.eye(4)
        matrix[:3, :3] = np.column_stack((x, np.cross(z, x), z))
        matrix[:3, 3] = points.mean(0)
        return cls(name, matrix, span)


@dataclass(frozen=True)
class JawSettings:
    minimum_opening: float = 0.0
    maximum_opening: float = 0.08
    opening_margin: float = 0.006
    finger_thickness: float = 0.004
    finger_width: float = 0.008
    finger_length: float = 0.03
    pad_height: float = 0.006
    palm_height: float = 0.008
    palm_width: float = 0.09
    palm_depth: float = 0.02
    pregrasp_distance: float = 0.03
    clearance: float = 0.001
    contact_tolerance: float = 0.001
    pose_tolerance: float = 0.003
    sample_spacing: float = 0.003
    minimum_contact_fraction: float = 0.9
    minimum_pose_support: float = 0.7
    maximum_pose_contradiction: float = 0.1
    maximum_contact_angle_degrees: float = 25.0
    maximum_tilt_degrees: float = 60.0
    overlap_threshold: float = 0.2
    max_picks: int = 16
    workers: int = 1

    def __post_init__(self):
        for name in (
            "maximum_opening",
            "opening_margin",
            "finger_thickness",
            "finger_width",
            "finger_length",
            "pad_height",
            "palm_height",
            "palm_width",
            "palm_depth",
            "pregrasp_distance",
            "clearance",
            "contact_tolerance",
            "pose_tolerance",
            "sample_spacing",
        ):
            object.__setattr__(self, name, number(getattr(self, name), name, 1e-6, 2))
        object.__setattr__(
            self, "minimum_opening", number(self.minimum_opening, "Minimum opening", 0, 2)
        )
        if (
            self.minimum_opening >= self.maximum_opening
            or self.pad_height > self.finger_length
            or self.contact_tolerance >= self.finger_thickness
            or self.clearance > self.contact_tolerance
            or self.palm_width < self.maximum_opening + 2 * self.finger_thickness
            or self.palm_depth < self.finger_width
        ):
            raise ValueError(
                "Use compatible jaw stroke, pad/finger dimensions and contact/clearance bands"
            )
        for name in ("minimum_contact_fraction", "minimum_pose_support"):
            object.__setattr__(self, name, number(getattr(self, name), name, 0.1, 1))
        for name in ("maximum_pose_contradiction", "overlap_threshold"):
            object.__setattr__(self, name, number(getattr(self, name), name, 0, 1))
        for name in ("maximum_contact_angle_degrees", "maximum_tilt_degrees"):
            object.__setattr__(self, name, number(getattr(self, name), name, 0.01, 89.9))
        for name, upper in (("workers", 8), ("max_picks", 128)):
            if type(getattr(self, name)) is not int or not 1 <= getattr(self, name) <= upper:
                raise ValueError(f"{name} must be an integer in 1..{upper}")


@dataclass(frozen=True)
class PartInstance:
    identifier: str
    camera_from_part: np.ndarray = field(repr=False, compare=False)
    accepted: bool
    capture_id: str
    label_id: int | None = None

    def __post_init__(self):
        label(self.identifier)
        acquisition_id(self.capture_id)
        if type(self.accepted) is not bool:
            raise ValueError("Explicitly declare whether the upstream pose was accepted")
        if self.label_id is not None and (
            type(self.label_id) is not int or not 1 <= self.label_id < 2**31
        ):
            raise ValueError("Use a positive integer instance label, or omit it")
        object.__setattr__(self, "camera_from_part", rigid(self.camera_from_part))

    @classmethod
    def from_record(cls, value, *, part_frame, camera_frame):
        if not isinstance(value, dict) or value.get("model") != "part_instance_v1":
            raise ValueError("Supply explicit part_instance_v1 accepted-pose records")
        pose = value.get("pose", {})
        if (
            not isinstance(pose, dict)
            or pose.get("model") != "pose_3d_v1"
            or pose.get("units") != "m"
            or pose.get("source_frame") != part_frame
            or pose.get("target_frame") != camera_frame
        ):
            raise ValueError(
                "Part pose must map the retained original part frame to this camera in m"
            )
        return cls(
            value["id"],
            pose["source_to_target"],
            value["accepted"],
            value["capture_id"],
            value.get("label_id"),
        )


@dataclass(frozen=True)
class JawRecipe:
    bin: Recipe
    part: PartSurface
    grasps: tuple
    settings: JawSettings = field(default_factory=JawSettings)
    grasp_from_tcp: np.ndarray = field(default_factory=lambda: np.eye(4), repr=False, compare=False)
    notes: dict = field(default_factory=dict, compare=False)
    mesh: PartMesh | None = field(default=None, repr=False, compare=False)

    def __post_init__(self):
        if not isinstance(self.bin, Recipe) or self.bin.units != "m":
            raise ValueError("Jaw planning requires a calibrated bin/reference recipe in meters")
        if not isinstance(self.part, PartSurface) or not isinstance(self.settings, JawSettings):
            raise ValueError("Retain a CAD part surface and validated jaw settings")
        if self.mesh is not None and (
            not isinstance(self.mesh, PartMesh) or self.mesh.frame != self.part.frame
        ):
            raise ValueError("Triangle mesh and part samples must share the original part frame")
        grasps = tuple(self.grasps)
        if (
            not 1 <= len(grasps) <= 32
            or any(not isinstance(g, JawGrasp) for g in grasps)
            or len({g.name for g in grasps}) != len(grasps)
        ):
            raise ValueError("Teach 1..32 uniquely named part-relative jaw grasps")
        object.__setattr__(self, "grasps", grasps)
        object.__setattr__(self, "grasp_from_tcp", rigid(self.grasp_from_tcp))
        if not isinstance(self.notes, dict):
            raise ValueError("Recipe notes must be a JSON object")
        raw = json.dumps(self.notes, allow_nan=False).encode("utf-8")
        if len(raw) > 65536:
            raise ValueError("Recipe notes exceed 64 KiB")
        object.__setattr__(self, "notes", json.loads(raw))

    def configuration(self):
        result = dict(
            bin=self.bin.configuration(),
            part_frame=self.part.frame,
            grasps=[g.record() for g in self.grasps],
            jaw_settings=asdict(self.settings),
            grasp_from_tcp=self.grasp_from_tcp.tolist(),
            units="m",
            notes=copy.deepcopy(self.notes),
        )
        if self.mesh is not None:
            result["mesh"] = dict(
                frame=self.mesh.frame,
                units="m",
                triangles=len(self.mesh.triangles),
                usage="diagnostic_only",
            )
        return result
