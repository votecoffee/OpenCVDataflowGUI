"""Cached CAD jaw teaching to finite measured-depth clearance, without robot execution."""

import copy
import hashlib
import math
from concurrent.futures import CancelledError, ThreadPoolExecutor
from dataclasses import dataclass

import numpy as np
from scipy.spatial import cKDTree

from .jaw_fit import retain_pose_fit
from .jaw_mesh import inspect_mesh
from .jaw_specs import JawRecipe, PartInstance, acquisition_id
from .scene import Scene


def transform(points, matrix):
    return points @ matrix[:3, :3].T + matrix[:3, 3]


def corners(low, high):
    return np.asarray(
        [[x, y, z] for x in (low[0], high[0]) for y in (low[1], high[1]) for z in (low[2], high[2])]
    )


def inside(points, low, high):
    return np.all(points >= low, axis=1) & np.all(points <= high, axis=1)


def aabb_overlap(first, second):
    a, b = np.asarray(first), np.asarray(second)
    intersection = np.prod(np.maximum(0, np.minimum(a[1], b[1]) - np.maximum(a[0], b[0])))
    denominator = min(np.prod(a[1] - a[0]), np.prod(b[1] - b[0]))
    return float(intersection / max(float(denominator), 1e-30))


def select_alternatives(candidates, settings):
    candidates.sort(key=lambda c: (c["status"] != "eligible", -c["score"], c["id"]))
    accepted = []
    for item in candidates:
        if item["status"] != "eligible":
            continue
        other = next(
            (
                c
                for c in accepted
                if aabb_overlap(c["overlap_bounds"], item["overlap_bounds"])
                > settings.overlap_threshold
            ),
            None,
        )
        if other is not None:
            item.update(
                status="rejected",
                reasons=["overlap_with_higher_ranked"],
                overlap_candidate=other["id"],
            )
        elif len(accepted) >= settings.max_picks:
            item.update(status="rejected", reasons=["grasp_count_limit"])
        else:
            item["rank"] = len(accepted) + 1
            accepted.append(item)
    return tuple(candidates)


def tool_boxes(span, opening, settings):
    """Open approach, closed retract, closure sweeps and fixed-width palm sweep."""
    s = settings
    low_z = -s.pad_height / 2
    high_z = s.finger_length - s.pad_height / 2
    result = []
    for sign in (-1, 1):
        for name, inner, outer, top in (
            (
                "open_approach",
                opening / 2,
                opening / 2 + s.finger_thickness,
                high_z + s.pregrasp_distance,
            ),
            (
                "closed_retract",
                span / 2,
                span / 2 + s.finger_thickness,
                high_z + s.pregrasp_distance,
            ),
            ("closure", span / 2, opening / 2 + s.finger_thickness, high_z),
        ):
            x = sorted((sign * inner, sign * outer))
            low = np.array([x[0], -s.finger_width / 2, low_z]) - s.clearance
            high = np.array([x[1], s.finger_width / 2, top]) + s.clearance
            result.append((f"{name}_{sign:+}", low, high))
    low = np.array([-s.palm_width / 2, -s.palm_depth / 2, high_z]) - s.clearance
    high = (
        np.array([s.palm_width / 2, s.palm_depth / 2, high_z + s.palm_height + s.pregrasp_distance])
        + s.clearance
    )
    result.append(("palm_sweep", low, high))
    return tuple(result)


def box_samples(boxes, spacing):
    counts = [np.ceil((high - low) / spacing).astype(int) + 1 for _, low, high in boxes]
    if sum(math.prod(int(n) for n in count) for count in counts) > 65_536:
        raise ValueError(
            "Gripper sampling exceeds 65536 points; declare a coarser training spacing"
        )
    result = []
    for (_, low, high), count in zip(boxes, counts):
        axes = [np.linspace(a, b, n) for a, b, n in zip(low, high, count)]
        result.append(np.stack(np.meshgrid(*axes, indexing="ij"), axis=-1).reshape(-1, 3))
    return np.unique(np.concatenate(result), axis=0)


@dataclass(frozen=True)
class JawResult:
    recipe: JawRecipe
    scene: Scene
    candidates: tuple
    capture_id: str
    pose_evidence: tuple
    pose_fits: tuple = ()
    mesh_fits: tuple = ()

    @property
    def picks(self):
        return tuple(c for c in self.candidates if c["status"] == "eligible")

    def report(self):
        report = dict(
            model="simple_bin_picking_jaw_v1",
            units="m",
            frame=self.recipe.bin.frame,
            camera_frame=self.recipe.bin.camera.frame,
            part_frame=self.recipe.part.frame,
            capture_id=self.capture_id,
            eligible_grasps=len(self.picks),
            candidates=copy.deepcopy(list(self.candidates)),
            pose_evidence=copy.deepcopy(list(self.pose_evidence)),
            contact_source=(
                "CAD-taught finite pad samples; not measured hidden contacts or force closure"
            ),
            clearance_definition=(
                "Finite gripper boxes, observed points and four-neighbor first-return rays"
            ),
            contact_band="Explicit CAD contact tolerance; not observed free space",
            overlap_metric=(
                "Contact AABB intersection over smaller volume; higher geometric score wins"
            ),
            unobserved_space="unknown_not_free",
            held_part_transport_checked=False,
            robot_execution=False,
            qualification="No full-robot, friction/force-closure or physical pick qualification",
            depth_sha256=hashlib.sha256(self.scene.depth.tobytes()).hexdigest(),
        )
        if self.recipe.mesh is not None:
            report["mesh_usage"] = "Retained diagnostic only; pose/clearance gates use part samples"
        return report


class JawPlanner:
    def __init__(self, recipe):
        if not isinstance(recipe, JawRecipe):
            raise TypeError("Use a retained JawRecipe")
        self.recipe = recipe
        self.model_tree = cKDTree(recipe.part.points)
        self.normals = recipe.part.normals / np.linalg.norm(recipe.part.normals, axis=1)[:, None]
        self.normals.flags.writeable = False
        self.compiled = tuple(self._compile(grasp) for grasp in recipe.grasps)

    def _compile(self, grasp):
        s = self.recipe.settings
        opening = max(s.minimum_opening, grasp.span + 2 * s.opening_margin)
        boxes = tool_boxes(grasp.span, opening, s)
        all_corners = np.concatenate([corners(low, high) for _, low, high in boxes])
        samples = box_samples(boxes, s.sample_spacing)
        model = transform(self.recipe.part.points, np.linalg.inv(grasp.part_from_grasp))
        allowed = self._contact_band(model, grasp)
        collisions = np.flatnonzero(
            np.logical_or.reduce([inside(model, low, high) for _, low, high in boxes]) & ~allowed
        )
        yz = np.asarray(
            [
                [y, z]
                for y in np.linspace(-s.finger_width / 2, s.finger_width / 2, 3)
                for z in np.linspace(-s.pad_height / 2, s.pad_height / 2, 3)
            ]
        )
        fractions, contacts = [], []
        for sign in (-1, 1):
            pad = transform(
                np.c_[np.full(len(yz), sign * grasp.span / 2), yz], grasp.part_from_grasp
            )
            distance, indices = self.model_tree.query(pad)
            normals = self.normals[indices]
            aligned = normals @ (sign * grasp.part_from_grasp[:3, 0])
            supported = (distance <= s.contact_tolerance) & (
                aligned >= np.cos(np.deg2rad(s.maximum_contact_angle_degrees))
            )
            fractions.append(float(supported.mean()))
            contacts.append(pad)
        for array in (samples, model, collisions):
            array.flags.writeable = False
        return dict(
            grasp=grasp,
            opening=opening,
            boxes=boxes,
            samples=samples,
            corners=all_corners,
            low=all_corners.min(0),
            high=all_corners.max(0),
            contact_fraction=min(fractions),
            contact_sides=tuple(fractions),
            contacts=np.concatenate(contacts),
            model_collisions=collisions,
        )

    def _contact_band(self, local, grasp):
        s = self.recipe.settings
        band = (
            (abs(abs(local[:, 0]) - grasp.span / 2) <= s.contact_tolerance + 1e-12)
            & (abs(local[:, 1]) <= s.finger_width / 2 + s.clearance)
            & (local[:, 2] >= -s.pad_height / 2 - s.clearance)
            & (local[:, 2] <= s.finger_length - s.pad_height / 2 + s.clearance)
        )
        if not band.any():
            return band
        points = transform(local[band], grasp.part_from_grasp)
        _, rows = self.model_tree.query(points)
        delta = points - self.recipe.part.points[rows]
        gap = np.sum(delta * self.normals[rows], axis=1)
        tangent = delta - gap[:, None] * self.normals[rows]
        # Bound both normal and tangential support: discrete CAD sampling must not
        # turn a valid contact band into holes, or extend an infinite plane.
        close = (abs(gap) <= s.contact_tolerance + 1e-12) & (
            np.linalg.norm(tangent, axis=1) <= s.contact_tolerance + 1e-12
        )
        band[np.flatnonzero(band)] &= close
        return band

    def _pose_evidence(self, scene, instance, review=None):
        if not instance.accepted:
            return dict(
                id=instance.identifier,
                status="rejected",
                reason="upstream_pose_not_accepted",
                coverage=0.0,
                contradiction=0.0,
            )
        s, part = self.recipe.settings, self.recipe.part
        points = transform(part.points, instance.camera_from_part)
        normals = self.normals @ instance.camera_from_part[:3, :3].T
        visible = (np.sum(normals * -points, axis=1) > 1e-12) & (points[:, 2] > 1e-8)
        rows = np.flatnonzero(visible)
        k, (width, height) = np.asarray(scene.recipe.camera.matrix), scene.recipe.camera.image_size
        pixels = np.zeros((len(rows), 2), int)
        projected = points[rows] @ k.T
        uv = projected[:, :2] / projected[:, 2:3]
        valid = (
            np.isfinite(uv).all(1)
            & np.all(uv >= 0, axis=1)
            & np.all(uv < [width - 1, height - 1], axis=1)
        )
        rows, uv = rows[valid], uv[valid]
        pixels = np.rint(uv).astype(int)
        keys = pixels[:, 1] * width + pixels[:, 0]
        order = np.lexsort((rows, points[rows, 2], keys))
        _, first = np.unique(keys[order], return_index=True)
        rows = rows[order[first]]
        bin_points = (points[rows] - scene.pose[:3, 3]) @ scene.pose[:3, :3]
        known, nearest, farthest, uv, z = scene.sample(bin_points)
        same = np.ones(len(rows), bool)
        if scene.instances is not None:
            if instance.label_id is None:
                raise ValueError(
                    "Supply each accepted pose's instance label when a label image is connected"
                )
            xy = np.floor(np.clip(uv, [0, 0], [width - 2, height - 2])).astype(int)
            x, y = xy.T
            labels = scene.instances[y[:, None] + [0, 0, 1, 1], x[:, None] + [0, 1, 0, 1]]
            same = np.all(labels == instance.label_id, axis=1)
        support = (
            known & same & (np.maximum(abs(z - nearest), abs(z - farthest)) <= s.pose_tolerance)
        )
        contradiction = known & (z < nearest - s.pose_tolerance)
        if review is not None:
            review.append(
                retain_pose_fit(
                    instance.identifier,
                    bin_points,
                    rows,
                    known,
                    nearest,
                    farthest,
                    z,
                    same,
                    support,
                    contradiction,
                    s.pose_tolerance,
                )
            )
        coverage = float(support.mean()) if len(rows) else 0.0
        bad = float(contradiction.mean()) if len(rows) else 0.0
        accepted = (
            len(rows) >= 12
            and coverage >= s.minimum_pose_support
            and bad <= s.maximum_pose_contradiction
        )
        return dict(
            id=instance.identifier,
            status="accepted" if accepted else "unknown" if not known.any() else "rejected",
            reason="raw_depth_fit" if accepted else "insufficient_current_pose_evidence",
            coverage=coverage,
            contradiction=bad,
            samples=len(rows),
            known_samples=int(known.sum()),
            supported_samples=int(support.sum()),
        )

    def _candidate(self, scene, instance, evidence, compiled, identifier):
        s, grasp = self.recipe.settings, compiled["grasp"]
        camera_from_grasp = instance.camera_from_part @ grasp.part_from_grasp
        bin_from_grasp = np.linalg.inv(scene.pose) @ camera_from_grasp
        tcp = bin_from_grasp @ self.recipe.grasp_from_tcp
        offset = np.eye(4)
        offset[2, 3] = s.pregrasp_distance
        pregrasp = bin_from_grasp @ offset @ self.recipe.grasp_from_tcp
        item = dict(
            id=identifier,
            instance_id=instance.identifier,
            grasp_name=grasp.name,
            status="rejected",
            reasons=[],
            score=0.0,
            opening=compiled["opening"],
            span=grasp.span,
            grasp_pose=bin_from_grasp.tolist(),
            tcp_pose=tcp.tolist(),
            pregrasp_pose=pregrasp.tolist(),
            approach_direction=(-bin_from_grasp[:3, 2]).tolist(),
            retract_direction=bin_from_grasp[:3, 2].tolist(),
            pose_status=evidence["status"],
            contact_fraction=compiled["contact_fraction"],
            contact_sides=list(compiled["contact_sides"]),
            contact_source="CAD_model_assisted",
            contact_identity="matching_instance_labels"
            if scene.instances is not None
            else "inferred_near_CAD_surface_without_labels",
            clearance_status="not_evaluated",
            collision_rows=[],
            unknown_samples=[],
            model_collision_rows=compiled["model_collisions"][:128].tolist(),
        )
        if evidence["status"] != "accepted":
            item.update(status=evidence["status"], reasons=[evidence["reason"]])
            return item
        item["score"] = float(0.5 * evidence["coverage"] + 0.5 * compiled["contact_fraction"])
        if grasp.span < s.minimum_opening or compiled["opening"] > s.maximum_opening:
            item["reasons"] = ["jaw_opening_limit"]
            return item
        if compiled["contact_fraction"] < s.minimum_contact_fraction:
            item["reasons"] = ["unsupported_CAD_contact_pads"]
            return item
        if len(compiled["model_collisions"]):
            item["reasons"] = ["CAD_gripper_sweep_collision"]
            item["clearance_status"] = "model_collision"
            return item
        tilt = float(np.degrees(np.arccos(np.clip(bin_from_grasp[2, 2], -1, 1))))
        item["tilt_degrees"] = tilt
        if tilt > s.maximum_tilt_degrees:
            item["reasons"] = ["approach_tilt_limit"]
            return item
        contacts = transform(
            corners(
                [-grasp.span / 2, -s.finger_width / 2, -s.pad_height / 2],
                [grasp.span / 2, s.finger_width / 2, s.pad_height / 2],
            ),
            bin_from_grasp,
        )
        item["overlap_bounds"] = [contacts.min(0).tolist(), contacts.max(0).tolist()]
        bounds = transform(compiled["corners"], bin_from_grasp)
        if (
            np.any(bounds[:, :2] < self.recipe.bin.minimum[:2])
            or np.any(bounds[:, :2] > self.recipe.bin.maximum[:2])
            or np.any(bounds[:, 2] < self.recipe.bin.minimum[2])
        ):
            item.update(reasons=["configured_bin_collision"], clearance_status="bin_collision")
            return item
        inv = np.linalg.inv(bin_from_grasp)
        center = transform(((compiled["low"] + compiled["high"]) / 2)[None], bin_from_grasp)[0]
        radius = float(np.linalg.norm(compiled["high"] - compiled["low"]) / 2) + 1e-12
        nearby = (
            np.asarray(scene.tree.query_ball_point(center, radius), int)
            if scene.tree
            else np.empty(0, int)
        )
        local = transform(scene.points[nearby], inv)
        hits = np.logical_or.reduce(
            [inside(local, low, high) for _, low, high in compiled["boxes"]]
        )
        allowance = self._contact_band(local, grasp)
        if scene.instances is not None:
            pixels = scene.pixels[nearby]
            allowance &= scene.instances[pixels[:, 1], pixels[:, 0]] == instance.label_id
        collision_rows = nearby[hits & ~allowance].tolist()
        item["collision_rows"] = sorted(collision_rows)[:128]
        item["collision_points"] = len(collision_rows)
        if collision_rows:
            item.update(
                reasons=["observed_gripper_sweep_collision"], clearance_status="observed_collision"
            )
            return item
        local = compiled["samples"]
        contact = self._contact_band(local, grasp)
        samples = transform(local, bin_from_grasp)
        known, nearest, _, _, z = scene.sample(samples)
        free = known & (z < nearest - s.contact_tolerance)
        unknown = ~free & ~contact
        item.update(
            clearance_samples=len(samples),
            free_samples=int((free & ~contact).sum()),
            contact_band_samples=int(contact.sum()),
            unknown_sample_count=int(unknown.sum()),
            unknown_samples=samples[unknown][:128].tolist(),
        )
        if unknown.any():
            item.update(
                status="unknown",
                reasons=["unobserved_or_occluded_gripper_sweep"],
                clearance_status="unknown",
            )
        else:
            item.update(status="eligible", clearance_status="sampled_free_outside_CAD_contact_band")
        return item

    def plan(
        self,
        depth,
        instances,
        *,
        capture_id,
        bin_to_camera=None,
        instance_labels=None,
        cancelled=lambda: False,
        retain_pose_fit=True,
    ):
        def check():
            if cancelled():
                raise CancelledError("Jaw planning cancelled; no current grasp published")

        check()
        if type(retain_pose_fit) is not bool:
            raise ValueError("Pose-fit retention must be boolean")
        acquisition_id(capture_id)
        instances = tuple(instances)
        if (
            len(instances) > 32
            or any(not isinstance(i, PartInstance) for i in instances)
            or len({i.identifier for i in instances}) != len(instances)
        ):
            raise ValueError("Use up to 32 uniquely identified accepted/rejected part instances")
        if any(i.capture_id != capture_id for i in instances):
            raise ValueError("Part poses and depth must declare the same current capture ID")
        scene = Scene(
            self.recipe.bin, depth, bin_to_camera=bin_to_camera, instances=instance_labels
        )
        check()
        evidence, review = [], [] if retain_pose_fit else None
        for item in instances:
            check()
            evidence.append(self._pose_evidence(scene, item, review))
        evidence = tuple(evidence)
        mesh_review = []
        if retain_pose_fit and self.recipe.mesh is not None:
            for item in instances:
                check()
                if item.accepted:
                    mesh_review.append(
                        inspect_mesh(
                            self.recipe.mesh,
                            scene,
                            item,
                            self.recipe.settings.pose_tolerance,
                            cancelled=cancelled,
                        )
                    )
        jobs = [
            (instance, fit, grasp, index * len(self.compiled) + g)
            for index, (instance, fit) in enumerate(zip(instances, evidence))
            for g, grasp in enumerate(self.compiled)
        ]

        def evaluate(job):
            check()
            return self._candidate(scene, *job)

        if self.recipe.settings.workers > 1 and len(jobs) > 1:
            with ThreadPoolExecutor(
                max_workers=self.recipe.settings.workers, thread_name_prefix="jaw-grasp"
            ) as pool:
                candidates = list(pool.map(evaluate, jobs))
        else:
            candidates = list(map(evaluate, jobs))
        check()
        selected = select_alternatives(candidates, self.recipe.settings)
        return JawResult(
            self.recipe,
            scene,
            selected,
            capture_id,
            evidence,
            tuple(review or ()),
            tuple(mesh_review),
        )
