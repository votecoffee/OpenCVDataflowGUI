"""Retained metric triangles and diagnostic first-surface evidence, independent of pose gates."""

from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from .jaw_fit import classify_pose_fit, retain_pose_fit
from .jaw_metrics import mesh_statistics
from .specs import label

MAX_TRIANGLES = 200_000


@dataclass(frozen=True)
class PartMesh:
    triangles: np.ndarray = field(repr=False, compare=False)
    frame: str = "part"

    def __post_init__(self):
        data = np.array(self.triangles, dtype=np.float64, order="C", copy=True)
        if (
            data.ndim != 3
            or data.shape[1:] != (3, 3)
            or not 1 <= len(data) <= MAX_TRIANGLES
            or not np.isfinite(data).all()
            or np.max(abs(data)) > 100
        ):
            raise ValueError("Retain 1..200000 finite metric triangles within +/-100 m")
        diagonal = float(np.linalg.norm(np.ptp(data.reshape(-1, 3), axis=0)))
        if diagonal < 1e-5:
            raise ValueError("Triangle mesh needs physical extent of at least 0.01 mm")
        cross = np.cross((data[:, 1] - data[:, 0]) / diagonal, (data[:, 2] - data[:, 0]) / diagonal)
        length = np.linalg.norm(cross, axis=1)
        if np.any(length <= np.finfo(float).eps * 16):
            raise ValueError("Remove degenerate triangles before retaining the mesh")
        normals = cross / length[:, None]
        area = length * diagonal**2 / 2
        for value in (data, normals, area):
            value.flags.writeable = False
        object.__setattr__(self, "triangles", data)
        object.__setattr__(self, "normals", normals)
        object.__setattr__(self, "areas", area)
        label(self.frame)

    def sample(self, count=40_000, seed=27):
        """Deterministic area-weighted surface samples in the original mesh frame."""
        from .jaw_specs import PartSurface

        if type(count) is not int or not 4 <= count <= 50_000:
            raise ValueError("Choose 4..50000 mesh surface samples")
        if type(seed) is not int or not 0 <= seed < 2**32:
            raise ValueError("Mesh sample seed must be an unsigned 32-bit integer")
        rng = np.random.default_rng(seed)
        rows = rng.choice(len(self.triangles), count, p=self.areas / self.areas.sum())
        uv = rng.random((count, 2))
        root = np.sqrt(uv[:, 0])
        weights = np.c_[1 - root, root * (1 - uv[:, 1]), root * uv[:, 1]]
        points = np.einsum("ni,nij->nj", weights, self.triangles[rows])
        return PartSurface(points, self.normals[rows], self.frame)

    @classmethod
    def read(cls, path, *, scale, frame="part", flip_normals=False):
        """Optional companion geometry reader, used only during explicit import."""
        try:
            from opencv_simple_3d_locate import read_mesh
        except ImportError as error:
            raise ValueError(
                "Mesh file import needs Simple3DLocate's geometry reader; "
                "load the bundled Simple Plugins plugin or use a PartMesh array"
            ) from error
        mesh = read_mesh(Path(path), scale=scale, flip_normals=flip_normals)
        return cls(mesh.triangles, frame)


@dataclass(frozen=True)
class MeshFitReview:
    instance_id: str
    points: np.ndarray
    states: np.ndarray
    pixel_ids: np.ndarray
    summary: dict


def inspect_mesh(mesh, scene, instance, tolerance, *, cancelled=lambda: False):
    from .jaw_raster import render_depth

    camera = scene.recipe.camera
    predicted, incidence, stride, reason = render_depth(
        mesh, instance.camera_from_part, camera, cancelled=cancelled
    )
    y, x = np.nonzero(np.isfinite(predicted))
    z = predicted[y, x]
    x, y = x * stride, y * stride
    observed = scene.depth[y, x]
    known = np.isfinite(observed) & (observed > 0) & (observed <= 1e9)
    same = np.ones(len(z), bool)
    if scene.instances is not None:
        if instance.label_id is None:
            raise ValueError("Supply each accepted pose's label for mesh diagnostic review")
        same = scene.instances[y, x] == instance.label_id
    delta = z - observed
    support = known & same & (abs(delta) <= tolerance)
    contradiction = known & (delta < -tolerance)
    k = np.asarray(camera.matrix)
    points = np.c_[(x - k[0, 2]) * z / k[0, 0], (y - k[1, 2]) * z / k[1, 1], z]
    points = (points - scene.pose[:3, 3]) @ scene.pose[:3, :3]
    review = retain_pose_fit(
        instance.identifier,
        points,
        y * camera.image_size[0] + x,
        known,
        observed,
        observed,
        z,
        same,
        support,
        contradiction,
        tolerance,
    )
    summary = dict(review.summary)
    states = classify_pose_fit(
        known, observed, observed, z, same, support, contradiction, tolerance
    )
    summary.update(
        model="jaw_triangle_pose_review_v1",
        status="unavailable" if reason or not len(z) else "reviewed",
        reason=reason or (None if len(z) else "no_projected_surface"),
        triangle_count=len(mesh.triangles),
        grid_stride_pixels=stride,
        renderer="bounded_perspective_first_surface_v1",
        acceptance_applied=False,
        point_gate_unchanged=True,
        row_identity="Full-image integer pixel ID",
        residual_definition="Predicted camera Z minus observed depth at the same integer pixel",
        residual_scope="Includes occlusion; separate diagnostic population from the point gate",
        weighting=mesh_statistics(states, z, incidence[y // stride, x // stride], camera, stride),
    )
    return MeshFitReview(
        instance.identifier, review.points, review.states, review.model_rows, summary
    )
