"""Native retained CAD-contact teaching and independent frozen jaw previews."""

import json
import uuid
from concurrent.futures import CancelledError, ThreadPoolExecutor
from dataclasses import replace
from pathlib import Path
from threading import Event

import cv2
import numpy as np
from opencv_dataflow.cloud_io import read_cloud, write_cloud
from opencv_dataflow.cloud_teaching import CloudTeachingWidget
from opencv_dataflow.cloud_viewer import CloudViewer
from opencv_dataflow.payloads import require_same_frame
from opencv_dataflow.pointclouds import PointCloud
from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGridLayout,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from .jaw_cli import read_json, read_numeric
from .jaw_dataflow import recipe_path
from .jaw_graphics import LAYERS, jaw_result_cloud
from .jaw_mesh import PartMesh
from .jaw_persistence import load_jaw_recipe, save_jaw_recipe
from .jaw_specs import JawGrasp, JawRecipe, JawSettings, PartSurface
from .jaw_teaching import (
    JawTeachingSession,
    freeze_inputs,
    grasp_segments,
    reference_capture,
    retain_reference,
    run_preview,
)
from .persistence import load_recipe

FRACTIONS = {
    "minimum_contact_fraction",
    "minimum_pose_support",
    "maximum_pose_contradiction",
    "overlap_threshold",
}
ADVANCED = FRACTIONS | {
    "maximum_contact_angle_degrees",
    "maximum_tilt_degrees",
    "contact_tolerance",
    "pose_tolerance",
    "sample_spacing",
    "workers",
    "max_picks",
}


class JawTrainingDialog(QDialog):
    def __init__(self, parent, parameters, context):
        super().__init__(parent)
        self.parameters, self.context = parameters, context
        self.session = JawTeachingSession()
        self._restoring = self._closed = False
        self._grasp_edits, self._setting_edits, self._mount_edits = set(), set(), set()
        self._loaded_grasp = None
        self._point_overrides = {}
        self._future = self._job = self._cancel = None
        self._live_revision = None
        self._last_capture = None
        self._unsubscribe = None
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="jaw-teaching")
        self.setWindowTitle("SimpleBinPicking Jaw · teach contacts and review clearance")
        self.resize(1470, 960)
        layout = QVBoxLayout(self)
        actions = QGridLayout()
        self.buttons = {}
        for text, callback in (
            ("Import jaw recipe…", self.choose_recipe),
            ("New from bin + CAD…", self.choose_setup),
            ("New from bin + triangle CAD…", self.choose_mesh_setup),
            ("Capture connected reference", self.capture_reference),
            ("Import reference…", self.choose_reference),
            ("Preview reference", self.preview_reference),
            ("Preview connected", self.preview_connected),
            ("Cancel preview", self.cancel_preview),
            ("Stage recipe", self.stage),
        ):
            button = QPushButton(text)
            button.clicked.connect(lambda checked=False, f=callback: self.guarded(f))
            index = len(self.buttons)
            actions.addWidget(button, index // 4, index % 4)
            self.buttons[text] = button
        layout.addLayout(actions)
        self.status = QLabel(
            "Import retained training, or a calibrated metric bin and CAD surface."
        )
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.identity = QLabel("No retained CAD/reference")
        self.identity.setWordWrap(True)
        layout.addWidget(self.identity)
        split = QSplitter()
        layout.addWidget(split, 1)
        controls = QWidget()
        side = QVBoxLayout(controls)
        self.forms = QTabWidget()
        side.addWidget(self.forms, 1)
        grasp_page = QWidget()
        grasp_layout = QVBoxLayout(grasp_page)
        self.grasps = QListWidget()
        self.grasps.setMaximumHeight(155)
        self.grasps.currentRowChanged.connect(self.select_grasp)
        grasp_layout.addWidget(self.grasps)
        row = QHBoxLayout()
        for text, callback in (
            ("Duplicate", self.duplicate_grasp),
            ("Remove", self.remove_grasp),
            ("Undo", self.undo),
        ):
            button = QPushButton(text)
            button.clicked.connect(lambda checked=False, f=callback: self.guarded(f))
            row.addWidget(button)
        grasp_layout.addLayout(row)
        form = QFormLayout()
        self.grasp_name = QLineEdit()
        self.grasp_name.textEdited.connect(lambda *_: self.changed("grasp", "name"))
        form.addRow("Grasp name", self.grasp_name)
        self.vectors = {}
        for name, title in (
            ("first", "First contact (mm)"),
            ("second", "Second contact (mm)"),
            ("retract", "Retract direction"),
        ):
            container, spins = self.vector_fields(
                lambda i, n=name: self.changed("grasp", (n, i)),
                decimals=9,
                limit=100_000 if name != "retract" else 1000,
            )
            self.vectors[name] = spins
            form.addRow(title, container)
        self.pick_target = QComboBox()
        for title, key in (
            ("Orbit / inspect", ""),
            ("Pick first contact", "first"),
            ("Pick second contact", "second"),
            ("Pick retract tip", "retract"),
        ):
            self.pick_target.addItem(title, key)
        self.pick_target.currentIndexChanged.connect(self.pick_mode)
        form.addRow("CAD point selection", self.pick_target)
        apply_button = QPushButton("Apply contact edit to draft")
        apply_button.clicked.connect(lambda: self.guarded(self.sync))
        form.addRow(apply_button)
        grasp_layout.addLayout(form)
        grasp_layout.addWidget(
            QLabel(
                "Orbit to expose the opposite face, then pick each contact.\n"
                "Coordinates use the original CAD frame. +Z retracts."
            )
        )
        grasp_layout.addStretch()
        self.forms.addTab(grasp_page, "Contacts")
        self.fields = {}
        for advanced, title in ((False, "Gripper"), (True, "Evidence / workers")):
            widget, form = QWidget(), QFormLayout()
            widget.setLayout(form)
            for name, value in vars(JawSettings()).items():
                if (name in ADVANCED) != advanced:
                    continue
                if name in ("max_picks", "workers"):
                    spin = QSpinBox()
                    spin.setRange(1, 8 if name == "workers" else 128)
                else:
                    spin = QDoubleSpinBox()
                    spin.setDecimals(9)
                    spin.setRange(
                        0, 100 if name in FRACTIONS else 89.9 if "degrees" in name else 2000
                    )
                spin.setValue(value * self.factor(name))
                spin.valueChanged.connect(lambda _, n=name: self.changed("setting", n))
                spin.setToolTip("Retained generic setting; preview after changing it.")
                self.fields[name] = spin
                unit = (
                    "%"
                    if name in FRACTIONS
                    else "deg"
                    if "degrees" in name
                    else ("" if name in ("max_picks", "workers") else "mm")
                )
                form.addRow(
                    name.replace("_", " ").capitalize() + (f" ({unit})" if unit else ""), spin
                )
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setWidget(widget)
            self.forms.addTab(scroll, title)
        mount_page, mount_form = QWidget(), QFormLayout()
        mount_page.setLayout(mount_form)
        self.mount = {}
        for name, title in (
            ("offset", "Grasp-from-TCP offset (mm)"),
            ("rotation", "Mount rotation vector (deg)"),
        ):
            widget, spins = self.vector_fields(
                lambda i, n=name: self.changed("mount", (n, i)), decimals=9, limit=100_000
            )
            self.mount[name] = spins
            mount_form.addRow(title, widget)
        note = QLabel("Retract follows grasp +Z, independently of the mounted TCP axes.")
        note.setWordWrap(True)
        mount_form.addRow(note)
        self.forms.addTab(mount_page, "TCP mount")
        self.health = QLabel(
            "Preview reports CAD contact, current pose fit and clearance separately."
        )
        self.health.setWordWrap(True)
        side.addWidget(self.health)
        row = QHBoxLayout()
        export, cancel = QPushButton("Export cached review…"), QPushButton("Cancel")
        export.clicked.connect(lambda: self.guarded(self.choose_export))
        cancel.clicked.connect(self.reject)
        row.addWidget(export)
        row.addWidget(cancel)
        side.addLayout(row)
        split.addWidget(controls)
        right, right_layout = QWidget(), QVBoxLayout()
        right.setLayout(right_layout)
        self.tabs = QTabWidget()
        self.editor = CloudTeachingWidget()
        self.editor.point_picked.connect(lambda pick: self.guarded(lambda: self.picked(pick)))
        self.editor.mode.removeItem(self.editor.mode.findData("draw"))
        self.tabs.addTab(self.editor, "Canonical CAD / taught jaws")
        self.reference_view = CloudViewer(None, self)
        self.viewer = CloudViewer(None, self)
        for viewer in (self.reference_view, self.viewer):
            viewer.setWindowFlags(Qt.WindowType.Widget)
            viewer.yaw.setValue(155)
        self.tabs.addTab(self.reference_view, "Retained measured reference")
        self.tabs.addTab(self.viewer, "Cached clearance evidence")
        right_layout.addWidget(self.tabs, 1)
        geometry_controls = QHBoxLayout()
        self.geometry_sweeps = QCheckBox("Show taught approach/closure/retract sweeps")
        self.geometry_sweeps.setChecked(True)
        self.geometry_sweeps.toggled.connect(lambda: self.guarded(self.show_geometry))
        geometry_controls.addWidget(self.geometry_sweeps)
        fit_jaws = QPushButton("Fit CAD + jaws")
        fit_jaws.clicked.connect(lambda: self.guarded(self.fit_jaws))
        geometry_controls.addWidget(fit_jaws)
        right_layout.addLayout(geometry_controls)
        row = QHBoxLayout()
        self.layers = {}
        for name in LAYERS:
            check = QCheckBox(name.replace("_", " ").capitalize())
            check.setChecked(True)
            check.toggled.connect(self.review)
            self.layers[name] = check
            row.addWidget(check)
        overview = QPushButton("Overview")
        overview.clicked.connect(lambda: self.table.setCurrentCell(-1, -1))
        row.addWidget(overview)
        right_layout.addLayout(row)
        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(
            ["Instance / grasp", "Status", "Score", "CAD contact", "Pose", "Clearance", "Reasons"]
        )
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setMaximumHeight(210)
        self.table.currentCellChanged.connect(self.review)
        right_layout.addWidget(self.table)
        self.fit_health = QLabel("Preview to inspect current pose-fit evidence.")
        self.fit_health.setWordWrap(True)
        right_layout.addWidget(self.fit_health)
        legend = QLabel(
            "CAD view: yellow contacts/retract, green closed jaws/palm, blue sweeps, RGB TCP. "
            "Review: gray measured scene, cyan derived CAD, green eligible, red rejected, "
            "orange unknown, magenta collision. CAD contact is model-assisted; no force closure "
            "or held-part/robot trajectory qualification. Pose fit: green support, magenta "
            "free-space contradiction, blue occluded, orange unknown, yellow ambiguous "
            "depth, purple label mismatch. Pose-fit points are derived CAD queries."
        )
        legend.setWordWrap(True)
        right_layout.addWidget(legend)
        split.addWidget(right)
        split.setSizes([470, 1000])
        self.timer = QTimer(self)
        self.timer.setInterval(35)
        self.timer.timeout.connect(self.poll)
        if hasattr(context, "subscribe_outputs"):
            self._unsubscribe = context.subscribe_outputs(self.output_notice)
        if parameters.get("recipe_path"):
            self.guarded(
                lambda: self.restore(
                    load_jaw_recipe(
                        recipe_path(context.project_dir, parameters["recipe_path"]),
                        sha256=parameters["sha256"],
                    )
                )
            )
        self.refresh()

    @staticmethod
    def factor(name):
        return (
            100
            if name in FRACTIONS
            else 1
            if name in ("workers", "max_picks") or "degrees" in name
            else 1000
        )

    @staticmethod
    def vector_fields(callback, *, decimals, limit):
        widget, layout, fields = QWidget(), QHBoxLayout(), []
        widget.setLayout(layout)
        layout.setContentsMargins(0, 0, 0, 0)
        for axis in range(3):
            spin = QDoubleSpinBox()
            spin.setDecimals(decimals)
            spin.setRange(-limit, limit)
            spin.valueChanged.connect(lambda _, i=axis: callback(i))
            layout.addWidget(spin)
            fields.append(spin)
        return widget, fields

    @property
    def dirty(self):
        return bool(self._grasp_edits or self._setting_edits or self._mount_edits)

    def guarded(self, callback):
        try:
            callback()
        except (ValueError, RuntimeError, OSError, KeyError, TypeError) as error:
            self.status.setText(str(error))

    def changed(self, kind, name):
        if self._restoring:
            return
        {"grasp": self._grasp_edits, "setting": self._setting_edits, "mount": self._mount_edits}[
            kind
        ].add(name)
        if kind == "grasp":
            self._point_overrides.pop(name, None)
        self.cancel_preview()
        self.status.setText("Draft edited. Prior evidence is frozen/stale; preview before Stage.")
        self.refresh()
        self.guarded(self.show_geometry)

    def restore(self, recipe):
        self.cancel_preview()
        self.session.load(recipe)
        self._loaded_grasp = None
        self._grasp_edits.clear()
        self._setting_edits.clear()
        self._mount_edits.clear()
        self._restoring = True
        for name, spin in self.fields.items():
            spin.setValue(getattr(recipe.settings, name) * self.factor(name))
        for i in range(3):
            self.mount["offset"][i].setValue(recipe.grasp_from_tcp[i, 3] * 1000)
            rvec = np.rad2deg(cv2.Rodrigues(recipe.grasp_from_tcp[:3, :3])[0].ravel())
            self.mount["rotation"][i].setValue(rvec[i])
        self._restoring = False
        self.editor.set_cloud(
            PointCloud(
                recipe.part.points,
                "m",
                recipe.part.frame,
                normals=recipe.part.normals,
                metadata=dict(
                    observations=False, description="Retained canonical CAD; original origin"
                ),
            )
        )
        self._source_identity = self.editor.source.identity
        self.fill_grasps(0)
        self.fit_jaws()
        self.show_reference()
        self.table.setRowCount(0)
        self.viewer.set_cloud(None)
        self.fit_health.setText("Preview to inspect current pose-fit evidence.")
        self.status.setText(
            "Retained CAD and jaw frames restored. Preview a frozen reference to stage."
            + (
                f" {len(recipe.mesh.triangles)} triangles retained for mesh diagnostics."
                if recipe.mesh is not None
                else ""
            )
        )
        self.refresh()

    def fill_grasps(self, row):
        self.grasps.blockSignals(True)
        self.grasps.clear()
        for g in self.session.recipe.grasps:
            self.grasps.addItem(f"{g.name} · {g.span * 1000:.4g} mm span")
        self.grasps.setCurrentRow(row)
        self.grasps.blockSignals(False)
        self.load_grasp(row)

    def load_grasp(self, row):
        if not 0 <= row < len(self.session.recipe.grasps):
            return
        self._loaded_grasp = self.session.recipe.grasps[row]
        self._grasp_edits.clear()
        self._point_overrides.clear()
        self._restoring = True
        self.grasp_name.setText(self._loaded_grasp.name)
        for name, value in self.grasp_values(self._loaded_grasp).items():
            for spin, v in zip(self.vectors[name], value):
                spin.setValue(v * (1 if name == "retract" else 1000))
        self._restoring = False
        self.show_geometry()

    def select_grasp(self, row):
        if self.session.recipe is None:
            return
        if self._grasp_edits:
            # Preserve uncommitted edits; switching must not silently discard them.
            previous = self.session.recipe.grasps.index(self._loaded_grasp)
            self.grasps.blockSignals(True)
            self.grasps.setCurrentRow(previous)
            self.grasps.blockSignals(False)
            self.status.setText(
                "Apply the pending contact edit, or Undo, before selecting another grasp."
            )
            return
        self.load_grasp(row)

    @staticmethod
    def grasp_values(grasp):
        frame = grasp.part_from_grasp
        return dict(
            first=frame[:3, 3] - frame[:3, 0] * grasp.span / 2,
            second=frame[:3, 3] + frame[:3, 0] * grasp.span / 2,
            retract=frame[:3, 2].copy(),
        )

    def current_grasp(self):
        old = self._loaded_grasp
        if old is None:
            raise ValueError("Import CAD geometry and a draft grasp first")
        values = self.grasp_values(old)
        for name in values:
            for i in range(3):
                if (name, i) in self._grasp_edits:
                    values[name][i] = self._point_overrides.get(
                        (name, i),
                        self.vectors[name][i].value() / (1 if name == "retract" else 1000),
                    )
        name = self.grasp_name.text() if "name" in self._grasp_edits else old.name
        if self._grasp_edits - {"name"}:
            return JawGrasp.from_contacts(name, **values)
        return replace(old, name=name) if name != old.name else old

    def candidate(self):
        recipe = self.session.recipe
        if recipe is None:
            raise ValueError("Import a calibrated bin/CAD setup first")
        if not self.dirty:
            return recipe
        settings = replace(
            recipe.settings,
            **{
                name: self.fields[name].value() / self.factor(name)
                if name not in ("workers", "max_picks")
                else self.fields[name].value()
                for name in self._setting_edits
            },
        )
        mount = recipe.grasp_from_tcp.copy()
        rvec = cv2.Rodrigues(mount[:3, :3])[0].ravel()
        for name, i in self._mount_edits:
            if name == "offset":
                mount[i, 3] = self.mount[name][i].value() / 1000
            else:
                rvec[i] = np.deg2rad(self.mount[name][i].value())
        if any(name == "rotation" for name, _ in self._mount_edits):
            mount[:3, :3] = cv2.Rodrigues(rvec)[0]
        grasps = tuple(
            self.current_grasp() if g is self._loaded_grasp else g for g in recipe.grasps
        )
        return replace(recipe, grasps=grasps, settings=settings, grasp_from_tcp=mount)

    def sync(self):
        if self.dirty:
            candidate = self.candidate()
            index = self.session.recipe.grasps.index(self._loaded_grasp)
            self.session.change(
                grasps=candidate.grasps,
                settings=candidate.settings,
                grasp_from_tcp=candidate.grasp_from_tcp,
            )
            self._grasp_edits.clear()
            self._setting_edits.clear()
            self._mount_edits.clear()
            self.fill_grasps(index)
        self.refresh()

    def show_geometry(self):
        if self.session.recipe is not None and self._loaded_grasp is not None:
            candidate = self.candidate()
            grasp = candidate.grasps[self.session.recipe.grasps.index(self._loaded_grasp)]
            self.editor.set_segments(
                grasp_segments(candidate, grasp, sweeps=self.geometry_sweeps.isChecked())
            )

    def fit_jaws(self):
        if self.editor.source is None:
            return
        self.show_geometry()
        center = self.editor.source.center
        vertices = np.array([p for segment in self.editor.segments for p in segment[:2]])
        radius = max(self.editor.source.radius, np.linalg.norm(vertices - center, axis=1).max())
        self.editor.zoom = float(np.clip(0.85 * self.editor.source.radius / radius, 0.1, 100))
        self.editor.pan = np.zeros(2)
        self.editor.render()

    def pick_mode(self):
        self.editor.mode.setCurrentIndex(
            self.editor.mode.findData("pick" if self.pick_target.currentData() else "orbit")
        )
        self.tabs.setCurrentIndex(0)

    def picked(self, pick):
        name = self.pick_target.currentData()
        if not name:
            return
        if pick.get("source_identity") != self._source_identity:
            raise ValueError("CAD source changed; pick again on the retained model")
        row = pick.get("row")
        if type(row) is not int or not 0 <= row < len(self.session.recipe.part.points):
            raise ValueError("Pick an actual retained CAD source row")
        point = self.session.recipe.part.points[row].copy()
        if name == "retract":
            point -= self.current_grasp().part_from_grasp[:3, 3]
        self._restoring = True
        for i, value in enumerate(point):
            self.vectors[name][i].setValue(value * (1 if name == "retract" else 1000))
        self._restoring = False
        # Pick coordinates use the retained float64 row; untouched components stay exact.
        for i in range(3):
            self._point_overrides[name, i] = point[i]
            self._grasp_edits.add((name, i))
        self.cancel_preview()
        self.refresh()
        self.show_geometry()
        self.status.setText(f"CAD row {row} selected for {name}; apply the edit and preview.")

    def duplicate_grasp(self):
        self.sync()
        recipe = self.session.recipe
        g = self._loaded_grasp
        used = {x.name for x in recipe.grasps}
        name = next((f"Grasp {i}" for i in range(1, 100) if f"Grasp {i}" not in used), None)
        self.session.change(grasps=(*recipe.grasps, replace(g, name=name)))
        self.fill_grasps(len(recipe.grasps))
        self.refresh()

    def remove_grasp(self):
        self.sync()
        recipe = self.session.recipe
        if len(recipe.grasps) == 1:
            raise ValueError("Keep at least one taught grasp")
        self.session.change(grasps=tuple(g for g in recipe.grasps if g is not self._loaded_grasp))
        self.fill_grasps(0)
        self.refresh()

    def undo(self):
        self.cancel_preview()
        if self.session.recipe is None:
            return
        if not self.dirty:
            self.session.undo()
        recipe, history = self.session.recipe, list(self.session._undo)
        revision = self.session.revision
        self.restore(recipe)
        self.session._undo = history
        self.session.revision = revision + 1

    def show_reference(self):
        recipe = self.session.recipe.bin
        raw = recipe.reference_depth * recipe.depth_scale
        y, x = np.where(np.isfinite(raw) & (raw > 0))
        if len(y):
            rows = np.linspace(0, len(y) - 1, min(30000, len(y)), dtype=int)
            y, x = y[rows], x[rows]
        points = np.c_[x, y, np.ones(len(y))] @ np.linalg.inv(recipe.camera.matrix).T
        points *= raw[y, x, None]
        points = (points - recipe.bin_to_camera[:3, 3]) @ recipe.bin_to_camera[:3, :3]
        self.reference_view.set_cloud(
            PointCloud(
                points,
                "m",
                recipe.frame,
                metadata=dict(
                    observations=True,
                    description="Raw retained first-return reference; missing rays unfilled",
                ),
            )
        )
        capture = reference_capture(self.session.recipe)
        text = (
            f"Frozen reference {capture.capture_id} · {len(capture.instances)} supplied poses"
            if capture
            else "Legacy depth retained; supply/capture part poses to preview"
        )
        self.identity.setText(
            f"{len(self.session.recipe.part.points):,} CAD rows · "
            f"original {self.session.recipe.part.frame} "
            f"frame · {len(self.session.recipe.grasps)} grasps · {text}"
        )

    def choose(self, title, filters):
        path, _ = QFileDialog.getOpenFileName(self, title, "", filters)
        return Path(path) if path else None

    def choose_recipe(self):
        path = self.choose("Retained CAD-jaw training", "Jaw training (*.sbpj)")
        if path:
            self.restore(load_jaw_recipe(path))

    def import_setup(self, base, part, *, mesh=None, notes=None):
        lo, hi = part.points.min(0), part.points.max(0)
        center = (lo + hi) / 2
        a, b = center.copy(), center.copy()
        axis = int(np.argmax(hi - lo))
        a[axis], b[axis] = lo[axis], hi[axis]
        retract = np.eye(3)[2 if axis != 2 else 1]
        seed = JawGrasp.from_contacts("Draft envelope grasp", a, b, retract)
        self.restore(
            JawRecipe(
                base,
                part,
                (seed,),
                notes=dict(
                    teaching="Authored envelope seed; verify opposing CAD contacts before use",
                    **(notes or {}),
                ),
                mesh=mesh,
            )
        )

    def choose_setup(self):
        base = self.choose("Calibrated bin/reference in meters", "Bin training (*.sbp)")
        if not base:
            return
        cad = self.choose("CAD surface with outward normals", "CAD point surface (*.ply *.pcd)")
        if not cad:
            return
        units, ok = QInputDialog.getItem(
            self, "CAD units", "Unmarked cloud coordinates are:", ["m", "mm"], 0, False
        )
        if not ok:
            return
        cloud = read_cloud(cad, units=units, frame="part", max_points=50000)
        if cloud.normals is None or cloud.units not in ("m", "mm"):
            raise ValueError("Import a CAD surface with outward normals and explicit m/mm units")
        part = PartSurface(
            cloud.points.astype(np.float64) * (1 if cloud.units == "m" else 0.001),
            cloud.normals,
            cloud.frame,
        )
        self.import_setup(load_recipe(base), part)

    def choose_mesh_setup(self):
        import hashlib

        base = self.choose("Calibrated bin/reference in meters", "Bin training (*.sbp)")
        if not base:
            return
        path = self.choose("Triangle CAD in its original part frame", "Triangle CAD (*.stl *.ply)")
        if not path:
            return
        units, ok = QInputDialog.getItem(
            self, "CAD units", "File coordinates are:", ["m", "mm"], 0, False
        )
        if not ok:
            return
        winding, ok = QInputDialog.getItem(
            self,
            "Triangle normals",
            "Declared outward winding:",
            ["File winding", "Reverse file winding"],
            0,
            False,
        )
        if not ok:
            return
        frame, ok = QInputDialog.getText(
            self, "Original part frame", "Frame name used by the part poses:", text="part"
        )
        if not ok:
            return
        mesh = PartMesh.read(
            path,
            scale=1 if units == "m" else 0.001,
            frame=frame,
            flip_normals=winding == "Reverse file winding",
        )
        self.import_setup(
            load_recipe(base),
            mesh.sample(),
            mesh=mesh,
            notes=dict(
                cad_source_sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest(),
                cad_source_units=units,
                cad_winding=winding,
                mesh_sample_seed=27,
                mesh_sample_count=40_000,
            ),
        )
        self.status.setText(
            f"Retained {len(mesh.triangles)} triangles and original part origin. "
            "Mesh fit is diagnostic; teach contacts, retain a pose reference and preview."
        )

    def from_bundle(self, bundle):
        if "instances" in bundle.inputs:
            require_same_frame(
                [bundle.inputs[k] for k in ("depth", "instances")],
                message="Depth and labels declare different coordinate grids",
            )
        identity = {
            name: getattr(bundle, name)
            for name in ("snapshot_id", "publication_id", "output_revision")
            if hasattr(bundle, name)
        }
        return freeze_inputs(
            self.session.recipe, {k: p.value for k, p in bundle.inputs.items()}, identity=identity
        )

    def set_reference(self, capture):
        self.sync()
        candidate = retain_reference(self.session.recipe, capture)
        self.session.change(bin=candidate.bin, notes=candidate.notes)
        self.cancel_preview()
        self.show_reference()
        self.status.setText("New frozen reference retained. Preview this draft before Stage.")
        self.refresh()

    def capture_reference(self):
        self.sync()
        self.set_reference(self.from_bundle(self.context.snapshot_connected_inputs()))

    def choose_reference(self):
        self.sync()
        records = self.choose("Capture/part-pose records", "JSON records (*.json)")
        if not records:
            return
        depth = self.choose("Recorded axial depth (stored recipe scale)", "Numeric depth (*.npy)")
        if depth:
            values = read_json(records)
            self.set_reference(
                freeze_inputs(
                    self.session.recipe,
                    {**values, "depth": read_numeric(depth)},
                    identity={"source": "Imported numeric depth/pose files"},
                )
            )

    def preview_reference(self):
        self.sync()
        capture = reference_capture(self.session.recipe)
        if capture is None:
            raise ValueError("Capture/import a reference with explicit part poses first")
        self.start_preview(capture)

    def preview_connected(self):
        self.sync()
        bundle = self.context.snapshot_connected_inputs()
        self.start_preview(self.from_bundle(bundle), revision=self.context.output_revision)

    def start_preview(self, capture, *, revision=None):
        if self._future is not None:
            raise ValueError("Wait for the bounded preview to finish or cancel")
        self._job = self.session.job(capture)
        self.session.preview_revision = -1
        self._live_revision = revision
        self._cancel = Event()
        self._future = self.pool.submit(run_preview, self._job, self._cancel.is_set)
        self.status.setText("Previewing one frozen CAD/grasp/depth/pose draft in the background…")
        self.timer.start()
        self.refresh()

    def cancel_preview(self):
        if self._cancel is not None:
            self._cancel.set()

    def output_notice(self, revision):
        if self._live_revision is not None and revision != self._live_revision:
            self.cancel_preview()
            self.session.preview_revision = -1
            self.status.setText(
                "Connected outputs changed; preview the new publication before Stage."
            )
            self.refresh()

    def poll(self):
        if self._closed or self._future is None or not self._future.done():
            return
        future, job, cancel = self._future, self._job, self._cancel
        self._future = self._job = self._cancel = None
        self.timer.stop()
        try:
            result = future.result()
            stale = (
                self.dirty
                or cancel.is_set()
                or (
                    self._live_revision is not None
                    and self.context.output_revision != self._live_revision
                )
            )
            if stale or not self.session.accept(job, result):
                self.status.setText(
                    "Discarded stale/cancelled preview; preview the current draft again."
                )
            else:
                self._last_capture = job[2]
                self.populate()
                self.tabs.setCurrentIndex(2)
                self.status.setText(
                    "Frozen preview complete. Stage edits, then Apply in the inspector."
                )
        except CancelledError:
            self.status.setText("Preview cancelled; no current training result staged.")
        except Exception as error:
            self.status.setText(str(error))
        self.refresh()

    def populate(self):
        result = self.session.result
        self.table.blockSignals(True)
        self.table.setRowCount(len(result.candidates))
        for row, item in enumerate(result.candidates):
            values = (
                f"{item['instance_id']} / {item['grasp_name']}",
                item["status"],
                f"{item['score']:.3f}",
                f"{item['contact_fraction']:.1%}",
                item["pose_status"],
                item["clearance_status"],
                ", ".join(item["reasons"]),
            )
            for column, value in enumerate(values):
                self.table.setItem(row, column, QTableWidgetItem(value))
        self.table.blockSignals(False)
        self.table.resizeColumnsToContents()
        self.table.setCurrentCell(0, 0)
        self.health.setText(
            f"{len(result.picks)} eligible / {len(result.candidates)} alternatives. "
            "CAD contacts and pose support are geometric evidence, not probabilities."
        )
        self.review()

    def review(self, *_):
        result = self.session.result
        if result is None:
            return
        row = self.table.currentRow()
        graphic = jaw_result_cloud(
            result,
            selected=result.candidates[row]["id"] if 0 <= row < len(result.candidates) else None,
            layers=tuple(k for k, b in self.layers.items() if b.isChecked()),
        )
        self.viewer.set_cloud(
            PointCloud(
                graphic.points,
                graphic.units,
                graphic.frame,
                colors=graphic.colors,
                metadata=graphic.metadata,
            )
        )
        summaries = graphic.metadata["pose_fit"]
        if summaries:
            counts = {
                name: sum(item["counts"][name] for item in summaries)
                for name in summaries[0]["counts"]
            }
            total = sum(counts.values())
            self.fit_health.setText(
                f"Pose fit: {total} tested model rays; "
                + ", ".join(f"{name.replace('_', ' ')} {count}" for name, count in counts.items())
                + ". Counts cover all tested rays; displayed points are a bounded subset."
            )
        else:
            self.fit_health.setText("No evaluated upstream pose samples in this selection.")
        meshes = graphic.metadata["mesh_fit"]
        if meshes:
            counts = {
                name: sum(item["counts"][name] for item in meshes) for name in meshes[0]["counts"]
            }
            self.fit_health.setText(
                self.fit_health.text()
                + "\nMesh diagnostic: "
                + ", ".join(f"{key.replace('_', ' ')} {value}" for key, value in counts.items())
                + "; acceptance uses the point gate. "
                + "; ".join(
                    f"stride {item['grid_stride_pixels']}, {item['status']}" for item in meshes
                )
            )

    def refresh(self):
        self.buttons["Stage recipe"].setEnabled(
            self.session.ready and not self.dirty and self._future is None
        )
        for name in ("Preview reference", "Preview connected"):
            self.buttons[name].setEnabled(self.session.recipe is not None and self._future is None)
        self.buttons["Cancel preview"].setEnabled(self._future is not None)
        for name in ("Capture connected reference", "Import reference…"):
            self.buttons[name].setEnabled(self.session.recipe is not None)

    def stage(self):
        if self.dirty or self._future is not None:
            raise ValueError("Preview the current draft before staging")
        if self._live_revision is not None and self.context.output_revision != self._live_revision:
            raise ValueError("Connected publication changed; preview it again before Stage")
        recipe = self.session.staged()
        relative = f"assets/bin_picking_jaw/{uuid.uuid4().hex}.sbpj"
        path = recipe_path(self.context.project_dir, relative)
        path.parent.mkdir(parents=True, exist_ok=True)
        digest = save_jaw_recipe(path, recipe)
        self.parameters.update(recipe_path=relative, sha256=digest)
        self.accept()

    def export(self, folder):
        result = self.session.result
        if result is None or self._last_capture is None:
            raise ValueError("Complete a preview before exporting its cached evidence")
        folder = Path(folder)
        folder.mkdir(parents=True, exist_ok=False)
        write_cloud(folder / "review.ply", self.viewer.cloud, binary=True)
        (folder / "graphics.json").write_text(
            json.dumps(self.viewer.cloud.metadata, indent=2, allow_nan=False) + "\n",
            encoding="utf-8",
            newline="\n",
        )
        save_jaw_recipe(
            folder / "previewed.sbpj", retain_reference(result.recipe, self._last_capture)
        )
        report = result.report()
        report["preview_identity"] = self._last_capture.identity
        report["selected_candidate"] = self.viewer.cloud.metadata["selected_candidate"]
        (folder / "report.json").write_text(
            json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8", newline="\n"
        )

    def choose_export(self):
        folder = QFileDialog.getExistingDirectory(self, "Parent for a fresh cached review export")
        if folder:
            self.export(Path(folder) / f"jaw_review_{uuid.uuid4().hex[:12]}")

    def done(self, result):
        if not self._closed:
            self._closed = True
            self.cancel_preview()
            self.timer.stop()
            if self._unsubscribe is not None:
                self._unsubscribe()
            self.pool.shutdown(wait=False, cancel_futures=True)
            for viewer in (self.viewer, self.reference_view):
                viewer.orbit_timer.stop()
                viewer.timer.stop()
        super().done(result)
