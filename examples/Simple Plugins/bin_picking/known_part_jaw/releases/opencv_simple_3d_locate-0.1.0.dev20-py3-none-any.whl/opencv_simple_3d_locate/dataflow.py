"""A cached, single-block integration with OpenCVDataflowGUI."""

import copy
import re
from pathlib import Path, PurePosixPath

import numpy as np
from opencv_dataflow.core import Port, Result
from opencv_dataflow.geometry3d_common import Tool3D, pose_record
from opencv_dataflow.payloads import NO_VALUE
from opencv_dataflow.pointclouds import PointCloud

from . import DepthScene, Locator, load_recipe
from .capture import bind_capture
from .graphics import fit_cloud, overlay
from .model import transformed
from .review import assessment


def recipe_path(project_dir, relative):
    if project_dir is None:
        raise ValueError("Save the project before choosing a 3D recipe.")
    if not isinstance(relative, str) or not relative:
        raise ValueError("Choose a project-relative .s3l recipe.")
    portable = PurePosixPath(relative)
    if (
        portable.is_absolute()
        or "\\" in relative
        or ":" in relative
        or ".." in portable.parts
        or portable.suffix != ".s3l"
    ):
        raise ValueError("Recipe must be a project-relative .s3l path using forward slashes.")
    root = Path(project_dir).resolve()
    target = (root / relative).resolve()
    if not target.is_relative_to(root):
        raise ValueError("Recipe resolves outside the project directory.")
    return target


def oriented(value):
    if not isinstance(value, PointCloud):
        raise ValueError("Connect a PointCloud with declared units and frame.")
    return (
        value.points
        if value.normals is None
        else np.ascontiguousarray(np.c_[value.points, value.normals])
    )


def depth_input(value):
    if value is None:
        return None
    if not isinstance(value, PointCloud):
        raise ValueError("Connect a PointCloud to depth_scene with declared units and frame.")
    return DepthScene(value.points, value.units, value.frame)


class Simple3DLocate(Tool3D):
    type_id, title = "3d.simple_locate", "Simple3DLocate"
    subtype = "Surface localization"
    process_inputs_readonly = True
    parallel_safe = True
    composes_result_image = True
    plugin_dialog_label = "Train 3D locator…"
    plugin_dialog_modeless = True
    inputs = (
        Port("scene", "cloud"),
        Port("camera", "data", required=False, required_when_connected=True),
        Port("depth_scene", "cloud", required=False, required_when_connected=True),
        Port("capture_id", "text", required=False, required_when_connected=True),
    )
    outputs = (
        Port("poses", "data"),
        Port("pose", "data", required=False),
        Port("count", "number"),
        Port("report", "data"),
        Port("aligned_model", "cloud", required=False),
        Port("fit", "cloud"),
        Port("overlay", required=False),
        Port("capture_id", "text", required=False),
    )
    defaults = {"recipe_path": "", "sha256": "", "render_overlay": False}
    parameter_help = {
        "recipe_path": "Project-relative oriented-surface .s3l recipe.",
        "sha256": "SHA-256 of the complete recipe, supplied by the trainer.",
        "render_overlay": (
            "Optionally render a bitmap assessment; the colored fit cloud is the primary preview."
        ),
    }
    output_help = {
        "pose": "Best model-to-scene pose_3d_v1, absent when there is no accepted match.",
        "poses": "All accepted model-to-scene poses, highest geometric fit score first.",
        "fit": (
            "Flyaround result cloud: gray scene, green supported, red missing, blue-gray hidden, "
            "magenta free-space contradictions and RGB pose axes."
        ),
        "report": "Geometric fit, camera-depth evidence and rejected-pose diagnostics.",
        "capture_id": "Bound acquisition ID, or absent for an untagged legacy invocation.",
    }
    input_help = {
        "capture_id": "Optional acquisition declaration; must match connected cloud metadata.",
        "scene": "Registered scene cloud; capture_id metadata is checked with depth_scene.",
        "depth_scene": "Full measured first-return cloud; tagged cloud pairs must share one ID.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.preview_output = "fit"
        self._verified = self._locator = None

    @property
    def filmstrip_output(self):
        return "overlay" if self.parameters["render_overlay"] else None

    def validate_parameters(self, parameters=None):
        super().validate_parameters(parameters)
        p = self.parameters if parameters is None else parameters
        recipe_path(self.project_dir, p["recipe_path"])
        if not isinstance(p["sha256"], str) or re.fullmatch("[0-9a-f]{64}", p["sha256"]) is None:
            raise ValueError("Stage a recipe with its SHA-256.")
        if type(p["render_overlay"]) is not bool:
            raise ValueError("render_overlay must be boolean.")

    def process(self, inputs):
        clouds = {name: inputs[name] for name in ("scene", "depth_scene") if name in inputs}
        if any(not isinstance(value, PointCloud) for value in clouds.values()):
            raise ValueError("Connect typed scene/depth PointCloud inputs")
        identity, binding = bind_capture(
            inputs.get("capture_id"), {name: value.metadata for name, value in clouds.items()}
        )
        details = dict(capture_id=identity, capture_binding=binding) if identity is not None else {}
        p = self.parameters
        recipe = load_recipe(
            recipe_path(self.project_dir, p["recipe_path"]),
            sha256=p["sha256"],
            cached=self._verified,
        )
        if self._verified is None or self._verified[0] != p["sha256"]:
            self._locator = Locator(recipe)
        self._verified = p["sha256"], recipe
        source = inputs["scene"]
        result = self._locator.locate(
            oriented(source),
            units=source.units,
            frame=source.frame,
            camera=inputs.get("camera"),
            depth_scene=depth_input(inputs.get("depth_scene")),
        )
        poses = [
            pose_record(
                match.pose,
                recipe.frame,
                source.frame,
                recipe.units,
                coverage=match.coverage,
                score=match.score,
                score_type=match.report()["score_type"],
                depth_verification=match.depth_verification,
                pose_alternatives=match.pose_alternatives,
                projective_scoring=match.projective_scoring,
                point_to_plane_rmse=match.rmse,
                **copy.deepcopy(details),
            )
            for match in result.matches
        ]
        aligned = NO_VALUE
        if result.matches:
            data = transformed(recipe.samples, result.matches[0].pose)
            aligned = PointCloud(
                data[:, :3],
                recipe.units,
                source.frame,
                normals=data[:, 3:],
                metadata=copy.deepcopy(details),
            )
        report = result.report()
        if details:
            report.update(copy.deepcopy(details))
            for match in report["matches"]:
                match.update(copy.deepcopy(details))
        fit = fit_cloud(recipe, result)
        fit.metadata.update(copy.deepcopy(details))
        return Result(
            {
                "poses": poses,
                "pose": poses[0] if poses else NO_VALUE,
                "count": len(poses),
                "report": report,
                "aligned_model": aligned,
                "fit": fit,
                "overlay": overlay(recipe, result) if p["render_overlay"] else NO_VALUE,
                "capture_id": identity if identity is not None else NO_VALUE,
            },
            passed=result.passed,
            fail_reasons=[] if result.passed else ["No geometrically verified instance."],
            message=assessment(result)["message"],
            event_data={"filmstrip_priority": -1} if p["render_overlay"] else {},
        )

    def create_plugin_dialog(self, parent, parameters, context):
        from .qt_training import LocateTrainingDialog

        return LocateTrainingDialog(parent, parameters, context)

    def close(self):
        self._verified = self._locator = None


def register(registry):
    registry.register(Simple3DLocate)
