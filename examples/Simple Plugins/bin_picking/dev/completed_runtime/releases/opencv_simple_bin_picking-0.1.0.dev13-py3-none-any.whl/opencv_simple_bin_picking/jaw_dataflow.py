"""One cached optional CAD-jaw planning block; existing suction block is unchanged."""

import re
from pathlib import Path, PurePosixPath

from opencv_dataflow.core import Port, Result
from opencv_dataflow.geometry3d_common import Tool3D, pose_record
from opencv_dataflow.parameter_validation import ValidationError
from opencv_dataflow.payloads import NO_VALUE, ValuePacket, require_same_frame
from opencv_dataflow.pointclouds import PointCloud

from .completed_review import CompletedPickingReview, retain_completed
from .jaw import JawPlanner
from .jaw_graphics import jaw_result_cloud
from .jaw_persistence import load_jaw_recipe
from .jaw_specs import PartInstance
from .specs import Camera


def recipe_path(root, relative):
    if root is None:
        raise ValueError("Save the project before selecting jaw training")
    if (
        not isinstance(relative, str)
        or not relative
        or "\\" in relative
        or ":" in relative
        or PurePosixPath(relative).is_absolute()
        or ".." in PurePosixPath(relative).parts
    ):
        raise ValueError("Choose a project-relative .sbpj jaw recipe")
    root = Path(root).resolve()
    path = (root / relative).resolve()
    if not path.is_relative_to(root) or path.suffix != ".sbpj":
        raise ValueError("Jaw recipe must stay inside this project")
    return path


class SimpleBinPickingJaw(CompletedPickingReview, Tool3D):
    type_id, title = "3d.simple_bin_picking_jaw", "SimpleBinPicking Jaw"
    subtype = "Bin picking"
    process_inputs_readonly = True
    parallel_safe = True
    preview_safe = True
    plugin_dialog_label = "Teach CAD jaw grasps…"
    plugin_dialog_modeless = True
    inputs = (
        Port("depth", "depth"),
        Port("part_instances", "data"),
        Port("capture_id", "text"),
        Port("camera", "data", required=False, required_when_connected=True),
        Port("bin_pose", "data", required=False, required_when_connected=True),
        Port("instances", required=False, required_when_connected=True),
    )
    outputs = (
        Port("picks", "data"),
        Port("candidates", "data"),
        Port("report", "data"),
        Port("count", "integer"),
        Port("tcp", "data", required=False),
        Port("pregrasp", "data", required=False),
        Port("graphics", "cloud", required=False),
        Port("pose_fit", "cloud", required=False),
        Port("mesh_fit", "cloud", required=False),
    )
    defaults = dict(recipe_path="", sha256="", render_graphics=True)
    parameter_help = {
        "recipe_path": "Project-relative sealed metric bin/CAD/grasp/gripper .sbpj setup.",
        "sha256": "Complete retained setup checksum; no dependencies or executable paths.",
        "render_graphics": "Native colored CAD/jaw/TCP/sweep and collision/unknown review cloud.",
    }
    input_help = {
        "part_instances": "Explicit current part_instance_v1 accepted-pose records.",
        "capture_id": "Current acquisition identity, equal to every supplied part instance.",
        "depth": "Registered axial depth; camera and stored scale are retained.",
        "instances": "Optional integer labels; poses must declare matching label IDs.",
    }
    output_help = {
        "picks": "Geometric alternatives with CAD-assisted contacts; not physical grasp truth.",
        "graphics": "Measured scene and derived CAD, fingers, palm, axes and sweeps.",
        "pose_fit": "Colored depth-fit evidence from sampled CAD predictions, not sensor returns.",
        "mesh_fit": "Diagnostic first-surface triangle rays; current acceptance still uses points.",
        "tcp": "Best TCP alternative; absent on rejection. Retract follows grasp +Z.",
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._key = self._planner = None
        self._completed_review = None
        self.preview_output = "graphics"

    def validate_parameters(self, parameters=None):
        super().validate_parameters(parameters)
        p = self.parameters if parameters is None else parameters
        try:
            recipe_path(self.project_dir, p["recipe_path"])
        except ValueError as error:
            raise ValidationError(str(error), "recipe_path") from error
        if not isinstance(p["sha256"], str) or not re.fullmatch("[a-f0-9]{64}", p["sha256"]):
            raise ValidationError("Pin the complete .sbpj SHA-256", "sha256")
        if type(p["render_graphics"]) is not bool:
            raise ValidationError("Rendering option must be boolean", "render_graphics")

    def process(self, inputs):
        self._completed_review = None
        p = self.parameters
        path = recipe_path(self.project_dir, p["recipe_path"])
        stat = path.stat()
        key = (str(path), p["sha256"], stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)
        if key != self._key:
            self._planner = self._key = None
            self._planner = JawPlanner(load_jaw_recipe(path, sha256=p["sha256"]))
            self._key = key
        recipe = self._planner.recipe
        if "camera" in inputs and Camera.from_record(inputs["camera"]) != recipe.bin.camera:
            raise ValueError("Current camera calibration differs from retained jaw setup")
        depth = inputs["depth"]
        if hasattr(depth, "units") and (depth.units != "m" or recipe.bin.depth_scale != 1):
            raise ValueError("Unit-bearing depth must be meters with stored recipe scale 1")
        if "instances" in inputs:
            require_same_frame(
                [
                    ValuePacket(inputs[name], self.input_payloads.get(name, {}))
                    for name in ("depth", "instances")
                ],
                message="Depth and instance labels declare different coordinate grids",
            )
        records = inputs["part_instances"]
        if not isinstance(records, list) or len(records) > 32:
            raise ValueError("Connect up to 32 explicit current part instances")
        instances = [
            PartInstance.from_record(
                value, part_frame=recipe.part.frame, camera_frame=recipe.bin.camera.frame
            )
            for value in records
        ]
        from .dataflow import input_pose

        result = self._planner.plan(
            depth,
            instances,
            capture_id=inputs["capture_id"],
            bin_to_camera=input_pose(inputs.get("bin_pose"), recipe.bin),
            instance_labels=inputs.get("instances"),
            cancelled=getattr(self, "_cancelled", lambda: False),
            retain_pose_fit=self.generate_graphics and p["render_graphics"],
        )
        cloud = pose_fit = mesh_fit = NO_VALUE
        if self.generate_graphics and p["render_graphics"]:
            graphic = jaw_result_cloud(result)
            cloud = PointCloud(
                graphic.points,
                "m",
                recipe.bin.frame,
                colors=graphic.colors,
                metadata=graphic.metadata,
            )
            if result.pose_fits:
                fit = jaw_result_cloud(result, layers=("pose_fit",))
                pose_fit = PointCloud(
                    fit.points, fit.units, fit.frame, colors=fit.colors, metadata=fit.metadata
                )
            if result.mesh_fits:
                fit = jaw_result_cloud(result, layers=("mesh_fit",))
                mesh_fit = PointCloud(
                    fit.points, fit.units, fit.frame, colors=fit.colors, metadata=fit.metadata
                )
        picks = list(result.picks)
        tcp = pregrasp = NO_VALUE
        if picks:
            details = dict(
                capture_id=result.capture_id,
                instance_id=picks[0]["instance_id"],
                grasp_name=picks[0]["grasp_name"],
            )
            tcp = pose_record(picks[0]["tcp_pose"], "tcp", recipe.bin.frame, "m", **details)
            pregrasp = pose_record(
                picks[0]["pregrasp_pose"], "tcp", recipe.bin.frame, "m", **details
            )
        report = result.report()
        report["recipe_sha256"] = p["sha256"]
        outputs = dict(
            picks=picks,
            candidates=list(result.candidates),
            report=report,
            count=len(picks),
            tcp=tcp,
            pregrasp=pregrasp,
            graphics=cloud,
            pose_fit=pose_fit,
            mesh_fit=mesh_fit,
        )
        payloads = retain_completed(self, "jaw", result, outputs)
        return Result(
            outputs,
            payloads=payloads,
            passed=bool(picks),
            score=max((c["score"] for c in result.candidates), default=0.0),
            fail_reasons=[] if picks else ["no_geometric_jaw_alternative"],
            message=(
                f"{len(picks)} geometric jaw alternatives; "
                "CAD-assisted contacts, no robot execution"
            ),
        )

    def create_plugin_dialog(self, parent, parameters, context):
        from .qt_jaw_training import JawTrainingDialog

        return JawTrainingDialog(parent, parameters, context)

    def close(self):
        self._planner = self._key = None
        super().close()

    def reset_runtime(self):
        super().reset_runtime()
        self.close()


def register(registry):
    registry.register(SimpleBinPickingJaw)
