"""Paired completed suction/jaw evidence; no planning, collision checks or reprojection."""

import copy
import hashlib
import json
from dataclasses import dataclass, field, is_dataclass
from pathlib import Path
from uuid import uuid4

import numpy as np
from opencv_dataflow.payloads import NO_VALUE
from opencv_dataflow.pointclouds import PointCloud

from .graphics import LAYERS as SUCTION_LAYERS
from .graphics import result_cloud
from .jaw_graphics import LAYERS as JAW_LAYERS
from .jaw_graphics import jaw_result_cloud
from .scene import Scene

BINDING = "bin_picking_completed_review"


def _json(value):
    return json.dumps(value, sort_keys=True, allow_nan=False).encode("utf-8")


def _readonly(value):
    array = np.asarray(value)
    return np.frombuffer(array.tobytes(), dtype=array.dtype).reshape(array.shape)


def _freeze(value, memo=None):
    memo = {} if memo is None else memo
    if id(value) in memo:
        return memo[id(value)]
    if isinstance(value, np.ndarray):
        result = _readonly(value)
    elif isinstance(value, Scene):
        result = object.__new__(Scene)
        memo[id(value)] = result
        for name in ("recipe", "depth", "pose", "points", "pixels", "instances"):
            setattr(result, name, _freeze(getattr(value, name), memo))
        # Drawing uses these arrays only. A planning index is intentionally absent.
        result.tree = None
    elif is_dataclass(value):
        result = object.__new__(type(value))
        memo[id(value)] = result
        for name, item in vars(value).items():
            object.__setattr__(result, name, _freeze(item, memo))
    elif isinstance(value, dict):
        result = {name: _freeze(item, memo) for name, item in value.items()}
    elif isinstance(value, (list, tuple)):
        result = type(value)(_freeze(item, memo) for item in value)
    else:
        result = copy.deepcopy(value)
    memo[id(value)] = result
    return result


def _cloud(value):
    return PointCloud(
        value.points,
        value.units,
        value.frame,
        colors=value.colors,
        normals=value.normals,
        pixels=value.pixels,
        source_size=value.source_size,
        metadata=copy.deepcopy(value.metadata),
    )


@dataclass(frozen=True)
class CompletedPickingRecord:
    identifier: str
    kind: str
    report_json: bytes
    scalar_json: bytes
    parameters_json: bytes
    ports: tuple
    _result: object = field(repr=False, compare=False)
    _clouds: dict = field(repr=False, compare=False)

    @classmethod
    def create(cls, kind, result, outputs, parameters):
        emitted = {name: value for name, value in outputs.items() if value is not NO_VALUE}
        clouds = {name: value for name, value in emitted.items() if isinstance(value, PointCloud)}
        scalars = {
            name: value
            for name, value in emitted.items()
            if name not in (*clouds, "report", "picks", "candidates")
        }
        return cls(
            uuid4().hex,
            kind,
            _json(outputs["report"]),
            _json(scalars),
            _json(parameters),
            tuple(emitted),
            result,
            clouds,
        )

    @property
    def report(self):
        return json.loads(self.report_json)

    @property
    def parameters(self):
        return json.loads(self.parameters_json)

    def __deepcopy__(self, memo):
        return self


def retain_completed(block, kind, result, outputs):
    if not (block.run_profile.input_previews and block.run_profile.output_previews):
        return {}
    record = CompletedPickingRecord.create(kind, result, outputs, block.parameters)
    block._completed_review = record
    return {name: {BINDING: {"id": record.identifier}} for name in record.ports}


class CompletedPickingReview:
    plugin_review_dialog_label = "Review completed bin-picking evidence…"

    def copy_runtime_from(self, other):
        super().copy_runtime_from(other)
        self._completed_review = other._completed_review

    def reset_runtime(self):
        super().reset_runtime()
        self._completed_review = None

    def close(self):
        self._completed_review = None
        super().close()

    def capture_completed_review(self, context):
        snapshot = getattr(context, "snapshot_processed_execution", None)
        if snapshot is None:
            raise ValueError("Completed review needs the host's paired execution-snapshot API")
        record = self._completed_review
        return capture_completed(
            record, snapshot(output_ports=("report",) if record is None else record.ports)
        )

    def create_plugin_review_dialog(self, parent, context):
        from .qt_completed_review import CompletedPickingReviewDialog

        return CompletedPickingReviewDialog(
            parent, context, lambda: self.capture_completed_review(context)
        )


def describe_input(value):
    array = np.asarray(value)
    return dict(
        shape=list(array.shape),
        dtype=array.dtype.str,
        sha256=hashlib.sha256(array.tobytes()).hexdigest(),
        attributes={
            name: copy.deepcopy(getattr(value, name))
            for name in ("units", "color_format", "display_min", "display_max", "metadata")
            if hasattr(value, name)
        },
    )


@dataclass(frozen=True)
class CompletedPickingCapture:
    record: CompletedPickingRecord
    _result: object = field(repr=False, compare=False)
    _arrays: dict = field(repr=False, compare=False)
    _descriptions: dict = field(repr=False, compare=False)
    _data: dict = field(repr=False, compare=False)
    _outputs: dict = field(repr=False, compare=False)
    _provenance: dict = field(repr=False, compare=False)

    @property
    def provenance(self):
        return copy.deepcopy(self._provenance)

    @property
    def recipe(self):
        return self._result.recipe if self.record.kind == "jaw" else self._result.scene.recipe

    @property
    def recipe_bytes(self):
        return self.recipe._source_bytes

    @property
    def layers(self):
        return JAW_LAYERS if self.record.kind == "jaw" else SUCTION_LAYERS

    @property
    def input_names(self):
        return tuple(self._arrays)

    def input_array(self, name):
        return self._arrays[name]

    def input_description(self, name):
        return copy.deepcopy(self._descriptions[name])

    def candidate(self, identity=None):
        if identity is None:
            return None
        if not isinstance(identity, bool):
            for candidate in self.record.report["candidates"]:
                if candidate["id"] == identity:
                    return candidate
        raise ValueError("Choose a recorded candidate ID")

    def measured_cloud(self):
        scene = self._result.scene
        return PointCloud(
            scene.points,
            scene.recipe.units,
            scene.recipe.frame,
            pixels=scene.pixels,
            source_size=scene.recipe.camera.image_size,
            metadata=dict(scope="retained_measured_first_returns", coordinate_frame="bin"),
        )

    def display_cloud(self, selected=None, layers=None, mode="plan"):
        self.candidate(selected)
        layers = self.layers if layers is None else tuple(layers)
        if any(name not in self.layers for name in layers):
            raise ValueError("Choose known evidence layers")
        if mode == "observations":
            return self.measured_cloud()
        if mode not in ("plan", "pose_fit", "mesh_fit"):
            raise ValueError("Choose a recorded evidence view")
        if mode in ("pose_fit", "mesh_fit"):
            fits = getattr(self._result, "pose_fits" if mode == "pose_fit" else "mesh_fits", ())
            if not fits:
                raise ValueError(
                    f"No {mode} arrays retained; run again with execution graphics enabled"
                )
            layers = (mode,)
        port = "graphics" if mode == "plan" else mode
        if selected is None and port in self._outputs and (mode != "plan" or layers == self.layers):
            return _cloud(self._outputs[port])
        graphics = (
            jaw_result_cloud(self._result, selected=selected, layers=layers)
            if self.record.kind == "jaw"
            else result_cloud(self._result, selected=selected, layers=layers)
        )
        return PointCloud(
            graphics.points,
            graphics.units,
            graphics.frame,
            colors=graphics.colors,
            metadata=copy.deepcopy(graphics.metadata),
        )

    def report(self, selected=None, layers=None, mode="plan"):
        scene = self._result.scene
        return dict(
            model="simple_bin_picking_completed_review_v1",
            kind=self.record.kind,
            execution_binding=self.record.identifier,
            completed_result=self.record.report,
            executed_parameters=self.record.parameters,
            executed_configuration=self.recipe.configuration(),
            selected=self.candidate(selected),
            display_mode=mode,
            display_layers=list(self.layers if layers is None else layers),
            input_arrays=copy.deepcopy(self._descriptions),
            input_data=copy.deepcopy(self._data),
            emitted_clouds=list(self._outputs),
            diagnostic_arrays=dict(
                pose_fit=len(getattr(self._result, "pose_fits", ())),
                mesh_fit=len(getattr(self._result, "mesh_fits", ())),
            ),
            bin_to_camera=scene.pose.tolist(),
            provenance=self.provenance,
            scene_row_scope=(
                "Positive finite scaled depth pixels in y/x order; "
                "pixels index captured camera depth"
            ),
            geometry_scope=(
                "Measured points are distinct from configured cups/jaws/CAD/sweeps/TCP "
                "and unknown query samples"
            ),
            score_scope=(
                "Geometric evidence, not pick success probability; "
                "selected/rejected/unknown stays unchanged"
            ),
            unknown_scope=(
                "Unobserved space is unknown, not free; geometric eligibility is not "
                "robot/physical grasp qualification"
            ),
            graphics_scope=(
                "Review derives display geometry from frozen evidence; "
                "missing diagnostic arrays stay unavailable"
            ),
            identity_scope=(
                "Paired software completion and declared capture IDs do not establish "
                "physical synchronization"
            ),
            planning_reexecuted=False,
            clearance_reexecuted=False,
            depth_reprojected=False,
            recipe_reloaded=False,
            training_changed=False,
            robot_execution=False,
        )

    def assessment(self, selected=None, layers=None, mode="plan", *, yaw=25, pitch=-20):
        import cv2
        from opencv_dataflow.pointclouds import render_cloud

        cloud = self.display_cloud(selected, layers, mode)
        image = np.full((900, 1280, 3), (30, 26, 22), np.uint8)
        image[80:720] = render_cloud(cloud, width=1280, height=640, yaw=yaw, pitch=pitch)
        candidate = self.candidate(selected)
        report = self.record.report
        lines = [
            f"SimpleBinPicking {self.record.kind} | {mode} | "
            f"{len(self._result.picks)} eligible alternatives",
            f"{cloud.units} | {report['camera_frame']} -> {cloud.frame} | "
            f"yaw {yaw}, pitch {pitch} | display projection",
            "All recorded candidates"
            if candidate is None
            else (
                f"Candidate {candidate['id']}: {candidate['status']} | "
                f"geometric score {candidate['score']:.5g}"
            ),
            "" if candidate is None else "Reasons: " + ", ".join(candidate["reasons"]),
            "Plan green eligible / red rejected / orange unknown; magenta measured/CAD collisions.",
            "Fit: green supported / magenta contradiction / blue occluded / orange unknown.",
            "Derived tool/CAD/TCP/fit/sweeps; unknown is not free. No physical/robot claim.",
        ]
        for text, y in zip(lines, (28, 57, 755, 782, 809, 842, 874)):
            text = text.encode("ascii", errors="replace").decode("ascii")[:180]
            while text and cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.53, 1)[0][0] > 1240:
                text = text[:-1]
            cv2.putText(
                image,
                text,
                (18, y),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.53,
                (230, 235, 240),
                1,
                cv2.LINE_AA,
            )
        return image

    def export(self, directory, selected=None, layers=None, mode="plan", *, yaw=25, pitch=-20):
        import cv2
        from opencv_dataflow.cloud_io import write_cloud

        document = self.report(selected, layers, mode)
        cloud = self.display_cloud(selected, layers, mode)
        target = Path(directory)
        target.mkdir(parents=True, exist_ok=False)
        filename = "executed_recipe.sbpj" if self.record.kind == "jaw" else "executed_recipe.sbp"
        (target / filename).write_bytes(self.recipe_bytes)
        document["exported_recipe_sha256"] = hashlib.sha256(self.recipe_bytes).hexdigest()
        for name, array in self._arrays.items():
            np.save(target / f"input_{name}.npy", array, allow_pickle=False)
        for name in ("points", "pixels", "depth", "pose", "instances"):
            value = getattr(self._result.scene, name)
            if value is not None:
                np.save(target / f"scene_{name}.npy", value, allow_pickle=False)
        for name, value in {"measured_scene": self.measured_cloud(), **self._outputs}.items():
            write_cloud(target / f"{name}.ply", value, binary=True)
            for member in ("points", "colors", "pixels"):
                array = getattr(value, member)
                if array is not None:
                    np.save(target / f"{name}_{member}.npy", array, allow_pickle=False)
        diagnostics = []
        for group in ("pose_fits", "mesh_fits"):
            for i, fit in enumerate(getattr(self._result, group, ())):
                entry = dict(group=group, index=i, arrays={})
                for name, array in vars(fit).items():
                    if isinstance(array, np.ndarray):
                        filename = f"{group}_{i}_{name}.npy"
                        np.save(target / filename, array, allow_pickle=False)
                        entry["arrays"][name] = filename
                diagnostics.append(entry)
        document["exported_diagnostics"] = diagnostics
        write_cloud(target / "selected_display.ply", cloud, binary=True)
        ok, png = cv2.imencode(
            ".png", self.assessment(selected, layers, mode, yaw=yaw, pitch=pitch)
        )
        if not ok:
            raise ValueError("Could not encode frozen bin-picking assessment")
        (target / "assessment.png").write_bytes(png.tobytes())
        document["projection"] = dict(yaw=yaw, pitch=pitch, scope="Display projection only")
        (target / "review.json").write_text(
            json.dumps(document, indent=2, allow_nan=False) + "\n", encoding="utf-8"
        )
        return target


def capture_completed(record, bundle):
    if record is None:
        raise ValueError("No retained completed bin picking; execute in Debug before reviewing")
    if set(bundle.outputs) != set(record.ports):
        raise ValueError("Completed output evidence is unavailable; capture the latest run again")
    if any(
        bundle.outputs[name].payload.get(BINDING, {}).get("id") != record.identifier
        for name in record.ports
    ):
        raise ValueError("Completed model/result evidence changed; capture the latest run again")
    report = record.report
    candidates = report["candidates"]
    picks = [item for item in candidates if item["status"] == "eligible"]
    if (
        _json(bundle.outputs["report"].value) != record.report_json
        or _json(bundle.outputs["candidates"].value) != _json(candidates)
        or _json(bundle.outputs["picks"].value) != _json(picks)
    ):
        raise ValueError("Completed candidate decisions changed; capture the latest run again")
    scalars = {
        name: packet.value
        for name, packet in bundle.outputs.items()
        if name not in (*record._clouds, "report", "picks", "candidates")
    }
    if _json(scalars) != record.scalar_json:
        raise ValueError("Completed poses/count changed; capture the latest run again")
    for name, expected in record._clouds.items():
        actual = bundle.outputs[name].value
        if (
            not isinstance(actual, PointCloud)
            or actual.units != expected.units
            or actual.frame != expected.frame
            or actual.source_size != expected.source_size
            or any(
                not np.array_equal(getattr(actual, member), getattr(expected, member))
                for member in ("points", "colors", "normals", "pixels")
            )
            or _json(actual.metadata) != _json(expected.metadata)
        ):
            raise ValueError("Completed cloud evidence changed")
    arrays = {
        name: packet.value
        for name, packet in bundle.inputs.items()
        if isinstance(packet.value, np.ndarray)
    }
    provenance = dict(
        snapshot_id=bundle.snapshot_id,
        block_id=bundle.block_id,
        output_revision=bundle.output_revision,
        execution_count=bundle.execution_count,
        passed=bool(bundle.passed),
        score=bundle.score,
        message=bundle.message,
        inputs={name: copy.deepcopy(packet.payload) for name, packet in bundle.inputs.items()},
        outputs={name: copy.deepcopy(packet.payload) for name, packet in bundle.outputs.items()},
    )
    frozen_record = _freeze(record)
    return CompletedPickingCapture(
        frozen_record,
        frozen_record._result,
        {name: _readonly(value) for name, value in arrays.items()},
        {name: describe_input(value) for name, value in arrays.items()},
        {
            name: copy.deepcopy(packet.value)
            for name, packet in bundle.inputs.items()
            if name not in arrays
        },
        frozen_record._clouds,
        provenance,
    )
