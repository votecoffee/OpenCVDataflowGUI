"""Explicit accepted-locator-report to metric part-instance conversion; no pose inference."""

import math

from .jaw_specs import PartInstance, acquisition_id
from .specs import label, rigid

MODELS = {
    "simple_3d_locate_v1": "verified_matches",
    "simple_gdrnpp_result_v1": "detection_candidates",
    "simple_foundation_pose_v1": "one_masked_instance_hypotheses",
}


def adapt_instances(
    report,
    *,
    capture_id,
    part_frame,
    camera_frame,
    instance_prefix="part",
    locator_capture_id=None,
    allow_legacy_capture=False,
    label_ids=None,
):
    """Only declared upstream-accepted poses become instances; jaw depth checks remain required."""
    acquisition_id(capture_id)
    label(part_frame)
    label(camera_frame)
    label(instance_prefix)
    label(instance_prefix + "-32")
    if type(allow_legacy_capture) is not bool:
        raise ValueError("Legacy capture binding must be an explicit boolean")
    if (
        not isinstance(report, dict)
        or not isinstance(report.get("model"), str)
        or report["model"] not in MODELS
    ):
        raise ValueError("Connect a supported Simple3DLocate, GDRNPP or FoundationPose report")
    if report.get("source_frame") != part_frame or report.get("target_frame") != camera_frame:
        raise ValueError("Locator must map the original retained part frame to this camera")
    units = report.get("units")
    if units not in ("m", "mm"):
        raise ValueError("Locator pose units must explicitly be m or mm")
    embedded = report.get("capture_id")
    if embedded is not None:
        acquisition_id(embedded)
        if embedded != capture_id:
            raise ValueError("Locator report belongs to a different capture")
        binding = "embedded_report_capture_id"
    else:
        if not allow_legacy_capture or locator_capture_id is None:
            raise ValueError(
                "Report has no capture ID; enable legacy binding and wire its source capture ID"
            )
        acquisition_id(locator_capture_id)
        if locator_capture_id != capture_id:
            raise ValueError("Declared legacy locator capture differs from current depth capture")
        binding = "explicit_legacy_source_capture_declaration"
    if locator_capture_id is not None and locator_capture_id != capture_id:
        raise ValueError("Declared locator capture differs from current depth capture")
    if label_ids is not None:
        if (
            not isinstance(label_ids, dict)
            or len(label_ids) > 512
            or any(
                not isinstance(key, str) or type(value) is not int or not 1 <= value < 2**31
                for key, value in label_ids.items()
            )
        ):
            raise ValueError("Label IDs must map current instance names to positive integer IDs")
    model = report["model"]
    if model == "simple_3d_locate_v1":
        candidates = report.get("matches")
    else:
        candidates = report.get("candidates")
    if not isinstance(candidates, list) or len(candidates) > 512:
        raise ValueError("Locator report needs a bounded candidate list (at most 512)")
    accepted, rows, seen = [], [], set()
    for index, item in enumerate(candidates):
        if not isinstance(item, dict):
            raise ValueError("Malformed locator candidate")
        if model == "simple_3d_locate_v1":
            candidate_id, status, pose = str(index + 1), "accepted", item
        else:
            candidate_id = item.get("id")
            if not isinstance(candidate_id, str) or not candidate_id or candidate_id in seen:
                raise ValueError("Locator candidates must have unique nonempty string IDs")
            seen.add(candidate_id)
            acquisition_id(candidate_id)
            fit = item.get("fit")
            status = fit.get("status", "unverified") if isinstance(fit, dict) else "unverified"
            if status not in ("accepted", "rejected", "unknown", "unverified", "ambiguous"):
                raise ValueError("Unknown upstream pose acceptance status")
            pose = item.get("pose") if model == "simple_gdrnpp_result_v1" else item
            if item.get("capture_id", capture_id) != capture_id:
                raise ValueError("Locator candidate belongs to a different capture")
        if not isinstance(pose, dict):
            raise ValueError("Malformed locator pose")
        if model == "simple_gdrnpp_result_v1" and (
            pose.get("model") != "pose_3d_v1"
            or pose.get("units") != units
            or pose.get("source_frame") != part_frame
            or pose.get("target_frame") != camera_frame
        ):
            raise ValueError("Candidate units/physical frames differ from the locator report")
        if pose.get("capture_id", capture_id) != capture_id:
            raise ValueError("Locator pose belongs to a different capture")
        matrix = rigid(pose.get("source_to_target")).copy()
        matrix[:3, 3] *= 0.001 if units == "mm" else 1
        decision = item.get("selection") or {}
        if not isinstance(decision, dict):
            raise ValueError("Malformed locator overlap selection")
        if decision.get("status") == "overlap_suppressed":
            status = "overlap_suppressed"
        rows.append(
            dict(
                candidate_id=candidate_id,
                upstream_status=status,
                emitted_instance=None,
                reason="upstream_not_accepted",
            )
        )
        if status == "accepted":
            rank = item.get("raw_logit") if model == "simple_foundation_pose_v1" else 0
            if (
                isinstance(rank, bool)
                or not isinstance(rank, (int, float))
                or not math.isfinite(rank)
            ):
                raise ValueError("FoundationPose needs finite raw cohort ranking logits")
            accepted.append((index, candidate_id, matrix, rank))
    count = len(accepted)
    if "passed" in report and (
        type(report["passed"]) is not bool or report["passed"] != bool(count)
    ):
        raise ValueError("Locator pass decision contradicts its accepted candidate list")
    if model == "simple_3d_locate_v1":
        if type(report.get("passed")) is not bool or report["passed"] != bool(count):
            raise ValueError("Simple3DLocate acceptance contradicts its verified match list")
    elif (
        type(report.get("accepted_candidates")) is not int or report["accepted_candidates"] != count
    ):
        raise ValueError("Locator accepted count contradicts its candidate decisions")
    if model == "simple_foundation_pose_v1":
        accepted.sort(key=lambda item: -item[3])
        for index, *_ in accepted[1:]:
            rows[index]["reason"] = "alternative_hypothesis_for_same_masked_instance"
        accepted = accepted[:1]
    if len(accepted) > 32:
        raise ValueError("Jaw planning supports at most 32 current physical instance proposals")
    instances = []
    for number, (index, candidate_id, matrix, _) in enumerate(accepted, 1):
        identifier = (
            f"{instance_prefix}-{candidate_id}"
            if model == "simple_gdrnpp_result_v1"
            else f"{instance_prefix}-{number}"
        )
        label(identifier)
        label_id = None
        if label_ids is not None:
            if identifier not in label_ids:
                raise ValueError("Supply an instance label for every emitted current instance")
            label_id = label_ids[identifier]
        instance = PartInstance(identifier, matrix, True, capture_id, label_id)
        pose = dict(
            model="pose_3d_v1",
            source_frame=part_frame,
            target_frame=camera_frame,
            units="m",
            source_to_target=instance.camera_from_part.tolist(),
        )
        record = dict(
            model="part_instance_v1", id=identifier, accepted=True, capture_id=capture_id, pose=pose
        )
        if label_id is not None:
            record["label_id"] = label_id
        instances.append(record)
        rows[index].update(emitted_instance=identifier, reason="upstream_accepted_geometry_only")
    return instances, dict(
        model="simple_part_instances_v1",
        locator_model=model,
        capture_id=capture_id,
        capture_binding=binding,
        source_frame=part_frame,
        target_frame=camera_frame,
        units="m",
        upstream_units=units,
        upstream_accepted_candidates=count,
        emitted_instances=len(instances),
        instance_semantics=MODELS[model],
        candidates=rows,
        identity_scope="Current acquisition proposals; generated ranks are not tracking identities",
        qualification="Conversion only; jaw contact/current-depth/clearance checks still required",
        legacy_scope="Explicit binding is a caller declaration, not proof of acquisition synchrony",
    )
