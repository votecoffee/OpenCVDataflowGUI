"""Bounded opposing CAD-contact suggestions; review never accepts a scene grasp."""

from concurrent.futures import CancelledError
from dataclasses import asdict, dataclass, replace
from hashlib import sha256

import numpy as np
from scipy.spatial import cKDTree

from .jaw import JawPlanner
from .jaw_specs import JawGrasp, JawRecipe, JawSettings

MAX_AXES = 12
ANCHORS_PER_AXIS = 25
MAX_VERIFIED = 96


@dataclass(frozen=True)
class ContactProposal:
    grasp: JawGrasp
    source_rows: tuple
    contact_sides: tuple
    pad_points: np.ndarray
    pad_supported: np.ndarray
    model_collision_rows: tuple
    model_collision_count: int
    reasons: tuple

    @property
    def reviewable(self):
        return not self.reasons

    def record(self):
        return dict(
            grasp=self.grasp.record(),
            source_rows=list(self.source_rows),
            contact_sides=list(self.contact_sides),
            pad_points=self.pad_points.tolist(),
            pad_supported=self.pad_supported.tolist(),
            model_collision_rows=list(self.model_collision_rows),
            model_collision_count=self.model_collision_count,
            status="reviewable" if self.reviewable else "rejected",
            reasons=list(self.reasons),
            contact_source="CAD_model_assisted",
            current_pose_and_scene_clearance_checked=False,
        )


@dataclass(frozen=True)
class ContactProposals:
    proposals: tuple
    axes: int
    seeds: int
    verified: int
    suppressed: int
    retract: tuple
    source_frame: str
    source_sha256: str
    settings: JawSettings

    def report(self):
        return dict(
            model="jaw_contact_proposals_v1",
            units="m",
            part_frame=self.source_frame,
            geometry_sha256=self.source_sha256,
            geometry_hash_format="Contiguous little-endian float64 point rows then normal rows",
            jaw_settings=asdict(self.settings),
            retract=list(self.retract),
            proposals=[p.record() for p in self.proposals],
            counts=dict(
                axes=self.axes,
                seeds=self.seeds,
                verified=self.verified,
                suppressed=self.suppressed,
                reviewable=sum(p.reviewable for p in self.proposals),
            ),
            budget=dict(
                axes=MAX_AXES,
                anchors_per_axis=ANCHORS_PER_AXIS,
                full_model_checks=MAX_VERIFIED,
                normal_bin_width=0.15,
                normal_separation_degrees=12,
                anchor_fractions=[0.5, 0.25, 0.75, 0.1, 0.9],
            ),
            source="Retained CAD surface samples and outward normals",
            acceptance_applied=False,
            robot_execution=False,
            qualification=(
                "Finite sampled CAD pad/sweep evidence only; explicitly review and add, "
                "then preview current pose/depth. No force closure or physical grasp claim"
            ),
        )


def normal_axes(normals, check):
    """Dominant antipodal normal bins; no camera/world axis or per-example thresholds."""
    first = np.argmax(abs(normals) > 1e-8, axis=1)
    canonical = normals * np.where(normals[np.arange(len(normals)), first] < 0, -1, 1)[:, None]
    bins, inverse, counts = np.unique(
        np.rint(canonical / 0.15).astype(np.int8), axis=0, return_inverse=True, return_counts=True
    )
    means = np.c_[tuple(np.bincount(inverse, weights=canonical[:, i]) for i in range(3))]
    axes = []
    for index in np.lexsort((bins[:, 2], bins[:, 1], bins[:, 0], -counts))[:256]:
        check()
        axis = means[index] / np.linalg.norm(means[index])
        if any(abs(axis @ old) > np.cos(np.deg2rad(12)) for old in axes):
            continue
        axes.append(axis)
        if len(axes) == MAX_AXES:
            break
    return axes


def propose_contacts(recipe, retract=(0, 0, 1), *, limit=24, cancelled=lambda: False):
    """Generate model-only alternatives without mutating retained training.

    Closing directions come from dominant normal bins. A fixed 5x5 target grid
    queries opposing patches in their tangential plane. Finite pad support ranks
    seeds before bounded full sampled-model sweep checks. The declared retract
    preference is projected perpendicular to each actual contact line.
    """
    if not isinstance(recipe, JawRecipe):
        raise TypeError("Use a retained JawRecipe")
    if type(limit) is not int or not 1 <= limit <= 32:
        raise ValueError("Choose 1..32 displayed contact suggestions")
    retract = np.asarray(retract, float)
    if retract.shape != (3,) or not np.isfinite(retract).all() or np.linalg.norm(retract) < 1e-8:
        raise ValueError("Declare a finite nonzero part-frame retract preference")
    retract = retract / np.linalg.norm(retract)

    def check():
        if cancelled():
            raise CancelledError("Contact suggestion cancelled; no partial proposals retained")

    check()
    planner = JawPlanner(recipe)
    part, s = recipe.part, recipe.settings
    points, normals = part.points, planner.normals
    seeds, used_pairs = [], set()
    center = points.mean(0)
    angle = np.cos(np.deg2rad(s.maximum_contact_angle_degrees))
    axes = normal_axes(normals, check)
    for axis in axes:
        check()
        z = retract - axis * (axis @ retract)
        if np.linalg.norm(z) < 0.1:
            continue
        z /= np.linalg.norm(z)
        basis = np.c_[np.cross(z, axis), z]
        positive = np.flatnonzero(normals @ axis >= angle)
        negative = np.flatnonzero(normals @ axis <= -angle)
        if len(positive) < 9 or len(negative) < 9:
            continue
        pos, neg = points[positive] @ basis, points[negative] @ basis
        p_tree, n_tree = cKDTree(pos), cKDTree(neg)
        low, high = np.maximum(pos.min(0), neg.min(0)), np.minimum(pos.max(0), neg.max(0))
        if np.any(high <= low):
            continue
        fractions = (0.5, 0.25, 0.75, 0.1, 0.9)
        targets = np.array([low + (high - low) * [a, b] for a in fractions for b in fractions])
        _, p_ids = p_tree.query(targets)
        distance, n_ids = n_tree.query(pos[p_ids])
        for p_id, n_id, distance in zip(p_ids, n_ids, distance):
            check()
            if distance > 2 * s.contact_tolerance:
                continue
            first, second = int(negative[n_id]), int(positive[p_id])
            if (first, second) in used_pairs or (points[second] - points[first]) @ axis <= 1e-5:
                continue
            used_pairs.add((first, second))
            try:
                grasp = JawGrasp.from_contacts("suggested", points[first], points[second], retract)
            except ValueError:
                continue
            sides, pads, supported = planner._contact_support(grasp)
            center_distance = np.linalg.norm(grasp.part_from_grasp[:3, 3] - center)
            seeds.append(
                (min(sides), center_distance, first, second, grasp, sides, pads, supported)
            )
    seeds.sort(
        key=lambda item: (
            not (
                s.minimum_opening <= item[4].span
                and max(s.minimum_opening, item[4].span + 2 * s.opening_margin) <= s.maximum_opening
            ),
            -item[0],
            item[1],
            item[2],
            item[3],
        )
    )
    evaluated = []
    for _, _, first, second, grasp, sides, pads, supported in seeds[:MAX_VERIFIED]:
        check()
        reasons, collisions = [], np.empty(0, int)
        opening = max(s.minimum_opening, grasp.span + 2 * s.opening_margin)
        if grasp.span < s.minimum_opening or opening > s.maximum_opening:
            reasons.append("jaw_opening_limit")
        if min(sides) < s.minimum_contact_fraction:
            reasons.append("unsupported_CAD_contact_pads")
        if "jaw_opening_limit" not in reasons:
            compiled = planner._compile(grasp)
            collisions = compiled["model_collisions"]
            if len(collisions):
                reasons.append("CAD_gripper_sweep_collision")
        evaluated.append(
            ContactProposal(
                grasp,
                (first, second),
                tuple(sides),
                pads,
                supported,
                tuple(map(int, collisions[:128])),
                len(collisions),
                tuple(reasons),
            )
        )
    evaluated.sort(
        key=lambda p: (
            not p.reviewable,
            -min(p.contact_sides),
            p.model_collision_count,
            p.source_rows,
        )
    )
    kept, names = [], {g.name for g in recipe.grasps}
    minimum_distance = max(2 * s.contact_tolerance, min(s.finger_width, s.pad_height) / 2)
    for item in evaluated:
        check()
        frame = item.grasp.part_from_grasp
        if any(
            np.linalg.norm(frame[:3, 3] - p.grasp.part_from_grasp[:3, 3]) < minimum_distance
            and abs(frame[:3, 0] @ p.grasp.part_from_grasp[:3, 0]) > np.cos(np.deg2rad(12))
            and frame[:3, 2] @ p.grasp.part_from_grasp[:3, 2] > np.cos(np.deg2rad(12))
            for p in kept
        ):
            continue
        index = 1
        while f"suggested_{index:02}" in names:
            index += 1
        name = f"suggested_{index:02}"
        names.add(name)
        kept.append(replace(item, grasp=replace(item.grasp, name=name)))
        if len(kept) == limit:
            break
    check()
    digest = sha256(points.astype("<f8", copy=False).tobytes())
    digest.update(part.normals.astype("<f8", copy=False).tobytes())
    return ContactProposals(
        tuple(kept),
        len(axes),
        len(seeds),
        len(evaluated),
        len(evaluated) - len(kept),
        tuple(map(float, retract)),
        part.frame,
        digest.hexdigest(),
        s,
    )


def add_proposals(recipe, proposals):
    """Explicit selected additions; sealed notes retain their actual source-row provenance."""
    selected = tuple(proposals)
    if not selected or any(
        not isinstance(p, ContactProposal) or not p.reviewable for p in selected
    ):
        raise ValueError("Select at least one reviewable CAD contact suggestion")
    names = {g.name for g in recipe.grasps}
    if any(p.grasp.name in names for p in selected) or len({p.grasp.name for p in selected}) != len(
        selected
    ):
        raise ValueError("Suggested grasp names conflict with retained training; generate again")
    planner = JawPlanner(recipe)
    for p in selected:
        if len(p.source_rows) != 2 or any(
            type(i) is not int or not 0 <= i < len(recipe.part.points) for i in p.source_rows
        ):
            raise ValueError("Suggestion source rows differ from the retained CAD; generate again")
        contacts = recipe.part.points[list(p.source_rows)]
        actual = p.grasp.part_from_grasp
        expected = JawGrasp.from_contacts(p.grasp.name, *contacts, actual[:3, 2])
        if not np.allclose(expected.part_from_grasp, actual, atol=1e-12, rtol=0):
            raise ValueError("Suggestion source rows differ from the retained CAD; generate again")
        compiled = planner._compile(p.grasp)
        if (
            p.grasp.span < recipe.settings.minimum_opening
            or compiled["opening"] > recipe.settings.maximum_opening
            or compiled["contact_fraction"] < recipe.settings.minimum_contact_fraction
            or len(compiled["model_collisions"])
        ):
            raise ValueError(
                "Suggestion no longer passes current gripper/CAD checks; generate again"
            )
    notes = dict(recipe.notes)
    history = dict(notes.get("jaw_contact_suggestions_v1", {}))
    for p in selected:
        history[p.grasp.name] = p.record()
    notes["jaw_contact_suggestions_v1"] = history
    return replace(recipe, grasps=recipe.grasps + tuple(p.grasp for p in selected), notes=notes)


def proposal_cloud(recipe, proposal):
    """Cached derived CAD, finite pad tests, gripper/TCP axes and collision witnesses."""
    from .graphics import CloudGraphics
    from .jaw_teaching import grasp_segments

    points, colors, components = [], [], []

    def add(data, color, role):
        data = np.asarray(data).reshape(-1, 3)
        start = sum(map(len, points))
        points.append(data)
        colors.append(np.tile(color, (len(data), 1)))
        components.append(
            dict(role=role, row_start=start, row_stop=start + len(data), observations=False)
        )

    rows = np.linspace(
        0, len(recipe.part.points) - 1, min(20_000, len(recipe.part.points)), dtype=int
    )
    add(recipe.part.points[rows], (115, 125, 140), "retained_CAD")
    add(recipe.part.points[list(proposal.model_collision_rows)], (255, 45, 210), "CAD_collisions")
    add(recipe.part.points[list(proposal.source_rows)], (255, 230, 50), "source_contacts")
    for a, b, color, _ in grasp_segments(recipe, proposal.grasp):
        if color == (80, 240, 110) and not proposal.reviewable:
            color = (245, 75, 75)
        add(np.linspace(a, b, 16), color, "derived_gripper")
    for point, supported in zip(proposal.pad_points, proposal.pad_supported):
        for axis in np.eye(3):
            add(
                np.linspace(point - axis * 0.0008, point + axis * 0.0008, 5),
                (65, 230, 100) if supported else (245, 75, 75),
                "finite_pad_test",
            )
    xyz, rgb = np.concatenate(points), np.concatenate(colors).astype(np.uint8)
    xyz.flags.writeable = rgb.flags.writeable = False
    return CloudGraphics(
        xyz,
        rgb,
        "m",
        recipe.part.frame,
        dict(
            model="jaw_contact_proposal_graphics_v1",
            components=components,
            proposal=proposal.record(),
            acceptance_applied=False,
            runtime_scene_checked=False,
        ),
    )
