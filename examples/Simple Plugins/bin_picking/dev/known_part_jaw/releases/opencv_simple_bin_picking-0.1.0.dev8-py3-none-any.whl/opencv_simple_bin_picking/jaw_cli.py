"""Retain CAD jaw setup and plan from explicit current depth/accepted-pose records."""

import argparse
import json
from pathlib import Path

from .jaw import JawPlanner
from .jaw_persistence import load_jaw_recipe, save_jaw_recipe
from .jaw_specs import JawGrasp, JawRecipe, JawSettings, PartInstance, PartSurface
from .persistence import MAX_BYTES, load_recipe, read_array, strict_json


def read_json(path):
    if path.stat().st_size > 1024 * 1024:
        raise ValueError("JSON declaration exceeds 1 MiB")
    return strict_json(path.read_bytes())


def read_numeric(path, *, labels=False):
    if path.stat().st_size > MAX_BYTES:
        raise ValueError("Numeric input exceeds 64 MiB")
    return read_array(path.read_bytes(), labels=labels)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    train = commands.add_parser("train", help="Retain CAD points/normals and authored jaw frames")
    for name in ("bin_recipe", "points", "normals", "configuration", "output"):
        train.add_argument(name, type=Path)
    run = commands.add_parser(
        "plan", help="Geometry/first-return evaluation only; no robot execution"
    )
    for name in ("recipe", "depth", "instances", "output"):
        run.add_argument(name, type=Path)
    run.add_argument("--capture-id", required=True)
    run.add_argument("--instance-labels", type=Path)
    args = parser.parse_args(argv)
    if args.command == "train":
        config = read_json(args.configuration)
        recipe = JawRecipe(
            load_recipe(args.bin_recipe),
            PartSurface(
                read_numeric(args.points), read_numeric(args.normals), config["part_frame"]
            ),
            tuple(JawGrasp(**grasp) for grasp in config["grasps"]),
            JawSettings(**config.get("jaw_settings", {})),
            config.get("grasp_from_tcp", [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]),
            notes=config.get("notes", {}),
        )
        digest = save_jaw_recipe(args.output, recipe)
        print(json.dumps(dict(sha256=digest, units="m", network_training=False)))
        return 0
    recipe = load_jaw_recipe(args.recipe)
    records = read_json(args.instances)
    if not isinstance(records, list) or len(records) > 32:
        raise ValueError("Supply a list of up to 32 explicit part instances")
    instances = [
        PartInstance.from_record(
            item, part_frame=recipe.part.frame, camera_frame=recipe.bin.camera.frame
        )
        for item in records
    ]
    depth = read_numeric(args.depth)
    labels = read_numeric(args.instance_labels, labels=True) if args.instance_labels else None
    result = JawPlanner(recipe).plan(
        depth, instances, capture_id=args.capture_id, instance_labels=labels, retain_pose_fit=False
    )
    with args.output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result.report(), stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps(dict(eligible_grasps=len(result.picks), physical_grasp_qualified=False)))
    return 0 if result.picks else 1


if __name__ == "__main__":
    raise SystemExit(main())
