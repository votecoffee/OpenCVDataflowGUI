"""Native colored jaw/contact/sweep/pose-fit review; derived rows never enter planning."""

import copy

import numpy as np

from .graphics import COLORS, CloudGraphics
from .jaw import corners, tool_boxes, transform
from .jaw_fit import POSE_FIT_COLORS, STATES

LAYERS = ("scene", "bin", "model", "jaws", "sweep", "poses", "witnesses", "pose_fit")


def jaw_result_cloud(result, *, selected=None, layers=LAYERS):
    if any(name not in LAYERS for name in layers):
        raise ValueError("Choose known jaw result graphic layers")
    if selected is not None and selected not in {c["id"] for c in result.candidates}:
        raise ValueError("Select an existing jaw candidate")
    xyz, rgb, components = [], [], []
    count = 0

    def add(points, color, role):
        nonlocal count
        points = np.asarray(points).reshape(-1, 3)
        xyz.append(points)
        rgb.append(np.tile(color, (len(points), 1)))
        components.append(
            dict(
                role=role, rows=[count, count + len(points)], observations=role == "measured_scene"
            )
        )
        count += len(points)

    def line(a, b, color, role, n=20):
        add(np.linspace(a, b, n), color, role)

    def box(low, high, matrix, color, role):
        vertices = transform(corners(low, high), matrix)
        for i in range(8):
            for bit in (1, 2, 4):
                if i < i ^ bit:
                    line(vertices[i], vertices[i ^ bit], color, role)

    scene, recipe = result.scene, result.recipe
    settings = recipe.settings
    if "scene" in layers and len(scene.points):
        rows = np.linspace(0, len(scene.points) - 1, min(len(scene.points), 30_000), dtype=int)
        add(scene.points[rows], COLORS["scene"], "measured_scene")
    if "bin" in layers:
        box(recipe.bin.minimum, recipe.bin.maximum, np.eye(4), COLORS["bin"], "configured_bin")
    if selected is None:
        candidates = list(result.picks[:8])
        candidates += [
            c
            for c in result.candidates
            if c["status"] != "eligible"
            and c["reasons"] not in (["overlap_with_higher_ranked"], ["grasp_count_limit"])
        ][:8]
    else:
        candidates = [c for c in result.candidates if c["id"] == selected]
    drawn = set()
    for i, item in enumerate(candidates):
        frame = np.asarray(item["grasp_pose"])
        grasp = next(g for g in recipe.grasps if g.name == item["grasp_name"])
        color = COLORS[item["status"]]
        if "model" in layers and item["instance_id"] not in drawn:
            rows = np.linspace(
                0, len(recipe.part.points) - 1, min(3000, len(recipe.part.points)), dtype=int
            )
            matrix = frame @ np.linalg.inv(grasp.part_from_grasp)
            add(transform(recipe.part.points[rows], matrix), [70, 180, 230], "derived_CAD")
            drawn.add(item["instance_id"])
        low_z = -settings.pad_height / 2
        high_z = settings.finger_length - settings.pad_height / 2
        if "jaws" in layers:
            for sign in (-1, 1):
                for span, tint, role in (
                    (item["span"], color, "derived_closed_finger"),
                    (item["opening"], [75, 150, 240], "derived_open_finger"),
                ):
                    x = sorted((sign * span / 2, sign * (span / 2 + settings.finger_thickness)))
                    box(
                        [x[0], -settings.finger_width / 2, low_z],
                        [x[1], settings.finger_width / 2, high_z],
                        frame,
                        tint,
                        role,
                    )
            box(
                [-settings.palm_width / 2, -settings.palm_depth / 2, high_z],
                [settings.palm_width / 2, settings.palm_depth / 2, high_z + settings.palm_height],
                frame,
                color,
                "derived_palm",
            )
        if "sweep" in layers and (selected is not None or i == 0):
            for _, low, high in tool_boxes(item["span"], item["opening"], settings):
                box(low, high, frame, COLORS["sweep"], "derived_swept_envelope")
        if "poses" in layers:
            tcp, pregrasp = np.asarray(item["tcp_pose"]), np.asarray(item["pregrasp_pose"])
            line(tcp[:3, 3], pregrasp[:3, 3], color, "derived_approach", 40)
            for axis in range(3):
                tint = np.zeros(3)
                tint[axis] = 255
                line(tcp[:3, 3], tcp[:3, 3] + tcp[:3, axis] * 0.012, tint, "derived_TCP_axes")
        if "witnesses" in layers:
            add(
                scene.points[item["collision_rows"]],
                COLORS["collision"],
                "observed_collision_witness",
            )
            add(item["unknown_samples"], COLORS["unknown"], "derived_unknown_queries")
            if item["model_collision_rows"]:
                matrix = frame @ np.linalg.inv(grasp.part_from_grasp)
                add(
                    transform(recipe.part.points[item["model_collision_rows"]], matrix),
                    COLORS["collision"],
                    "derived_CAD_collision_witness",
                )
    fits = result.pose_fits
    if selected is not None:
        identity = candidates[0]["instance_id"]
        fits = tuple(fit for fit in fits if fit.instance_id == identity)
    if "pose_fit" in layers:
        for fit in fits:
            for code, name in enumerate(STATES):
                add(fit.points[fit.states == code], POSE_FIT_COLORS[name], f"derived_pose_{name}")
    points = np.concatenate(xyz).astype(np.float32) if xyz else np.empty((0, 3), np.float32)
    colors = np.concatenate(rgb).astype(np.uint8) if rgb else np.empty((0, 3), np.uint8)
    points.flags.writeable = colors.flags.writeable = False
    return CloudGraphics(
        points,
        colors,
        "m",
        recipe.bin.frame,
        dict(
            derived_review=True,
            components=components,
            capture_id=result.capture_id,
            contact_source="CAD_taught_not_measured_force_closure",
            selected_candidate=selected,
            unobserved_space="unknown_not_free",
            physical_grasp_qualified=False,
            pose_fit=[copy.deepcopy(fit.summary) for fit in fits],
            pose_fit_legend=copy.deepcopy(POSE_FIT_COLORS),
            pose_fit_points="Predicted CAD samples; not additional sensor returns or free space",
        ),
    )
