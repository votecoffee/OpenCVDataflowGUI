"""Bounded cached review of the exact four-neighbor pose check; no new decision gate."""

from dataclasses import dataclass

import numpy as np

POSE_FIT_COLORS = {
    "supported": [65, 230, 100],
    "contradiction": [245, 55, 210],
    "occluded": [70, 135, 245],
    "unknown": [255, 165, 45],
    "ambiguous": [245, 230, 65],
    "label_mismatch": [165, 95, 235],
}
STATES = tuple(POSE_FIT_COLORS)
ROWS_PER_STATE = 256


@dataclass(frozen=True)
class PoseFitReview:
    instance_id: str
    points: np.ndarray
    states: np.ndarray
    model_rows: np.ndarray
    summary: dict


def retain_pose_fit(
    instance_id,
    points,
    model_rows,
    known,
    nearest,
    farthest,
    z,
    same,
    support,
    contradiction,
    tolerance,
):
    """Classify already-tested rays, retaining rare states without changing their counts.

    A point behind every observed neighbor is only classified as occluded. A
    depth/label discontinuity is ambiguous rather than a fabricated correspondence.
    The caller passes the actual support/contradiction masks used for acceptance.
    """
    codes = {name: i for i, name in enumerate(STATES)}
    states = np.full(len(points), codes["unknown"], np.uint8)
    states[known] = codes["ambiguous"]
    states[known & ~same] = codes["label_mismatch"]
    states[known & (z > farthest + tolerance)] = codes["occluded"]
    states[contradiction] = codes["contradiction"]
    states[support] = codes["supported"]
    counts, retained, selected = {}, {}, []
    for code, name in enumerate(STATES):
        rows = np.flatnonzero(states == code)
        counts[name] = len(rows)
        rows = rows[np.linspace(0, len(rows) - 1, min(len(rows), ROWS_PER_STATE), dtype=int)]
        retained[name] = len(rows)
        selected.append(rows)
    rows = np.sort(np.concatenate(selected))
    arrays = [np.array(v[rows], copy=True) for v in (points, states, model_rows)]
    for value in arrays:
        value.flags.writeable = False

    def residual(observed):
        # All known rays, including possible occluders. Never call this pose error.
        values = (z - observed)[known]
        return np.quantile(values, [0.05, 0.5, 0.95]).tolist() if len(values) else None

    summary = dict(
        instance_id=instance_id,
        inspected_samples=len(points),
        counts=counts,
        retained_counts=retained,
        rows_per_state_limit=ROWS_PER_STATE,
        pose_tolerance_m=tolerance,
        nearest_residual_p05_p50_p95_m=residual(nearest),
        farthest_residual_p05_p50_p95_m=residual(farthest),
        residual_definition="Predicted camera Z minus observed neighbor Z; all known rays",
        residual_scope="Includes occlusion and discontinuities; not independent pose error",
        sampling="Deterministic per-state subset; counts and quantiles use all tested rays",
    )
    return PoseFitReview(instance_id, *arrays, summary)
