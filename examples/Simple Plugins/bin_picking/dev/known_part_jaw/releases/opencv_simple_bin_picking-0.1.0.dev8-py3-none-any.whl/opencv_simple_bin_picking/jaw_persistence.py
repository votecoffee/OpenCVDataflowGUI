"""Self-contained metric jaw recipes; bounded numeric members and atomic new files."""

import hashlib
import io
import json
import os
from pathlib import Path
from tempfile import NamedTemporaryFile
from zipfile import ZIP_DEFLATED, BadZipFile, ZipFile, ZipInfo

from .jaw_specs import JawGrasp, JawRecipe, JawSettings, PartSurface
from .persistence import MAX_BYTES, array_bytes, read_array, strict_json
from .specs import Camera, Recipe, SuctionSettings


def save_jaw_recipe(path, recipe):
    if not isinstance(recipe, JawRecipe):
        raise TypeError("Save a validated JawRecipe")
    path = Path(path)
    if path.suffix != ".sbpj":
        raise ValueError("Choose a .sbpj jaw recipe")
    if path.exists():
        raise FileExistsError("Preserve existing training; choose a new jaw recipe filename")
    arrays = dict(
        depth=recipe.bin.reference_depth, part=recipe.part.points, normals=recipe.part.normals
    )
    if recipe.bin.reference_rgb is not None:
        arrays["rgb"] = recipe.bin.reference_rgb
    if recipe.bin.reference_instances is not None:
        arrays["labels"] = recipe.bin.reference_instances
    entries = {name + ".npy": array_bytes(value) for name, value in arrays.items()}
    manifest = dict(
        version=1,
        tool="simple_bin_picking_jaw",
        **recipe.configuration(),
        arrays={name: hashlib.sha256(value).hexdigest() for name, value in entries.items()},
    )
    entries["recipe.json"] = json.dumps(manifest, indent=2, allow_nan=False).encode("utf-8")
    if sum(map(len, entries.values())) > MAX_BYTES:
        raise ValueError("Retained jaw setup exceeds 64 MiB")
    with NamedTemporaryFile(dir=path.parent, prefix=".jaw-setup-", delete=False) as temporary:
        pending = Path(temporary.name)
    try:
        with ZipFile(pending, "w") as archive:
            for name, value in entries.items():
                info = ZipInfo(name, (1980, 1, 1, 0, 0, 0))
                info.compress_type, info.create_system = ZIP_DEFLATED, 0
                archive.writestr(info, value)
        if pending.stat().st_size > MAX_BYTES:
            raise ValueError("Retained jaw archive exceeds 64 MiB")
        os.link(pending, path)
    finally:
        pending.unlink(missing_ok=True)
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_jaw_recipe(path, *, sha256=None):
    path = Path(path)
    if path.stat().st_size > MAX_BYTES:
        raise ValueError("Jaw archive exceeds 64 MiB")
    raw = path.read_bytes()
    if sha256 is not None and hashlib.sha256(raw).hexdigest() != sha256:
        raise ValueError("Jaw recipe SHA-256 differs")
    try:
        with ZipFile(io.BytesIO(raw)) as archive:
            names = archive.namelist()
            required = {"recipe.json", "depth.npy", "part.npy", "normals.npy"}
            if (
                not required.issubset(names)
                or len(names) != len(set(names))
                or set(names) - required - {"rgb.npy", "labels.npy"}
                or sum(i.file_size for i in archive.infolist()) > MAX_BYTES
                or archive.getinfo("recipe.json").file_size > 1024 * 1024
            ):
                raise ValueError("Unexpected/duplicate/oversized jaw archive members")
            manifest = strict_json(archive.read("recipe.json"))
            if (
                type(manifest["version"]) is not int
                or manifest["version"] != 1
                or manifest["tool"] != "simple_bin_picking_jaw"
                or manifest["units"] != "m"
                or not isinstance(manifest["arrays"], dict)
                or set(manifest["arrays"]) != set(names) - {"recipe.json"}
            ):
                raise ValueError("Unsupported jaw recipe manifest")
            arrays = {}
            for name, digest in manifest["arrays"].items():
                data = archive.read(name)
                if hashlib.sha256(data).hexdigest() != digest:
                    raise ValueError("Jaw numeric member checksum differs")
                arrays[name[:-4]] = read_array(
                    data, rgb=name == "rgb.npy", labels=name == "labels.npy"
                )
        config = manifest["bin"]
        base = Recipe(
            Camera(**config["camera"]),
            arrays["depth"],
            config["bin_to_camera"],
            config["minimum"],
            config["maximum"],
            units=config["units"],
            frame=config["frame"],
            depth_scale=config["depth_scale"],
            settings=SuctionSettings(**config["settings"]),
            reference_rgb=arrays.get("rgb"),
            reference_instances=arrays.get("labels"),
        )
        return JawRecipe(
            base,
            PartSurface(arrays["part"], arrays["normals"], manifest["part_frame"]),
            tuple(JawGrasp(**g) for g in manifest["grasps"]),
            JawSettings(**manifest["jaw_settings"]),
            manifest["grasp_from_tcp"],
            notes=manifest.get("notes", {}),
        )
    except (BadZipFile, KeyError, TypeError, OSError) as error:
        raise ValueError(f"Invalid jaw recipe: {error}") from error
