"""Frozen completed measurements and exact consumed pixels; no measurement rerun."""

import copy
import hashlib
import json
from collections import OrderedDict
from dataclasses import asdict, dataclass, field
from numbers import Integral

import cv2
import numpy as np

from .measurement import PathWidthResult, _ScanTrace
from .recipe import PathWidthRecipe
from .station_review import review_trace, save_station_review, station_group

BINDING = "spw_completed_review"


def _json(value):
    return json.dumps(
        value, sort_keys=True, allow_nan=False, default=lambda v: v.tolist()
    ).encode()


def _readonly(value):
    array = np.asarray(value)
    return np.frombuffer(array.tobytes(), dtype=array.dtype).reshape(array.shape)


@dataclass(frozen=True)
class CompletedPathRecord:
    identifier: str
    manifest: bytes
    recipe: PathWidthRecipe
    result: PathWidthResult
    context_json: bytes

    @classmethod
    def create(cls, identifier, manifest, recipe, result, calibration, pose, fixture):
        context = _json(
            dict(
                calibration=calibration,
                reference_to_image=pose,
                reference_fixture=fixture,
            )
        )
        return cls(identifier, bytes(manifest), recipe, result, context)

    @property
    def manifest_sha256(self):
        return hashlib.sha256(self.manifest).hexdigest()

    @property
    def context(self):
        return json.loads(self.context_json)

    def __deepcopy__(self, memo):
        return self


@dataclass(frozen=True)
class CompletedPathCapture:
    record: CompletedPathRecord
    source_pixels: np.ndarray = field(repr=False, compare=False)
    image: np.ndarray = field(repr=False, compare=False)
    inspected: np.ndarray = field(repr=False, compare=False)
    source_format: str
    _provenance: dict = field(repr=False, compare=False)
    _traces: OrderedDict = field(default_factory=OrderedDict, repr=False, compare=False)

    @property
    def calibration(self):
        return self.record.context["calibration"]

    @property
    def provenance(self):
        return copy.deepcopy(self._provenance)

    @property
    def source_sha256(self):
        return hashlib.sha256(self.source_pixels.tobytes()).hexdigest()

    def trace(self, index):
        # Only a requested diagnostic profile is resampled. Edge selection, widths,
        # station status and verdict stay the immutable completed measurements.
        if (
            isinstance(index, bool)
            or not isinstance(index, Integral)
            or not 0 <= index < len(self.record.result.stations)
        ):
            raise ValueError("Select a valid zero-based station index")
        if index not in self._traces:
            trace = review_trace(
                self.image,
                self.record.result,
                index,
                self.record.recipe.settings,
                self.calibration,
            )
            self._traces[index] = _ScanTrace(
                **{
                    name: None if value is None else _readonly(value)
                    for name, value in vars(trace).items()
                }
            )
            if len(self._traces) > 64:
                self._traces.popitem(last=False)
        self._traces.move_to_end(index)
        return self._traces[index]

    def report(self):
        result = self.record.result
        groups = ("measured", "out_of_tolerance", "missing", "ambiguous", "unobserved")
        return dict(
            model="simple_path_width_completed_review_v1",
            execution_binding=self.record.identifier,
            manifest_sha256=self.record.manifest_sha256,
            source_image=dict(
                shape=list(self.source_pixels.shape),
                dtype=self.source_pixels.dtype.str,
                format=self.source_format,
                sha256=self.source_sha256,
            ),
            measurement_image=dict(
                shape=list(self.image.shape), dtype=self.image.dtype.str
            ),
            inspected_pixels=int(np.count_nonzero(self.inspected)),
            station_groups={
                group: sum(
                    station_group(result, i) == group
                    for i in range(len(result.stations))
                )
                for group in groups
            },
            measurements=asdict(result),
            executed_context=self.record.context,
            provenance=self.provenance,
            coordinate_scope="Measurements in exact consumed image pixels; upstream spatial/pyramid metadata retained",
            identity_scope="Software completion identifiers do not establish physical exposure identity",
            profile_scope="Diagnostic samples resampled from frozen pixels on selection; 64-station cache",
            measurement_reexecuted=False,
            recipe_reloaded=False,
            training_changed=False,
        )

    def export(self, directory, index=0):
        target = save_station_review(
            directory,
            self.image,
            self.record.result,
            index,
            self.record.recipe.settings,
            calibration=self.calibration,
            trace=self.trace(index),
        )
        for name, pixels in (
            ("consumed_input", self.source_pixels),
            ("measurement_input", self.image),
        ):
            with (target / f"{name}.npy").open("wb") as stream:
                np.save(stream, pixels, allow_pickle=False)
        (target / "executed_manifest.json").write_bytes(self.record.manifest)
        ok, encoded = cv2.imencode(".png", self.inspected.astype(np.uint8) * 255)
        if not ok:
            raise ValueError("Could not encode inspection coverage")
        (target / "inspected_mask.png").write_bytes(encoded.tobytes())
        path = target / "review.json"
        report = json.loads(path.read_bytes())
        report["completed_execution"] = self.report()
        path.write_text(
            json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8"
        )
        return target


def capture_completed(record, bundle):
    from opencv_dataflow.images import image_format
    from opencv_dataflow.processing import gray_image
    from opencv_dataflow.selection import selection_mask

    if record is None:
        raise ValueError(
            "No retained completed measurements; execute in Debug before reviewing"
        )
    packet = bundle.outputs["measurements"]
    binding = packet.payload.get(BINDING, {})
    expected = asdict(record.result)
    expected.pop("physical_measurements")
    expected = {"model": "simple_path_width_v1", **expected}
    if (
        binding.get("id") != record.identifier
        or binding.get("manifest_sha256") != record.manifest_sha256
        or _json(packet.value) != _json(expected)
    ):
        raise ValueError(
            "Completed measurement/model evidence changed; capture the latest run again"
        )
    source = bundle.inputs["image"].value
    image = _readonly(gray_image(source, (np.uint8, np.uint16, np.float32)))
    values = {name: packet.value for name, packet in bundle.inputs.items()}
    mask = selection_mask(values, source)
    inspected = np.ones(image.shape, bool) if mask is None else np.asarray(mask) != 0
    provenance = dict(
        snapshot_id=bundle.snapshot_id,
        block_id=bundle.block_id,
        output_revision=bundle.output_revision,
        execution_count=bundle.execution_count,
        passed=bool(bundle.passed),
        score=bundle.score,
        message=bundle.message,
        inputs={
            name: copy.deepcopy(packet.payload)
            for name, packet in bundle.inputs.items()
        },
        outputs={
            name: copy.deepcopy(packet.payload)
            for name, packet in bundle.outputs.items()
        },
    )
    return CompletedPathCapture(
        record,
        _readonly(source),
        image,
        _readonly(inspected),
        image_format(source),
        provenance,
    )
