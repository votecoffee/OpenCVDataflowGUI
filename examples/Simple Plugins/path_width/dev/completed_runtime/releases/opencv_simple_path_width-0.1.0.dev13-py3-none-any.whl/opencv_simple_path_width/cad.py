"""Import one connected XY path from a named modelspace DXF layer."""

import math
from dataclasses import dataclass
from itertools import islice

import numpy as np

from .geometry import MAX_VERTICES, path_vertices
from .measurement import Point

_SUPPORTED = {"LINE", "ARC", "CIRCLE", "LWPOLYLINE", "POLYLINE"}


@dataclass(frozen=True)
class CadPath:
    vertices: tuple[Point, ...]
    closed: bool
    units: int


def _join_paths(paths, tolerance):
    endpoints = np.vstack([part[[0, -1]] for part in paths])
    peer = np.full(len(endpoints), -1, dtype=int)
    for index, point in enumerate(endpoints):
        neighbors = np.flatnonzero(np.linalg.norm(endpoints - point, axis=1) <= tolerance)
        if len(neighbors) > 2:
            raise ValueError("CAD layer has a branch or coincident endpoints. Select one unbranched chain.")
        if len(neighbors) == 2:
            peer[index] = neighbors[0] if neighbors[1] == index else neighbors[1]
    ends = np.flatnonzero(peer == -1)
    if len(ends) not in (0, 2):
        raise ValueError("CAD layer contains disconnected paths.")
    closed = len(ends) == 0
    index = 0 if closed else ends[0]
    seen = set()
    ordered = []
    while index >= 0 and index // 2 not in seen:
        seen.add(index // 2)
        part = paths[index // 2]
        if index % 2:
            part = part[::-1]
        ordered.append(part if not ordered else part[1:])
        index = peer[index ^ 1]
    if len(seen) != len(paths):
        raise ValueError("CAD layer contains disconnected paths.")
    vertices = np.vstack(ordered)
    return (vertices[:-1] if closed else vertices), closed


def load_dxf(path, layer: str, *, curve_tolerance: float = 0.05, join_tolerance: float = 1e-5) -> CadPath:
    """Import a selected planar chain, retaining the DXF drawing units.

    Curve flattening and endpoint matching tolerances are in drawing units.
    Separate entities may be reversed to connect their endpoints.
    """
    try:
        import ezdxf
        from ezdxf.path import make_path
    except ModuleNotFoundError as error:
        if error.name != "ezdxf":
            raise
        raise ValueError("Install the optional [cad] extra to import DXF paths.") from error

    if not isinstance(layer, str) or not layer.strip():
        raise ValueError("Select one DXF modelspace layer.")
    for value in (curve_tolerance, join_tolerance):
        if not math.isfinite(value) or value <= 0:
            raise ValueError("CAD tolerances must be finite and positive.")
    try:
        document = ezdxf.readfile(path)
        paths = []
        count = 0
        z_range = []
        for entity in document.modelspace():
            if entity.dxf.layer.casefold() != layer.casefold():
                continue
            kind = entity.dxftype()
            if kind not in _SUPPORTED or (kind == "POLYLINE" and not entity.is_2d_polyline):
                raise ValueError(f"Unsupported DXF entity {kind} on the selected layer.")
            if kind in ("ARC", "CIRCLE"):
                if not math.isfinite(entity.dxf.radius) or entity.dxf.radius <= 0:
                    raise ValueError("A DXF arc or circle requires a positive finite radius.")
                flattened = entity.flattening(curve_tolerance)
            else:
                flattened = make_path(entity).flattening(curve_tolerance, segments=2)
            points = np.asarray([tuple(point) for point in islice(flattened, MAX_VERTICES + 2)])
            count += len(points)
            if count > MAX_VERTICES + 1:
                raise ValueError("CAD path exceeds the vertex limit. Increase curve tolerance.")
            if len(points) < 2 or not np.isfinite(points).all() or np.max(np.abs(points[:, :2])) > 1e6:
                raise ValueError("CAD entities must have finite, bounded XY coordinates and a nonzero length.")
            if kind == "CIRCLE":
                points[-1] = points[0]
            z_range.extend((points[:, 2].min(), points[:, 2].max()))
            paths.append(points[:, :2])
    except ezdxf.DXFError as error:
        raise ValueError(f"Could not import DXF: {error}") from error

    if not paths:
        raise ValueError(f"No modelspace entities on DXF layer {layer}.")
    if max(z_range) - min(z_range) > 1e-6:
        raise ValueError("CAD entities must lie in a common plane parallel to XY.")
    vertices, closed = _join_paths(paths, join_tolerance)
    return CadPath(tuple(map(tuple, path_vertices(vertices, closed).tolist())), closed, int(document.units))
