"""Point editing and station review views for the training dialog."""

import uuid
from pathlib import Path

import cv2
import numpy as np
from opencv_dataflow.canvas import pixmap
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QPainter, QPen, QPolygonF
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
)

from .geometry import MAX_VERTICES
from .measurement import _trace_station
from .station_review import (
    nearest_station,
    save_station_review,
    station_bounds,
    station_indices,
    station_report,
)
from .trend import PLOT_LEFT, PLOT_RIGHT, draw_scan_trace


class PathCanvas(FilmstripImageView):
    changed = Signal()
    picked = Signal(float, float)

    def __init__(self, parent):
        super().__init__(parent)
        self.vertices = []
        self.closed = False
        self.selected = None
        self.pick_seed = False
        self._dragging = False
        self.setMinimumSize(440, 350)
        self.setToolTip("Drag points · Shift-click inserts · Delete removes · Scroll to zoom · Alt-drag to pan")

    def set_vertices(self, vertices):
        self.vertices = [list(map(float, point)) for point in vertices]
        self.selected = None
        self._changed()

    def _changed(self):
        self.viewport().update()
        self.changed.emit()

    def _image_point(self, event, *, clamp=False):
        image = self.image_item.pixmap()
        if image.isNull():
            return None
        point = self.mapToScene(event.position().toPoint())
        x, y = point.x() - .5, point.y() - .5
        if not clamp and not self.sceneRect().contains(point):
            return None
        return [float(np.clip(x, 0, image.width() - 1)), float(np.clip(y, 0, image.height() - 1))]

    def _insert_at(self, point):
        vertices = np.asarray(self.vertices)
        chain = np.vstack((vertices, vertices[:1])) if self.closed else vertices
        deltas = np.diff(chain, axis=0)
        fraction = np.sum((point - chain[:-1]) * deltas, axis=1) / np.maximum(
            np.sum(deltas**2, axis=1), 1e-12,
        )
        nearest = chain[:-1] + deltas * np.clip(fraction, 0, 1)[:, None]
        return int(np.argmin(np.sum((nearest - point) ** 2, axis=1))) + 1

    def mousePressEvent(self, event):
        if event.button() != Qt.MouseButton.LeftButton or event.modifiers() & Qt.KeyboardModifier.AltModifier:
            super().mousePressEvent(event)
            return
        point = self._image_point(event)
        if point is None:
            return
        if self.pick_seed:
            self.picked.emit(*point)
            return
        self.setFocus()
        if self.vertices:
            distances = np.linalg.norm(np.asarray(self.vertices) - point, axis=1)
            index = int(np.argmin(distances))
            if distances[index] * self.transform().m11() <= 9:
                self.selected, self._dragging = index, True
                self._changed()
                return
        if len(self.vertices) < MAX_VERTICES:
            if len(self.vertices) > 1 and event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                self.selected = self._insert_at(point)
            else:
                self.selected = len(self.vertices)
            self.vertices.insert(self.selected, point)
            self._dragging = True
            self._changed()

    def mouseMoveEvent(self, event):
        if self._dragging and event.buttons() & Qt.MouseButton.LeftButton:
            self.vertices[self.selected] = self._image_point(event, clamp=True)
            self._changed()
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if self._dragging and event.button() == Qt.MouseButton.LeftButton:
            self._dragging = False
            self.vertices[self.selected] = self._image_point(event, clamp=True)
            self._changed()
        else:
            super().mouseReleaseEvent(event)

    def remove_selected(self):
        if self.selected is not None:
            self.vertices.pop(self.selected)
            self.selected = None
            self._changed()

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            self.remove_selected()
        else:
            super().keyPressEvent(event)

    def reverse(self):
        vertices = self.vertices
        self.set_vertices([vertices[0], *vertices[:0:-1]] if self.closed and vertices else vertices[::-1])

    def set_start(self):
        if self.closed and self.selected is not None:
            self.set_vertices(self.vertices[self.selected:] + self.vertices[:self.selected])

    def drawForeground(self, painter, rect):
        if not self.vertices:
            return
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        pen = QPen(QColor("#55dcf0"), 2)
        pen.setCosmetic(True)
        painter.setPen(pen)
        points = [QPointF(x + .5, y + .5) for x, y in self.vertices]
        if len(points) > 1:
            painter.drawPolyline(QPolygonF(points + points[:1] if self.closed else points))
        radius = 4. / self.transform().m11()
        painter.setPen(Qt.PenStyle.NoPen)
        for i, point in enumerate(points):
            color = "#f7b05e" if i == self.selected else "#56ef85" if i == 0 else "#e6edf6"
            painter.setBrush(QColor(color))
            painter.drawEllipse(point, radius, radius)


class _TrendView(FilmstripImageView):
    picked = Signal(float)

    def mousePressEvent(self, event):
        point = self.mapToScene(event.position().toPoint())
        if (event.button() == Qt.MouseButton.LeftButton
                and not event.modifiers() & Qt.KeyboardModifier.AltModifier
                and self.sceneRect().contains(point) and PLOT_LEFT <= point.x() <= PLOT_RIGHT):
            self.picked.emit((point.x() - PLOT_LEFT) / (PLOT_RIGHT - PLOT_LEFT))
        else:
            super().mousePressEvent(event)


class _StationImageView(FilmstripImageView):
    picked = Signal(float, float)

    def __init__(self, parent):
        super().__init__(parent)
        self._press = None
        self.setToolTip("Click near a station to select it; drag to pan; scroll to zoom.")

    def mousePressEvent(self, event):
        self._press = (event.position() if event.button() == Qt.MouseButton.LeftButton
                       and not event.modifiers() & Qt.KeyboardModifier.AltModifier else None)
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        pressed, self._press = self._press, None
        super().mouseReleaseEvent(event)
        if (event.button() == Qt.MouseButton.LeftButton and pressed is not None
                and (event.position() - pressed).manhattanLength() <= 5):
            point = self.mapToScene(event.position().toPoint())
            if self.image_item.boundingRect().contains(point):
                self.picked.emit(point.x() - .5, point.y() - .5)


class MeasurementPreview(QDialog):
    def __init__(self, parent, overlay, trend, result, *, reference, settings, calibration=None, physical_trend=None,
                 trace_provider=None, export_handler=None):
        super().__init__(parent)
        self.resize(1280, 850)
        self.reference = reference
        self.signal = reference.astype(np.float32, copy=False)
        self.settings = settings
        self.calibration = calibration
        self._trace_provider = trace_provider
        self._export_handler = export_handler
        layout = QVBoxLayout(self)
        body = QHBoxLayout()
        layout.addLayout(body, 1)
        self.image = _StationImageView(self)
        self.image.set_image(pixmap(overlay))
        self.trend = _TrendView(self)
        self.trend.set_image(pixmap(trend))
        body.addWidget(self.image, 1)
        plots = QVBoxLayout()
        body.addLayout(plots, 1)
        self.result = result
        self.selected_station = None
        self.trace = None
        self.physical_cursor = None
        pen = QPen(QColor("#00fbff"), 2)
        pen.setCosmetic(True)
        self.marker = self.image.scene().addEllipse(0, 0, 0, 0, pen)
        self.marker.setZValue(1)
        scan_pen = QPen(QColor("#36d9f5"), 1, Qt.PenStyle.DashLine)
        scan_pen.setCosmetic(True)
        self.scan_line = self.image.scene().addLine(0, 0, 0, 0, scan_pen)
        self.scan_line.setZValue(1)
        self.cursor = self.trend.scene().addLine(0, 0, 0, 0, pen)
        self.cursor.hide()
        self.cursor.setZValue(1)
        self.trend.picked.connect(self.select_station)
        self.image.picked.connect(self._image_selected)
        if physical_trend is None:
            plots.addWidget(self.trend, 1)
        else:
            self.tabs = QTabWidget(self)
            self.tabs.addTab(self.trend, "Pixels")
            self.physical_trend = _TrendView(self)
            self.physical_trend.set_image(pixmap(physical_trend))
            units = result.physical_measurements.units
            self.tabs.addTab(self.physical_trend, f"Physical ({units})")
            plots.addWidget(self.tabs, 1)
            self.physical_cursor = self.physical_trend.scene().addLine(0, 0, 0, 0, pen)
            self.physical_cursor.hide()
            self.physical_cursor.setZValue(1)
            self.physical_trend.picked.connect(lambda fraction: self.select_station(fraction, physical=True))
            self.tabs.currentChanged.connect(self._trend_changed)
            self.tabs.setCurrentIndex(1)
            verdict = "Pass" if result.passed else "Fail · " + ", ".join(
                reason.replace("_", " ") for reason in result.failures
            )
            summary = QLabel(f"Calibrated verdict · {verdict}")
            summary.setWordWrap(True)
            layout.addWidget(summary)
        self.profile = FilmstripImageView(self)
        self.profile.setToolTip("Filtered samples and the gradient used to detect the selected station's edges.")
        plots.addWidget(self.profile, 1)
        legend = QLabel("Shaded search windows · Red gradient thresholds · Cyan selected edges")
        legend.setWordWrap(True)
        plots.addWidget(legend)
        self.measurements = QTableWidget(0, 4)
        self.measurements.setHorizontalHeaderLabels(["Measurement / units", "Value", "Limits", "Meaning"])
        self.measurements.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.measurements.setMaximumHeight(160)
        self.measurements.horizontalHeader().setStretchLastSection(True)
        plots.addWidget(self.measurements)

        selection = QHBoxLayout()
        selection.addWidget(QLabel("Station"))
        self.station_number = QSpinBox(self)
        self.station_number.setRange(1, len(result.stations))
        self.station_number.setToolTip("Step through stations or click a position on a trend.")
        selection.addWidget(self.station_number)
        selection.addWidget(QLabel(f"of {len(result.stations)}"))
        self.station_details = QLabel()
        self.station_details.setWordWrap(True)
        selection.addWidget(self.station_details, 1)
        layout.addLayout(selection)
        self.station_explanation = QLabel()
        self.station_explanation.setWordWrap(True)
        layout.addWidget(self.station_explanation)
        navigation = QHBoxLayout()
        self.problem_filter = QComboBox()
        for text, key in (("Needs review", "problems"), ("Measured violations", "out_of_tolerance"),
                          ("Missing edges", "missing"), ("Ambiguous", "ambiguous"),
                          ("Unobserved", "unobserved"), ("All stations", "all")):
            self.problem_filter.addItem(text, key)
        self.problem_filter.currentIndexChanged.connect(self._filter_changed)
        navigation.addWidget(self.problem_filter)
        self.previous_issue = QPushButton("Previous")
        self.next_issue = QPushButton("Next")
        self.previous_issue.clicked.connect(lambda: self._next_issue(-1))
        self.next_issue.clicked.connect(lambda: self._next_issue(1))
        navigation.addWidget(self.previous_issue)
        navigation.addWidget(self.next_issue)
        self.problem_count = QLabel()
        navigation.addWidget(self.problem_count)
        for label, action in (("Focus station", self._focus_station), ("Fit image", self.image.fit_image),
                              ("100%", self.image.actual_size), ("Export station…", self._export_station)):
            button = QPushButton(label)
            button.clicked.connect(action)
            navigation.addWidget(button)
        navigation.addStretch()
        layout.addLayout(navigation)
        self.export_status = QLabel()
        self.export_status.setWordWrap(True)
        layout.addWidget(self.export_status)
        self.station_number.valueChanged.connect(self._number_changed)
        self._show_station(0, self.physical_cursor is not None)

    def _physical_active(self):
        return self.physical_cursor is not None and self.tabs.currentIndex() == 1

    def _image_selected(self, x, y):
        self._show_station(nearest_station(self.result, (x, y)), self._physical_active())

    def _filter_changed(self):
        indices = station_indices(self.result, self.problem_filter.currentData())
        self.previous_issue.setEnabled(bool(indices))
        self.next_issue.setEnabled(bool(indices))
        self.problem_count.setText(f"{len(indices)} of {len(self.result.stations)}")

    def _next_issue(self, direction):
        indices = station_indices(self.result, self.problem_filter.currentData())
        if not indices:
            return
        ordered = indices if direction > 0 else indices[::-1]
        index = next((i for i in ordered if (i - self.selected_station) * direction > 0), ordered[0])
        self._show_station(index, self._physical_active())

    def _focus_station(self):
        bounds = station_bounds(self.reference, self.result, self.selected_station, self.trace)
        self.image.fitInView(QRectF(*bounds), Qt.AspectRatioMode.KeepAspectRatio)
        self.image._fitted = False

    def _export_station(self):
        directory = QFileDialog.getExistingDirectory(self, "Directory for a new station review folder")
        if directory:
            try:
                destination = Path(directory) / f"path-width-review-{uuid.uuid4().hex[:12]}"
                if self._export_handler is not None:
                    target = self._export_handler(destination, self.selected_station)
                else:
                    target = save_station_review(
                        destination, self.reference, self.result, self.selected_station,
                        self.settings, calibration=self.calibration, trace=self.trace,
                    )
                self.export_status.setText(f"Saved station review to {target}. Measurements unchanged.")
            except (OSError, ValueError, TypeError, cv2.error) as error:
                self.export_status.setText(f"Could not export station review: {error}")

    def _number_changed(self, value):
        if value - 1 != self.selected_station:
            physical = self.physical_cursor is not None and self.tabs.currentIndex() == 1
            self._show_station(value - 1, physical)

    def select_station(self, fraction, *, physical=False):
        if physical:
            report = self.result.physical_measurements
            target = fraction * report.path_length
            index = min(range(len(report.stations)), key=lambda i: abs(report.stations[i].distance - target))
        else:
            target = fraction * self.result.path_length_px
            index = min(range(len(self.result.stations)), key=lambda i: abs(self.result.stations[i].distance_px - target))
        self._show_station(index, physical)

    def _trend_changed(self, index):
        if self.selected_station is not None:
            self._show_station(self.selected_station, physical=index == 1)

    def _show_station(self, index, physical):
        changed = index != self.selected_station
        self.selected_station = index
        self.station_number.setValue(index + 1)
        pixel = self.result.stations[index]
        x, y = pixel.point
        self.marker.setRect(x - 5.5, y - 5.5, 12, 12)
        if changed:
            trace = (self._trace_provider(index) if self._trace_provider is not None
                     else _trace_station(self.signal, pixel, self.settings, self.calibration))
            self.trace = trace
            self.scan_line.setLine(*(trace.endpoints.ravel() + .5))
            self.profile.set_image(pixmap(draw_scan_trace(trace, pixel.status, self.settings.min_gradient)))
        self._place_cursor(self.cursor, pixel.distance_px / self.result.path_length_px)
        station, distance, width, offset, units = pixel, pixel.distance_px, pixel.width_px, pixel.center_offset_px, "px"
        if self.physical_cursor is not None:
            report = self.result.physical_measurements
            plane = report.stations[index]
            self._place_cursor(self.physical_cursor, plane.distance / report.path_length)
            if physical:
                station, distance, width, offset, units = plane, plane.distance, plane.width, plane.center_offset, report.units
        description = station.status.replace("_", " ")
        if width is not None:
            description = f"width {width:.2f} {units} · offset {offset:+.2f} {units}"
            if station.issues:
                description += " · " + ", ".join(issue.replace("_", " ") for issue in station.issues)
        details = f"Station {distance:.2f} {units} · {description}"
        self.setWindowTitle(details)
        self.station_details.setText(details)
        self.review_report = station_report(self.result, index, self.settings)
        self.station_details.setToolTip(self.review_report["explanation"])
        self.station_explanation.setText(self.review_report["explanation"])
        self.measurements.setRowCount(len(self.review_report["metrics"]))
        for row, metric in enumerate(self.review_report["metrics"]):
            low = "—" if metric["minimum"] is None else f"{metric['minimum']:.4g}"
            high = "—" if metric["maximum"] is None else f"{metric['maximum']:.4g}"
            values = (f"{metric['name']} ({metric['units']})",
                      "not measured" if metric["value"] is None else f"{metric['value']:.4g}",
                      f"{low} … {high}", metric["status"])
            for column, value in enumerate(values):
                self.measurements.setItem(row, column, QTableWidgetItem(value))
        self.measurements.resizeColumnsToContents()
        self._filter_changed()

    @staticmethod
    def _place_cursor(cursor, fraction):
        cursor_x = PLOT_LEFT + fraction * (PLOT_RIGHT - PLOT_LEFT)
        cursor.setLine(cursor_x, 38, cursor_x, 265)
        cursor.show()
