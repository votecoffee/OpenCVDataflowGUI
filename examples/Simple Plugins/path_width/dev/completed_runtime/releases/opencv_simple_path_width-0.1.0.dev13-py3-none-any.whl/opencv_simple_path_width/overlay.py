"""Render an inspection overlay from completed measurements."""

import cv2
import numpy as np

from .centerline import PathDraft
from .measurement import PathWidthResult

_PATH = (240, 212, 55)
_PASS = (79, 225, 96)
_FAIL = (64, 65, 245)
_AMBIGUOUS = (35, 180, 253)
_UNOBSERVED = (165, 165, 165)


def _backdrop(image):
    image = np.asarray(image)
    if image.ndim != 2:
        raise ValueError("Expected the grayscale inspection image.")
    preview = image if image.dtype == np.uint8 else cv2.normalize(
        image, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U,
    )
    return cv2.cvtColor(preview, cv2.COLOR_GRAY2BGR)


def _draw_path(overlay, vertices, closed):
    points = np.rint(np.asarray(vertices) * 16).astype(np.int32)
    cv2.polylines(overlay, [points], closed, _PATH, 1, cv2.LINE_AA, shift=4)


def draw_centerline(image: np.ndarray, draft: PathDraft) -> np.ndarray:
    """Draw the proposed centerline, its start, and its direction in BGR."""
    overlay = _backdrop(image)
    _draw_path(overlay, draft.vertices, draft.closed)
    vertices = np.asarray(draft.vertices)
    start = vertices[0]
    delta = vertices[1] - start
    arrow_tip = start + delta * min(1., 16. / np.linalg.norm(delta))
    start_pixel, tip_pixel = np.rint([start, arrow_tip]).astype(np.int32)
    cv2.arrowedLine(overlay, tuple(start_pixel), tuple(tip_pixel), _PASS, 2, cv2.LINE_AA, tipLength=.25)
    cv2.circle(overlay, tuple(start_pixel), 3, _PASS, -1, cv2.LINE_AA)
    if not draft.closed:
        cv2.circle(overlay, tuple(np.rint(vertices[-1]).astype(np.int32)), 3, _FAIL, -1, cv2.LINE_AA)
    return overlay


def draw_overlay(image: np.ndarray, result: PathWidthResult) -> np.ndarray:
    """Draw the path, measured edge pairs, and unavailable stations in BGR."""
    overlay = _backdrop(image)
    _draw_path(overlay, result.path, result.closed)
    physical = result.physical_measurements
    for index, row in enumerate(result.stations):
        if row.edges is not None:
            passed = row.status == "pass" and (physical is None or not physical.stations[index].issues)
            color = _PASS if passed else _FAIL
            a, b = np.rint(np.asarray(row.edges) * 16).astype(np.int32)
            cv2.line(overlay, tuple(a), tuple(b), color, 1, cv2.LINE_AA, shift=4)
            for point in (a, b):
                cv2.circle(overlay, tuple(point), 16, color, -1, cv2.LINE_AA, shift=4)
        else:
            color = {"missing": _FAIL, "ambiguous": _AMBIGUOUS}.get(row.status, _UNOBSERVED)
            cv2.drawMarker(overlay, tuple(round(v) for v in row.point), color, cv2.MARKER_TILTED_CROSS, 5, 1)
    return overlay
