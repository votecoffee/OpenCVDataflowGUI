"""Train, review, and stage a path-width recipe from the DataflowGUI inspector."""

import uuid
from dataclasses import fields, replace
from pathlib import Path

import cv2
import numpy as np
from opencv_dataflow.canvas import pixmap
from opencv_dataflow.payloads import image_with_payload, metadata
from opencv_dataflow.processing import gray_image
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from .cad import load_dxf
from .centerline import extract_centerline
from .cli import _read_gray, _read_json, _read_path
from .dataflow import (
    _read_pinned,
    _recipe_path,
    preview_calibration_for_reference,
    recipe_reference,
    reference_fixture_for_capture,
)
from .geometry import path_vertices
from .measurement import _PHYSICAL_LIMITS, _PHYSICAL_OPTIONS, PathWidthSettings
from .overlay import draw_overlay
from .qt_canvas import MeasurementPreview, PathCanvas
from .recipe import PathWidthRecipe, _affine, fit_alignment, save_recipe
from .trend import draw_physical_trend, draw_trend

_IMAGES = "Images (*.png *.tif *.tiff *.jpg *.jpeg *.bmp);;All files (*)"
_OPTIONAL = {
    "min_width", "max_width", "max_center_offset", "max_gap", "nominal_width", "edge_search_radius",
    *_PHYSICAL_OPTIONS,
}
_FIELD_HELP = {
    "nominal_width": "Optional expected width in pixels. Centers the two edge search bands.",
    "edge_search_radius": "Half-width of each edge search band in pixels. Set with nominal width.",
    "edge_continuity": "Favor edges supported by nearby stations. Set to 0 to select by strength alone.",
    "physical_units": "Units printed by the calibration profile, such as mm. Required with physical spacing, bands, or limits.",
    "station_spacing_physical": "Optional spacing in the profile units. Takes precedence over pixel station spacing.",
    "nominal_width_physical": "Expected width in the profile units. Choose Calibrated plane normal and clear the pixel bands.",
    "edge_search_radius_physical": "Half-width of each edge band in the profile units. Set with nominal width physical.",
}


class PathWidthTrainingDialog(QDialog):
    def __init__(self, parent, parameters, context):
        super().__init__(parent)
        self.setWindowTitle("Train path width")
        self.resize(1140, 720)
        self.parameters, self.context = parameters, context
        self.reference = None
        self.preview_calibration = None
        self.reference_fixture = parameters["reference_fixture"]
        self.alignment = None
        self.cad_units = None
        self.start = self.end = None
        self.canvas = PathCanvas(self)
        self.canvas.changed.connect(self._refresh)
        self.canvas.picked.connect(self._pick_point)
        self.status = QLabel("Open or capture a reference, then create or import a path.")
        self.status.setWordWrap(True)
        self.count = QLabel()
        self.reference_label = QLabel("No reference image")
        self.closed = QCheckBox("Closed path")
        self.closed.toggled.connect(self._set_closed)
        self._build()
        self._perform(self._restore)
        self._refresh()

    def _button(self, title, action):
        button = QPushButton(title)
        button.clicked.connect(lambda: self._perform(action))
        return button

    def _perform(self, action):
        try:
            action()
        except (OSError, KeyError, TypeError, ValueError, cv2.error) as error:
            self.status.setText(str(error))

    def _build(self):
        layout = QVBoxLayout(self)
        files = QHBoxLayout()
        self.capture_fixture_button = self._button("Capture image + fixture", self._capture_fixture)
        if not hasattr(self.context, "snapshot_input_data"):
            self.capture_fixture_button.setEnabled(False)
            self.capture_fixture_button.setToolTip("Update DataflowGUI to capture a wired fixture pose.")
        for button in (
            self._button("Open reference…", self._open_reference),
            self._button("Capture wired image", self._capture_reference),
            self.capture_fixture_button,
            self._button("Import path…", self._open_path),
            self._button("Align path…", self._align),
            self._button("Trace mask…", self._trace_mask),
        ):
            files.addWidget(button)
        layout.addLayout(files)
        row = QHBoxLayout()
        row.addWidget(self.closed)
        for title, action in (
            ("Reverse", self.canvas.reverse), ("Set selected as start", self.canvas.set_start),
            ("Remove point", self.canvas.remove_selected), ("Clear path", self._clear),
            ("Fit", self.canvas.fit_image),
        ):
            row.addWidget(self._button(title, action))
        row.addStretch()
        row.addWidget(self.count)
        layout.addLayout(row)

        hint = QLabel("Click to append · Shift-click to insert · Drag to move · Delete to remove · Scroll to zoom · Alt-drag to pan")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        body = QHBoxLayout()
        body.addWidget(self.canvas, 1)
        sidebar = QWidget()
        form = QFormLayout(sidebar)
        form.addRow(self.reference_label)
        self.fixture_label = QLabel()
        self.fixture_label.setWordWrap(True)
        form.addRow(self.fixture_label)
        self.clear_fixture_button = self._button("Clear reference fixture", self._clear_fixture)
        form.addRow(self.clear_fixture_button)
        self.calibration_label = QLabel("Preview calibration · none")
        self.calibration_label.setWordWrap(True)
        form.addRow(self.calibration_label)
        calibration_controls = QHBoxLayout()
        self.wired_calibration_button = self._button("Use wired", self._use_wired_calibration)
        self.open_calibration_button = self._button("Open profile…", self._open_calibration)
        self.clear_calibration_button = self._button("Clear", self._clear_calibration)
        self.wired_calibration_button.setToolTip(
            "Use the published calibration connected to this block."
            if hasattr(self.context, "snapshot_input_data")
            else "Update DataflowGUI to use a wired calibration."
        )
        self.open_calibration_button.setToolTip("Choose a planar profile for the reference's pixel grid.")
        self.clear_calibration_button.setToolTip("Clear the preview calibration and return to pixel preview.")
        for button in (self.wired_calibration_button, self.open_calibration_button, self.clear_calibration_button):
            calibration_controls.addWidget(button)
        form.addRow(calibration_controls)
        self.pick_mode = QComboBox()
        self.pick_mode.addItems(("Edit path", "Pick trace start", "Pick trace end"))
        self.pick_mode.currentIndexChanged.connect(lambda index: setattr(self.canvas, "pick_seed", index != 0))
        form.addRow("Canvas mode", self.pick_mode)
        self.seed_label = QLabel("Trace points optional")
        self.seed_label.setWordWrap(True)
        form.addRow(self.seed_label)
        form.addRow(self._button("Clear trace points", self._clear_seeds))
        self.polarity = QComboBox()
        self.polarity.addItems(("bright", "dark"))
        form.addRow("Polarity", self.polarity)
        self.scan_mode = QComboBox()
        self.scan_mode.addItem("Image normal", "image_normal")
        self.scan_mode.addItem("Calibrated plane normal", "plane_normal")
        self.scan_mode.setToolTip("Plane-normal scans require a planar calibration. Search distances stay in pixels.")
        form.addRow("Cross-scan direction", self.scan_mode)
        self.fields = {}
        for field in fields(PathWidthSettings):
            if field.name not in ("polarity", "scan_mode"):
                line = QLineEdit("" if field.default is None else str(field.default))
                line.setObjectName(field.name)
                if field.name in _OPTIONAL:
                    line.setPlaceholderText("Optional")
                if field.name in _FIELD_HELP:
                    line.setToolTip(_FIELD_HELP[field.name])
                self.fields[field.name] = line
                form.addRow(field.name.replace("_", " ").capitalize(), line)
        scroll = QScrollArea(widgetResizable=True)
        scroll.setFixedWidth(310)
        scroll.setWidget(sidebar)
        body.addWidget(scroll)
        layout.addLayout(body, 1)
        layout.addWidget(self.status)
        footer = QHBoxLayout()
        self.preview_button = self._button("Preview on reference", self._preview)
        self.stage_button = self._button("Stage recipe", self._stage)
        footer.addWidget(self.preview_button)
        footer.addStretch()
        footer.addWidget(self.stage_button)
        footer.addWidget(self._button("Close", self.reject))
        layout.addLayout(footer)

    def _restore(self):
        relative = self.parameters.get("recipe_path")
        if relative:
            _, recipe, image = _read_pinned(
                self.context.project_dir, relative, self.parameters.get("manifest_sha256"),
                with_reference=True,
            )
            self.use_reference(image, "Saved reference", fixture=self.reference_fixture)
            self._set_path(recipe)
            self.polarity.setCurrentText(recipe.settings.polarity)
            self.scan_mode.setCurrentIndex(self.scan_mode.findData(recipe.settings.scan_mode))
            for name, line in self.fields.items():
                value = getattr(recipe.settings, name)
                line.setText("" if value is None else str(value))
            self.status.setText("Saved reference and path loaded.")

    def _file(self, title, filter):
        filename, _ = QFileDialog.getOpenFileName(self, title, filter=filter)
        return Path(filename) if filename else None

    def use_reference(self, image, label, *, fixture=None):
        if fixture is None and self.reference_fixture:
            raise ValueError("Capture image + fixture together, or clear the reference fixture first.")
        payload = metadata(image)
        image = gray_image(image, (np.uint8, np.uint16))
        if self.reference is not None and self.reference.shape != image.shape:
            self._clear()
        self.reference = np.array(image, copy=True)
        if payload:
            self.reference = image_with_payload(self.reference, payload)
        self._reset_calibration()
        self.reference_fixture = [] if fixture is None else fixture
        self.canvas.set_image(pixmap(self.reference))
        self.reference_label.setText(f"{label} · {image.shape[1]} × {image.shape[0]}")
        self._clear_seeds()
        self._refresh()

    def _open_reference(self):
        path = self._file("Open training reference", _IMAGES)
        if path:
            self.use_reference(_read_gray(path), path.name)
            self.status.setText("Reference loaded. Import a path, trace a mask, or click to draw.")

    def _capture_reference(self):
        self.context.refresh_images()
        packet = self.context.snapshot_input_image("image")
        self.use_reference(packet.value, "Captured wired image")
        self.status.setText("Reference captured from the wired image.")

    def _capture_fixture(self):
        self.context.refresh_images()
        image = self.context.snapshot_input_image("image")
        pose = self.context.snapshot_input_data("pose")
        fixture = reference_fixture_for_capture(image, pose)
        self.use_reference(image.value, "Captured wired image", fixture=fixture)
        self.status.setText("Reference and fixture captured together. Review the path before staging.")

    def _clear_fixture(self):
        self.reference_fixture = []
        self._refresh()
        self.status.setText("Fixture cleared in the draft. Use a reference-to-image transform or disconnect pose.")

    def _set_preview_calibration(self, mapping, payload, label):
        if self.reference is None:
            raise ValueError("Open or capture a reference before selecting its preview calibration.")
        self.preview_calibration = preview_calibration_for_reference(mapping, payload, self.reference)
        self.calibration_label.setText(f"Preview calibration · {label} · {mapping['units'].strip()}")
        self._refresh()
        self.status.setText("Calibration attached for preview. Inspection uses the wired profile.")

    def _use_wired_calibration(self):
        packet = self.context.snapshot_input_data("calibration")
        self._set_preview_calibration(packet.value, packet.payload, "Wired")

    def _open_calibration(self):
        path = self._file("Open planar calibration for preview", "JSON (*.json)")
        if path:
            self._set_preview_calibration(_read_json(path), {}, path.name)

    def _reset_calibration(self):
        self.preview_calibration = None
        self.calibration_label.setText("Preview calibration · none")

    def _clear_calibration(self):
        self._reset_calibration()
        self._refresh()
        self.status.setText("Preview calibration cleared.")

    def _set_path(self, recipe):
        self.alignment, self.cad_units = recipe.source_to_reference, recipe.cad_units
        self.closed.setChecked(recipe.closed)
        self.canvas.set_vertices(recipe.reference_vertices())

    def _open_path(self):
        path = self._file("Import path", "Paths (*.json *.dxf);;All files (*)")
        if not path:
            return
        if path.suffix.lower() == ".dxf":
            layer, accepted = QInputDialog.getText(self, "DXF layer", "Modelspace layer")
            if not accepted:
                return
            cad = load_dxf(path, layer)
            recipe = PathWidthRecipe(cad.vertices, cad.closed, cad_units=cad.units)
        else:
            vertices, closed = _read_path(path)
            recipe = PathWidthRecipe(vertices, closed)
        self._set_path(recipe)
        self.status.setText(f"Imported {path.name}. Align it if the coordinates differ from the reference.")

    def _source_vertices(self):
        points = path_vertices(self.canvas.vertices, self.closed.isChecked())
        if self.alignment is None:
            return points
        matrix = np.asarray(self.alignment)
        return (points - matrix[:, 2]) @ np.linalg.inv(matrix[:, :2]).T

    def _align(self):
        path = self._file("Open affine matrix or landmark pairs", "JSON (*.json)")
        if not path:
            return
        data = _read_json(path)
        residual = ""
        if isinstance(data, dict):
            fit = fit_alignment(data["source"], data["reference"])
            data = fit.matrix
            residual = f" RMS {fit.rms_error_px:.3f} px · max {fit.max_error_px:.3f} px."
        matrix = _affine(data)
        recipe = PathWidthRecipe(self._source_vertices(), self.closed.isChecked(),
                                 source_to_reference=matrix, cad_units=self.cad_units)
        self._set_path(recipe)
        self.status.setText(f"Alignment applied to the draft.{residual} Review the path before staging.")

    def _pick_point(self, x, y):
        if self.pick_mode.currentIndex() == 1:
            self.start = (x, y)
        else:
            self.end = (x, y)
        start = "—" if self.start is None else f"{self.start[0]:.1f}, {self.start[1]:.1f}"
        end = "—" if self.end is None else f"{self.end[0]:.1f}, {self.end[1]:.1f}"
        self.seed_label.setText(f"Start {start} · End {end}")
        self.pick_mode.setCurrentIndex(0)

    def _clear_seeds(self):
        self.start = self.end = None
        self.seed_label.setText("Trace points optional")
        self.pick_mode.setCurrentIndex(0)

    def _trace_mask(self):
        if self.reference is None:
            raise ValueError("Open or capture a reference image first.")
        path = self._file("Trace aligned reference mask", _IMAGES)
        if path:
            mask = _read_gray(path)
            if mask.shape != self.reference.shape:
                raise ValueError("Mask dimensions differ from the reference.")
            draft = extract_centerline(mask, start=self.start, end=self.end)
            self._set_path(PathWidthRecipe(draft.vertices, draft.closed))
            self.status.setText(f"Traced {len(draft.vertices)} vertices. Edit the path or preview its measurements.")

    def _set_closed(self, closed):
        self.canvas.closed = closed
        self.canvas.viewport().update()
        self._refresh()

    def _clear(self):
        self.alignment = self.cad_units = None
        self.closed.setChecked(False)
        self.canvas.set_vertices([])

    def _refresh(self):
        count = len(self.canvas.vertices)
        ready = self.reference is not None and count >= (3 if self.closed.isChecked() else 2)
        self.count.setText(f"{count} vertices")
        self.wired_calibration_button.setEnabled(
            self.reference is not None and hasattr(self.context, "snapshot_input_data")
        )
        self.open_calibration_button.setEnabled(self.reference is not None)
        self.clear_calibration_button.setEnabled(self.preview_calibration is not None)
        self.clear_fixture_button.setEnabled(bool(self.reference_fixture))
        if self.reference_fixture:
            try:
                x, y = _affine(self.reference_fixture)[:, 2]
                self.fixture_label.setText(f"Fixture origin · x {x:.1f}, y {y:.1f}")
            except (TypeError, ValueError):
                self.fixture_label.setText("Invalid reference fixture")
        else:
            self.fixture_label.setText("No reference fixture")
        self.preview_button.setEnabled(ready)
        self.stage_button.setEnabled(ready and self.context.project_dir is not None)
        self.stage_button.setToolTip("" if self.context.project_dir else "Save the DataflowGUI project first.")

    def _recipe(self):
        values = {}
        for name, line in self.fields.items():
            value = line.text().strip()
            if name == "physical_units":
                values[name] = value
            else:
                values[name] = None if not value and name in _OPTIONAL else float(value)
        settings = PathWidthSettings(polarity=self.polarity.currentText(), scan_mode=self.scan_mode.currentData(), **values)
        return PathWidthRecipe(self._source_vertices(), self.closed.isChecked(), settings,
                               self.alignment, self.cad_units)

    def _preview(self):
        recipe = self._recipe()
        prefix = "Reference preview"
        if self.preview_calibration is None and recipe.settings.scan_mode == "plane_normal":
            raise ValueError("Attach a preview calibration to preview plane-normal scans.")
        if self.preview_calibration is None and recipe.settings.station_spacing_physical is not None:
            raise ValueError("Attach a preview calibration to preview physical station spacing.")
        if self.preview_calibration is None and recipe.settings.requires_calibration:
            recipe = replace(recipe, settings=replace(recipe.settings, **dict.fromkeys(_PHYSICAL_LIMITS)))
            prefix = "Pixel preview · Physical limits use wired calibration at inspection"
        result = recipe.measure(self.reference, calibration=self.preview_calibration)
        physical = result.physical_measurements
        gap, units = result.longest_gap_px, "px"
        if physical is not None:
            prefix = "Calibrated preview · Pass" if result.passed else "Calibrated preview · Fail"
            gap, units = physical.longest_gap, physical.units
        self.status.setText(f"{prefix} · {result.coverage:.0%} measured · {gap:.2f} {units} longest gap")
        dialog = MeasurementPreview(
            self, draw_overlay(self.reference, result), draw_trend(result, recipe.settings), result,
            reference=self.reference, settings=recipe.settings, calibration=self.preview_calibration,
            physical_trend=None if physical is None else draw_physical_trend(physical, recipe.settings),
        )
        dialog.exec()

    def _stage(self):
        if self.reference_fixture:
            _affine(self.reference_fixture)
        recipe = self._recipe()
        relative = f"assets/path_width/{uuid.uuid4().hex}.spw"
        target = _recipe_path(self.context.project_dir, relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        try:
            save_recipe(target, recipe, self.reference)
            pinned = recipe_reference(self.context.project_dir, relative)
        except (OSError, TypeError, ValueError, cv2.error):
            target.unlink(missing_ok=True)
            raise
        self.parameters.update(pinned, reference_fixture=self.reference_fixture)
        self.accept()
