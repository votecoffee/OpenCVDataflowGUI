"""Arc-length stations and directions on open and closed image paths."""

import math

import numpy as np

MAX_STATIONS = 8192
MAX_VERTICES = 4096


def path_vertices(vertices, closed):
    path = np.asarray(vertices, dtype=np.float64)
    minimum = 3 if closed else 2
    if (path.ndim != 2 or path.shape[1] != 2 or not minimum <= len(path) <= MAX_VERTICES
            or not np.isfinite(path).all() or np.max(np.abs(path)) > 1e6):
        raise ValueError(f"Path requires {minimum} to {MAX_VERTICES} finite [x, y] vertices.")
    path = path[np.r_[True, np.any(np.diff(path, axis=0) != 0, axis=1)]]
    if closed and len(path) > 1 and np.array_equal(path[0], path[-1]):
        path = path[:-1]
    if len(np.unique(path, axis=0)) < minimum:
        raise ValueError(f"Path requires at least {minimum} distinct vertices.")

    return path


def _station_count(length, spacing):
    intervals = length / spacing
    if not math.isfinite(intervals):
        raise ValueError(f"Path exceeds {MAX_STATIONS} stations. Increase station spacing.")
    nearest = round(intervals)
    # Rotation can move an exact integer ratio a few floating-point units above it.
    count = max(1, nearest if math.isclose(intervals, nearest, rel_tol=1e-12) else math.ceil(intervals))
    if count > MAX_STATIONS:
        raise ValueError(f"Path exceeds {MAX_STATIONS} stations. Increase station spacing.")
    return count


def path_stations(vertices, closed, spacing, corner_angle, corner_margin, *, grid=None):
    path = path_vertices(vertices, closed)
    chain = np.vstack((path, path[0])) if closed else path
    deltas = np.diff(chain, axis=0)
    lengths = np.linalg.norm(deltas, axis=1)
    if np.any(lengths < 1e-8):
        raise ValueError("Adjacent path vertices must differ by at least 1e-8 pixels.")
    arc = np.r_[0., np.cumsum(lengths)]
    length = float(arc[-1])
    if grid is None:
        count = _station_count(length, spacing)
        step = length / count
        distances = (np.arange(count) + 0.5) * step
    else:
        distances, boundaries = grid
        count = len(distances)
        step = length / count
    segments = np.searchsorted(arc[1:], distances, side="right")
    fraction = ((distances - arc[segments]) / lengths[segments])[:, None]
    positions = chain[segments] + fraction * deltas[segments]

    unit = deltas / lengths[:, None]
    incoming = np.roll(unit, 1, axis=0) if closed else np.vstack((unit[0], unit))
    outgoing = unit if closed else np.vstack((unit, unit[-1]))
    bisector = incoming + outgoing
    magnitude = np.linalg.norm(bisector, axis=1)
    sharp = ((np.sum(incoming * outgoing, axis=1) <= math.cos(math.radians(corner_angle)))
             | (magnitude < 1e-12))
    bisector /= np.where(sharp, 1., magnitude)[:, None]
    end_segments = (segments + 1) % len(path)
    start = np.where(sharp[segments, None], unit[segments], bisector[segments])
    end = np.where(sharp[end_segments, None], unit[segments], bisector[end_segments])
    tangent = (1 - fraction) * start + fraction * end
    tangent /= np.linalg.norm(tangent, axis=1)[:, None]
    normals = np.column_stack((-tangent[:, 1], tangent[:, 0]))

    corners = np.zeros(count, dtype=bool)
    sharp_distances = arc[:len(path)][sharp]
    if len(sharp_distances):
        if closed:
            sharp_distances = np.r_[sharp_distances[-1] - length, sharp_distances, sharp_distances[0] + length]
        indices = np.searchsorted(sharp_distances, distances)
        before = sharp_distances[np.maximum(indices - 1, 0)]
        after = sharp_distances[np.minimum(indices, len(sharp_distances) - 1)]
        nearest = np.minimum(np.abs(distances - before), np.abs(after - distances))
        if grid is None:
            corners = nearest <= max(corner_margin, step / 2)
        else:
            corners = (
                (nearest <= corner_margin)
                | ((before <= distances) & (before >= boundaries[:-1]))
                | ((after >= distances) & (after <= boundaries[1:]))
            )
    return path, length, step, distances, positions, normals, corners
