"""Display measurement trends with tolerance guides and breaks at missing scans."""

import cv2
import numpy as np

_AXIS = (150, 161, 175)
_TRACE = (100, 224, 133)
_LIMIT = (80, 106, 228)
_FONT = cv2.FONT_HERSHEY_SIMPLEX
PLOT_LEFT, PLOT_RIGHT = 80, 605


def _panel(canvas, x, values, limits, top, title, *, label_limits=True):
    left, right, bottom = PLOT_LEFT, PLOT_RIGHT, top + 98
    cv2.putText(canvas, title, (left, top - 10), _FONT, .47, _AXIS, 1, cv2.LINE_AA)
    cv2.line(canvas, (left, top), (left, bottom), _AXIS)
    cv2.line(canvas, (left, bottom), (right, bottom), _AXIS)
    valid = np.flatnonzero(np.isfinite(values))
    if not len(valid):
        cv2.putText(canvas, "No measured stations", (left + 12, top + 24), _FONT, .44, _AXIS, 1, cv2.LINE_AA)
        return
    scale = max(1., np.max(np.abs(values[valid])), *(abs(limit) for limit in limits))
    data = np.r_[values[valid] / scale, np.asarray(limits) / scale]
    low, high = data.min(), data.max()
    pad = max(.02, (high - low) * .08)
    low, high = low - pad, high + pad
    if not limits or not label_limits:
        cv2.putText(canvas, f"{high * scale:.3g}", (8, top + 3), _FONT, .37, _AXIS, 1, cv2.LINE_AA)
        cv2.putText(canvas, f"{low * scale:.3g}", (8, bottom + 3), _FONT, .37, _AXIS, 1, cv2.LINE_AA)

    def y_for(value):
        return np.rint(bottom - (value / scale - low) * (bottom - top) / (high - low)).astype(int)

    for limit in limits:
        y = int(y_for(limit))
        cv2.line(canvas, (left, y), (right, y), _LIMIT, 1, cv2.LINE_AA)
        if label_limits:
            cv2.putText(canvas, f"{limit:.3g}", (8, y + 3), _FONT, .37, _LIMIT, 1, cv2.LINE_AA)
    observed = np.column_stack((x[valid], y_for(values[valid]))).astype(np.int32)
    for run in np.split(observed, np.flatnonzero(np.diff(valid) != 1) + 1):
        if len(run) == 1:
            cv2.circle(canvas, tuple(run[0]), 2, _TRACE, -1, cv2.LINE_AA)
        else:
            cv2.polylines(canvas, [run], False, _TRACE, 1, cv2.LINE_AA)


def _draw(distances, path_length, widths, offsets, units, width_limits=(), offset_limits=()):
    chart = np.full((292, 630, 3), (27, 23, 20), np.uint8)
    x = np.rint(PLOT_LEFT + np.asarray(distances) / path_length * (PLOT_RIGHT - PLOT_LEFT)).astype(int)
    _panel(chart, x, np.asarray(widths, dtype=float), width_limits, 38, f"Width ({units})")
    _panel(chart, x, np.asarray(offsets, dtype=float), offset_limits, 167, f"Signed center offset ({units})")
    cv2.putText(chart, "0", (79, 283), _FONT, .4, _AXIS, 1, cv2.LINE_AA)
    caption = f"{path_length:.4g} {units}"
    text_width = cv2.getTextSize(caption, _FONT, .4, 1)[0][0]
    cv2.putText(chart, caption, (max(PLOT_LEFT + 20, PLOT_RIGHT - text_width), 283), _FONT, .4, _AXIS, 1, cv2.LINE_AA)
    return chart


def _guides(min_width, max_width, offset_limit):
    return (
        [limit for limit in (min_width, max_width) if limit is not None],
        [] if offset_limit is None else [-offset_limit, offset_limit],
    )


def draw_scan_trace(trace, status, min_gradient):
    """Return the selected station's filtered profile and detector gradient."""
    chart = np.full((292, 630, 3), (27, 23, 20), np.uint8)
    if trace.intensity is None:
        messages = {
            "corner": "Scan skipped at a sharp path corner.",
            "masked": "Scan crosses excluded pixels.",
            "clipped": "Scan exceeds the image or its search windows exceed the span.",
        }
        cv2.putText(chart, messages[status], (PLOT_LEFT, 146), _FONT, .47, _AXIS, 1, cv2.LINE_AA)
        return chart
    half = trace.offsets[-1]

    def x_for(offset):
        return np.rint(PLOT_LEFT + (offset / half + 1) * (PLOT_RIGHT - PLOT_LEFT) / 2).astype(int)

    if trace.bands is not None:
        for start, end in x_for(trace.bands):
            for top in (38, 167):
                cv2.rectangle(chart, (int(start), top), (int(end), top + 98), (54, 43, 34), -1)
    _panel(chart, x_for(trace.offsets), trace.intensity, (), 38, "Filtered intensity")
    gradients_at = (trace.offsets[:-1] + trace.offsets[1:]) / 2
    thresholds = (-min_gradient, min_gradient) if min_gradient else (0.,)
    caption = f"Polarity-adjusted gradient (intensity / px)   |   Threshold +/-{min_gradient:.3g}"
    _panel(chart, x_for(gradients_at), trace.gradient, thresholds, 167, caption, label_limits=False)
    if trace.edges is not None:
        for x in x_for(trace.edges):
            for top in (38, 167):
                cv2.line(chart, (int(x), top), (int(x), top + 98), (245, 219, 59), 1, cv2.LINE_AA)
    for x, caption in ((PLOT_LEFT, f"-{half:g} px"), (int(x_for(0)), "0"), (PLOT_RIGHT - 42, f"+{half:g} px")):
        cv2.putText(chart, caption, (x, 283), _FONT, .4, _AXIS, 1, cv2.LINE_AA)
    return chart


def draw_trend(result, settings):
    """Return pixel width and signed offset plots with configured limits."""
    return _draw(
        [station.distance_px for station in result.stations], result.path_length_px,
        [station.width_px for station in result.stations], [station.center_offset_px for station in result.stations],
        "px", *_guides(settings.min_width, settings.max_width, settings.max_center_offset),
    )


def draw_physical_trend(result, settings=None):
    """Plot calibrated width and signed offset along the path on its plane."""
    limits = ((), ()) if settings is None else _guides(
        settings.min_width_physical, settings.max_width_physical, settings.max_center_offset_physical,
    )
    return _draw(
        [station.distance for station in result.stations], result.path_length,
        [station.width for station in result.stations], [station.center_offset for station in result.stations],
        result.units, *limits,
    )
