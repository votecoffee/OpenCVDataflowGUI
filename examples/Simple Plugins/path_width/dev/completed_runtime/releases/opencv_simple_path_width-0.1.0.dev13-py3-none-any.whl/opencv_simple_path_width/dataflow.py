"""Qt-free SimplePathWidth inspection block for an installed DataflowGUI host."""

import hashlib
import re
import uuid
from dataclasses import asdict
from pathlib import Path, PurePosixPath
from zipfile import BadZipFile, ZipFile

import numpy as np
from opencv_dataflow.core import Block, Port, Result
from opencv_dataflow.payloads import NO_VALUE, check_spatial, frame, metadata
from opencv_dataflow.poses import pose_for_image
from opencv_dataflow.processing import gray_image
from opencv_dataflow.selection import SELECTION_INPUTS, selection_mask
from opencv_dataflow.tickets import ticket_key

from .calibration import _profile
from .completed_review import BINDING, CompletedPathRecord, capture_completed
from .overlay import draw_overlay
from .recipe import _affine, _decode_manifest, _manifest_bytes, _read_reference
from .trend import draw_physical_trend, draw_trend


def _recipe_path(project_dir, relative):
    if project_dir is None:
        raise ValueError("Save the project before selecting a path width recipe.")
    if not isinstance(relative, str) or not relative:
        raise ValueError("Choose a project-relative path width recipe.")
    portable = PurePosixPath(relative)
    if portable.is_absolute() or "\\" in relative or ":" in relative or ".." in portable.parts or portable.suffix.lower() != ".spw":
        raise ValueError("Recipe must be a project-relative .spw path using forward slashes.")
    root = Path(project_dir).resolve()
    target = (root / relative).resolve()
    if not target.is_relative_to(root):
        raise ValueError("Recipe path resolves outside the project directory.")
    return target


def _read_pinned(project_dir, relative, pin=None, *, cached=None, with_reference=False, with_manifest=False):
    try:
        with ZipFile(_recipe_path(project_dir, relative)) as archive:
            raw = _manifest_bytes(archive)
            digest = hashlib.sha256(raw).hexdigest()
            if pin is not None and digest != pin.lower():
                raise ValueError("Recipe manifest SHA-256 mismatch. Stage the intended recipe again.")
            recipe = cached[1] if cached and cached[0] == digest else _decode_manifest(raw)
            reference = _read_reference(archive, recipe) if with_reference else None
    except (BadZipFile, KeyError, TypeError, RuntimeError) as error:
        raise ValueError(f"Invalid path width recipe: {error}") from error
    values = digest, recipe, reference
    return (*values, raw) if with_manifest else values


def recipe_reference(project_dir, relative):
    digest, _, _ = _read_pinned(project_dir, relative)
    return {"recipe_path": relative, "manifest_sha256": digest}


def _reference_to_image(pose, image, reference_fixture):
    if pose is None:
        if reference_fixture:
            raise ValueError("A reference fixture matrix requires a current image pose.")
        return None
    if not isinstance(pose, dict) or pose.get("model") not in ("image_affine_v1", "image_pose_v1"):
        raise ValueError("Connect an affine reference transform or a valid image pose.")
    if pose["model"] == "image_pose_v1":
        matrix = np.asarray(pose_for_image(pose, image)["source_to_target"])
    else:
        if reference_fixture:
            raise ValueError("A reference fixture matrix requires an image pose input.")
        matrix = np.asarray(pose.get("source_to_target"), dtype=float)
    if matrix.shape == (3, 3) and np.allclose(matrix[2], [0, 0, 1], rtol=0, atol=1e-10):
        matrix = matrix[:2]
    matrix = _affine(matrix)
    if reference_fixture:
        local = np.vstack((_affine(reference_fixture), [0, 0, 1]))
        matrix = matrix @ np.linalg.inv(local)
    return matrix


def _acquisition_id(ticket):
    return (*ticket_key(ticket), ticket["sequence"])


def reference_fixture_for_capture(image_packet, pose_packet):
    """Resolve a fixture pose into the pixels of the same captured frame."""
    pose = pose_packet.value
    if not isinstance(pose, dict) or pose.get("model") != "image_pose_v1":
        raise ValueError("Capture requires a valid image pose on the pose input.")
    matrix = _reference_to_image(pose, image_packet.value, [])
    image_payload = image_packet.payload
    pose_payload = pose.get("target_payload", {})
    if not all(payload.get("spatial", {}).get("root_id") for payload in (image_payload, pose_payload)):
        raise ValueError("The image and fixture pose must have a shared coordinate root.")
    image_ticket = image_payload.get("ticket")
    pose_ticket = pose_payload.get("ticket")
    if image_ticket is None or pose_ticket is None:
        raise ValueError("Capture needs acquisition tickets on the image and the fixture pose.")
    # Ticket keys can intentionally repeat. The sequence distinguishes those acquisitions.
    image_id = _acquisition_id(image_ticket)
    for ticket in (pose_ticket, pose_packet.payload.get("ticket", pose_ticket)):
        if _acquisition_id(ticket) != image_id:
            raise ValueError("Image and fixture pose belong to different acquisitions. Run the graph again.")
    return matrix.tolist()


def _calibration_for_image(mapping, payload, image):
    calibrated_frame = payload.get("spatial", {})
    root = calibrated_frame.get("root_id")
    if root is None:
        return mapping
    matrix, size, _, _ = _profile(mapping)
    check_spatial(payload, size)
    image_frame = metadata(image).get("spatial", {})
    if image_frame.get("root_id") != root or image_frame["root_size"] != calibrated_frame["root_size"]:
        raise ValueError("Calibration and image have different coordinate roots. For a saved setup, load its profile.")
    to_calibrated = np.linalg.solve(calibrated_frame["to_root"], image_frame["to_root"])
    return {
        **mapping, "pixel_to_physical": (matrix @ to_calibrated).tolist(),
        "image_size": list(image.shape[1::-1]),
    }


def preview_calibration_for_reference(mapping, payload, reference):
    """Resolve a preview mapping against the exact reference currently in the trainer."""
    if payload.get("spatial", {}).get("root_id") is not None:
        context = metadata(reference)
        if not context.get("spatial", {}).get("root_id"):
            raise ValueError("Capture the wired reference image before using a frame-bound calibration.")
        mapping = _calibration_for_image(mapping, payload, reference)
        reference_ticket, calibration_ticket = context.get("ticket"), payload.get("ticket")
        if (reference_ticket is None or calibration_ticket is None
                or _acquisition_id(reference_ticket) != _acquisition_id(calibration_ticket)):
            raise ValueError("Reference and calibration need the same acquisition. Capture the matching reference.")
    _, size, _, _ = _profile(mapping)
    if reference.shape[1::-1] != size:
        raise ValueError("Calibration image size differs from the preview reference.")
    return mapping


class SimplePathWidth(Block):
    type_id, title = "inspect.simple_path_width", "SimplePathWidth"
    category, block_type, subtype = "Inspection", "Inspection", "Measurements"
    process_inputs_readonly = True
    parallel_safe = True
    composes_result_image = True
    plugin_dialog_label = "Train path width…"
    plugin_dialog_modeless = True
    plugin_review_dialog_label = "Review completed path width…"
    inputs = (
        *SELECTION_INPUTS, Port("pose", "data", required=False, required_when_connected=True),
        Port("calibration", "data", required=False, required_when_connected=True),
    )
    outputs = (
        Port("measurements", "data"), Port("mean_width", "number", required=False),
        Port("coverage", "number"), Port("longest_gap", "number"),
        Port("overlay", required=False), Port("trend", required=False),
        Port("physical_measurements", "data", required=False),
        Port("mean_width_physical", "number", required=False),
        Port("longest_gap_physical", "number", required=False),
        Port("physical_trend", required=False),
    )
    defaults = {
        "recipe_path": "", "manifest_sha256": "", "reference_fixture": [],
        "render_overlay": True, "render_trend": True,
    }
    parameter_help = {
        "recipe_path": "Project-relative .spw recipe staged by the trainer.",
        "manifest_sha256": "SHA-256 of the measurement manifest inside the recipe.",
        "reference_fixture": "Fixture-to-reference matrix. Capture it with the reference image in the trainer.",
        "render_overlay": "Draw paired edges on the inspection image and show it in the filmstrip.",
        "render_trend": "Render pixel trends and a physical trend when a planar calibration is wired.",
    }
    input_help = {
        "pose": "Reference-to-image affine transform. With Reference fixture, supply the current image pose.",
        "calibration": "Planar calibration mapping or profile for the current inspection image grid.",
    }
    _verified = None
    _completed_review = None

    def copy_runtime_from(self, other):
        super().copy_runtime_from(other)
        self._completed_review = other._completed_review

    def reset_runtime(self):
        super().reset_runtime()
        self._completed_review = None

    def close(self):
        self._completed_review = None
        self._verified = None
        super().close()

    def capture_completed_review(self, context):
        snapshot = getattr(context, "snapshot_processed_execution", None)
        if snapshot is None:
            raise ValueError("Completed review needs the host's paired execution-snapshot API")
        return capture_completed(self._completed_review, snapshot(output_ports=("measurements",)))

    def create_plugin_review_dialog(self, parent, context):
        from .qt_completed_review import CompletedPathReviewDialog

        return CompletedPathReviewDialog(parent, context, lambda: self.capture_completed_review(context))

    @property
    def filmstrip_output(self):
        return "overlay" if self.parameters["render_overlay"] else None

    def validate_parameters(self, parameters=None):
        super().validate_parameters(parameters)
        p = self.parameters if parameters is None else parameters
        _recipe_path(self.project_dir, p["recipe_path"])
        if not isinstance(p["manifest_sha256"], str) or re.fullmatch(r"[0-9a-fA-F]{64}", p["manifest_sha256"]) is None:
            raise ValueError("Stage a recipe with a valid manifest SHA-256.")
        if p["reference_fixture"]:
            _affine(p["reference_fixture"])
        if any(type(p[name]) is not bool for name in ("render_overlay", "render_trend")):
            raise ValueError("Rendering options must be boolean.")

    def process(self, inputs):
        self._completed_review = None
        p = self.parameters
        digest, recipe, _, manifest = _read_pinned(
            self.project_dir, p["recipe_path"], p["manifest_sha256"], cached=self._verified,
            with_manifest=True,
        )
        self._verified = digest, recipe
        source = inputs["image"]
        image = gray_image(source, (np.uint8, np.uint16, np.float32))
        pose = _reference_to_image(inputs.get("pose"), source, p["reference_fixture"])
        mapping = None
        if "calibration" in inputs:
            if not isinstance(inputs["calibration"], dict):
                raise ValueError("Expected a planar_homography_v1 calibration profile.")
            mapping = _calibration_for_image(inputs["calibration"], self.input_payloads.get("calibration", {}), source)
        result = recipe.measure(
            image, mask=selection_mask(inputs, source), reference_to_image=pose, calibration=mapping,
        )
        physical = result.physical_measurements
        overlay = draw_overlay(image, result) if p["render_overlay"] else NO_VALUE
        trend = draw_trend(result, recipe.settings) if p["render_trend"] else NO_VALUE
        physical_trend = (
            draw_physical_trend(physical, recipe.settings)
            if physical is not None and p["render_trend"] else NO_VALUE
        )
        measurements = asdict(result)
        physical_data = measurements.pop("physical_measurements")
        contexts = {}
        for name, chart in (("trend", trend), ("physical_trend", physical_trend)):
            if chart is not NO_VALUE:
                contexts[name] = {"spatial": frame(list(chart.shape[1::-1]), f"{self.id}:{name}")}
        gap, units = (result.longest_gap_px, "px") if physical is None else (physical.longest_gap, physical.units)
        if self.run_profile.input_previews and self.run_profile.output_previews:
            record = CompletedPathRecord.create(
                uuid.uuid4().hex, manifest, recipe, result, mapping, pose, p["reference_fixture"],
            )
            self._completed_review = record
            contexts["measurements"] = {BINDING: {"id": record.identifier, "manifest_sha256": digest}}
        return Result(
            {
                "measurements": {"model": "simple_path_width_v1", **measurements},
                "mean_width": NO_VALUE if result.mean_width_px is None else result.mean_width_px,
                "coverage": result.coverage, "longest_gap": result.longest_gap_px,
                "overlay": overlay, "trend": trend,
                "physical_measurements": NO_VALUE if physical is None else {
                    "model": "simple_path_width_physical_v1", **physical_data,
                },
                "mean_width_physical": (
                    NO_VALUE if physical is None or physical.mean_width is None else physical.mean_width
                ),
                "longest_gap_physical": NO_VALUE if physical is None else physical.longest_gap,
                "physical_trend": physical_trend,
            },
            payloads=contexts, passed=result.passed, score=result.coverage,
            fail_reasons=list(result.failures),
            event_data={"filmstrip_priority": -1} if p["render_overlay"] else {},
            message=f"{result.coverage:.0%} measured · longest gap {gap:.2f} {units}",
        )

    def create_plugin_dialog(self, parent, parameters, context):
        from .qt_training import PathWidthTrainingDialog

        return PathWidthTrainingDialog(parent, parameters, context)


def register(registry):
    registry.register(SimplePathWidth)
