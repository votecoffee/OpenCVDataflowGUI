"""Assess completed stations without repeating path measurement or edge pairing."""

import hashlib
import json
import textwrap
from dataclasses import asdict
from numbers import Integral
from pathlib import Path

import cv2
import numpy as np

from .measurement import _trace_station
from .overlay import draw_overlay
from .trend import (
    PLOT_LEFT,
    PLOT_RIGHT,
    draw_physical_trend,
    draw_scan_trace,
    draw_trend,
)

UNOBSERVED = ("corner", "masked", "clipped")


def station_group(result, index):
    row = result.stations[index]
    if row.status in UNOBSERVED:
        return "unobserved"
    if row.status in ("missing", "ambiguous"):
        return row.status
    physical = result.physical_measurements
    if row.issues or (physical is not None and physical.stations[index].issues):
        return "out_of_tolerance"
    return "measured"


def station_indices(result, group="problems"):
    if group not in (
        "problems",
        "out_of_tolerance",
        "missing",
        "ambiguous",
        "unobserved",
        "all",
    ):
        raise ValueError("Unknown station review filter.")
    return [
        i
        for i in range(len(result.stations))
        if group == "all"
        or (
            station_group(result, i) != "measured"
            if group == "problems"
            else station_group(result, i) == group
        )
    ]


def nearest_station(result, point):
    point = np.asarray(point, float)
    if point.shape != (2,) or not np.isfinite(point).all() or not result.stations:
        raise ValueError("Select a finite image point on a result with stations.")
    return int(
        np.argmin(
            np.sum(
                (np.asarray([row.point for row in result.stations]) - point) ** 2,
                axis=1,
            )
        )
    )


def station_report(result, index, settings):
    if (
        isinstance(index, bool)
        or not isinstance(index, Integral)
        or not 0 <= index < len(result.stations)
    ):
        raise ValueError("Select a valid zero-based station index.")
    row = result.stations[index]
    group = station_group(result, index)
    physical = result.physical_measurements
    notes = {
        "measured": "Two edges measured; station limits are satisfied.",
        "out_of_tolerance": "Edges measured, but one or more pixel/physical station limits failed.",
        "missing": "Observed scan without an accepted opposing edge pair; "
        "counted toward missing-edge gaps.",
        "ambiguous": "Observed scan with unresolved competing edge pairs; no width is reported.",
        "unobserved": {
            "corner": "Scan skipped at a sharp path corner.",
            "masked": "Scan crosses excluded pixels; no profile or width is reported.",
            "clipped": "Scan or edge search bands extend beyond available image support.",
        }.get(row.status, "Scan unavailable."),
    }
    metrics = []

    def metric(name, value, units, minimum=None, maximum=None):
        status = "not measured" if value is None else "diagnostic"
        if value is not None and (minimum is not None or maximum is not None):
            status = (
                "outside limits"
                if (
                    (minimum is not None and value < minimum)
                    or (maximum is not None and value > maximum)
                )
                else "within limits"
            )
        metrics.append(
            dict(
                name=name,
                value=value,
                units=units,
                minimum=minimum,
                maximum=maximum,
                status=status,
            )
        )

    metric("Width", row.width_px, "px", settings.min_width, settings.max_width)
    maximum = settings.max_center_offset
    metric(
        "Signed offset",
        row.center_offset_px,
        "px",
        None if maximum is None else -maximum,
        maximum,
    )
    if physical is not None:
        plane = physical.stations[index]
        metric(
            "Width",
            plane.width,
            physical.units,
            settings.min_width_physical,
            settings.max_width_physical,
        )
        maximum = settings.max_center_offset_physical
        metric(
            "Signed offset",
            plane.center_offset,
            physical.units,
            None if maximum is None else -maximum,
            maximum,
        )
    for side in range(2):
        metric(
            f"Edge {side + 1} strength",
            None if row.edge_strengths is None else row.edge_strengths[side],
            "native intensity/px",
            settings.min_gradient,
        )
    return {
        "model": "simple_path_width_station_review_v1",
        "station_number": index + 1,
        "station_count": len(result.stations),
        "group": group,
        "explanation": notes[group],
        "pixel_station": asdict(row),
        "physical_station": None
        if physical is None
        else {"units": physical.units, **asdict(physical.stations[index])},
        "metrics": metrics,
        "path_passed": result.passed,
        "path_failures": list(result.failures),
        "coverage": result.coverage,
        "minimum_coverage": settings.min_coverage,
        "observed_fraction": result.observed_fraction,
        "longest_gap_px": result.longest_gap_px,
        "maximum_gap_px": settings.max_gap,
        "physical_gap": None
        if physical is None
        else {
            "length": physical.longest_gap,
            "maximum": settings.max_gap_physical,
            "units": physical.units,
        },
    }


def review_trace(image, result, index, settings, calibration=None):
    station_report(result, index, settings)
    return _trace_station(
        np.asarray(image).astype(np.float32, copy=False),
        result.stations[index],
        settings,
        calibration,
    )


def selected_overlay(image, result, index, trace):
    output = draw_overlay(image, result)
    ends = np.rint(trace.endpoints * 16).astype(np.int32)
    cv2.line(
        output, tuple(ends[0]), tuple(ends[1]), (245, 219, 59), 2, cv2.LINE_AA, shift=4
    )
    point = tuple(round(v) for v in result.stations[index].point)
    cv2.drawMarker(output, point, (245, 219, 59), cv2.MARKER_CROSS, 13, 2, cv2.LINE_AA)
    if result.stations[index].edges is not None:
        for edge in result.stations[index].edges:
            cv2.circle(
                output, tuple(round(v) for v in edge), 4, (245, 219, 59), 1, cv2.LINE_AA
            )
    return output


def station_bounds(image, result, index, trace):
    points = np.vstack((trace.endpoints, [result.stations[index].point]))
    center = (points.min(axis=0) + points.max(axis=0)) / 2
    # Include neighboring image context even for a nearly vertical/horizontal
    # scan, rather than exporting a thin strip with no recognizable surface.
    side = max(96, 0.75 * np.linalg.norm(trace.endpoints[1] - trace.endpoints[0]))
    half = np.maximum((points.max(axis=0) - points.min(axis=0)) / 2 + 22, side / 2)
    low = np.maximum(0, np.floor(center - half).astype(int))
    high = np.minimum(image.shape[1::-1], np.ceil(center + half + 1).astype(int))
    if np.any(high <= low):
        return 0, 0, image.shape[1], image.shape[0]
    return int(low[0]), int(low[1]), int(high[0] - low[0]), int(high[1] - low[1])


def selected_trend(result, settings, index, *, physical=False):
    plane = result.physical_measurements
    if physical and plane is None:
        raise ValueError("No calibrated measurements are available.")
    output = (
        draw_physical_trend(plane, settings)
        if physical
        else draw_trend(result, settings)
    )
    fraction = (
        plane.stations[index].distance / plane.path_length
        if physical
        else result.stations[index].distance_px / result.path_length_px
    )
    x = round(PLOT_LEFT + fraction * (PLOT_RIGHT - PLOT_LEFT))
    cv2.line(output, (x, 38), (x, 265), (245, 219, 59), 1, cv2.LINE_AA)
    return output


def _text(image, text, point, *, scale=0.5, width=600):
    text = (
        str(text)
        .replace("µ", "u")
        .encode("ascii", errors="replace")
        .decode("ascii")[:240]
    )
    while (
        text and cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, scale, 1)[0][0] > width
    ):
        text = text[:-4] + "..." if len(text) > 4 else ""
    cv2.putText(
        image,
        text,
        point,
        cv2.FONT_HERSHEY_SIMPLEX,
        scale,
        (230, 235, 240),
        1,
        cv2.LINE_AA,
    )


def draw_assessment(image, result, index, settings, *, calibration=None, trace=None):
    report = station_report(result, index, settings)
    trace = (
        review_trace(image, result, index, settings, calibration)
        if trace is None
        else trace
    )
    output = np.full((960, 1280, 3), (30, 25, 20), np.uint8)
    _text(
        output,
        f"Station {index + 1}/{len(result.stations)} | {report['group'].replace('_', ' ')}",
        (16, 30),
        scale=0.7,
        width=1240,
    )
    overlay = selected_overlay(image, result, index, trace)
    x, y, w, h = station_bounds(image, result, index, trace)
    scale = min(600 / w, 480 / h)
    crop = cv2.resize(
        overlay[y : y + h, x : x + w],
        (max(1, round(w * scale)), max(1, round(h * scale))),
        interpolation=cv2.INTER_NEAREST,
    )
    top, left = 65 + (480 - crop.shape[0]) // 2, 10 + (600 - crop.shape[1]) // 2
    output[top : top + crop.shape[0], left : left + crop.shape[1]] = crop
    _text(
        output, f"Input crop {x}, {y}, {w}, {h}; display resized", (10, 572), scale=0.46
    )
    _text(
        output,
        "Cyan: selected scan/edges | Green pass | Red violation/missing",
        (10, 598),
        scale=0.44,
    )
    _text(output, "Amber ambiguous | Gray unobserved", (10, 621), scale=0.44)
    for row, line in enumerate(textwrap.wrap(report["explanation"], width=74)):
        _text(output, line, (650, 68 + row * 20), scale=0.46)
    _text(
        output,
        f"Image station: ({result.stations[index].point[0]:.3g}, "
        f"{result.stations[index].point[1]:.3g}) px",
        (650, 114),
    )
    for row, metric in enumerate(report["metrics"]):
        value = (
            "not measured"
            if metric["value"] is None
            else f"{metric['value']:.4g} {metric['units']}"
        )
        low = "-" if metric["minimum"] is None else f"{metric['minimum']:.4g}"
        high = "-" if metric["maximum"] is None else f"{metric['maximum']:.4g}"
        _text(output, f"{metric['name']}: {value}", (650, 145 + row * 44))
        _text(
            output,
            f"Limits [{low}, {high}] | {metric['status']}",
            (650, 164 + row * 44),
            scale=0.43,
        )
    _text(
        output,
        f"Path {'PASS' if result.passed else 'FAIL'} | measured {result.coverage:.1%} / "
        f"min {settings.min_coverage:.1%}",
        (650, 465),
    )
    _text(
        output,
        f"Observed {result.observed_fraction:.1%} | "
        f"longest missing-edge gap {result.longest_gap_px:.3g} px",
        (650, 492),
        scale=0.46,
    )
    _text(
        output,
        "Path limits/verdict include stations beyond this selected crop.",
        (650, 520),
        scale=0.44,
    )
    _text(
        output,
        ", ".join(result.failures) or "No path failure reasons.",
        (650, 546),
        scale=0.44,
    )
    maximum_gap = "unset" if settings.max_gap is None else f"{settings.max_gap:g} px"
    _text(
        output,
        f"Missing-edge gap limit: {maximum_gap}",
        (650, 575),
        scale=0.46,
    )
    if report["physical_gap"] is not None:
        gap = report["physical_gap"]
        maximum = "unset" if gap["maximum"] is None else f"{gap['maximum']:g}"
        _text(
            output,
            f"Physical gap: {gap['length']:.3g} {gap['units']} | max {maximum}",
            (650, 600),
            scale=0.46,
        )
    output[648:940, 10:640] = draw_scan_trace(
        trace, result.stations[index].status, settings.min_gradient
    )
    output[648:940, 650:1280] = selected_trend(
        result, settings, index, physical=result.physical_measurements is not None
    )
    return output


def save_station_review(
    directory, image, result, index, settings, *, calibration=None, trace=None
):
    report = station_report(result, index, settings)
    trace = (
        review_trace(image, result, index, settings, calibration)
        if trace is None
        else trace
    )
    report.update(
        image_size=list(image.shape[1::-1]),
        image_dtype=str(image.dtype),
        image_sha256=hashlib.sha256(image.tobytes()).hexdigest(),
        settings=asdict(settings),
        calibration=calibration,
        crop_pixels=list(station_bounds(image, result, index, trace)),
        trace={
            name: None if value is None else value.tolist()
            for name, value in vars(trace).items()
        },
    )
    pages = {
        "overlay.png": selected_overlay(image, result, index, trace),
        "profile.png": draw_scan_trace(
            trace, result.stations[index].status, settings.min_gradient
        ),
        "pixel_trend.png": selected_trend(result, settings, index),
        "assessment.png": draw_assessment(
            image, result, index, settings, calibration=calibration, trace=trace
        ),
    }
    if result.physical_measurements is not None:
        pages["physical_trend.png"] = selected_trend(
            result, settings, index, physical=True
        )

    def native_json(value):
        if isinstance(value, (np.ndarray, np.generic)):
            return value.tolist()
        raise TypeError(f"Unsupported station review value: {type(value).__name__}")

    document = (
        json.dumps(report, indent=2, allow_nan=False, default=native_json) + "\n"
    ).encode("utf-8")
    target = Path(directory)
    target.mkdir(parents=True, exist_ok=False)
    for name, pixels in pages.items():
        ok, encoded = cv2.imencode(".png", pixels)
        if not ok:
            raise ValueError("Could not encode a station review image.")
        (target / name).write_bytes(encoded.tobytes())
    (target / "review.json").write_bytes(document)
    return target
