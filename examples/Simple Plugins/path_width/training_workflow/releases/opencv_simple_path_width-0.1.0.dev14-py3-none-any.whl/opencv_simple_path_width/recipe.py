"""Portable inspection setup, including its native-depth training reference."""

import json
import os
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from tempfile import NamedTemporaryFile
from zipfile import BadZipFile, ZipFile

import cv2
import numpy as np

from .geometry import path_vertices
from .measurement import _PHYSICAL_OPTIONS, PathWidthSettings, Point, measure_path

_VERSION = 1
_MANIFEST = "recipe.json"
_REFERENCE = "reference.png"
_MAX_PIXELS = 64_000_000


def _rows(points):
    return tuple(map(tuple, points.tolist()))


def _affine(value):
    matrix = np.asarray(value, dtype=np.float64)
    if (matrix.shape != (2, 3) or not np.isfinite(matrix).all()
            or np.linalg.cond(matrix[:, :2]) > 1e10):
        raise ValueError("An affine transform requires a finite, invertible 2 × 3 matrix.")
    return matrix


def _transform(points, matrix):
    affine = _affine(matrix)
    return points @ affine[:, :2].T + affine[:, 2]


def _reference_size(value):
    if (len(value) != 2 or any(type(side) is not int or not 2 <= side < 32767 for side in value)
            or value[0] * value[1] > _MAX_PIXELS):
        raise ValueError("Reference size must be [width, height] within 64 million pixels.")
    return tuple(value)


@dataclass(frozen=True)
class AlignmentFit:
    matrix: tuple[tuple[float, float, float], tuple[float, float, float]]
    residuals_px: tuple[float, ...]
    rms_error_px: float
    max_error_px: float


def fit_alignment(source, reference) -> AlignmentFit:
    """Fit a source-to-reference affine map from ordered landmark pairs."""
    source = np.asarray(source, dtype=np.float64)
    reference = np.asarray(reference, dtype=np.float64)
    if (source.ndim != 2 or source.shape[1] != 2 or not 3 <= len(source) <= 4096
            or source.shape != reference.shape or not np.isfinite(source).all()
            or not np.isfinite(reference).all() or np.max(np.abs(source)) > 1e6
            or np.max(np.abs(reference)) > 1e6):
        raise ValueError("Supply at least three finite source and reference [x, y] landmark pairs.")
    center = source.mean(axis=0)
    delta = source - center
    scale = np.linalg.norm(delta, axis=1).max()
    if scale == 0:
        raise ValueError("Source landmarks must span a plane.")
    design = np.column_stack((delta / scale, np.ones(len(source))))
    solution, _, rank, _ = np.linalg.lstsq(design, reference, rcond=1e-10)
    if rank != 3:
        raise ValueError("Source landmarks must span a plane.")
    linear = solution[:2].T / scale
    matrix = _affine(np.column_stack((linear, solution[2] - linear @ center)))
    errors = np.linalg.norm(_transform(source, matrix) - reference, axis=1)
    return AlignmentFit(
        _rows(matrix), tuple(errors.tolist()), float(np.sqrt(np.mean(errors**2))), float(errors.max()),
    )


@dataclass(frozen=True)
class PathWidthRecipe:
    vertices: tuple[Point, ...]
    closed: bool = False
    settings: PathWidthSettings = PathWidthSettings()
    source_to_reference: tuple[tuple[float, float, float], tuple[float, float, float]] | None = None
    cad_units: int | None = None
    reference_size: tuple[int, int] | None = None

    def __post_init__(self):
        if not isinstance(self.closed, bool):
            raise ValueError("closed must be boolean.")
        if not isinstance(self.settings, PathWidthSettings):
            raise ValueError("settings must be a PathWidthSettings value.")
        vertices = path_vertices(self.vertices, self.closed)
        object.__setattr__(self, "vertices", _rows(vertices))
        if self.source_to_reference is not None:
            matrix = _affine(self.source_to_reference)
            object.__setattr__(self, "source_to_reference", _rows(matrix))
            path_vertices(_transform(vertices, matrix), self.closed)
        if self.cad_units is not None and (type(self.cad_units) is not int or not 0 <= self.cad_units <= 24):
            raise ValueError("cad_units must be a DXF INSUNITS code from 0 to 24.")
        if self.reference_size is not None:
            object.__setattr__(self, "reference_size", _reference_size(self.reference_size))

    def reference_vertices(self) -> np.ndarray:
        points = np.asarray(self.vertices)
        return points if self.source_to_reference is None else _transform(points, self.source_to_reference)

    def measure(self, image, *, mask=None, reference_to_image=None, calibration=None):
        vertices = self.reference_vertices()
        if reference_to_image is not None:
            vertices = _transform(vertices, reference_to_image)
        elif self.reference_size is not None and np.shape(image)[:2][::-1] != self.reference_size:
            raise ValueError("Image size differs from the recipe reference. Supply a reference-to-image transform.")
        return measure_path(image, vertices, self.settings, closed=self.closed, mask=mask, calibration=calibration)


def save_recipe(path, recipe: PathWidthRecipe, reference) -> None:
    """Atomically write the recipe and an 8- or 16-bit grayscale reference to a ZIP."""
    reference = np.asarray(reference)
    if reference.ndim != 2 or reference.dtype not in (np.uint8, np.uint16):
        raise ValueError("Reference must be an 8- or 16-bit grayscale image.")
    size = _reference_size(reference.shape[::-1])
    if recipe.reference_size is not None and recipe.reference_size != size:
        raise ValueError("Reference size differs from the recipe.")
    data = asdict(replace(recipe, reference_size=size))
    settings = data["settings"]
    for name in (*_PHYSICAL_OPTIONS, "physical_units"):
        if settings[name] is None or settings[name] == "":
            del settings[name]
    if settings["scan_mode"] == "image_normal":
        del settings["scan_mode"]
    for name, value in settings.items():
        if value is not None and not isinstance(value, str):
            settings[name] = float(value)
    manifest = json.dumps({"version": _VERSION, **data}, indent=2, allow_nan=False) + "\n"
    ok, encoded = cv2.imencode(".png", reference)
    if not ok:
        raise ValueError("Could not encode the reference image.")
    target = Path(path)
    with NamedTemporaryFile(dir=target.parent, prefix=f".{target.name}.", suffix=".tmp", delete=False) as tmp:
        temporary = Path(tmp.name)
    try:
        with ZipFile(temporary, "w") as archive:
            archive.writestr(_MANIFEST, manifest)
            archive.writestr(_REFERENCE, encoded.tobytes())
        os.replace(temporary, target)
    finally:
        temporary.unlink(missing_ok=True)


def _manifest_bytes(archive):
    if sorted(archive.namelist()) != sorted((_MANIFEST, _REFERENCE)):
        raise ValueError("Recipe must contain one manifest and one reference image.")
    if archive.getinfo(_MANIFEST).file_size > 1024 * 1024:
        raise ValueError("Recipe manifest exceeds 1 MiB.")
    return archive.read(_MANIFEST)


def _decode_manifest(raw):
    data = json.loads(raw)
    if not isinstance(data, dict) or type(data.get("version")) is not int or data.pop("version") != _VERSION:
        raise ValueError("Unsupported path width recipe version.")
    if data.get("reference_size") is None:
        raise ValueError("Recipe is missing its reference size.")
    data["settings"] = PathWidthSettings(**data["settings"])
    return PathWidthRecipe(**data)


def load_recipe(path) -> PathWidthRecipe:
    """Read the saved geometry and settings without decoding the reference image."""
    try:
        with ZipFile(path) as archive:
            return _decode_manifest(_manifest_bytes(archive))
    except (BadZipFile, KeyError, TypeError, RuntimeError) as error:
        raise ValueError(f"Invalid path width recipe: {error}") from error


def _read_reference(archive, recipe):
    if archive.getinfo(_REFERENCE).file_size > 2 * _MAX_PIXELS + 1024 * 1024:
        raise ValueError("Recipe reference is too large.")
    png = archive.read(_REFERENCE)
    if (png[:8] != b"\x89PNG\r\n\x1a\n" or png[12:16] != b"IHDR"
            or (int.from_bytes(png[16:20], "big"), int.from_bytes(png[20:24], "big")) != recipe.reference_size):
        raise ValueError("Reference PNG dimensions differ from the recipe.")
    pixels = cv2.imdecode(np.frombuffer(png, np.uint8), cv2.IMREAD_UNCHANGED)
    if pixels is None or pixels.ndim != 2 or pixels.dtype not in (np.uint8, np.uint16):
        raise ValueError("Invalid grayscale reference PNG.")
    return pixels


def load_reference(path) -> np.ndarray:
    """Read the exact reference pixels for reviewing or editing a recipe."""
    try:
        with ZipFile(path) as archive:
            recipe = _decode_manifest(_manifest_bytes(archive))
            return _read_reference(archive, recipe)
    except (BadZipFile, KeyError, TypeError, RuntimeError) as error:
        raise ValueError(f"Invalid path width recipe: {error}") from error
