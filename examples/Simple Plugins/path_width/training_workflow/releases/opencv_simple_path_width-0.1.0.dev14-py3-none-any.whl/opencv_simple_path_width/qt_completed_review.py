"""Independent read-only Results dialog; shared station controls with training."""

from opencv_dataflow.canvas import pixmap
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from opencv_dataflow.images import ImageArray
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTabWidget,
    QVBoxLayout,
)

from .overlay import draw_overlay
from .qt_canvas import MeasurementPreview
from .trend import draw_physical_trend, draw_trend


class CompletedPathReviewDialog(QDialog):
    def __init__(self, parent, context, capture):
        super().__init__(parent)
        self.resize(1320, 980)
        self.setWindowTitle("Completed path width review")
        self.snapshot = None
        self.panel = None
        self._capture = capture
        self._closed = False
        layout = QVBoxLayout(self)
        actions = QHBoxLayout()
        self.capture_button = QPushButton("Capture latest completed run")
        self.capture_button.clicked.connect(self.capture_latest)
        actions.addWidget(self.capture_button)
        close = QPushButton("Close review")
        close.clicked.connect(self.reject)
        actions.addWidget(close)
        layout.addLayout(actions)
        self.identity = QLabel("No completed frame captured")
        self.identity.setWordWrap(True)
        layout.addWidget(self.identity)
        self.status = QLabel()
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.summary = QLabel()
        self.summary.setWordWrap(True)
        layout.addWidget(self.summary)
        self.tabs = QTabWidget()
        self.source_view = FilmstripImageView(self)
        self.tabs.addTab(self.source_view, "Exact consumed input")
        layout.addWidget(self.tabs, 1)
        self.finished.connect(lambda *_: setattr(self, "_closed", True))
        unsubscribe = context.subscribe_outputs(self.publication_changed)
        self.finished.connect(unsubscribe)
        self.destroyed.connect(unsubscribe)
        self.capture_latest()

    def publication_changed(self, revision):
        if self.snapshot is not None and not self._closed:
            self.status.setText(
                "Editor publication changed. Frozen review stays unchanged; capture latest explicitly."
            )

    def capture_latest(self):
        if self._closed:
            return
        try:
            snapshot = self._capture()
        except (ValueError, RuntimeError, KeyError) as error:
            suffix = (
                " Previous frozen frame remains displayed."
                if self.snapshot is not None
                else ""
            )
            self.status.setText(str(error) + suffix)
            return
        record, result = snapshot.record, snapshot.record.result
        settings = record.recipe.settings
        physical = result.physical_measurements
        panel = MeasurementPreview(
            self,
            draw_overlay(snapshot.image, result),
            draw_trend(result, settings),
            result,
            reference=snapshot.image,
            settings=settings,
            calibration=snapshot.calibration,
            physical_trend=None
            if physical is None
            else draw_physical_trend(physical, settings),
            trace_provider=snapshot.trace,
            export_handler=snapshot.export,
        )
        panel.setWindowFlags(Qt.WindowType.Widget)
        if self.panel is not None:
            self.tabs.removeTab(self.tabs.indexOf(self.panel))
            self.panel.deleteLater()
        self.panel = panel
        self.snapshot = snapshot
        self.tabs.insertTab(0, panel, "Completed measurements and profiles")
        self.tabs.setCurrentIndex(0)
        self.source_view.set_image(
            pixmap(ImageArray(snapshot.source_pixels, snapshot.source_format))
        )
        p = snapshot.provenance
        self.identity.setText(
            f"{p['block_id']} · completion {p['execution_count']} · "
            f"{'PASS' if result.passed else 'FAIL'} · {len(result.stations)} stations · "
            f"manifest {record.manifest_sha256[:16]} · input {snapshot.source_sha256[:16]}"
        )
        physical_gap = (
            ""
            if physical is None
            else f" · physical gap {physical.longest_gap:.4g} {physical.units}"
        )
        groups = snapshot.report()["station_groups"]
        self.summary.setText(
            f"Measured {result.coverage:.1%} / minimum {settings.min_coverage:.1%} · "
            f"observed {result.observed_fraction:.1%} · longest missing-edge gap {result.longest_gap_px:.4g} px"
            + physical_gap
            + "\n"
            + " · ".join(
                f"{key.replace('_', ' ')}: {value}" for key, value in groups.items()
            )
            + "\nPath failures: "
            + (", ".join(result.failures) or "none")
        )
        self.status.setText(
            "Frozen completed measurements and limits. Profiles resample frozen pixels on selection; "
            "edge pairs/verdict are never recomputed. Missing, ambiguous and unobserved scans stay distinct. "
            "Training is unchanged."
        )
