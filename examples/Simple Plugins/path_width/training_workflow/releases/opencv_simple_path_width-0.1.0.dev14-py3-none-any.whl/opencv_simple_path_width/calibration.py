"""Convert detected cross-scan endpoints to measurements on a calibrated plane."""

from __future__ import annotations

from dataclasses import dataclass
from numbers import Real
from typing import TYPE_CHECKING

import numpy as np

from .geometry import _station_count, path_vertices

if TYPE_CHECKING:
    from .measurement import PathWidthResult, PathWidthSettings, Point


@dataclass(frozen=True)
class PhysicalStation:
    distance: float
    point: Point
    status: str
    edges: tuple[Point, Point] | None = None
    width: float | None = None
    center_offset: float | None = None
    issues: tuple[str, ...] = ()


@dataclass(frozen=True)
class PhysicalGap:
    start: float
    end: float
    length: float
    wraps: bool


@dataclass(frozen=True)
class PhysicalPathWidthResult:
    units: str
    calibration_rms_error: float
    path_length: float
    stations: tuple[PhysicalStation, ...]
    min_width: float | None
    max_width: float | None
    mean_width: float | None
    gaps: tuple[PhysicalGap, ...] = ()
    longest_gap: float = 0.
    failures: tuple[str, ...] = ()
    station_spacing: float | None = None


def _profile(mapping):
    if not isinstance(mapping, dict) or mapping.get("model") != "planar_homography_v1":
        raise ValueError("Expected a planar_homography_v1 calibration profile.")
    matrix = np.asarray(mapping.get("pixel_to_physical"), dtype=float)
    if matrix.shape != (3, 3) or not np.isfinite(matrix).all():
        raise ValueError("Calibration requires a finite, invertible 3 × 3 matrix.")
    scale = np.max(np.abs(matrix))
    if not scale or np.linalg.matrix_rank(matrix / scale) != 3:
        raise ValueError("Calibration requires a finite, invertible 3 × 3 matrix.")
    size, units, error = (mapping.get(key) for key in ("image_size", "units", "rms_error"))
    if (not isinstance(size, (list, tuple)) or len(size) != 2
            or any(type(side) is not int or side < 2 for side in size)):
        raise ValueError("Calibration must declare its image_size as [width, height].")
    if not isinstance(units, str) or not units.strip():
        raise ValueError("Calibration must declare physical units.")
    if isinstance(error, bool) or not isinstance(error, Real) or not np.isfinite(error) or error < 0:
        raise ValueError("Calibration rms_error must be finite and nonnegative.")
    return matrix / scale, tuple(size), units.strip(), float(error)


def _measurement_profile(mapping, image_size, settings=None):
    matrix, size, units, error = _profile(mapping)
    if tuple(image_size) != size:
        raise ValueError("Calibration image size differs from the inspection image.")
    if settings is not None and settings.requires_calibration and settings.physical_units.strip() != units:
        raise ValueError(f"Physical settings require units {settings.physical_units.strip()!r}; calibration uses {units!r}.")
    return matrix, size, units, error


def _project(points, matrix):
    homogeneous = np.column_stack((points, np.ones(len(points))))
    mapped = homogeneous @ matrix.T
    denominator = mapped[:, 2]
    denominator_scale = np.abs(homogeneous) @ np.abs(matrix[2])
    if (np.any(np.abs(denominator) <= 1e-12 * denominator_scale)
            or np.any(denominator > 0) and np.any(denominator < 0)):
        raise ValueError("Inspection geometry crosses the calibration horizon.")
    result = mapped[:, :2] / denominator[:, None]
    if not np.isfinite(result).all():
        raise ValueError("Calibration produced nonfinite plane coordinates.")
    return result


def _plane_scan_geometry(centers, normals, mapping, *, image_size, settings):
    """Return unit pixel directions and optional per-station pixel band limits."""
    matrix, size, _, _ = _measurement_profile(mapping, image_size, settings)
    plane_centers = _project(centers, matrix)
    # This is the local pixel-to-plane Jacobian up to a common scalar per point.
    jacobian = matrix[:2, :2] - plane_centers[:, :, None] * matrix[2, :2]
    pixel_tangents = np.column_stack((normals[:, 1], -normals[:, 0]))
    plane_tangents = np.einsum("nij,nj->ni", jacobian, pixel_tangents)
    # Pull back the perpendicularity constraint. Rotating J.T @ J @ tangent
    # gives a pixel scan direction whose mapped line is normal to the plane path.
    constraint = np.einsum("nij,ni->nj", jacobian, plane_tangents)
    directions = np.column_stack((-constraint[:, 1], constraint[:, 0]))
    lengths = np.hypot(directions[:, 0], directions[:, 1])
    if not np.isfinite(lengths).all() or np.any(lengths == 0):
        raise ValueError("Calibration produced an invalid plane-normal scan direction.")
    directions /= lengths[:, None]

    offsets = np.array([-settings.scan_half_width, settings.scan_half_width])
    endpoints = centers[:, None, :] + directions[:, None, :] * offsets[None, :, None]
    inside = np.all((endpoints >= 0) & (endpoints <= np.asarray(size) - 1), axis=(1, 2))
    # A pole anywhere on an in-frame scan makes its plane geometry undefined,
    # including when the detector ultimately finds both edges on one side.
    _project(np.vstack((centers, endpoints[inside].reshape(-1, 2))), matrix)
    if settings.nominal_width_physical is None:
        return directions, None

    # Orient the plane normal to match positive motion along the pixel scan.
    plane_normals = np.einsum("nij,nj->ni", jacobian, directions)
    denominator = centers @ matrix[2, :2] + matrix[2, 2]
    plane_lengths = np.hypot(plane_normals[:, 0], plane_normals[:, 1])
    if not np.isfinite(plane_lengths).all() or np.any(plane_lengths == 0):
        raise ValueError("Calibration produced an invalid physical scan normal.")
    plane_normals /= (np.sign(denominator) * plane_lengths)[:, None]
    half, radius = settings.nominal_width_physical / 2, settings.edge_search_radius_physical
    bounds = np.array([[-half - radius, -half + radius], [half - radius, half + radius]])
    plane_bounds = plane_centers[:, None, None, :] + bounds[None, :, :, None] * plane_normals[:, None, None, :]
    mapped = _project(np.vstack((plane_centers, plane_bounds.reshape(-1, 2))), np.linalg.inv(matrix))
    pixel_bounds = mapped[len(centers):].reshape(-1, 2, 2, 2)
    limits = np.einsum("nbkj,nj->nbk", pixel_bounds - centers[:, None, None, :], directions)
    if not np.isfinite(limits).all() or np.any(np.diff(limits.reshape(-1, 4), axis=1) <= 0):
        raise ValueError("Calibration produced invalid physical edge search bands.")
    return directions, limits


def _physical_station_grid(vertices, closed, mapping, *, image_size, settings):
    """Return the pixel arc positions of equal physical cells and their centers."""
    matrix, _, _, _ = _measurement_profile(mapping, image_size, settings)
    path = path_vertices(vertices, closed)
    chain = np.vstack((path, path[0])) if closed else path
    plane = _project(chain, matrix)
    deltas = np.diff(plane, axis=0)
    lengths = np.linalg.norm(deltas, axis=1)
    arc = np.r_[0., np.cumsum(lengths)]
    if not np.isfinite(arc).all() or np.any(np.diff(arc) <= 0):
        raise ValueError("Calibration produced invalid physical station distances.")
    count = _station_count(float(arc[-1]), settings.station_spacing_physical)
    edges = np.linspace(0., arc[-1], count + 1)
    midpoints = edges[:-1] + np.diff(edges) / 2
    physical = np.r_[midpoints, edges]
    segments = np.searchsorted(arc[1:-1], physical, side="right")
    fraction = (physical - arc[segments]) / lengths[segments]
    points = plane[segments] + fraction[:, None] * deltas[segments]
    pixels = _project(points, np.linalg.inv(matrix))
    pixel_arc = np.r_[0., np.cumsum(np.linalg.norm(np.diff(chain, axis=0), axis=1))]
    distances = pixel_arc[segments] + np.linalg.norm(pixels - chain[segments], axis=1)
    centers, boundaries = distances[:count], distances[count:]
    boundaries[0], boundaries[-1] = 0., pixel_arc[-1]
    if (not np.isfinite(distances).all()
            or np.any(centers <= boundaries[:-1]) or np.any(centers >= boundaries[1:])):
        raise ValueError("Calibration produced invalid pixel station cells.")
    return centers, boundaries


def _plane_distances(pixel_distances, plane_points, pixel_arc, plane_arc, plane_path):
    segments = np.searchsorted(pixel_arc[1:-1], pixel_distances, side="right")
    distances = plane_arc[segments] + np.linalg.norm(plane_points - plane_path[segments], axis=1)
    if not np.isfinite(distances).all():
        raise ValueError("Calibration produced invalid path distances.")
    return distances


def _physical_issues(width, offset, settings):
    issues = []
    if settings is not None:
        if settings.min_width_physical is not None and width < settings.min_width_physical:
            issues.append("width_below_minimum")
        if settings.max_width_physical is not None and width > settings.max_width_physical:
            issues.append("width_above_maximum")
        if settings.max_center_offset_physical is not None and abs(offset) > settings.max_center_offset_physical:
            issues.append("center_out_of_tolerance")
    return tuple(issues)


def calibrate_result(
    result: PathWidthResult, mapping, *, image_size, settings: PathWidthSettings | None = None,
) -> PhysicalPathWidthResult:
    """Report width and signed offset normal to the mapped path on its plane.

    The mapping is expressed in the measured image's [width, height] pixel
    grid. An optional settings value supplies physical tolerance checks.
    """
    matrix, _, units, error = _measurement_profile(mapping, image_size, settings)
    path = np.asarray(result.path)
    if result.closed:
        path = np.vstack((path, path[0]))
    pixel_arc = np.r_[0., np.cumsum(np.linalg.norm(np.diff(path, axis=0), axis=1))]
    gap_distances = [distance for gap in result.gaps for distance in (gap.start_px, gap.end_px)]
    gap_points = np.column_stack([np.interp(gap_distances, pixel_arc, coord) for coord in path.T])
    points = np.asarray([station.point for station in result.stations])
    measured = [index for index, station in enumerate(result.stations) if station.edges is not None]
    edges = np.asarray([result.stations[index].edges for index in measured]).reshape(-1, 2)
    mapped = _project(np.vstack((path, points, edges, gap_points)), matrix)
    plane_path, plane_points, plane_edges, plane_gap_points = np.split(
        mapped, np.cumsum([len(path), len(points), len(edges)]),
    )
    plane_edges = plane_edges.reshape(-1, 2, 2)

    plane_arc = np.r_[0., np.cumsum(np.linalg.norm(np.diff(plane_path, axis=0), axis=1))]
    if not np.isfinite(plane_arc).all() or not plane_arc[-1] > 0:
        raise ValueError("Calibration produced invalid path distances.")
    path_length = float(plane_arc[-1])
    station_distances = [station.distance_px for station in result.stations]
    distances = _plane_distances(station_distances, plane_points, pixel_arc, plane_arc, plane_path)
    boundaries = _plane_distances(gap_distances, plane_gap_points, pixel_arc, plane_arc, plane_path).reshape(-1, 2)
    gaps = []
    for gap, (start, end) in zip(result.gaps, boundaries.tolist(), strict=True):
        length = (path_length - start) + end if gap.wraps else end - start
        gaps.append(PhysicalGap(start, end, length, gap.wraps))

    stations = [
        PhysicalStation(float(distance), tuple(point.tolist()), pixel.status)
        for distance, point, pixel in zip(distances, plane_points, result.stations, strict=True)
    ]
    widths = []
    if measured:
        normals = np.asarray([result.stations[index].normal for index in measured])
        tangents = np.column_stack((normals[:, 1], -normals[:, 0]))
        derivatives = tangents @ matrix[:, :2].T
        centers = plane_points[measured]
        # The differential of the homography, up to a common scalar per station.
        plane_tangents = derivatives[:, :2] - centers * derivatives[:, 2, None]
        perpendicular = np.column_stack((-plane_tangents[:, 1], plane_tangents[:, 0]))
        lengths = np.linalg.norm(perpendicular, axis=1)
        if not np.isfinite(lengths).all() or np.any(lengths == 0):
            raise ValueError("Calibration produced an invalid path normal.")
        perpendicular /= lengths[:, None]
        offsets = np.einsum("nij,nj->ni", plane_edges - centers[:, None], perpendicular)
        differences = offsets[:, 1] - offsets[:, 0]
        widths = np.abs(differences).tolist()
        # Preserve the image scan's positive side, even for a reflected calibration.
        centers_offset = (offsets[:, 0] / 2 + offsets[:, 1] / 2) * np.sign(differences)
        if not np.isfinite(offsets).all() or not np.isfinite(widths).all() or np.any(differences == 0):
            raise ValueError("Calibration produced an invalid physical width or offset.")
        for index, endpoints, width, offset in zip(measured, plane_edges, widths, centers_offset, strict=True):
            previous = stations[index]
            a, b = endpoints.tolist()
            issues = _physical_issues(width, offset, settings)
            stations[index] = PhysicalStation(
                previous.distance, previous.point, "out_of_tolerance" if issues else previous.status,
                (tuple(a), tuple(b)), width, float(offset), issues,
            )
    mean = float(np.mean(widths)) if widths else None
    if mean is not None and not np.isfinite(mean):
        raise ValueError("Calibration produced an invalid mean width.")
    longest_gap = max((gap.length for gap in gaps), default=0.)
    failures = []
    if settings is not None and settings.max_gap_physical is not None and longest_gap > settings.max_gap_physical:
        failures.append("physical_gap_above_maximum")
    if any(station.issues for station in stations):
        failures.append("physical_station_out_of_tolerance")
    spacing = None
    if result.station_spacing_px is None:
        step = path_length / len(stations)
        if np.allclose(distances, (np.arange(len(stations)) + .5) * step, rtol=1e-9, atol=step * 1e-9):
            spacing = step
    return PhysicalPathWidthResult(
        units, error, path_length, tuple(stations), min(widths, default=None), max(widths, default=None), mean,
        tuple(gaps), longest_gap, tuple(failures), spacing,
    )
