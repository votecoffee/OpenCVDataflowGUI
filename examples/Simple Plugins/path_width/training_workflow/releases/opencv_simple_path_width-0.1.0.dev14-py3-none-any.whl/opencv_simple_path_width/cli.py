"""File-based runner for a path width inspection."""

import argparse
import json
from dataclasses import asdict
from pathlib import Path

import cv2
import numpy as np

from .measurement import PathWidthSettings, measure_path
from .overlay import draw_overlay
from .recipe import load_recipe


def _read_gray(path):
    pixels = cv2.imdecode(np.frombuffer(path.read_bytes(), np.uint8), cv2.IMREAD_UNCHANGED)
    if pixels is None:
        raise ValueError(f"Cannot decode {path}.")
    if pixels.ndim == 3:
        conversion = cv2.COLOR_BGRA2GRAY if pixels.shape[2] == 4 else cv2.COLOR_BGR2GRAY
        return cv2.cvtColor(pixels, conversion)
    return pixels


def _read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def _read_path(path):
    data = _read_json(path)
    if not isinstance(data, dict) or "vertices" not in data or data.keys() - {"vertices", "closed"}:
        raise ValueError("Path must contain vertices and optionally closed.")
    return data["vertices"], data.get("closed", False)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("image", type=Path)
    parser.add_argument("path", type=Path, help="JSON path or a saved .spw recipe")
    parser.add_argument("--settings", type=Path, help="JSON object with PathWidthSettings fields")
    parser.add_argument("--pose", type=Path, help="Reference-to-image affine matrix JSON for a saved recipe")
    parser.add_argument("--calibration", type=Path, help="Planar calibration profile for the inspection image")
    parser.add_argument("--mask", type=Path, help="Aligned 8-bit mask, with nonzero pixels selected")
    parser.add_argument("--report", type=Path, help="Write the JSON result to this file")
    parser.add_argument("--overlay", type=Path, help="Write an annotated PNG")
    args = parser.parse_args(argv)
    try:
        inputs = {
            path.resolve()
            for path in (args.image, args.path, args.settings, args.mask, args.pose, args.calibration)
            if path
        }
        outputs = [path.resolve() for path in (args.report, args.overlay) if path]
        if len(set(outputs)) != len(outputs) or inputs.intersection(outputs):
            raise ValueError("Output paths must be distinct from the inputs and each other.")
        if args.overlay and args.overlay.suffix.lower() != ".png":
            raise ValueError("Overlay output must use the .png extension.")
        image = _read_gray(args.image)
        mask = _read_gray(args.mask) if args.mask else None
        calibration = _read_json(args.calibration) if args.calibration else None
        if args.calibration and not isinstance(calibration, dict):
            raise ValueError("Calibration JSON must contain a planar calibration profile.")
        if args.path.suffix.lower() == ".spw":
            if args.settings:
                raise ValueError("A saved recipe already contains settings.")
            pose = _read_json(args.pose) if args.pose else None
            if args.pose and pose is None:
                raise ValueError("Pose JSON must contain a reference-to-image affine matrix.")
            result = load_recipe(args.path).measure(image, mask=mask, reference_to_image=pose, calibration=calibration)
        else:
            if args.pose:
                raise ValueError("A reference-to-image pose requires a saved .spw recipe.")
            vertices, closed = _read_path(args.path)
            settings = PathWidthSettings(**_read_json(args.settings)) if args.settings else PathWidthSettings()
            result = measure_path(image, vertices, settings, closed=closed, mask=mask, calibration=calibration)
        data = asdict(result)
        if result.physical_measurements is None:
            data.pop("physical_measurements")
        if args.overlay:
            ok, encoded = cv2.imencode(".png", draw_overlay(image, result))
            if not ok:
                raise ValueError("Could not encode the overlay.")
            args.overlay.write_bytes(encoded.tobytes())
        report = json.dumps(data, indent=2, allow_nan=False) + "\n"
        if args.report:
            args.report.write_text(report, encoding="utf-8")
        else:
            print(report, end="")
    except (OSError, TypeError, ValueError, cv2.error) as error:
        parser.error(str(error))
    return 0 if result.passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
