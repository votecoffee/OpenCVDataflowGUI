"""Extract and preview an editable path from an aligned training mask."""

import argparse
import json
from dataclasses import asdict
from pathlib import Path

import cv2

from .centerline import extract_centerline
from .cli import _read_gray
from .overlay import draw_centerline


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mask", type=Path, help="8-bit reference mask with foreground nonzero")
    parser.add_argument("path", type=Path, help="Output editable path JSON")
    parser.add_argument("--start", type=float, nargs=2, metavar=("X", "Y"), help="Foreground seed or loop seam")
    parser.add_argument("--end", type=float, nargs=2, metavar=("X", "Y"), help="End seed for choosing a branch")
    parser.add_argument("--reverse", action="store_true", help="Reverse the trace direction")
    parser.add_argument("--simplify-px", type=float, default=.75, help="Maximum polyline simplification error")
    parser.add_argument("--reference", type=Path, help="Optional reference image for the preview")
    parser.add_argument("--preview", type=Path, help="Write an annotated PNG of the proposed path")
    args = parser.parse_args(argv)
    try:
        inputs = {path.resolve() for path in (args.mask, args.reference) if path}
        outputs = [path.resolve() for path in (args.path, args.preview) if path]
        if len(set(outputs)) != len(outputs) or inputs.intersection(outputs):
            raise ValueError("Output paths must be distinct from the inputs and each other.")
        if args.path.suffix.lower() != ".json":
            raise ValueError("Path output must use the .json extension.")
        if args.preview and args.preview.suffix.lower() != ".png":
            raise ValueError("Preview output must use the .png extension.")
        if args.reference and args.preview is None:
            raise ValueError("The reference image is only used for a preview.")
        mask = _read_gray(args.mask)
        draft = extract_centerline(
            mask, start=args.start, end=args.end, reverse=args.reverse, simplify_px=args.simplify_px,
        )
        if args.preview:
            image = _read_gray(args.reference) if args.reference else mask
            if image.shape != mask.shape:
                raise ValueError("Reference and mask image dimensions must match.")
            ok, encoded = cv2.imencode(".png", draw_centerline(image, draft))
            if not ok:
                raise ValueError("Could not encode the trace preview.")
            args.preview.write_bytes(encoded.tobytes())
        args.path.write_text(json.dumps(asdict(draft), indent=2, allow_nan=False) + "\n", encoding="utf-8")
        print(f"Saved {len(draft.vertices)} vertices for a {'closed' if draft.closed else 'open'} path.")
    except (OSError, TypeError, ValueError, cv2.error) as error:
        parser.error(str(error))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
