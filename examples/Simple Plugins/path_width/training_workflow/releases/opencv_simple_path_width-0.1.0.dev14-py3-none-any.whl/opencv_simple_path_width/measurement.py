"""Cross-scan edge measurements in the input image coordinate frame."""

import math
from dataclasses import dataclass, replace
from numbers import Real

import cv2
import numpy as np

from .calibration import (
    PhysicalPathWidthResult,
    _physical_station_grid,
    _plane_scan_geometry,
    calibrate_result,
)
from .geometry import path_stations

Point = tuple[float, float]
_PHYSICAL_LIMITS = (
    "min_width_physical", "max_width_physical", "max_center_offset_physical", "max_gap_physical",
)
_PHYSICAL_OPTIONS = (
    "station_spacing_physical", "nominal_width_physical", "edge_search_radius_physical", *_PHYSICAL_LIMITS,
)


@dataclass(frozen=True)
class PathWidthSettings:
    station_spacing: float = 2.0
    scan_half_width: float = 16.0
    sample_spacing: float = 0.25
    smoothing_sigma: float = 0.7
    polarity: str = "bright"
    min_gradient: float = 12.0
    min_width: float | None = None
    max_width: float | None = None
    max_center_offset: float | None = None
    min_coverage: float = 0.9
    max_gap: float | None = None
    corner_angle: float = 45.0
    corner_margin: float = 2.0
    nominal_width: float | None = None
    edge_search_radius: float | None = None
    edge_continuity: float = 0.0
    physical_units: str = ""
    min_width_physical: float | None = None
    max_width_physical: float | None = None
    max_center_offset_physical: float | None = None
    max_gap_physical: float | None = None
    scan_mode: str = "image_normal"
    station_spacing_physical: float | None = None
    nominal_width_physical: float | None = None
    edge_search_radius_physical: float | None = None

    def __post_init__(self):
        ranges = {
            "station_spacing": (0.25, 1e6),
            "scan_half_width": (1, 1e6),
            "sample_spacing": (0.125, 1),
            "smoothing_sigma": (0, 16),
            "min_gradient": (0, math.inf),
            "min_coverage": (0, 1),
            "corner_angle": (1, 180),
            "corner_margin": (0, 1e6),
            "edge_continuity": (0, 10),
        }
        for field in ("min_width", "max_width", "max_center_offset", "max_gap",
                      "nominal_width", "edge_search_radius", *_PHYSICAL_OPTIONS):
            if getattr(self, field) is not None:
                ranges[field] = (0, math.inf)
        for field, (low, high) in ranges.items():
            value = getattr(self, field)
            if (isinstance(value, bool) or not isinstance(value, Real)
                    or not math.isfinite(value) or not low <= value <= high):
                raise ValueError(f"{field} must be finite and in [{low}, {high}].")
        if self.polarity not in ("bright", "dark"):
            raise ValueError("polarity must be bright or dark.")
        if self.scan_mode not in ("image_normal", "plane_normal"):
            raise ValueError("scan_mode must be image_normal or plane_normal.")
        if self.min_width is not None and self.max_width is not None and self.min_width > self.max_width:
            raise ValueError("min_width must not exceed max_width.")
        if (self.min_width_physical is not None and self.max_width_physical is not None
                and self.min_width_physical > self.max_width_physical):
            raise ValueError("min_width_physical must not exceed max_width_physical.")
        if not isinstance(self.physical_units, str) or (self.requires_calibration and not self.physical_units.strip()):
            raise ValueError("Set physical_units to the profile units when using physical spacing, bands, or limits.")
        if self.station_spacing_physical is not None and self.station_spacing_physical <= 0:
            raise ValueError("station_spacing_physical must be positive.")
        if (self.nominal_width is None) != (self.edge_search_radius is None):
            raise ValueError("Set both nominal_width and edge_search_radius to enable edge search bands.")
        if self.nominal_width is not None:
            half = self.nominal_width / 2
            if not 0 < self.edge_search_radius < half or half + self.edge_search_radius > self.scan_half_width:
                raise ValueError("Edge search bands must be disjoint and fit inside the cross-scan.")
        if (self.nominal_width_physical is None) != (self.edge_search_radius_physical is None):
            raise ValueError("Set both nominal_width_physical and edge_search_radius_physical.")
        if self.nominal_width_physical is not None:
            if self.scan_mode != "plane_normal":
                raise ValueError("Physical edge search bands require plane-normal scans.")
            if self.nominal_width is not None:
                raise ValueError("Use either pixel or physical edge search bands.")
            if not 0 < self.edge_search_radius_physical < self.nominal_width_physical / 2:
                raise ValueError("Physical edge search bands must be disjoint and have positive radius.")
        if self.edge_continuity and self.nominal_width is None and self.nominal_width_physical is None:
            raise ValueError("Edge continuity requires edge search bands.")

    @property
    def requires_calibration(self):
        return any(getattr(self, field) is not None for field in _PHYSICAL_OPTIONS)


@dataclass(frozen=True)
class Station:
    distance_px: float
    point: Point
    normal: Point
    status: str
    edges: tuple[Point, Point] | None = None
    edge_strengths: tuple[float, float] | None = None
    width_px: float | None = None
    center_offset_px: float | None = None
    issues: tuple[str, ...] = ()


@dataclass(frozen=True)
class Gap:
    start_px: float
    end_px: float
    length_px: float
    wraps: bool


@dataclass(frozen=True)
class PathWidthResult:
    path: tuple[Point, ...]
    closed: bool
    path_length_px: float
    station_spacing_px: float | None
    stations: tuple[Station, ...]
    gaps: tuple[Gap, ...]
    min_width_px: float | None
    max_width_px: float | None
    mean_width_px: float | None
    coverage: float
    observed_fraction: float
    longest_gap_px: float
    passed: bool
    failures: tuple[str, ...]
    physical_measurements: PhysicalPathWidthResult | None = None


def _peak_indices(values, minimum):
    middle = values[1:-1]
    return np.flatnonzero(
        (middle > 0) & (middle >= minimum) & (middle > values[:-2]) & (middle >= values[2:])
    ) + 1


def _band_peaks(rising, falling, bands):
    return tuple(
        peaks[(peaks >= first) & (peaks < stop)]
        for peaks, (first, stop) in zip((rising, falling), bands, strict=True)
    )


def _refine_edges(gradient, peaks, direction, pitch):
    strength = direction * gradient[peaks]
    left, right = direction * gradient[peaks - 1], direction * gradient[peaks + 1]
    fraction = 0.5 * (left - right) / (left - 2 * strength + right)
    offsets = (peaks + 0.5 + fraction) * pitch
    return offsets, strength - 0.25 * (left - right) * fraction


def _edge_pair(profile, step, sign, minimum, bands=None):
    gradient = sign * np.diff(profile) / step
    rising = _peak_indices(gradient, minimum)
    falling = _peak_indices(-gradient, minimum)
    if bands is None:
        indices = np.sort(np.r_[rising, falling])
        directions = gradient[indices] > 0
        pairs = np.flatnonzero(directions[:-1] & ~directions[1:])
        if not len(pairs):
            return "missing", None, None
        if len(pairs) > 1:
            return "ambiguous", None, None
        pair = indices[pairs[0]:pairs[0] + 2]
    else:
        peaks = _band_peaks(rising, falling, bands)
        if not all(len(side) for side in peaks):
            return "missing", None, None
        best = tuple(side[np.abs(gradient[side]) == np.abs(gradient[side]).max()] for side in peaks)
        if any(len(side) != 1 for side in best):
            return "ambiguous", None, None
        pair = np.concatenate(best)
    offsets, strengths = _refine_edges(gradient, pair, np.array([1., -1.]), step)
    return "measured", offsets, strengths


def _band_candidates(profile, pitch, sign, minimum, bands):
    gradient = sign * np.diff(profile) / pitch
    peaks = _band_peaks(_peak_indices(gradient, minimum), _peak_indices(-gradient, minimum), bands)
    if not all(len(side) for side in peaks):
        return None
    candidates = []
    for direction, side in zip((1., -1.), peaks, strict=True):
        offsets, strengths = _refine_edges(gradient, side, direction, pitch)
        log_gradient = np.log(direction * gradient[side])
        candidates.append((offsets, strengths, log_gradient.max() - log_gradient))
    return tuple(candidates)


def _continuous_pair(candidates, index, count, spacings, weight, closed):
    # Use up to two adjacent valid stations on each side of the current one.
    # Short loops use fewer neighbors so each station contributes at most once.
    depth = min(2, (count - 1) // 2) if closed else 2
    neighbors = []
    for direction in (-1, 1):
        chain = []
        for distance in range(1, depth + 1):
            neighbor = index + distance * direction
            if closed:
                neighbor %= count
            if neighbor not in candidates:
                break
            chain.append(neighbor)
        neighbors.append((direction, chain))

    chosen, strengths = [], []
    for side, (positions, gradient_strengths, loss) in enumerate(candidates[index]):
        if len(positions) == 1:
            chosen.append(positions[0])
            strengths.append(gradient_strengths[0])
            continue
        costs = loss.copy()
        for direction, chain in neighbors:
            support = 0.
            for depth_index in range(len(chain) - 1, -1, -1):
                neighbor = chain[depth_index]
                previous = chain[depth_index - 1] if depth_index else index
                offsets, _, evidence = candidates[neighbor][side]
                prior = candidates[previous][side][0]
                spacing = spacings[previous if direction == 1 else neighbor]
                # Cap the displacement cost to allow an abrupt real change in width.
                displacement = np.minimum(np.abs(prior[:, None] - offsets[None, :]) / spacing, 2.)
                support = np.min(weight * displacement + evidence + support, axis=1)
            costs += support
        best = np.flatnonzero(costs <= costs.min() + 1e-12)
        if len(best) != 1:
            return None
        chosen.append(positions[best[0]])
        strengths.append(gradient_strengths[best[0]])
    return np.asarray(chosen), strengths


def _measured_station(fields, offsets, strengths, settings, scan_direction):
    low, high = offsets - settings.scan_half_width
    width, offset = float(high - low), float((low + high) / 2)
    issues = []
    if settings.min_width is not None and width < settings.min_width:
        issues.append("width_below_minimum")
    if settings.max_width is not None and width > settings.max_width:
        issues.append("width_above_maximum")
    if settings.max_center_offset is not None and abs(offset) > settings.max_center_offset:
        issues.append("center_out_of_tolerance")
    _, point, _ = fields
    edge_points = tuple(tuple(edge.tolist()) for edge in point + np.array([low, high])[:, None] * scan_direction)
    return Station(
        *fields, "out_of_tolerance" if issues else "pass", edge_points,
        tuple(float(strength) for strength in strengths), width, offset, tuple(issues),
    )


def _gaps(missing, step, length, closed, boundaries=None):
    count = len(missing)
    transitions = np.diff(np.r_[False, missing, False].astype(np.int8))
    starts = np.flatnonzero(transitions == 1).tolist()
    stops = np.flatnonzero(transitions == -1).tolist()

    def make_gap(start, stop, wraps=False):
        if boundaries is None:
            cells = stop - start + (count if wraps else 0)
            return Gap(start * step, min(length, stop * step), cells * step, wraps)
        low, high = float(boundaries[start]), float(boundaries[stop])
        span = (length - low) + high if wraps else high - low
        return Gap(low, high, span, wraps)

    gaps = []
    if closed and len(starts) > 1 and starts[0] == 0 and stops[-1] == count:
        start, stop = starts.pop(), stops.pop(0)
        starts.pop(0)
        stops.pop()
        gaps.append(make_gap(start, stop, True))
    for start, stop in zip(starts, stops, strict=True):
        gaps.append(make_gap(start, stop))
    return tuple(sorted(gaps, key=lambda gap: gap.start_px))


def _scan_axis(settings):
    intervals = math.ceil(2 * settings.scan_half_width / settings.sample_spacing)
    if intervals >= 1024:
        raise ValueError("Cross-scan exceeds 1024 samples. Reduce its span or increase sample spacing.")
    cross = np.linspace(-settings.scan_half_width, settings.scan_half_width, intervals + 1)
    return cross, 2 * settings.scan_half_width / intervals


def _scan_geometry(centers, normals, calibration, image_size, settings):
    directions, limits = normals, None
    if settings.scan_mode == "plane_normal":
        directions, limits = _plane_scan_geometry(
            centers, normals, calibration, image_size=image_size, settings=settings,
        )
    if settings.nominal_width is not None:
        midpoints = np.array([-settings.nominal_width / 2, settings.nominal_width / 2])
        limits = np.column_stack((midpoints - settings.edge_search_radius, midpoints + settings.edge_search_radius))
    return directions, limits


def _sample_profiles(signal, maps, valid, sigma, kernel):
    profiles = cv2.remap(signal, maps, None, cv2.INTER_LINEAR).astype(np.float64)
    if not np.isfinite(profiles[valid]).all():
        raise ValueError("Image contains nonfinite cross-scan samples.")
    if sigma:
        profiles = cv2.GaussianBlur(profiles, (kernel, 1), sigmaX=sigma, borderType=cv2.BORDER_REPLICATE)
    return profiles


@dataclass(frozen=True)
class _ScanTrace:
    offsets: np.ndarray
    endpoints: np.ndarray
    intensity: np.ndarray | None
    gradient: np.ndarray | None
    bands: np.ndarray | None
    edges: np.ndarray | None


def _trace_station(signal, station, settings, calibration):
    """Resample one completed station using the same image-space scan as inspection."""
    cross, pitch = _scan_axis(settings)
    center = np.array([station.point])
    directions, bands = _scan_geometry(center, np.array([station.normal]), calibration, signal.shape[::-1], settings)
    direction = directions[0]
    points = center + cross[:, None] * direction
    if bands is not None and bands.ndim == 3:
        bands = bands[0]
    intensity = gradient = edges = None
    if station.status not in ("corner", "masked", "clipped"):
        sigma = settings.smoothing_sigma / pitch
        kernel = 2 * math.ceil(3 * sigma) + 1
        intensity = _sample_profiles(signal, points[None].astype(np.float32), [True], sigma, kernel)[0]
        sign = 1 if settings.polarity == "bright" else -1
        gradient = sign * np.diff(intensity) / pitch
        if station.edges is not None:
            edges = (np.asarray(station.edges) - center) @ direction
    return _ScanTrace(cross, points[[0, -1]], intensity, gradient, bands, edges)


def measure_path(
    image: np.ndarray,
    vertices,
    settings: PathWidthSettings = PathWidthSettings(),
    *,
    closed: bool = False,
    mask: np.ndarray | None = None,
    calibration: dict | None = None,
) -> PathWidthResult:
    """Measure paired edges across an ordered path in grayscale image pixels.

    Vertices are [x, y] and positive offsets follow the normal (-dy, dx).
    A nonzero mask admits bilinear samples only when their contributing pixels
    are all selected. Sample widths and settings use image pixels, except
    min_gradient, which uses native intensity units per image pixel, and
    the physical spacing, bands, and limits, which require a matching planar calibration.
    Plane-normal scans change the scan direction while keeping pixel sampling.
    """
    if calibration is None:
        if settings.scan_mode == "plane_normal":
            raise ValueError("Plane-normal scans require a planar calibration profile.")
        if settings.station_spacing_physical is not None:
            raise ValueError("Physical station spacing requires a planar calibration profile.")
        if settings.requires_calibration:
            raise ValueError("Physical limits require a planar calibration profile.")
    image = np.asarray(image)
    if (image.ndim != 2 or image.dtype not in (np.uint8, np.uint16, np.float32)
            or min(image.shape) < 2 or max(image.shape) >= 32767):
        raise ValueError("Expected a 2D uint8, uint16, or float32 image with axes from 2 to 32766.")
    selection = None
    if mask is not None:
        mask = np.asarray(mask)
        if mask.shape != image.shape or mask.dtype not in (np.bool_, np.uint8):
            raise ValueError("Mask must be boolean or uint8 and match the image shape.")
        selection = (mask != 0).astype(np.float32)
    if not isinstance(closed, bool):
        raise ValueError("closed must be boolean.")
    grid = None
    if settings.station_spacing_physical is not None:
        grid = _physical_station_grid(vertices, closed, calibration, image_size=image.shape[::-1], settings=settings)
    path, length, step, distances, centers, normals, corners = path_stations(
        vertices, closed, settings.station_spacing, settings.corner_angle, settings.corner_margin, grid=grid,
    )
    cross, pitch = _scan_axis(settings)
    scan_directions, limits = _scan_geometry(centers, normals, calibration, image.shape[::-1], settings)
    bands, bands_by_station, bands_fit = None, None, None
    if limits is not None:
        gradient_positions = cross[:-1] + pitch / 2
        lower = np.searchsorted(gradient_positions, limits[..., 0])
        upper = np.searchsorted(gradient_positions, limits[..., 1], side="right")
        if limits.ndim == 2:
            bands = tuple(zip(lower, upper, strict=True))
        else:
            bands_by_station = np.stack((lower, upper), axis=-1)
            bands_fit = np.all(np.abs(limits) <= settings.scan_half_width, axis=(1, 2))
    sigma = settings.smoothing_sigma / pitch
    kernel = 2 * math.ceil(3 * sigma) + 1
    signal = image.astype(np.float32, copy=False)
    image_limit = np.asarray(image.shape[::-1]) - 1
    sign = 1 if settings.polarity == "bright" else -1
    rows = []
    candidates = {} if settings.edge_continuity else None

    for first in range(0, len(distances), 256):
        batch = slice(first, first + 256)
        points = centers[batch, None, :] + scan_directions[batch, None, :] * cross[None, :, None]
        inside = np.all((points >= 0) & (points <= image_limit), axis=(1, 2))
        if bands_fit is not None:
            inside &= bands_fit[batch]
        maps = np.where(inside[:, None, None], points, 0).astype(np.float32)
        valid = inside & ~corners[batch]
        if selection is not None:
            valid &= np.all(cv2.remap(selection, maps, None, cv2.INTER_LINEAR) == 1, axis=1)
        profiles = _sample_profiles(signal, maps, valid, sigma, kernel)
        for i, profile in enumerate(profiles):
            index = first + i
            # Keep the image path normal for calibrated reporting. Detected
            # endpoints follow the actual scan direction, which may differ.
            point, normal = centers[index], normals[index]
            fields = (float(distances[index]), tuple(point.tolist()), tuple(normal.tolist()))
            if not valid[i]:
                status = "corner" if corners[index] else "masked" if inside[i] else "clipped"
                rows.append(Station(*fields, status))
                continue
            search_bands = bands if bands_by_station is None else bands_by_station[index]
            if candidates is not None:
                choices = _band_candidates(profile, pitch, sign, settings.min_gradient, search_bands)
                if choices is not None:
                    candidates[index] = choices
                rows.append(Station(*fields, "missing"))
                continue
            status, offsets, strengths = _edge_pair(profile, pitch, sign, settings.min_gradient, search_bands)
            if offsets is None:
                rows.append(Station(*fields, status))
            else:
                rows.append(_measured_station(fields, offsets, strengths, settings, scan_directions[index]))

    if candidates:
        spacings = np.full(len(rows), step) if grid is None else np.diff(np.r_[distances, distances[0] + length])
        for index in candidates:
            row = rows[index]
            fields = row.distance_px, row.point, row.normal
            selected = _continuous_pair(candidates, index, len(rows), spacings, settings.edge_continuity, closed)
            rows[index] = (
                Station(*fields, "ambiguous") if selected is None
                else _measured_station(fields, *selected, settings, scan_directions[index])
            )

    widths = [row.width_px for row in rows if row.width_px is not None]
    gaps = _gaps([row.status == "missing" for row in rows], step, length, closed, None if grid is None else grid[1])
    coverage = len(widths) / len(rows)
    observed = sum(row.status not in ("corner", "clipped", "masked") for row in rows) / len(rows)
    longest = max((gap.length_px for gap in gaps), default=0.)
    failures = []
    if not widths:
        failures.append("no_width_measurements")
    if coverage < settings.min_coverage:
        failures.append("coverage_below_minimum")
    if settings.max_gap is not None and longest > settings.max_gap:
        failures.append("gap_above_maximum")
    if any(row.issues for row in rows):
        failures.append("station_out_of_tolerance")
    result = PathWidthResult(
        tuple(tuple(point.tolist()) for point in path), closed, length, step if grid is None else None, tuple(rows), gaps,
        min(widths, default=None), max(widths, default=None), float(np.mean(widths)) if widths else None,
        coverage, observed, longest, not failures, tuple(failures),
    )
    if calibration is None:
        return result
    physical = calibrate_result(result, calibration, image_size=image.shape[::-1], settings=settings)
    return replace(
        result, physical_measurements=physical,
        passed=result.passed and not physical.failures, failures=(*result.failures, *physical.failures),
    )
