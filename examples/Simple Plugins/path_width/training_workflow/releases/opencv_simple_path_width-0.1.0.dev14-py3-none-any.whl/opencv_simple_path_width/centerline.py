"""Trace an editable image-space route through a reference foreground mask."""

import math
from dataclasses import dataclass

import cv2
import numpy as np

from .geometry import MAX_VERTICES, path_vertices
from .measurement import Point

_MAX_MASK_PIXELS = 64_000_000
_MAX_SKELETON_PIXELS = 100_000


@dataclass(frozen=True)
class PathDraft:
    vertices: tuple[Point, ...]
    closed: bool

    def __post_init__(self):
        if not isinstance(self.closed, bool):
            raise ValueError("closed must be boolean.")
        vertices = path_vertices(self.vertices, self.closed)
        object.__setattr__(self, "vertices", tuple(map(tuple, vertices.tolist())))


def _seed_label(seed, labels):
    point = np.asarray(seed, dtype=float)
    if point.shape != (2,) or not np.isfinite(point).all():
        raise ValueError("A trace point requires finite [x, y] coordinates.")
    x, y = np.rint(point)
    if not (0 <= x < labels.shape[1] and 0 <= y < labels.shape[0]) or labels[int(y), int(x)] == 0:
        raise ValueError("Trace points must be inside the foreground mask.")
    return int(labels[int(y), int(x)])


def _component(mask, start, end):
    count, labels, stats, _ = cv2.connectedComponentsWithStats(
        np.ascontiguousarray(mask != 0, dtype=np.uint8), connectivity=8,
    )
    if count <= 1:
        raise ValueError("Reference mask has no foreground.")
    if start is None and count > 2:
        raise ValueError("Reference mask has multiple components. Choose a start point on the intended bead.")
    label = 1 if start is None else _seed_label(start, labels)
    if end is not None and _seed_label(end, labels) != label:
        raise ValueError("Start and end points must be on the same foreground component.")
    x, y, width, height = stats[label, :4]
    return labels[y:y + height, x:x + width] == label, np.array([x, y])


def _skeleton_graph(mask):
    try:
        from skimage.graph import pixel_graph
        from skimage.morphology import skeletonize
    except ModuleNotFoundError as error:
        if error.name != "skimage":
            raise
        raise ValueError("Install the optional [trace] extra to extract a centerline.") from error

    skeleton = skeletonize(np.pad(mask, 1))[1:-1, 1:-1]
    count = np.count_nonzero(skeleton)
    if not 2 <= count <= _MAX_SKELETON_PIXELS:
        raise ValueError(f"A trace requires 2 to {_MAX_SKELETON_PIXELS} skeleton pixels.")
    graph, flat = pixel_graph(skeleton, connectivity=2)
    y, x = np.divmod(flat, skeleton.shape[1])
    # A diagonal across a connected right-angle corner would make a false branch.
    rows = np.repeat(np.arange(len(flat)), np.diff(graph.indptr))
    columns = graph.indices
    diagonal = (x[rows] != x[columns]) & (y[rows] != y[columns])
    graph.data[diagonal & (skeleton[y[rows], x[columns]] | skeleton[y[columns], x[rows]])] = 0
    graph.eliminate_zeros()
    return graph, np.column_stack((x, y))


def _closest(points, seed):
    return int(np.argmin(np.sum((points - seed) ** 2, axis=1)))


def _shortest_route(graph, start, end):
    from scipy.sparse.csgraph import dijkstra

    if start == end:
        raise ValueError("Start and end points select the same location on the centerline.")
    distances, previous = dijkstra(graph, directed=False, indices=start, return_predecessors=True)
    if not np.isfinite(distances[end]):
        raise ValueError("Could not connect the selected trace points.")
    route = [end]
    while route[-1] != start:
        route.append(int(previous[route[-1]]))
    return route[::-1]


def _ordered_route(graph, points, start, end):
    if end is not None:
        return _shortest_route(graph, _closest(points, start), _closest(points, end)), False

    degrees = np.diff(graph.indptr)
    endpoints = np.flatnonzero(degrees == 1)
    if np.any((degrees == 0) | (degrees > 2)) or len(endpoints) not in (0, 2):
        raise ValueError("The centerline has branches. Choose a start and end point to select a route.")
    closed = len(endpoints) == 0
    choices = np.arange(len(points)) if closed else endpoints
    index = int(choices[0] if start is None else choices[_closest(points[choices], start)])
    route = []
    previous = -1
    while len(route) < len(points):
        route.append(index)
        neighbors = graph.indices[graph.indptr[index]:graph.indptr[index + 1]]
        following = next((int(candidate) for candidate in neighbors if candidate != previous), -1)
        if following == -1 or following == route[0]:
            break
        previous, index = index, following
    if len(route) != len(points):
        raise ValueError("The centerline has disconnected segments. Select a start and end point.")
    if closed:
        x, y = points[route].T
        if x @ np.roll(y, -1) - y @ np.roll(x, -1) < 0:
            route[1:] = route[:0:-1]
    return route, closed


def _within_mask(points, component, closed):
    drawn = np.zeros(component.shape, np.uint8)
    vertices = np.rint(points * 16).astype(np.int32)
    cv2.polylines(drawn, [vertices], closed, 1, 1, cv2.LINE_8, shift=4)
    return not np.any(drawn[~component])


def _smooth_path(points, component, closed, tolerance):
    pad = np.pad(points.astype(float), ((3, 3), (0, 0)), mode="wrap" if closed else "edge")
    smoothed = cv2.GaussianBlur(pad, (1, 7), sigmaX=1.2, sigmaY=1.2)[3:-3]
    smoothed[0] = points[0]
    if not closed:
        smoothed[-1] = points[-1]
    if _within_mask(smoothed, component, closed):
        points = smoothed

    def simplify(piece):
        return cv2.approxPolyDP(piece.astype(np.float32), tolerance, False).reshape(-1, 2)

    if closed:
        middle = len(points) // 2
        first = simplify(points[:middle + 1])
        last = simplify(np.vstack((points[middle:], points[0])))
        simplified = np.vstack((first[:-1], last[:-1]))
    else:
        simplified = simplify(points)
    if len(simplified) >= (3 if closed else 2) and _within_mask(simplified, component, closed):
        return simplified
    return points


def extract_centerline(
    mask: np.ndarray, *, start: Point | None = None, end: Point | None = None,
    reverse: bool = False, simplify_px: float = 0.75,
) -> PathDraft:
    """Propose a smooth ordered path from one foreground component.

    A lone start selects a component and chooses an open end or closed seam.
    Two points select the shortest route between them, including at branches.
    """
    mask = np.asarray(mask)
    if (mask.ndim != 2 or mask.dtype not in (np.bool_, np.uint8)
            or min(mask.shape) < 2 or max(mask.shape) >= 32767 or mask.size > _MAX_MASK_PIXELS):
        raise ValueError("Expected a 2D boolean or uint8 reference mask within 64 million pixels.")
    if end is not None and start is None:
        raise ValueError("An end point requires a start point.")
    if not isinstance(reverse, bool) or not math.isfinite(simplify_px) or not 0 <= simplify_px <= 20:
        raise ValueError("reverse must be boolean and simplify_px must be between 0 and 20.")
    component, origin = _component(mask, start, end)
    graph, points = _skeleton_graph(component)
    route, closed = _ordered_route(graph, points + origin, start, end)
    vertices = _smooth_path(points[route], component, closed, simplify_px) + origin
    if len(vertices) > MAX_VERTICES:
        raise ValueError("Centerline exceeds the vertex limit. Increase simplify_px or select a shorter route.")
    if reverse:
        vertices = np.vstack((vertices[0], vertices[:0:-1])) if closed else vertices[::-1]
    return PathDraft(vertices, closed)
