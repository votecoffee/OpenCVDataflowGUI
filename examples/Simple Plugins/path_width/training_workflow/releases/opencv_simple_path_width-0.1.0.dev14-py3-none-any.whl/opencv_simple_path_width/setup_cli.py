"""Save a reference image, path alignment, and inspection settings as a recipe."""

import argparse
import json
import math
from dataclasses import asdict, replace
from pathlib import Path

import cv2

from .cad import load_dxf
from .cli import _read_gray, _read_json, _read_path
from .measurement import PathWidthSettings
from .recipe import PathWidthRecipe, fit_alignment, save_recipe


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reference", type=Path, help="Training reference image")
    parser.add_argument("path", type=Path, help="Ordered JSON vertices or a modelspace DXF")
    parser.add_argument("recipe", type=Path, help="Output .spw recipe")
    parser.add_argument("--layer", help="Modelspace layer containing the DXF path")
    parser.add_argument("--curve-tolerance", type=float, default=.05, help="DXF curve flattening in drawing units")
    parser.add_argument("--join-tolerance", type=float, default=1e-5, help="DXF endpoint matching in drawing units")
    parser.add_argument("--reverse", action="store_true", help="Reverse the path direction")
    alignment = parser.add_mutually_exclusive_group()
    alignment.add_argument("--transform", type=Path, help="Source-to-reference affine matrix JSON")
    alignment.add_argument("--landmarks", type=Path, help="JSON with source and reference [x, y] pairs")
    parser.add_argument("--max-alignment-error", type=float, help="Reject a landmark fit above this maximum pixel residual")
    parser.add_argument("--settings", type=Path, help="JSON object with PathWidthSettings fields")
    args = parser.parse_args(argv)
    try:
        if args.recipe.suffix.lower() != ".spw":
            raise ValueError("Recipe output must use the .spw extension.")
        inputs = (args.reference, args.path, args.settings, args.transform, args.landmarks)
        if any(path and path.resolve() == args.recipe.resolve() for path in inputs):
            raise ValueError("Recipe output must be distinct from the inputs.")
        if args.max_alignment_error is not None and (
                args.landmarks is None or not math.isfinite(args.max_alignment_error) or args.max_alignment_error < 0):
            raise ValueError("Maximum alignment error must be finite and nonnegative and requires landmarks.")

        units = None
        if args.path.suffix.lower() == ".dxf":
            cad = load_dxf(args.path, args.layer, curve_tolerance=args.curve_tolerance,
                           join_tolerance=args.join_tolerance)
            vertices, closed, units = cad.vertices, cad.closed, cad.units
        else:
            if args.layer:
                raise ValueError("Layer selection requires a DXF path.")
            vertices, closed = _read_path(args.path)

        fit = None
        matrix = _read_json(args.transform) if args.transform else None
        if args.transform and matrix is None:
            raise ValueError("Transform JSON must contain a source-to-reference affine matrix.")
        if args.landmarks:
            pairs = _read_json(args.landmarks)
            fit = fit_alignment(pairs["source"], pairs["reference"])
            if args.max_alignment_error is not None and fit.max_error_px > args.max_alignment_error:
                raise ValueError(f"Maximum landmark residual {fit.max_error_px:.3f} px exceeds the configured limit.")
            matrix = fit.matrix
        settings = PathWidthSettings(**_read_json(args.settings)) if args.settings else PathWidthSettings()
        recipe = PathWidthRecipe(vertices, closed, settings, matrix, units)
        if args.reverse:
            path = (recipe.vertices[0], *recipe.vertices[:0:-1]) if closed else recipe.vertices[::-1]
            recipe = replace(recipe, vertices=path)
        save_recipe(args.recipe, recipe, _read_gray(args.reference))
        print(json.dumps({
            "recipe": str(args.recipe), "vertices": len(recipe.vertices), "closed": closed,
            "cad_units": units, "alignment": asdict(fit) if fit is not None else None,
        }, indent=2))
    except (OSError, KeyError, TypeError, ValueError, cv2.error) as error:
        parser.error(str(error))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
