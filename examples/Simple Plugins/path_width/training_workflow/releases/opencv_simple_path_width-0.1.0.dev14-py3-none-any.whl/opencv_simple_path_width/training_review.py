"""Geometric setup guides; never sample pixels or choose measured edges."""

from dataclasses import dataclass, replace

import numpy as np

from .calibration import _measurement_profile, _physical_station_grid, _project
from .geometry import path_stations
from .measurement import _PHYSICAL_LIMITS, _scan_axis, _scan_geometry


@dataclass(frozen=True)
class SetupGuide:
    length_px: float
    length_physical: float | None
    units: str
    centers: np.ndarray
    directions: np.ndarray
    endpoints: np.ndarray
    bands: np.ndarray | None
    corners: np.ndarray
    inside: np.ndarray
    bands_fit: np.ndarray
    pixel_only: bool


def inspect_setup(recipe, image_size, calibration=None):
    """Use the detector's exact station/scan geometry without running inspection.

    Geometry cannot establish edge visibility, mask coverage or measurement
    accuracy. Physical limits without a profile allow the existing pixel-only
    preview; physical station spacing and plane-normal scans require a profile.
    """
    settings = recipe.settings
    _scan_axis(settings)  # Enforce the same bounded sampling budget.
    pixel_only = calibration is None and settings.requires_calibration
    if calibration is None:
        if (
            settings.scan_mode == "plane_normal"
            or settings.station_spacing_physical is not None
        ):
            raise ValueError(
                "Attach a preview calibration for plane-normal scans or physical station spacing."
            )
        if pixel_only:
            settings = replace(settings, **dict.fromkeys(_PHYSICAL_LIMITS))
    vertices = recipe.reference_vertices()
    grid = None
    if settings.station_spacing_physical is not None:
        grid = _physical_station_grid(
            vertices,
            recipe.closed,
            calibration,
            image_size=image_size,
            settings=settings,
        )
    path, length, _, _, centers, normals, corners = path_stations(
        vertices,
        recipe.closed,
        settings.station_spacing,
        settings.corner_angle,
        settings.corner_margin,
        grid=grid,
    )
    directions, bands = _scan_geometry(
        centers, normals, calibration, image_size, settings
    )
    if bands is not None:
        bands = np.broadcast_to(bands, (len(centers), 2, 2)).copy()
    endpoints = (
        centers[:, None, :]
        + directions[:, None, :]
        * np.array(
            [-settings.scan_half_width, settings.scan_half_width],
        )[None, :, None]
    )
    inside = np.all(
        (endpoints >= 0) & (endpoints <= np.asarray(image_size) - 1), axis=(1, 2)
    )
    bands_fit = (
        np.ones(len(centers), dtype=bool)
        if bands is None
        else np.all(
            np.abs(bands) <= settings.scan_half_width,
            axis=(1, 2),
        )
    )
    physical_length, units = None, "px"
    if calibration is not None:
        matrix, _, units, _ = _measurement_profile(calibration, image_size, settings)
        chain = np.vstack((path, path[0])) if recipe.closed else path
        physical_length = float(
            np.linalg.norm(np.diff(_project(chain, matrix), axis=0), axis=1).sum()
        )
    return SetupGuide(
        length,
        physical_length,
        units,
        centers,
        directions,
        endpoints,
        bands,
        corners,
        inside,
        bands_fit,
        pixel_only,
    )
