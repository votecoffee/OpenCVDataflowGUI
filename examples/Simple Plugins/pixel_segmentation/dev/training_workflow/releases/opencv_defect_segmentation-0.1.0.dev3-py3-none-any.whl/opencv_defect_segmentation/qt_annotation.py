"""Optional Qt front end for native-grid annotation."""

import math
from pathlib import Path

import cv2
import numpy as np
from PySide6.QtCore import QPointF, QRectF, Qt, Signal, QTimer
from PySide6.QtGui import QActionGroup, QColor, QImage, QKeySequence, QPainter, QPen, QPolygonF
from PySide6.QtWidgets import (
    QApplication, QComboBox, QDoubleSpinBox, QFileDialog, QLabel, QMainWindow, QMessageBox, QSpinBox, QToolBar, QWidget,
)

from . import DEFECT, IGNORE, NORMAL, PixelSegmenter, defect_mask_from_scores
from .annotation import MaskDraft, Selection, annotation_entries, connected_selection, wand_selection
from .evaluation import _COMPARISON_COLORS, _comparison_classes, _comparison_counts, metrics
from .image_io import read_image


_PALETTE = np.array([(0, 0, 0, 0), (35, 164, 246, 117), (238, 47, 49, 150)], dtype=np.uint8)
_OUTSIDE = (0, 0, 0, 112)
_PREDICTED = (255, 210, 34, 125)
_SELECTION = (110, 245, 207, 94)
_COMPARISON = np.column_stack((_COMPARISON_COLORS, np.array([0, 155, 0, 185, 185, 185], dtype=np.uint8)))


def _qimage(array, format):
    return QImage(array.data, array.shape[1], array.shape[0], array.strides[0], format)


def _segment_distance(point, a, b):
    vx, vy = b[0] - a[0], b[1] - a[1]
    dx, dy = point[0] - a[0], point[1] - a[1]
    if vx or vy:
        amount = min(1., max(0., (dx*vx + dy*vy) / (vx*vx + vy*vy)))
        dx, dy = dx - amount*vx, dy - amount*vy
    return math.hypot(dx, dy)


class PatchView(QWidget):
    changed = Signal()
    labels_edited = Signal()
    cursor_pixel = Signal(int, int, int)
    label_requested = Signal(int)

    def __init__(self):
        super().__init__()
        self.setMouseTracking(True)
        self.setMinimumSize(320, 240)
        self.draft = None
        self.label = DEFECT
        self.brush = 3
        self._zoom = 1.
        self._offset = QPointF()
        self._last_paint = None
        self._last_pan = None
        self._prediction = QImage()
        self._comparing = False
        self._show_labels = True
        self._boost = True
        self.tool = "brush"
        self.wand_tolerance = 0
        self.clear_selection()

    def set_case(self, pixels, draft):
        self.pixels, self.draft = pixels, draft
        self._last_paint = self._last_pan = None
        self.clear_selection()
        self._set_prediction_image(None)
        self._label_bytes = np.empty((*pixels.shape, 4), dtype=np.uint8)
        self._labels = _qimage(self._label_bytes, QImage.Format.Format_RGBA8888)
        self.refresh_labels()
        self.set_contrast(self._boost)
        self.fit()

    def set_contrast(self, boost):
        self._boost = boost
        if self.draft is None:
            return
        upper = np.iinfo(self.pixels.dtype).max
        low, high = 0, upper
        if boost and self.draft.allowed.any():
            low, high = np.percentile(self.pixels[self.draft.allowed], (1, 99))
            if high <= low:
                low, high = 0, upper
        self._display_bytes = np.clip((self.pixels.astype(np.float32) - low) * (255 / (high - low)),
                                      0, 255).astype(np.uint8)
        self._image = _qimage(self._display_bytes, QImage.Format.Format_Grayscale8)
        self.update()

    def refresh_labels(self, rect=None):
        if rect is None:
            area = np.s_[:, :]
        else:
            x, y, width, height = rect
            area = np.s_[y:y + height, x:x + width]
        overlay = self._label_bytes[area]
        overlay[:] = _PALETTE[self.draft.labels[area]]
        overlay[~self.draft.allowed[area]] = _OUTSIDE
        self.update()

    def show_labels(self, visible):
        self._show_labels = visible
        self.update()

    def set_prediction(self, mask):
        overlay = None
        if mask is not None:
            overlay = np.zeros((*mask.shape, 4), np.uint8)
            overlay[mask] = _PREDICTED
        self._set_prediction_image(overlay)

    def _set_prediction_image(self, overlay, *, comparing=False):
        self._prediction = QImage()
        self._predicted_bytes = overlay
        self._comparing = comparing
        if overlay is not None:
            self._prediction = _qimage(overlay, QImage.Format.Format_RGBA8888)
        self.update()

    def set_heatmap(self, score):
        observed = np.isfinite(score)
        values = (np.clip(np.where(observed, score, 0), 0, 1) * 255).astype(np.uint8)
        colors = cv2.applyColorMap(values, cv2.COLORMAP_TURBO)
        overlay = cv2.cvtColor(colors, cv2.COLOR_BGR2RGBA)
        overlay[..., 3] = np.where(observed, 160, 0)
        self._set_prediction_image(overlay)

    def compare_prediction(self, predicted, observed):
        classes = _comparison_classes(self.draft.labels, observed, predicted)
        overlay = _COMPARISON[classes]
        overlay[~observed] = _OUTSIDE
        self._set_prediction_image(overlay, comparing=True)
        return _comparison_counts(classes)

    def fit(self):
        if self.draft is None:
            return
        height, width = self.pixels.shape
        self._zoom = min(self.width() / width, self.height() / height)
        self._center()

    def native(self):
        if self.draft is not None:
            self._zoom = 1.
            self._center()

    def _center(self):
        height, width = self.pixels.shape
        self._offset = QPointF((self.width() - width * self._zoom) / 2,
                               (self.height() - height * self._zoom) / 2)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor("#202124"))
        if self.draft is None:
            return
        height, width = self.pixels.shape
        rect = QRectF(self._offset.x(), self._offset.y(), width * self._zoom, height * self._zoom)
        painter.drawImage(rect, self._image)
        if not self._prediction.isNull():
            painter.drawImage(rect, self._prediction)
        if self._show_labels and not self._comparing:
            painter.drawImage(rect, self._labels)
        self._paint_selection(painter, rect)

    def wheelEvent(self, event):
        if self.draft is None or event.angleDelta().y() == 0:
            return
        position = event.position()
        target = self._zoom * 1.25 ** (event.angleDelta().y() / 120)
        target = min(max(target, min(.04, self._zoom)), max(24., self._zoom))
        self._offset = position - (position - self._offset) * (target / self._zoom)
        self._zoom = target
        self.update()
        event.accept()

    def _pixel(self, position):
        local = (position - self._offset) / self._zoom
        return math.floor(local.x()), math.floor(local.y())

    @property
    def has_selection(self):
        return self._selection is not None

    def clear_selection(self):
        self._selection = self._replace = self._wand_seed = self._drag = None
        self._polygon_open = False
        self._selected = self._selection_bytes = None
        self._selection_image = QImage()
        self.update()

    def set_tool(self, tool):
        self.finish_stroke()
        self.tool = tool
        self.changed.emit()

    def set_tolerance(self, value):
        self.wand_tolerance = value
        if self._wand_seed is not None:
            self._wand(self._wand_seed)

    def load_selection(self, selected):
        self.clear_selection()
        self._selection = Selection.trace(selected & self.draft.allowed)
        self._refresh_selection()
        self.changed.emit()

    def _wand(self, point):
        if not self.draft.allowed[point[1], point[0]]:
            return
        self.load_selection(wand_selection(self.pixels, self.draft.allowed, point, self.wand_tolerance))
        self._wand_seed = point

    def _refresh_selection(self):
        self._selection_image = QImage()
        self._selection_bytes = self._selected = None
        if self._selection is not None and not self._polygon_open:
            self._selected = self._selection.raster(self.pixels.shape) & self.draft.allowed
            self._selection_bytes = np.zeros((*self.pixels.shape, 4), np.uint8)
            self._selection_bytes[self._selected] = _SELECTION
            self._selection_image = _qimage(self._selection_bytes, QImage.Format.Format_RGBA8888)
        self.update()

    def _paint_selection(self, painter, rect):
        if self._selection is None:
            return
        if not self._selection_image.isNull():
            painter.drawImage(rect, self._selection_image)
        pen = QPen(QColor("#6ef5cf"))
        pen.setWidthF(1.5)
        painter.setPen(pen)

        def screen(point):
            return self._offset + QPointF((point[0]+.5)*self._zoom, (point[1]+.5)*self._zoom)

        for path in self._selection.paths if self._selection.kind == "polygon" else ():
            points = QPolygonF([screen(point) for point in path])
            if self._polygon_open:
                painter.drawPolyline(points)
            else:
                painter.drawPolygon(points)
        for _, _, point in self._selection.handles():
            center = screen(point)
            painter.fillRect(QRectF(center.x()-3, center.y()-3, 6, 6), QColor("#6ef5cf"))

    def finish_polygon(self):
        if not self._polygon_open or len(set(self._selection.paths[0])) < 3:
            return False
        self._polygon_open = False
        self._refresh_selection()
        self.changed.emit()
        return True

    def apply_region(self):
        if self._polygon_open and not self.finish_polygon():
            return False
        if self._selected is None or not self._selected.any():
            return False
        if self.draft.apply_selection(self._selected, self.label, replace=self._replace):
            self.refresh_labels()
            self.labels_edited.emit()
        self.clear_selection()
        self.changed.emit()
        return True

    def _near_handle(self, point):
        handles = self._selection.handles()
        if handles:
            nearest = min(handles, key=lambda h: math.dist(point, h[2]))
            if math.dist(point, nearest[2])*self._zoom <= 7:
                return nearest
        return None

    def _begin_selection(self, point):
        selection = self._selection
        if self._polygon_open:
            points = selection.paths[0]
            if len(points) >= 3 and math.dist(point, points[0])*self._zoom <= 7:
                self.finish_polygon()
            elif point != points[-1]:
                points.append(point)
                self.update()
            return
        if selection is not None:
            handle = self._near_handle(point)
            if handle is not None:
                ring, index, _ = handle
                self._wand_seed = None
                if selection.kind == "polygon":
                    self._drag = ("point", ring, index)
                else:
                    self._drag = ("box", selection.handles()[(index+2) % 4][2])
                return
            if selection.kind == "polygon":
                edges = [(r, i, _segment_distance(point, path[i-1], p))
                         for r, path in enumerate(selection.paths) for i, p in enumerate(path) if len(path)>1]
                if edges:
                    ring, index, distance = min(edges, key=lambda edge: edge[2])
                    if distance*self._zoom <= 6:
                        selection.paths[ring].insert(index, point)
                        self._wand_seed = None
                        self._drag = ("point", ring, index)
                        self._refresh_selection()
                        return
            if self._selected is not None and self._selected[point[1], point[0]]:
                self._wand_seed = None
                self._drag = ("move", point, selection.copy())
            return
        if self.tool == "wand":
            self._wand(point)
        elif self.tool == "edit":
            label = int(self.draft.labels[point[1], point[0]])
            if label != IGNORE:
                selected = connected_selection((self.draft.labels == label) & self.draft.allowed, point)
                if selected.any():
                    self.load_selection(selected)
                    self._replace = selected
                    self.label_requested.emit(label)
        elif self.tool == "polygon":
            self._selection = Selection("polygon", [[point]])
            self._polygon_open = True
            self.update()
            self.changed.emit()
        elif self.tool != "brush":
            self._selection = Selection(self.tool, [[point, point]])
            self._drag = ("box", point)
            self._refresh_selection()
            self.changed.emit()

    def _drag_selection(self, point):
        kind, *args = self._drag
        if kind == "point":
            ring, index = args
            self._selection.paths[ring][index] = point
        elif kind == "move":
            origin, before = args
            self._selection = before.copy()
            self._selection.translate(point[0]-origin[0], point[1]-origin[1], self.pixels.shape)
        else:
            origin, = args
            if self._selection.kind == "circle":
                x, y = origin
                sx = -1 if point[0] < x else 1
                sy = -1 if point[1] < y else 1
                height, width = self.pixels.shape
                size = min(max(abs(point[0]-x), abs(point[1]-y)),
                           x if sx<0 else width-1-x, y if sy<0 else height-1-y)
                point = x+sx*size, y+sy*size
            self._selection.paths[0] = [origin, point]
        self._refresh_selection()

    def _remove_vertex(self, point):
        if self._selection is None or self._selection.kind != "polygon":
            return
        handle = self._near_handle(point)
        if handle is not None:
            ring, index, _ = handle
            points = self._selection.paths[ring]
            if len(points) > (1 if self._polygon_open else 3):
                points.pop(index)
                self._wand_seed = None
                self._refresh_selection()

    def mousePressEvent(self, event):
        if self.draft is None:
            return
        if event.button() == Qt.MouseButton.MiddleButton:
            self._last_pan = event.position()
        elif event.button() in (Qt.MouseButton.LeftButton, Qt.MouseButton.RightButton):
            x, y = self._pixel(event.position())
            if 0 <= x < self.pixels.shape[1] and 0 <= y < self.pixels.shape[0]:
                if event.button() == Qt.MouseButton.RightButton:
                    self._remove_vertex((x, y))
                elif self._selection is not None or self.tool != "brush":
                    self._begin_selection((x, y))
                else:
                    self.draft.begin_stroke()
                    self._last_paint = (x, y)
                    self._paint_to((x, y))

    def mouseMoveEvent(self, event):
        if self.draft is None:
            return
        if self._last_pan is not None:
            self._offset += event.position() - self._last_pan
            self._last_pan = event.position()
            self.update()
        x, y = self._pixel(event.position())
        height, width = self.pixels.shape
        if 0 <= x < width and 0 <= y < height:
            self.cursor_pixel.emit(x, y, int(self.pixels[y, x]))
        point = min(max(x, 0), width - 1), min(max(y, 0), height - 1)
        if self._last_paint is not None:
            self._paint_to(point)
        if self._drag is not None:
            self._drag_selection(point)

    def _paint_to(self, point):
        rect = self.draft.paint(self._last_paint, point, self.label, self.brush)
        self._last_paint = point
        if rect is not None:
            self.refresh_labels(rect)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.finish_stroke()
            if self._drag is not None:
                x, y = self._pixel(event.position())
                height, width = self.pixels.shape
                self._drag_selection((min(max(x, 0), width - 1), min(max(y, 0), height - 1)))
            self._drag = None
        elif event.button() == Qt.MouseButton.MiddleButton:
            self._last_pan = None

    def finish_stroke(self):
        if self._last_paint is not None:
            edited = self.draft.end_stroke()
            self._last_paint = None
            if edited:
                self.labels_edited.emit()
            self.changed.emit()


class AnnotationWindow(QMainWindow):
    labels_saved = Signal()
    settings_kept = Signal(float, int)

    def __init__(self, entries, *, region=None, model=None, threshold=.5, min_area_px=1,
                 compare_labels=False, allow_keep_settings=False, parent=None):
        super().__init__(parent, Qt.WindowType.Window)
        self.entries = entries
        self.region = region
        self.model = model
        self.index = 0
        self._source_depth = None
        self.view = PatchView()
        self.view.changed.connect(self._status)
        self.view.cursor_pixel.connect(self._cursor)
        self.view.label_requested.connect(self._select_label)
        self.setCentralWidget(self.view)
        self.resize(920, 720)

        tools = QToolBar("Annotation")
        tools.setMovable(False)
        self.addToolBar(tools)
        self.previous = tools.addAction("Previous", lambda: self.move(-1))
        self.next = tools.addAction("Next", lambda: self.move(1))
        save = tools.addAction("Save mask", self.save)
        save.setShortcut(QKeySequence.StandardKey.Save)
        undo = tools.addAction("Undo", self.undo)
        undo.setShortcut(QKeySequence.StandardKey.Undo)
        tools.addSeparator()
        self.labels = QActionGroup(self)
        self.labels.setExclusive(True)
        self._label_actions = {}
        for label, name, key in ((DEFECT, "Foreground", "2"), (NORMAL, "Background", "1"), (IGNORE, "Ignore", "0")):
            action = tools.addAction(name)
            action.setCheckable(True)
            action.setChecked(label == DEFECT)
            action.setShortcut(key)
            action.triggered.connect(lambda checked, value=label: setattr(self.view, "label", value))
            self.labels.addAction(action)
            self._label_actions[label] = action
        tools.addWidget(QLabel("  Brush px "))
        brush = QSpinBox()
        brush.setRange(1, 99)
        brush.setValue(self.view.brush)
        brush.valueChanged.connect(lambda value: setattr(self.view, "brush", value))
        tools.addWidget(brush)

        regions = QToolBar("Regions")
        regions.setMovable(False)
        self.addToolBarBreak()
        self.addToolBar(regions)
        self.tool = QComboBox()
        for title, mode in (("Brush","brush"), ("Polygon","polygon"), ("Rectangle","rectangle"),
                            ("Circle","circle"), ("Ellipse","ellipse"), ("Magic wand","wand"),
                            ("Edit labeled region","edit")):
            self.tool.addItem(title, mode)
        self.tool.currentIndexChanged.connect(lambda: self.view.set_tool(self.tool.currentData()))
        regions.addWidget(self.tool)
        regions.addWidget(QLabel("  Wand DN "))
        self.wand = QSpinBox()
        self.wand.setRange(0, 65535)
        self.wand.setToolTip("Maximum raw intensity difference from the seed pixel")
        self.wand.valueChanged.connect(self.view.set_tolerance)
        regions.addWidget(self.wand)
        self.finish_region = regions.addAction("Apply region", self._apply_region)
        self.finish_region.setToolTip("Apply the selection as the active label")
        enter = self.addAction("Close polygon or apply region", self._enter_region)
        enter.setShortcuts([QKeySequence("Return"), QKeySequence("Enter")])
        self.cancel_region = regions.addAction("Cancel region", self._cancel_region)
        self.cancel_region.setShortcut(QKeySequence("Escape"))
        regions.addAction("Import selection…", lambda: self._import_mask(False))
        regions.addAction("Import labels…", lambda: self._import_mask(True))

        views = QToolBar("Display")
        views.setMovable(False)
        self.addToolBarBreak()
        self.addToolBar(views)
        views.addAction("Fit", self.view.fit)
        views.addAction("1:1", self.view.native)
        contrast = views.addAction("Boost contrast")
        contrast.setCheckable(True)
        contrast.setChecked(True)
        contrast.toggled.connect(self.view.set_contrast)
        self.label_layer = views.addAction("Show labels")
        self.label_layer.setCheckable(True)
        self.label_layer.setChecked(True)
        self.label_layer.toggled.connect(self.view.show_labels)
        self.preview = views.addAction("Show prediction")
        self.preview.setCheckable(True)
        self.preview.setEnabled(model is not None)
        self.preview.toggled.connect(self._preview)
        self.heatmap = views.addAction("Score heatmap")
        self.heatmap.setCheckable(True)
        self.heatmap.setEnabled(model is not None)
        self.heatmap.toggled.connect(self._refresh_preview)
        views.addWidget(QLabel("  Cutoff "))
        self.threshold = QDoubleSpinBox()
        self.threshold.setRange(.001, 1.)
        self.threshold.setDecimals(3)
        self.threshold.setSingleStep(.025)
        self.threshold.setValue(threshold)
        self.threshold.setEnabled(model is not None)
        self.threshold.valueChanged.connect(self._refresh_preview)
        views.addWidget(self.threshold)
        views.addWidget(QLabel("  Min px "))
        self.minimum_area = QSpinBox()
        self.minimum_area.setRange(1, 2_147_483_647)
        self.minimum_area.setValue(min_area_px)
        self.minimum_area.setEnabled(model is not None)
        self.minimum_area.valueChanged.connect(self._refresh_preview)
        views.addWidget(self.minimum_area)
        self.compare = self.comparison_summary = None
        self.keep_settings = None
        self._review_ready = False
        if compare_labels:
            comparison = QToolBar("Validation")
            comparison.setMovable(False)
            self.addToolBarBreak()
            self.addToolBar(comparison)
            self.compare = comparison.addAction("Compare labels")
            self.compare.setCheckable(True)
            self.compare.setChecked(model is not None)
            self.compare.setEnabled(model is not None)
            self.compare.toggled.connect(self._refresh_preview)
            if allow_keep_settings:
                self.keep_settings = comparison.addAction("Keep preview settings", self._keep_settings)
                self.keep_settings.setToolTip("Keep this cutoff and minimum area for staging in the trainer")
                self.keep_settings.setEnabled(False)
            self.comparison_summary = QLabel()
            self.comparison_summary.setToolTip(
                "Green hit · Red missed foreground · Amber extra foreground · Purple unlabeled prediction"
            )
            comparison.addWidget(self.comparison_summary)
            self.view.labels_edited.connect(self._refresh_comparison)
        self._position = QLabel()
        self.statusBar().addPermanentWidget(self._position)
        self._load(0)

    def _load(self, index):
        entry = self.entries[index]
        pixels = read_image(entry.image)
        if pixels.ndim != 2 or not pixels.size or pixels.dtype not in (np.uint8, np.uint16):
            raise ValueError("Supply a nonempty 8- or 16-bit grayscale image.")
        valid = read_image(entry.valid) if entry.valid is not None else None
        draft = MaskDraft(pixels.shape, entry.labels, region=self.region, valid=valid)
        self.index = index
        self._valid, self._predicted = valid, None
        self.preview.setChecked(False)
        self.view.set_case(pixels, draft)
        if self._source_depth != pixels.dtype:
            self._source_depth = pixels.dtype
            maximum = np.iinfo(pixels.dtype).max
            span = float(np.ptp(np.percentile(pixels[draft.allowed], (1, 99)))) if draft.allowed.any() else maximum
            self.wand.setMaximum(maximum)
            self.wand.setValue(max(1, round(span * .03)))
        self.previous.setEnabled(index > 0)
        self.next.setEnabled(index + 1 < len(self.entries))
        self._position.clear()
        self._status()
        QTimer.singleShot(0, self.view, self.view.fit)

    def _cursor(self, x, y, value):
        score = getattr(self._predicted, "score", None)
        confidence = "" if score is None or not self.preview.isChecked() or not np.isfinite(score[y,x]) else f"    Score {score[y,x]:.3f}"
        self._position.setText(f"Pixel {x}, {y}    Raw {value}{confidence}")

    def _status(self):
        draft = self.view.draft
        name = self.entries[self.index].name
        marker = " *" if draft.dirty else ""
        self.setWindowTitle(f"Segmentation annotation · {name}{marker}")
        self.finish_region.setEnabled(self.view.has_selection)
        self.cancel_region.setEnabled(self.view.has_selection)
        if self.view._polygon_open:
            hint = "Click points · Enter to close"
        elif self.view.has_selection:
            hint = "Drag handles · Click polygon edge to add point · Right-click point to remove · Enter to apply"
        elif self.view.tool == "edit":
            hint = "Click an existing label to edit its connected region"
        else:
            hint = "Wheel zoom · Middle drag pan"
        self.statusBar().showMessage(
            f"{self.index + 1}/{len(self.entries)}   {draft.path.name}    {hint}"
        )
        self._sync_keep_settings()

    def _select_label(self, label):
        self._label_actions[label].setChecked(True)
        self.view.label = label

    def _cancel_region(self):
        self.view.clear_selection()
        self._status()

    def _enter_region(self):
        if self.view._polygon_open:
            self.view.finish_polygon()
        elif self.view.has_selection:
            self._apply_region()

    def _apply_region(self):
        if not self.view.apply_region():
            self.statusBar().showMessage("Select an observed region. A polygon needs at least three points.", 5000)

    def _import_mask(self, categorical):
        if self.view.has_selection:
            self.statusBar().showMessage("Apply or cancel the pending region before importing.", 5000)
            return
        self.view.finish_stroke()
        caption = "Import categorical labels" if categorical else "Import binary selection"
        directory = str(self.entries[self.index].image.parent)
        filename, _ = QFileDialog.getOpenFileName(self, caption, directory, "Masks (*.png *.tif *.tiff *.bmp)")
        if not filename:
            return
        try:
            labels = read_image(Path(filename))
            if categorical:
                if self.view.draft.import_labels(labels):
                    self.view.refresh_labels()
                    self.view.labels_edited.emit()
            else:
                if labels.shape != self.view.pixels.shape or labels.dtype not in (np.uint8, np.uint16):
                    raise ValueError("Import an aligned 8- or 16-bit grayscale mask.")
                selected = labels != 0
                if not (selected & self.view.draft.allowed).any():
                    raise ValueError("The mask has no foreground in the observed inspection region.")
                self.view.load_selection(selected)
        except (OSError, ValueError, cv2.error) as error:
            QMessageBox.warning(self, "Could not import mask", str(error))
        self._status()

    def _preview(self, enabled):
        if enabled and self._predicted is None:
            try:
                self._predicted = self.model.segment(self.view.pixels, region=self.region, valid=self._valid)
            except (ValueError, RuntimeError, cv2.error) as error:
                self.preview.setChecked(False)
                QMessageBox.warning(self, "Prediction unavailable", str(error))
                return
        self._refresh_preview()

    def _refresh_preview(self):
        score = getattr(self._predicted, "score", None)
        comparing = (self.compare is not None and self.compare.isChecked()
                     and self.preview.isChecked() and score is not None
                     and not self.heatmap.isChecked())
        self.label_layer.setEnabled(not comparing)
        if self.comparison_summary is not None:
            self.comparison_summary.clear()
        self._review_ready = False
        if not self.preview.isChecked() or self._predicted is None:
            self.view.set_prediction(None)
        elif score is None:
            self.view.set_prediction(self._predicted.defect)
        elif self.heatmap.isChecked():
            self.view.set_heatmap(score)
        else:
            mask = defect_mask_from_scores(
                score, threshold=self.threshold.value(), min_area_px=self.minimum_area.value())
            if comparing:
                counts = self.view.compare_prediction(mask, np.isfinite(score))
                labeled = sum(counts.values())
                self._review_ready = labeled > 0
                values = [f"{name.title()} {value:.2%}" if value is not None else f"{name.title()} —"
                          for name, value in metrics(counts).items()]
                self.comparison_summary.setText(f"  {labeled:,} labeled px · " + " · ".join(values))
            else:
                self.view.set_prediction(mask)
        self._sync_keep_settings()

    def _sync_keep_settings(self):
        if self.keep_settings is not None:
            self.keep_settings.setEnabled(
                self._review_ready and not self.view.has_selection and not self.view.draft.dirty
            )

    def _keep_settings(self):
        cutoff, area = self.threshold.value(), self.minimum_area.value()
        self.settings_kept.emit(cutoff, area)
        self.statusBar().showMessage(f"Kept cutoff {cutoff:g} and minimum area {area} px for staging.", 6000)

    def disable_settings_handoff(self):
        if self.keep_settings is not None:
            self.keep_settings.setVisible(False)
            self.keep_settings = None

    def _refresh_comparison(self):
        if self.view._comparing:
            self._refresh_preview()

    def save(self):
        self.view.finish_stroke()
        if self.view.has_selection and not self.view.apply_region():
            self.statusBar().showMessage("Complete or cancel the pending region before saving.", 5000)
            return False
        try:
            draft = self.view.draft
            updated = draft.dirty or not draft.path.exists()
            draft.save()
        except (OSError, ValueError, cv2.error) as error:
            QMessageBox.warning(self, "Could not save labels", str(error))
            return False
        if updated:
            self.labels_saved.emit()
        self._status()
        return True

    def undo(self):
        self.view.finish_stroke()
        if self.view.has_selection:
            self._cancel_region()
            return
        if self.view.draft.undo():
            self.view.refresh_labels()
            self.view.labels_edited.emit()
            self._status()

    def _leave(self):
        self.view.finish_stroke()
        if not self.view.draft.dirty and not self.view.has_selection:
            return True
        buttons = QMessageBox.StandardButton
        answer = QMessageBox.question(self, "Save label mask", "Save changes before leaving this image?",
                                      buttons.Save | buttons.Discard | buttons.Cancel, buttons.Save)
        if answer == buttons.Save:
            return self.save()
        return answer == buttons.Discard

    def move(self, direction):
        target = self.index + direction
        if 0 <= target < len(self.entries) and self._leave():
            try:
                self._load(target)
            except (OSError, ValueError, cv2.error) as error:
                QMessageBox.warning(self, "Could not open image", str(error))

    def closeEvent(self, event):
        event.setAccepted(self._leave())


def launch(manifest, *, region_path=None, model_path=None):
    entries = annotation_entries(manifest, region_path=region_path, model_path=model_path)
    region = read_image(region_path) if region_path is not None else None
    model = PixelSegmenter.load(model_path) if model_path is not None else None
    app = QApplication([])
    window = AnnotationWindow(entries, region=region, model=model)
    window.show()
    return app.exec()
