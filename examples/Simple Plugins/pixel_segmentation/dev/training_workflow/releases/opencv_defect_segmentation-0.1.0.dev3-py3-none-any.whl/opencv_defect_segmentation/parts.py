"""Measure registered parts and project categorical results onto the source grid."""

import math
from concurrent.futures import CancelledError, ThreadPoolExecutor
from contextlib import ExitStack
from dataclasses import dataclass
from itertools import islice

import cv2
import numpy as np

from . import DEFECT, NORMAL, PixelSegmenter, Region, _MAX_SEGMENT_WORKERS, _mask
from .registration import warp_registered_patch


MAX_PART_WORKERS = _MAX_SEGMENT_WORKERS
_NATIVE_TRANSFORM = ((1., 0., 0.), (0., 1., 0.), (0., 0., 1.))


@dataclass(frozen=True)
class PatchPlacement:
    size: tuple[int, int]
    to_source: np.ndarray


@dataclass(frozen=True)
class PartMeasurement:
    patch_size: tuple[int, int]
    patch_to_source: tuple[tuple[float, ...], ...]
    requested_pixels: int
    inspected_pixels: int
    defect_pixels: int
    regions: tuple[Region, ...]

    @property
    def inspected_fraction(self):
        return self.inspected_pixels / self.requested_pixels if self.requested_pixels else 0.

    @property
    def defect_fraction(self):
        return self.defect_pixels / self.inspected_pixels if self.inspected_pixels else None


@dataclass(frozen=True)
class PartInspection:
    parts: tuple[PartMeasurement, ...]
    mask: np.ndarray
    inspected: np.ndarray
    score_map: np.ndarray | None = None


def _measurement(result, size, to_source):
    return PartMeasurement(
        size, to_source, result.requested_pixels,
        int(np.count_nonzero(result.inspected)), int(np.count_nonzero(result.defect)), result.regions,
    )


def _check_cancelled(cancelled):
    if cancelled is not None and cancelled():
        raise CancelledError("Part inspection cancelled.")


def inspect_image(model, image, *, region=None, source_valid=None, threshold=.5, min_area_px=1,
                  workers=1, cancelled=None, include_scores=False):
    """Segment a full native image and return the ordinary source-grid result."""
    _check_cancelled(cancelled)
    result = model.segment(image, region=region, valid=source_valid, threshold=threshold,
                           min_area_px=min_area_px, vote_workers=workers)
    _check_cancelled(cancelled)
    scores = np.where(result.inspected, result.score, np.float32(0)) if include_scores else None
    measurement = _measurement(result, image.shape[::-1], _NATIVE_TRANSFORM)
    return PartInspection((measurement,), result.defect.astype(np.uint8) * 255,
                          result.inspected.astype(np.uint8) * 255, scores)


def _project(state, patch_labels, patch_to_source):
    # Warp only the footprint of this patch. The half-pixel edges enclose
    # all source pixels that can hit it under nearest-neighbor sampling.
    height, width = patch_labels.shape
    corners = np.array([[-.5, -.5, 1], [width - .5, -.5, 1],
                        [width - .5, height - .5, 1], [-.5, height - .5, 1]])
    image_points = corners @ patch_to_source[:2].T
    limit = state.shape[::-1]
    lower = np.clip(image_points.min(axis=0), 0, limit)
    upper = np.clip(image_points.max(axis=0), -1, limit)
    left, top = map(math.floor, lower)
    right, bottom = (min(size, math.ceil(coord) + 1) for coord, size in zip(upper, limit))
    if right <= left or bottom <= top:
        return
    to_crop = patch_to_source[:2].copy()
    to_crop[:, 2] -= (left, top)
    projected = cv2.warpAffine(patch_labels, to_crop, (right - left, bottom - top), flags=cv2.INTER_NEAREST)
    crop = state[top:bottom, left:right]
    np.maximum(crop, projected, out=crop)


def inspect_parts(model, image, placements, *, samples_per_pixel=1, region=None,
                  source_valid=None, threshold=.5, min_area_px=1, workers=1, cancelled=None,
                  include_scores=False):
    """Return patch-local measurements and two source-grid binary masks.

    Pixel counts and fractions use the actual sampled patch grid. Projected
    masks use nearest-neighbor labels and the union of all visible parts.
    Optional source-grid scores use nearest-neighbor sampling and maximum
    votes across overlapping parts. Uninspected scores are zero.
    Workers share a read-only model. A lone patch can use the worker budget
    for voting. Projection and result ordering stay serial.
    """
    if image.ndim != 2 or not image.size or image.dtype not in (np.uint8, np.uint16):
        raise ValueError("Supply a nonempty 8- or 16-bit grayscale image.")
    if type(workers) is not int or not 1 <= workers <= MAX_PART_WORKERS:
        raise ValueError(f"Part workers must be an integer from 1 to {MAX_PART_WORKERS}.")
    if source_valid is not None:
        source_valid = _mask(source_valid, image.shape)
    state = np.zeros(image.shape, np.uint8)
    score_map = np.zeros(image.shape, np.float32) if include_scores else None
    measurements = []

    def measure(placement, vote_workers=1):
        patch = warp_registered_patch(image, placement.to_source, placement.size,
                                      samples_per_pixel=samples_per_pixel, source_valid=source_valid)
        segment = model.segment
        options = {}
        # Keep the original call contract for custom classifiers.
        if vote_workers > 1 and getattr(segment, "__func__", None) is PixelSegmenter.segment:
            options["vote_workers"] = vote_workers
        result = segment(patch.pixels, region=region, valid=patch.valid, threshold=threshold,
                         min_area_px=min_area_px, **options)
        labels = result.inspected.astype(np.uint8) * NORMAL
        labels[result.defect] = DEFECT
        measurement = _measurement(result, patch.pixels.shape[::-1], tuple(map(tuple, patch.to_source.tolist())))
        scores = np.where(result.inspected, result.score, np.float32(0)) if include_scores else None
        return labels, scores, patch.to_source, measurement

    placements = iter(placements)
    with ExitStack() as stack:
        pool = None
        while batch := tuple(islice(placements, workers)):
            _check_cancelled(cancelled)
            if len(batch) == 1:
                measured = (measure(batch[0], workers),)
            else:
                if pool is None:
                    pool = stack.enter_context(ThreadPoolExecutor(max_workers=workers))
                measured = pool.map(measure, batch)
            for labels, scores, transform, measurement in measured:
                _check_cancelled(cancelled)
                _project(state, labels, transform)
                if score_map is not None:
                    _project(score_map, scores, transform)
                measurements.append(measurement)
    _check_cancelled(cancelled)
    if source_valid is not None:
        state[~source_valid] = 0
        if score_map is not None:
            score_map[~source_valid] = 0
    return PartInspection(tuple(measurements), (state == DEFECT).astype(np.uint8) * 255,
                          (state != 0).astype(np.uint8) * 255, score_map)
