"""Calibrate a whole-region review cue from explicitly labeled examples."""

from dataclasses import asdict, dataclass, field

import numpy as np

from . import DEFECT, NORMAL, _mask


_TAILS = (5, 10, 20)
_PERCENTILES = (*_TAILS, 80, 90, 95)
_PENALTIES = (0., .25, .5, 1.)


@dataclass(frozen=True)
class ToneCandidate:
    polarity: str
    percentile: int
    spread_penalty: float
    control_ceiling_dn: float
    affected_floor_dn: float

    @property
    def gap_dn(self):
        return self.affected_floor_dn - self.control_ceiling_dn


@dataclass(frozen=True)
class ToneCalibration:
    best_candidate: ToneCandidate
    control_images: int
    affected_images: int
    brightness_drift_dn: int
    dtype: np.dtype
    _region: np.ndarray = field(repr=False, compare=False)

    @property
    def separable(self):
        return self.best_candidate.gap_dn > 0

    def report(self):
        return {
            "dtype": str(self.dtype),
            "region_pixels": int(np.count_nonzero(self._region)),
            "control_images": self.control_images,
            "affected_images": self.affected_images,
            "brightness_drift_dn": self.brightness_drift_dn,
            "separable": self.separable,
            "best_candidate": {**asdict(self.best_candidate), "gap_dn": self.best_candidate.gap_dn},
        }

    def measure(self, pixels, *, valid=None):
        """Return a review status when the trained region is fully observed."""
        if not self.separable:
            raise ValueError("The calibration has overlapping reference groups.")
        _check_grid(pixels, self._region, self.dtype)
        observed = _mask(valid, pixels.shape) & self._region
        coverage = float(np.count_nonzero(observed) / np.count_nonzero(self._region))
        if coverage < 1.:
            return {"status": "unobserved", "coverage": coverage, "score_dn": None}
        candidate = self.best_candidate
        values = np.percentile(pixels[self._region], _PERCENTILES)
        score = _score(values, int(np.iinfo(self.dtype).max), candidate.polarity,
                       _TAILS.index(candidate.percentile), candidate.spread_penalty)
        if score <= candidate.control_ceiling_dn:
            status = "control_range"
        elif score >= candidate.affected_floor_dn:
            status = "review"
        else:
            status = "between_references"
        return {"status": status, "coverage": coverage, "score_dn": float(score)}


def _check_grid(pixels, region, dtype):
    if pixels.shape != region.shape or pixels.dtype != dtype:
        raise ValueError("Tone examples must share the trained grid and native bit depth.")


def _score(values, peak, polarity, index, penalty):
    tail = values[index] if polarity == "bright" else peak - values[-1 - index]
    return tail - penalty * (values[-1] - values[0])


def _measure_examples(samples, region, dtype, *, affected):
    peak = int(np.iinfo(dtype).max)
    measurements = []
    for sample in samples:
        _check_grid(sample.pixels, region, dtype)
        labels = sample.labels
        if labels.dtype != np.uint8 or labels.shape != region.shape or np.any(labels > DEFECT):
            raise ValueError("Labels must be aligned uint8 values 0, 1, or 2.")
        if not _mask(sample.valid, region.shape)[region].all():
            raise ValueError("Every tone calibration example must show the entire region.")
        if affected and not np.all(labels[region] == DEFECT):
            raise ValueError("Every affected example needs defect labels throughout the region.")
        if not affected and not np.any(labels[region] == NORMAL):
            raise ValueError("Every control example needs a normal label inside the region.")
        pixels = sample.pixels[region]
        headroom = min(int(pixels.min()), peak - int(pixels.max()))
        measurements.append((np.percentile(pixels, _PERCENTILES), headroom))
    return measurements


def calibrate_tone(controls, affected, region, *, brightness_drift_dn=0):
    """Find the best gap between controls and fully affected region examples.

    Drift expands each reference in both directions before comparing the groups.
    With saturation, use the conservative bound for a tail minus a spread.
    """
    controls, affected = list(controls), list(affected)
    if not controls or not affected:
        raise ValueError("Supply controls and fully affected examples.")
    image = controls[0].pixels
    dtype = image.dtype
    if image.ndim != 2 or not image.size or dtype not in (np.uint8, np.uint16):
        raise ValueError("Supply nonempty 8- or 16-bit grayscale images.")
    peak = int(np.iinfo(dtype).max)
    if type(brightness_drift_dn) is not int or not 0 <= brightness_drift_dn <= peak:
        raise ValueError(f"Brightness drift must be an integer from 0 to {peak} for this bit depth.")
    mask = _mask(region, image.shape)
    if region is None or not mask.any():
        raise ValueError("Supply a nonempty explicit region for tone calibration.")
    mask.flags.writeable = False
    normal = _measure_examples(controls, mask, dtype, affected=False)
    full = _measure_examples(affected, mask, dtype, affected=True)

    def envelope(examples, polarity, index, penalty, direction):
        for values, headroom in examples:
            # With no clipping the spread stays constant. Under clipping each
            # quantile and the spread can move by at most the requested drift.
            drift = brightness_drift_dn * (1. + penalty if headroom < brightness_drift_dn else 1.)
            yield float(_score(values, peak, polarity, index, penalty) + direction * drift)

    candidates = []
    for polarity in ("bright", "dark"):
        for index, percentile in enumerate(_TAILS):
            for penalty in _PENALTIES:
                ceiling = max(envelope(normal, polarity, index, penalty, 1))
                floor = min(envelope(full, polarity, index, penalty, -1))
                candidates.append(ToneCandidate(polarity, percentile, penalty, ceiling, floor))
    best = max(candidates, key=lambda candidate: candidate.gap_dn)
    return ToneCalibration(best, len(normal), len(full), brightness_drift_dn, dtype, mask)
