"""Score predictions against explicit normal and defect labels."""

from bisect import bisect_left

import cv2
import numpy as np

from . import DEFECT, NORMAL


_COMPARISON_COLORS = np.array([
    (0, 0, 0), (204, 162, 238), (0, 0, 0), (247, 150, 29), (235, 61, 97), (38, 212, 162),
], dtype=np.uint8)


def _comparison_classes(labels, inspected, predicted):
    # Two palette entries per label, for background and foreground predictions.
    classes = 2 * labels + predicted
    classes[~inspected] = 0
    return classes


def _comparison_counts(classes):
    _, _, tn, fp, fn, tp = np.bincount(classes.ravel(), minlength=len(_COMPARISON_COLORS))
    return {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)}


def _check_labels(labels, result):
    if labels.dtype != np.uint8 or labels.shape != result.inspected.shape or np.any(labels > DEFECT):
        raise ValueError("Labels must be aligned uint8 values 0, 1, or 2.")


def offset_brightness(pixels, offset_dn):
    """Shift a native grayscale image for diagnostic replays, with saturation."""
    if pixels.ndim != 2 or not pixels.size or pixels.dtype not in (np.uint8, np.uint16):
        raise ValueError("Supply a nonempty 8- or 16-bit grayscale image.")
    maximum = int(np.iinfo(pixels.dtype).max)
    if type(offset_dn) is not int or not -maximum <= offset_dn <= maximum:
        raise ValueError(f"Brightness offset must be an integer from {-maximum} to {maximum} for this image.")
    return np.clip(pixels.astype(np.int32) + offset_dn, 0, maximum).astype(pixels.dtype)


def score_labels(labels, result):
    """Count matches on observed labels and report support for positive regions."""
    _check_labels(labels, result)
    defect = labels == DEFECT
    normal = labels == NORMAL
    observed_defect = defect & result.inspected
    observed_normal = normal & result.inspected
    predicted = result.defect
    counts = {
        "tp": int(np.count_nonzero(observed_defect & predicted)),
        "fn": int(np.count_nonzero(observed_defect & ~predicted)),
        "fp": int(np.count_nonzero(observed_normal & predicted)),
        "tn": int(np.count_nonzero(observed_normal & ~predicted)),
        "uninspected_defect": int(np.count_nonzero(defect & ~result.inspected)),
        "uninspected_normal": int(np.count_nonzero(normal & ~result.inspected)),
    }
    count, components = cv2.connectedComponents(defect.astype(np.uint8), connectivity=8)
    sizes = np.bincount(components[defect], minlength=count)
    visible = np.bincount(components[observed_defect], minlength=count)
    hits = np.bincount(components[observed_defect & predicted], minlength=count)
    regions = [
        {"labeled_pixels": int(sizes[i]), "inspected_pixels": int(visible[i]), "matched_pixels": int(hits[i])}
        for i in range(1, count)
    ]
    return {"counts": counts, "metrics": metrics(counts), "positive_regions": regions}


def score_area(labels, result):
    """Bound the true defect fraction and signed area error on the observed region."""
    _check_labels(labels, result)
    observed = result.inspected
    inspected = int(np.count_nonzero(observed))
    known = int(np.count_nonzero(observed & (labels != 0)))
    defect = int(np.count_nonzero(observed & (labels == DEFECT)))
    predicted = int(np.count_nonzero(result.defect & observed))
    report = {
        "inspected_pixels": inspected,
        "labeled_pixels": known,
        "label_coverage": None,
        "predicted_fraction": None,
        "reference_fraction_bounds": None,
        "signed_error_points_bounds": None,
    }
    if inspected:
        upper = defect + inspected - known
        report.update(
            label_coverage=known / inspected,
            predicted_fraction=predicted / inspected,
            reference_fraction_bounds=[defect / inspected, upper / inspected],
            signed_error_points_bounds=[100 * (predicted - upper) / inspected,
                                        100 * (predicted - defect) / inspected],
        )
    return report


def score_repeatability(first, second, *, tolerance_px=0):
    """Compare two segmentations of the same part on a shared registered grid.

    Run each capture with its own validity mask and the same requested region.
    The comparison uses only pixels observed in both captures.
    """
    if type(tolerance_px) is not int or tolerance_px < 0:
        raise ValueError("Repeatability tolerance must be a nonnegative integer.")
    if first.inspected.shape != second.inspected.shape or first.requested_pixels != second.requested_pixels:
        raise ValueError("Repeatability requires the same registered grid and requested region.")
    shared = first.inspected & second.inspected
    observed = int(np.count_nonzero(shared))
    left, right = first.defect & shared, second.defect & shared
    first_count, second_count = int(np.count_nonzero(left)), int(np.count_nonzero(right))
    total = first_count + second_count
    overlap = int(np.count_nonzero(left & right))
    dice = 2 * overlap / total if total else None
    within_tolerance = dice
    if tolerance_px and first_count and second_count:
        def near_count(source, target):
            distance = cv2.distanceTransform((~target).astype(np.uint8), cv2.DIST_L2, cv2.DIST_MASK_PRECISE)
            return int(np.count_nonzero(source & (distance <= tolerance_px)))

        within_tolerance = (near_count(left, right) + near_count(right, left)) / total
    return {
        "shared_inspected_pixels": observed,
        "shared_coverage": observed / first.requested_pixels if first.requested_pixels else 0.,
        "first_defect_pixels": first_count,
        "second_defect_pixels": second_count,
        "first_defect_fraction": first_count / observed if observed else None,
        "second_defect_fraction": second_count / observed if observed else None,
        "absolute_area_delta_points": 100 * abs(first_count - second_count) / observed if observed else None,
        "dice": dice,
        "within_tolerance_fraction": within_tolerance,
        "tolerance_px": tolerance_px,
    }


def metrics(counts):
    tp, fn, fp, tn = (counts[key] for key in ("tp", "fn", "fp", "tn"))
    return {
        "precision": tp / (tp + fp) if tp + fp else None,
        "recall": tp / (tp + fn) if tp + fn else None,
        "specificity": tn / (tn + fp) if tn + fp else None,
    }


def score_region_sizes(regions, upper_bounds):
    """Group scored positive regions by labeled area, preserving observation coverage."""
    bounds = list(upper_bounds)
    if (not bounds or any(type(value) is not int or value < 1 for value in bounds)
            or any(left >= right for left, right in zip(bounds, bounds[1:]))):
        raise ValueError("Area band bounds must be strictly increasing positive integers.")
    bands = []
    for previous, upper in zip([0, *bounds], [*bounds, None]):
        bands.append({"min_labeled_px": previous + 1, "max_labeled_px": upper,
                      "regions": 0, "fully_observed": 0, "unobserved": 0,
                      "any_overlap": 0, "half_observed_overlap": 0,
                      "labeled_pixels": 0, "inspected_pixels": 0, "matched_pixels": 0})
    for region in regions:
        labeled, inspected, matched = (region[key] for key in ("labeled_pixels", "inspected_pixels", "matched_pixels"))
        band = bands[bisect_left(bounds, labeled)]
        band["regions"] += 1
        band["fully_observed"] += int(inspected == labeled)
        band["unobserved"] += int(inspected == 0)
        band["any_overlap"] += int(matched > 0)
        band["half_observed_overlap"] += int(inspected > 0 and 2 * matched >= inspected)
        band["labeled_pixels"] += labeled
        band["inspected_pixels"] += inspected
        band["matched_pixels"] += matched
    for band in bands:
        inspected = band["inspected_pixels"]
        band["pixel_recall"] = band["matched_pixels"] / inspected if inspected else None
    return bands
