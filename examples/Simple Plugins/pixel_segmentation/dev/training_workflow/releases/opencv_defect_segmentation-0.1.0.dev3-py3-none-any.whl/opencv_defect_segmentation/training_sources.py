"""Portable, verified training pixels and annotations, separate from inference."""

import hashlib
import json
from concurrent.futures import CancelledError
from dataclasses import dataclass, field, replace
from pathlib import Path, PurePosixPath
from uuid import uuid4

import cv2
import numpy as np


def _json(value):
    return (json.dumps(value, indent=2, allow_nan=False) + "\n").encode("utf-8")


def _digest(value):
    return hashlib.sha256(value).hexdigest()


def _check(cancelled):
    if cancelled is not None and cancelled():
        raise CancelledError("Training source restoration cancelled.")


def _member(root, name):
    relative = PurePosixPath(name)
    if (
        not name
        or relative.is_absolute()
        or ".." in relative.parts
        or "\\" in name
        or ":" in name
        or relative.suffix not in (".png", ".json")
    ):
        raise ValueError("Training source paths must be relative PNG/JSON members.")
    path = (root / name).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("Training source member resolves outside its bundle.")
    return path


def source_receipt(model_path):
    return Path(model_path).with_suffix(".training.json")


def _write_files(directory, files, cancelled=None):
    """Own a new directory; on failure remove only the files created here."""
    directory.mkdir(parents=True, exist_ok=False)
    written = []
    try:
        for name, content in files:
            _check(cancelled)
            target = _member(directory, name)
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as stream:
                stream.write(content)
            written.append(target)
        _check(cancelled)
    except BaseException:
        for path in reversed(written):
            path.unlink(missing_ok=True)
        for path in sorted(
            (p for p in directory.rglob("*") if p.is_dir()),
            key=lambda p: len(p.parts),
            reverse=True,
        ):
            path.rmdir()
        directory.rmdir()
        raise


class SourceCollector:
    """Compress the native decoded inputs while they are already loaded for fitting."""

    def __init__(self, source_names=None):
        self.files = {}
        self.rows = {}
        self.names = {}
        self._source_names = source_names or {}

    def add(self, role, sample, name):
        rows = self.rows.setdefault(role, [])
        row = {}
        for kind, pixels in (
            ("image", sample.pixels),
            ("labels", sample.labels),
            ("valid", sample.valid),
        ):
            if pixels is None:
                continue
            member = f"{len(rows):05d}/{kind}.png"
            ok, encoded = cv2.imencode(".png", pixels)
            if not ok:
                raise ValueError("Could not retain training pixels as lossless PNG.")
            self.files[f"{role}/{member}"] = encoded.tobytes()
            row[kind] = member
        rows.append(row)
        originals = self._source_names.get(role, ())
        display = originals[len(rows) - 1] if len(originals) >= len(rows) else name
        self.names.setdefault(role, []).append(Path(display).name)

    def finish(self, *, health, fingerprints, saved_only):
        manifests = {}
        for role, rows in self.rows.items():
            name = f"{role}/manifest.json"
            self.files[name] = _json(rows)
            manifests[role] = name
        return TrainingSources(
            tuple(sorted(self.files.items())),
            manifests,
            health,
            tuple(sorted(value.hex() for value in fingerprints)),
            saved_only,
            self.names,
        )


@dataclass(frozen=True)
class TrainingSources:
    files: tuple
    manifests: dict
    health: dict
    fingerprints: tuple
    saved_only: bool
    names: dict = field(default_factory=dict)

    def with_validation(self, validation=None):
        """Replace only the last reviewed validation split, keeping fitted inputs exact."""
        files = {name: data for name, data in self.files if not name.startswith("validation/")}
        manifests = {key: value for key, value in self.manifests.items() if key != "validation"}
        names = {key: value for key, value in self.names.items() if key != "validation"}
        health = {**self.health, "validation_images": 0}
        if validation is not None:
            files.update(validation.files)
            manifests.update(validation.manifests)
            names.update(validation.names)
            health["validation_images"] = validation.health["validation_images"]
        return replace(
            self,
            files=tuple(sorted(files.items())),
            manifests=manifests,
            names=names,
            health=health,
        )

    def write(self, model_path, model_sha256, region_sha256):
        model_path = Path(model_path)
        folder = model_path.with_suffix(".training")
        _write_files(folder, self.files)
        receipt = dict(
            schema="simple_segmentation_training_sources/v1",
            model_sha256=model_sha256,
            region_sha256=region_sha256,
            directory=folder.name,
            manifests=self.manifests,
            health=self.health,
            training_fingerprints=self.fingerprints,
            saved_masks_only=self.saved_only,
            source_names=self.names,
            sha256={name: _digest(content) for name, content in self.files},
            pixel_encoding=(
                "Lossless native decoded pixels, full labels before region clipping, "
                "optional validity"
            ),
        )
        created = False
        try:
            with source_receipt(model_path).open("xb") as stream:
                created = True
                stream.write(_json(receipt))
        except BaseException:
            if created:
                source_receipt(model_path).unlink(missing_ok=True)
            for name, _ in reversed(self.files):
                _member(folder, name).unlink()
            for path in sorted(
                (p for p in folder.rglob("*") if p.is_dir()),
                key=lambda p: len(p.parts),
                reverse=True,
            ):
                path.rmdir()
            folder.rmdir()
            raise


def load_sources(model_path, model_sha256, region_sha256, *, cancelled=None):
    """Verify optional sidecars; never load or run the classifier."""
    model_path = Path(model_path)
    receipt_path = source_receipt(model_path)
    if not receipt_path.is_file():
        return None
    if not receipt_path.resolve().is_relative_to(model_path.parent.resolve()):
        raise ValueError("Training source receipt resolves outside the model folder.")
    if _digest(model_path.read_bytes()) != model_sha256:
        raise ValueError("Training source model SHA-256 differs from its pin.")
    receipt = json.loads(receipt_path.read_bytes())
    if (
        receipt.get("schema") != "simple_segmentation_training_sources/v1"
        or receipt.get("model_sha256") != model_sha256
        or receipt.get("region_sha256") != region_sha256
    ):
        raise ValueError("Training sources belong to a different model or inspection region.")
    if receipt.get("directory") != model_path.with_suffix(".training").name:
        raise ValueError("Training source directory differs from its model companion.")
    root = model_path.with_suffix(".training")
    if not root.resolve().is_relative_to(model_path.parent.resolve()):
        raise ValueError("Training source directory resolves outside the model folder.")
    files = []
    for name, digest in receipt["sha256"].items():
        _check(cancelled)
        content = _member(root, name).read_bytes()
        if _digest(content) != digest:
            raise ValueError(f"Retained training source SHA-256 mismatch: {name}")
        files.append((name, content))
    contents = dict(files)
    manifests = receipt["manifests"]
    if "training" not in manifests or set(manifests) - {"training", "details", "validation"}:
        raise ValueError("Training source manifest roles are invalid.")
    for name in manifests.values():
        rows = json.loads(contents[name])
        if not rows:
            raise ValueError("A retained training manifest is empty.")
        for row in rows:
            if not isinstance(row, dict) or not {"image", "labels"} <= row.keys() <= {
                "image",
                "labels",
                "valid",
            }:
                raise ValueError("A retained training manifest entry is invalid.")
            for value in row.values():
                member = _member(_member(root, name).parent, value)
                if member.relative_to(root.resolve()).as_posix() not in contents:
                    raise ValueError("A retained manifest references an unverified image.")
    health = receipt["health"]
    for name in (
        "training_images",
        "detail_images",
        "validation_images",
        "background_pixels",
        "foreground_pixels",
        "skipped_drafts",
    ):
        if type(health.get(name)) is not int or health[name] < 0:
            raise ValueError("Training source counts must be nonnegative integers.")
    fingerprints = receipt["training_fingerprints"]
    if (
        type(receipt["saved_masks_only"]) is not bool
        or not fingerprints
        or any(
            not isinstance(value, str)
            or len(value) != 64
            or any(c not in "0123456789abcdef" for c in value)
            for value in fingerprints
        )
    ):
        raise ValueError("Training source fingerprints or saved-mask settings are invalid.")
    return TrainingSources(
        tuple(files),
        manifests,
        receipt["health"],
        tuple(receipt["training_fingerprints"]),
        receipt["saved_masks_only"],
        receipt.get("source_names", {}),
    )


def source_assets(model_path, model_sha256, region_sha256):
    sources = load_sources(model_path, model_sha256, region_sha256)
    if sources is None:
        return []
    folder = Path(model_path).with_suffix(".training")
    return [source_receipt(model_path), *(folder / name for name, _ in sources.files)]


def restore_sources(project_dir, model_path, model_sha256, region_sha256, *, cancelled=None):
    sources = load_sources(model_path, model_sha256, region_sha256, cancelled=cancelled)
    if sources is None:
        return None
    folder = Path(project_dir).resolve() / ".local/segmentation-drafts" / uuid4().hex
    _write_files(folder, sources.files, cancelled)
    return sources, {role: folder / name for role, name in sources.manifests.items()}


def annotation_preview(sources, region=None, *, role="training"):
    """Show the first retained labels without predicting or rereading source files."""
    files = dict(sources.files)
    manifest = sources.manifests[role]
    row = json.loads(files[manifest])[0]

    def pixels(field):
        name = (PurePosixPath(manifest).parent / row[field]).as_posix()
        return cv2.imdecode(np.frombuffer(files[name], np.uint8), cv2.IMREAD_UNCHANGED)

    native, labels = pixels("image"), pixels("labels")
    gray = cv2.normalize(native, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
    rgb = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
    allowed = np.ones(labels.shape, bool) if region is None else region != 0
    if "valid" in row:
        allowed &= pixels("valid") != 0
    for label, color in ((1, (60, 130, 255)), (2, (255, 65, 65))):
        selected = (labels == label) & allowed
        rgb[selected] = (0.5 * rgb[selected] + 0.5 * np.asarray(color)).astype(np.uint8)
    rgb[~allowed] //= 3
    scale = min(1.0, 640 / max(native.shape))
    if scale < 1:
        rgb = cv2.resize(
            rgb,
            tuple(max(1, round(n * scale)) for n in native.shape[::-1]),
            interpolation=cv2.INTER_AREA,
        )
    return rgb
