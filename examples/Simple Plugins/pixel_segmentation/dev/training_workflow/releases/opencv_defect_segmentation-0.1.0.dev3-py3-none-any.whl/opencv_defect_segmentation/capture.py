"""Export matched, registered patches for explicit native-grid labeling."""

from concurrent.futures import CancelledError
from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
from tempfile import TemporaryDirectory

import cv2
import numpy as np

from . import _mask
from .registration import warp_registered_patch


@dataclass(frozen=True)
class PatchCapture:
    manifest: Path
    captured: int
    incomplete: int
    skipped: int


def _write_png(path, pixels):
    ok, data = cv2.imencode(".png", pixels)
    if not ok:
        raise OSError("OpenCV could not encode a captured patch.")
    path.write_bytes(data.tobytes())


def _write_json(path, value):
    path.write_text(json.dumps(value, allow_nan=False, indent=2) + "\n", encoding="utf-8")


def capture_patches(image, placements, directory, *, samples_per_pixel=1, source_valid=None,
                    region=None, frame_payload=None, cancelled=None):
    """Publish a complete, new training manifest with empty label destinations."""
    placements = tuple(placements)
    if not placements:
        raise ValueError("Capture requires at least one matched part.")
    if any(part.size != placements[0].size for part in placements[1:]):
        raise ValueError("Capture one trained patch size per dataset.")
    destination = Path(directory)
    if destination.exists() or destination.is_symlink():
        raise FileExistsError(f"Capture directory already exists: {destination}")
    destination = destination.parent.resolve() / destination.name

    def check_cancelled():
        if cancelled is not None and cancelled():
            raise CancelledError("Patch capture cancelled.")

    check_cancelled()
    destination.parent.mkdir(parents=True, exist_ok=True)
    records, parts, skipped = [], [], []
    requested = None
    with TemporaryDirectory(dir=destination.parent, prefix=".capture-") as temp:
        draft = Path(temp) / "dataset"
        (draft / "images").mkdir(parents=True)
        (draft / "valid").mkdir()
        for index, part in enumerate(placements, 1):
            check_cancelled()
            patch = warp_registered_patch(image, part.to_source, part.size, samples_per_pixel=samples_per_pixel,
                                          source_valid=source_valid)
            if requested is None:
                requested = _mask(region, patch.pixels.shape)
                requested_count = int(np.count_nonzero(requested))
                if not requested_count:
                    raise ValueError("The patch region must contain pixels.")
            observed = int(np.count_nonzero(patch.valid & requested))
            if not observed:
                skipped.append(index)
                continue
            stem = f"part-{index:03d}"
            entry = {"image": f"images/{stem}.png", "valid": f"valid/{stem}.png", "labels": f"labels/{stem}.png"}
            _write_png(draft / entry["image"], patch.pixels)
            _write_png(draft / entry["valid"], patch.valid.astype(np.uint8) * 255)
            records.append(entry)
            parts.append({"match_index": index, "image": entry["image"], "patch_to_source": patch.to_source.tolist(),
                          "requested_pixels": requested_count, "observed_pixels": observed})
        if not parts:
            raise ValueError("The matched parts have no observed pixels in the patch region.")
        if region is not None:
            _write_png(draft / "region.png", requested.astype(np.uint8) * 255)
        _write_json(draft / "training.json", records)
        _write_json(draft / "capture.json", {
            "model": "registered_patch_capture_v1",
            "source_size": list(image.shape[::-1]),
            "source_dtype": str(image.dtype),
            "source_gray_sha256": sha256(image.tobytes()).hexdigest(),
            "source_frame": frame_payload or {},
            "samples_per_pixel": int(samples_per_pixel),
            "patch_size": list(requested.shape[::-1]),
            "region": "region.png" if region is not None else None,
            "skipped_unobserved_matches": skipped,
            "parts": parts,
        })
        check_cancelled()
        draft.rename(destination)
    incomplete = sum(part["observed_pixels"] < part["requested_pixels"] for part in parts)
    return PatchCapture(destination / "training.json", len(parts), incomplete, len(skipped))
