"""Frozen segmentation maps, reported patch regions and exact executed assets."""

import copy
import hashlib
import json
from dataclasses import dataclass, field
from numbers import Integral
from pathlib import Path

import cv2
import numpy as np

from .graphics import _excluded, draw_heatmap, draw_overlay
from .parts import PartInspection

BINDING = "segmentation_completed_review"


def _json(value):
    return json.dumps(value, sort_keys=True, allow_nan=False).encode("utf-8")


def _readonly(value):
    array = np.asarray(value)
    return np.frombuffer(array.tobytes(), dtype=array.dtype).reshape(array.shape)


@dataclass(frozen=True)
class CompletedSegmentationRecord:
    identifier: str
    type_id: str
    report_json: bytes
    parameters_json: bytes
    model_bytes: bytes | None = field(repr=False)
    region_bytes: bytes | None = field(repr=False)
    score_source: str
    _private_scores: np.ndarray | None = field(repr=False, compare=False)

    @classmethod
    def create(cls, identifier, type_id, report, result, parameters, assets):
        source = (
            ("output" if parameters["emit_score_map"] else "heatmap")
            if result.score_map is not None
            else "not_retained"
        )
        return cls(
            identifier,
            type_id,
            _json(report),
            _json(parameters),
            None if assets is None else assets[1],
            None if assets is None else assets[2],
            source,
            result.score_map if source == "heatmap" else None,
        )

    @property
    def report(self):
        return json.loads(self.report_json)

    @property
    def parameters(self):
        return json.loads(self.parameters_json)

    def __deepcopy__(self, memo):
        return self


@dataclass(frozen=True)
class CompletedSegmentationCapture:
    record: CompletedSegmentationRecord
    source_pixels: np.ndarray = field(repr=False, compare=False)
    image: np.ndarray = field(repr=False, compare=False)
    mask: np.ndarray = field(repr=False, compare=False)
    inspected: np.ndarray = field(repr=False, compare=False)
    scores: np.ndarray | None = field(repr=False, compare=False)
    source_format: str
    _provenance: dict = field(repr=False, compare=False)
    _views: dict = field(default_factory=dict, repr=False, compare=False)

    @property
    def provenance(self):
        return copy.deepcopy(self._provenance)

    @property
    def source_sha256(self):
        return hashlib.sha256(self.source_pixels.tobytes()).hexdigest()

    def selection(self, part=None, region=None):
        if part is None:
            if region is not None:
                raise ValueError("Choose a part before a region")
            return None
        parts = self.record.report["parts"]
        if (
            isinstance(part, bool)
            or not isinstance(part, Integral)
            or not 0 <= part < len(parts)
        ):
            raise ValueError("Select a valid zero-based part index")
        item = parts[part]
        if region is None:
            x = y = 0
            w, h = item["patch_size"]
            selected = None
        else:
            if (
                isinstance(region, bool)
                or not isinstance(region, Integral)
                or not 0 <= region < len(item["regions"])
            ):
                raise ValueError("Select a valid zero-based region index")
            selected = item["regions"][region]
            x, y, w, h = (selected[name] for name in ("x", "y", "width", "height"))
        points = np.array(
            [
                [x - 0.5, y - 0.5, 1],
                [x + w - 0.5, y - 0.5, 1],
                [x + w - 0.5, y + h - 0.5, 1],
                [x - 0.5, y + h - 0.5, 1],
            ]
        )
        polygon = points @ np.asarray(item["patch_to_source"], float)[:2].T
        return dict(
            part_index=int(part),
            region_index=None if region is None else int(region),
            part=item,
            region=selected,
            source_polygon=polygon.tolist(),
            scope="Projected sampled-patch bounds; displayed mask/scores are the source union, not isolated region members",
        )

    def bounds(self, part=None, region=None):
        selection = self.selection(part, region)
        height, width = self.image.shape
        if selection is None:
            return 0, 0, width, height
        points = np.asarray(selection["source_polygon"])
        low = np.maximum(0, np.floor(points.min(axis=0) - 16).astype(int))
        high = np.minimum([width, height], np.ceil(points.max(axis=0) + 17).astype(int))
        if np.any(high <= low):
            return 0, 0, width, height
        return int(low[0]), int(low[1]), int(high[0] - low[0]), int(high[1] - low[1])

    def render(self, mode="overlay", part=None, region=None):
        if mode not in ("overlay", "votes", "coverage"):
            raise ValueError("Unknown review view")
        if mode not in self._views:
            from opencv_dataflow.images import ImageArray

            source = ImageArray(self.source_pixels, self.source_format)
            result = PartInspection((), self.mask, self.inspected, self.scores)
            if mode == "overlay":
                output = draw_overlay(source, result)
            elif mode == "votes":
                output = draw_heatmap(source, result)
            else:
                output = np.full((*self.image.shape, 3), (50, 60, 50), np.uint8)
                output[self.inspected != 0] = (65, 185, 85)
                output[(self.mask != 0) & (self.inspected != 0)] = (25, 35, 235)
                _excluded(output, self.inspected)
            self._views[mode] = _readonly(output)
        output = self._views[mode].copy()
        selected = self.selection(part, region)
        if selected is not None:
            polygon = np.asarray(selected["source_polygon"])
            cv2.polylines(
                output,
                [np.rint(np.clip(polygon, -1e6, 1e6) * 16).astype(np.int32)],
                True,
                (245, 220, 60),
                1,
                cv2.LINE_AA,
                shift=4,
            )
            center = tuple(np.rint(polygon.mean(axis=0)).astype(int))
            if 0 <= center[0] < output.shape[1] and 0 <= center[1] < output.shape[0]:
                cv2.drawMarker(
                    output, center, (245, 220, 60), cv2.MARKER_CROSS, 13, 1, cv2.LINE_AA
                )
        return output

    def report(self, part=None, region=None):
        inspected = int(np.count_nonzero(self.inspected))
        foreground = int(np.count_nonzero((self.mask != 0) & (self.inspected != 0)))
        state = (
            "no_placements"
            if self.record.report["count"] == 0
            else "no_observed_pixels"
            if not inspected
            else "measured"
        )
        return dict(
            model="simple_segmentation_completed_review_v1",
            type_id=self.record.type_id,
            execution_binding=self.record.identifier,
            state=state,
            inspection=self.record.report,
            executed_parameters=self.record.parameters,
            source_image=dict(
                shape=list(self.source_pixels.shape),
                dtype=self.source_pixels.dtype.str,
                format=self.source_format,
                sha256=self.source_sha256,
            ),
            source_inspected_pixels=inspected,
            source_foreground_pixels=foreground,
            source_foreground_fraction=None
            if not inspected
            else foreground / inspected,
            score_source=self.record.score_source,
            scores_available=self.scores is not None,
            score_semantics="Uncalibrated forest vote fraction 0..1; scores outside inspected are zero sentinels, not measured background",
            map_semantics="Source masks are unions; source votes use nearest sampling and maximum across overlapping parts",
            region_semantics="Reported component bounds/area/mean vote use each sampled patch grid before projection",
            selected=self.selection(part, region),
            display_crop_source=list(self.bounds(part, region)),
            provenance=self.provenance,
            identity_scope="Software completion identifiers do not establish physical exposure identity",
            block_judgment_scope="Passed means some observations were processed; foreground presence is not a quality acceptance gate",
            inference_reexecuted=False,
            recipe_reloaded=False,
            training_changed=False,
        )

    def assessment(self, part=None, region=None):
        sheet = np.full((820, 1200, 3), 22, np.uint8)
        x, y, w, h = self.bounds(part, region)
        for i, mode in enumerate(("overlay", "votes")):
            if mode == "votes" and self.scores is None:
                continue
            crop = self.render(mode, part, region)[y : y + h, x : x + w]
            scale = min(580 / w, 490 / h)
            resized = cv2.resize(
                crop, (max(1, round(w * scale)), max(1, round(h * scale)))
            )
            top, left = (
                48 + (490 - resized.shape[0]) // 2,
                10 + i * 600 + (580 - resized.shape[1]) // 2,
            )
            sheet[top : top + resized.shape[0], left : left + resized.shape[1]] = (
                resized
            )
        details = self.report(part, region)
        p = self.record.parameters
        lines = [
            f"Completed segmentation | {details['state'].replace('_', ' ')}",
            "Source union overlay | Votes: fixed 0..1, not calibrated probability",
            f"Source crop [{x}, {y}, {w}, {h}], display resized; cyan = selected projected bounds/center",
            f"Source: {details['source_inspected_pixels']} inspected; {details['source_foreground_pixels']} foreground",
            f"Executed cutoff {p['threshold']:g}; min component area {p['min_area_px']} sampled pixels; sampling {p['samples_per_pixel']}x",
            f"{self.record.report['count']} parts/images; {self.record.report['incomplete_count']} with incomplete coverage",
            "Green inspected background | Red foreground | Gray checks excluded/unobserved",
            "Sampled patch component counts differ from projected source-union pixel counts.",
        ]
        selected = details["selected"]
        if selected is not None:
            item = selected["part"]
            lines += [
                f"Part {part + 1}: {item['inspected_pixels']}/{item['requested_pixels']} sampled pixels inspected; {item['defect_pixels']} foreground"
            ]
            if selected["region"] is not None:
                item = selected["region"]
                lines += [
                    f"Region {region + 1}: area {item['area_px']} sampled pixels; local mean vote {item['mean_score']:.4g}"
                ]
        for i, line in enumerate(lines):
            position = (12, 26) if i == 0 else (12, 565 + (i - 1) * 23)
            cv2.putText(
                sheet,
                line,
                position,
                cv2.FONT_HERSHEY_SIMPLEX,
                0.49,
                (232, 235, 240),
                1,
                cv2.LINE_AA,
            )
        if self.scores is None:
            cv2.putText(
                sheet,
                "Votes not retained for this completed run",
                (620, 260),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (232, 235, 240),
                1,
                cv2.LINE_AA,
            )
        return sheet

    def export(self, directory, part=None, region=None):
        document = self.report(part, region)
        target = Path(directory)
        target.mkdir(parents=True, exist_ok=False)
        for name, array in (
            ("consumed_input", self.source_pixels),
            ("measurement_input", self.image),
            ("mask", self.mask),
            ("inspected", self.inspected),
            ("score_map", self.scores),
        ):
            if array is not None:
                np.save(target / f"{name}.npy", array, allow_pickle=False)
        assets = {}
        for name, data in (
            ("executed_model.yml", self.record.model_bytes),
            ("executed_region.png", self.record.region_bytes),
        ):
            if data is not None:
                (target / name).write_bytes(data)
                assets[name] = hashlib.sha256(data).hexdigest()
        document["exported_assets"] = assets
        images = {
            "overlay.png": self.render("overlay", part, region),
            "coverage.png": self.render("coverage", part, region),
            "assessment.png": self.assessment(part, region),
        }
        if self.scores is not None:
            images["votes.png"] = self.render("votes", part, region)
        for name, array in images.items():
            ok, encoded = cv2.imencode(".png", array)
            if not ok:
                raise ValueError("Could not encode review image")
            (target / name).write_bytes(encoded.tobytes())
        (target / "review.json").write_text(
            json.dumps(document, indent=2, allow_nan=False) + "\n", encoding="utf-8"
        )
        return target


def capture_completed(record, bundle):
    from opencv_dataflow.images import image_format
    from opencv_dataflow.processing import gray_image

    if record is None:
        raise ValueError(
            "No retained completed segmentation; execute inference in Debug before reviewing"
        )
    packet = bundle.outputs["report"]
    binding = packet.payload.get(BINDING, {})
    report = record.report
    if (
        binding.get("id") != record.identifier
        or binding.get("model_sha256") != report["model_sha256"]
        or binding.get("region_sha256") != report["region_sha256"]
        or _json(packet.value) != record.report_json
    ):
        raise ValueError(
            "Completed model/result evidence changed; capture the latest run again"
        )
    source = bundle.inputs["image"].value
    image = gray_image(source, (np.uint8, np.uint16))
    if list(image.shape[::-1]) != report["image_size"]:
        raise ValueError("Completed input dimensions differ from the result grid")
    mask, inspected = (
        _readonly(bundle.outputs[name].value) for name in ("mask", "inspected")
    )
    scores = (
        bundle.outputs["score_map"].value
        if record.score_source == "output"
        else record._private_scores
    )
    scores = None if scores is None else _readonly(scores)
    if (
        mask.shape != image.shape
        or inspected.shape != image.shape
        or (scores is not None and scores.shape != image.shape)
    ):
        raise ValueError("Completed source maps differ from the consumed image grid")
    provenance = dict(
        snapshot_id=bundle.snapshot_id,
        block_id=bundle.block_id,
        output_revision=bundle.output_revision,
        execution_count=bundle.execution_count,
        passed=bool(bundle.passed),
        score=bundle.score,
        message=bundle.message,
        inputs={name: copy.deepcopy(p.payload) for name, p in bundle.inputs.items()},
        outputs={name: copy.deepcopy(p.payload) for name, p in bundle.outputs.items()},
    )
    return CompletedSegmentationCapture(
        record,
        _readonly(source),
        _readonly(image),
        mask,
        inspected,
        scores,
        image_format(source),
        provenance,
    )
