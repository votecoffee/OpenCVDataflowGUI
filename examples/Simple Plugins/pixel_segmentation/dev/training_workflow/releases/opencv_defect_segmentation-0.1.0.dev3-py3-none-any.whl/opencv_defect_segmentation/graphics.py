"""Source-aligned segmentation views, with excluded pixels visibly separate."""

import cv2
import numpy as np
from opencv_dataflow.features import overlay_image


def _excluded(output, inspected):
    # A neutral checker distinguishes unobserved pixels from low scores.
    # Use one row/column vector rather than allocating two full image grids.
    outside = inspected == 0
    if not np.any(outside):
        return
    rows = ((np.arange(output.shape[0]) // 8) % 2).astype(np.uint8)
    columns = ((np.arange(output.shape[1]) // 8) % 2).astype(np.uint8)
    checker = (rows[:, None] + columns[None, :]) % 2
    gray = cv2.cvtColor(output, cv2.COLOR_BGR2GRAY)
    output[outside] = np.clip(gray[outside, None] * .4 + 35 +
                              checker[outside, None] * 15, 0, 255).astype(np.uint8)


def draw_overlay(image, result):
    """Red foreground, lightly green observed background, gold coverage edges."""
    output = overlay_image(image)
    observed = result.inspected != 0
    positive = (result.mask != 0) & observed
    output[observed] = (.9 * output[observed] + .1 * np.array([65, 185, 85])).astype(np.uint8)
    output[positive] = (.45 * output[positive] + .55 * np.array([25, 35, 235])).astype(np.uint8)
    _excluded(output, result.inspected)
    contours, _ = cv2.findContours(result.inspected, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(output, contours, -1, (30, 211, 238), max(1, min(result.mask.shape) // 1000))
    return output


def draw_heatmap(image, result):
    """Viridis foreground vote fraction, fixed 0..1 scale, not auto-contrast."""
    if result.score_map is None:
        raise ValueError("Include scores to render the segmentation heatmap.")
    levels = np.rint(np.clip(result.score_map, 0, 1) * 255).astype(np.uint8)
    output = cv2.applyColorMap(levels, cv2.COLORMAP_VIRIDIS)
    outside = result.inspected == 0
    output[outside] = overlay_image(image)[outside]
    _excluded(output, result.inspected)
    return output
