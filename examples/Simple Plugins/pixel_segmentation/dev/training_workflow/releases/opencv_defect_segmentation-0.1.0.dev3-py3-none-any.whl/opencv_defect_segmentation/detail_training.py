"""Create local training examples from observed small-defect contrast."""

from dataclasses import dataclass

import cv2
import numpy as np

from . import DEFECT, NORMAL, TrainingImage, _mask


@dataclass(frozen=True)
class _Stamp:
    positive: np.ndarray
    contrast: np.ndarray
    native_peak: int


def _checked(sample):
    pixels, labels = sample.pixels, sample.labels
    if pixels.ndim != 2 or not pixels.size or pixels.dtype not in (np.uint8, np.uint16):
        raise ValueError("Detail training requires nonempty 8- or 16-bit grayscale images.")
    if labels.dtype != np.uint8 or labels.shape != pixels.shape or np.any(labels > DEFECT):
        raise ValueError("Detail training requires aligned uint8 labels with values 0, 1, or 2.")
    return _mask(sample.valid, pixels.shape)


def _stamp(sample, observed, component, bounds):
    x, y, width, height = bounds
    image_height, image_width = sample.pixels.shape
    if x < 4 or y < 4 or x + width + 4 > image_width or y + height + 4 > image_height:
        raise ValueError("A detail exemplar needs four pixels of context around its marked defect.")
    margin = max(32, 3 * max(width, height))
    x0, x1 = max(0, x - margin), min(image_width, x + width + margin)
    y0, y1 = max(0, y - margin), min(image_height, y + height + margin)
    window = np.s_[y0:y1, x0:x1]
    image = sample.pixels[window].astype(np.float32)
    normal = (sample.labels[window] == NORMAL) & observed[window]
    if np.count_nonzero(normal) < 25:
        raise ValueError("A detail exemplar needs at least 25 adjacent observed normal labels.")

    rows, cols = np.indices(image.shape)
    xnorm = (cols + x0 - (x + width / 2)) / margin
    ynorm = (rows + y0 - (y + height / 2)) / margin
    design = np.stack((np.ones(image.shape), xnorm, ynorm), axis=-1)
    controls, values = design[normal], image[normal]
    keep = np.ones(len(values), dtype=bool)
    native_peak = int(np.iinfo(sample.pixels.dtype).max)
    for _ in range(3):
        plane, _, rank, _ = np.linalg.lstsq(controls[keep], values[keep], rcond=None)
        if rank < 3:
            plane = np.array([np.median(values), 0., 0.])
            break
        error = values - controls @ plane
        center = np.median(error)
        spread = 1.4826 * np.median(np.abs(error - center))
        chosen = np.abs(error - center) <= max(32 * native_peak / 65535, 3 * spread)
        if np.count_nonzero(chosen) < 25 or np.array_equal(chosen, keep):
            break
        keep = chosen
    # Limit extrapolation beyond the marked normal samples.
    low, high = np.percentile(values, (5, 95))
    expected = np.clip(design @ plane, low, high)
    tight = np.s_[y - y0 - 4:y - y0 + height + 4, x - x0 - 4:x - x0 + width + 4]
    positive = component[window][tight].copy()
    residual = (image - expected)[tight]
    polarity = np.sign(np.median(residual[positive]))
    if polarity == 0:
        raise ValueError("A detail exemplar needs measurable contrast against its normal neighborhood.")
    signed = (polarity * np.maximum(polarity * residual, 0)).astype(np.float32)
    contrast = cv2.GaussianBlur(signed * positive, (0, 0), .65)
    return _Stamp(positive, contrast, native_peak)


def _collect(examples):
    stamps = []
    for sample in examples:
        observed = _checked(sample)
        positive = sample.labels == DEFECT
        if not positive.any() or np.any(positive & ~observed):
            raise ValueError("Each detail example needs fully observed defect labels.")
        count, labels, stats, _ = cv2.connectedComponentsWithStats(positive.astype(np.uint8))
        for index in range(1, count):
            stamps.append(_stamp(sample, observed, labels == index, tuple(map(int, stats[index, :4]))))
    if not stamps:
        raise ValueError("Supply at least one labeled detail example.")
    return stamps


def _synthesize(sample, stamps, count, random):
    available = _checked(sample) & (sample.labels == NORMAL)
    image = sample.pixels.copy()
    labels = np.zeros_like(sample.labels)
    native_peak = np.iinfo(sample.pixels.dtype).max
    for _ in range(count):
        stamp = stamps[int(random.integers(len(stamps)))]
        flip = int(random.integers(4))
        sy, sx = (-1 if flip & 1 else 1), (-1 if flip & 2 else 1)
        positive, contrast = stamp.positive[::sy, ::sx], stamp.contrast[::sy, ::sx]
        height, width = positive.shape
        if height > labels.shape[0] or width > labels.shape[1]:
            continue
        # A top-left erosion anchor finds boxes entirely inside normal labels.
        eligible = cv2.erode(available.astype(np.uint8), np.ones((height, width), np.uint8),
                             anchor=(0, 0), borderType=cv2.BORDER_CONSTANT, borderValue=0)
        positions = np.flatnonzero(eligible)
        if not len(positions):
            continue
        y, x = np.unravel_index(positions[int(random.integers(len(positions)))], labels.shape)
        area = np.s_[y:y + height, x:x + width]
        strength = float(random.uniform(.75, 1.25)) * (native_peak / stamp.native_peak)
        original = image[area]
        inserted = np.rint(np.clip(original.astype(np.float32) + contrast * strength, 0, native_peak))
        if not np.any(inserted[positive] != original[positive]):
            continue
        image[area] = inserted.astype(image.dtype)
        local = labels[area]
        local[:] = NORMAL
        uncertain = cv2.dilate(positive.astype(np.uint8), np.ones((5, 5), np.uint8)) != 0
        local[uncertain] = 0
        local[positive] = DEFECT
        # Keep insertions separated, including their normal context.
        available[max(0, y - 4):y + height + 4, max(0, x - 4):x + width + 4] = False
    if not labels.any():
        return None
    return TrainingImage(image, labels, sample.valid)


def augment_details(samples, examples, *, copies_per_image=6, seed=131):
    """Append examples with measured defect contrast placed on labeled normal pixels.

    Use fully observed detail exemplars at the same sampling scale as the
    training images. The original samples are retained, including broad defects.
    """
    if type(copies_per_image) is not int or copies_per_image < 1:
        raise ValueError("Detail copies per image must be a positive integer.")
    originals = list(samples)
    stamps = _collect(examples)
    random = np.random.default_rng(seed)
    augmented = [_synthesize(sample, stamps, copies_per_image, random) for sample in originals]
    added = [sample for sample in augmented if sample is not None]
    if not added:
        raise ValueError("No observed normal region could accept a detail exemplar with measurable contrast.")
    return [*originals, *added]
