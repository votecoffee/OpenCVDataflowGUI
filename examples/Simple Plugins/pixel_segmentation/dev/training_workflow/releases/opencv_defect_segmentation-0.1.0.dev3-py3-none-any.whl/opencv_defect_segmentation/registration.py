"""Extract inspection patches from an affine part pose at source image depth."""

from dataclasses import dataclass
from numbers import Integral

import cv2
import numpy as np


@dataclass(frozen=True)
class RegisteredPatch:
    pixels: np.ndarray
    valid: np.ndarray
    to_source: np.ndarray


def _valid_footprint(to_source, size, image_shape):
    # Each affine coordinate reaches its extrema at output pixel-center corners.
    x_span = to_source[:2, 0] * (size[0] - 1)
    y_span = to_source[:2, 1] * (size[1] - 1)
    origin = to_source[:2, 2]
    low = np.minimum(x_span, 0) + np.minimum(y_span, 0) + origin
    high = np.maximum(x_span, 0) + np.maximum(y_span, 0) + origin
    if np.all(low >= 0) and np.all(high <= np.asarray(image_shape[::-1]) - 1):
        return np.ones(size[::-1], dtype=bool)
    y, x = np.ogrid[:size[1], :size[0]]
    xx = to_source[0, 0] * x + to_source[0, 1] * y + to_source[0, 2]
    yy = to_source[1, 0] * x + to_source[1, 1] * y + to_source[1, 2]
    return (xx >= 0) & (xx <= image_shape[1] - 1) & (yy >= 0) & (yy <= image_shape[0] - 1)


def warp_registered_patch(image, patch_to_source, size, *, samples_per_pixel=1, source_valid=None):
    """Resample a part-local pixel grid and identify complete source support.

    The size is the trained patch width and height. The affine transform maps
    trained pixel centers to source pixel centers. Supersampling preserves the
    center and bounds of that grid, so a low-resolution locator can hand off to
    a higher-resolution inspection. The returned transform maps the new grid.
    """
    if image.ndim != 2 or not image.size or image.dtype not in (np.uint8, np.uint16):
        raise ValueError("Supply a nonempty 8- or 16-bit grayscale image.")
    width, height = size
    if any(not isinstance(value, Integral) or isinstance(value, (bool, np.bool_)) or value < 1
           for value in (width, height, samples_per_pixel)):
        raise ValueError("Patch dimensions and sampling factor must be positive integers.")
    transform = np.asarray(patch_to_source, dtype=np.float64)
    if transform.shape == (2, 3):
        transform = np.vstack((transform, [0., 0., 1.]))
    if (transform.shape != (3, 3) or not np.all(np.isfinite(transform))
            or not np.array_equal(transform[2], [0., 0., 1.])
            or np.linalg.det(transform[:2, :2]) == 0):
        raise ValueError("Patch pose must be a finite, nonsingular affine transform.")

    samples_per_pixel = int(samples_per_pixel)
    step = 1 / samples_per_pixel
    offset = (step - 1) / 2
    to_source = transform @ [[step, 0, offset], [0, step, offset], [0, 0, 1]]
    size = int(width) * samples_per_pixel, int(height) * samples_per_pixel
    flags = cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP
    pixels = cv2.warpAffine(image, to_source[:2], size, flags=flags)
    valid = _valid_footprint(to_source, size, image.shape)
    if source_valid is not None:
        if source_valid.shape != image.shape or source_valid.dtype not in (np.uint8, np.bool_):
            raise ValueError("Supply a source-aligned binary mask as bool or uint8.")
        coverage = cv2.warpAffine((source_valid != 0).astype(np.float32), to_source[:2], size, flags=flags)
        valid &= coverage == 1
    return RegisteredPatch(pixels, valid, to_source)
