"""Edit categorical labels on the native pixel grid and save them explicitly."""

from dataclasses import dataclass
from pathlib import Path
from tempfile import NamedTemporaryFile

import cv2
import numpy as np

from . import DEFECT, IGNORE, NORMAL, _mask
from .image_io import label_entries


def annotation_entries(manifest, *, region_path=None, model_path=None):
    entries = list(label_entries(manifest))
    if not entries:
        raise ValueError("The annotation manifest is empty.")
    protected = {path.resolve() for path in (manifest, region_path, model_path) if path is not None}
    for entry in entries:
        protected.add(entry.image.resolve())
        if entry.valid is not None:
            protected.add(entry.valid.resolve())
    outputs = set()
    for entry in entries:
        output = entry.labels.resolve()
        if entry.labels.suffix.lower() != ".png" or output in outputs or output in protected:
            raise ValueError("Each annotation needs a distinct PNG label path separate from input files.")
        outputs.add(output)
    return entries


def _existing_bytes(path):
    try:
        return path.read_bytes()
    except FileNotFoundError:
        return None


def connected_selection(eligible, point):
    """Return the 8-connected set containing the seed pixel."""
    x, y = point
    height, width = eligible.shape
    if not (0 <= x < width and 0 <= y < height and eligible[y, x]):
        return np.zeros(eligible.shape, dtype=bool)
    connected = eligible.astype(np.uint8)
    cv2.floodFill(connected, None, (x, y), 2, flags=8)
    return connected == 2


def wand_selection(pixels, allowed, point, tolerance):
    """Select connected pixels within tolerance of the native seed intensity."""
    x, y = point
    height, width = allowed.shape
    if not (0 <= x < width and 0 <= y < height):
        return np.zeros(allowed.shape, dtype=bool)
    eligible = (np.abs(pixels.astype(np.int32) - int(pixels[y, x])) <= tolerance) & allowed
    return connected_selection(eligible, point)


@dataclass
class Selection:
    kind: str
    paths: list

    @classmethod
    def trace(cls, selected):
        outlines, _ = cv2.findContours(selected.astype(np.uint8), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        return cls("polygon", [[tuple(map(int, point)) for point in contour[:, 0]] for contour in outlines])

    def copy(self):
        return Selection(self.kind, [path.copy() for path in self.paths])

    def handles(self):
        if self.kind == "polygon":
            return [(r, i, point) for r, path in enumerate(self.paths) for i, point in enumerate(path)]
        (x0, y0), (x1, y1) = self.paths[0]
        left, right = sorted((x0, x1))
        top, bottom = sorted((y0, y1))
        return [(0, i, point) for i, point in enumerate(
            ((left, top), (right, top), (right, bottom), (left, bottom)))]

    def translate(self, dx, dy, shape):
        points = [point for path in self.paths for point in path]
        if not points:
            return
        xs, ys = zip(*points)
        dx = min(max(dx, -min(xs)), shape[1] - 1 - max(xs))
        dy = min(max(dy, -min(ys)), shape[0] - 1 - max(ys))
        self.paths = [[(x + dx, y + dy) for x, y in path] for path in self.paths]

    def raster(self, shape):
        selected = np.zeros(shape, dtype=np.uint8)
        if self.kind == "polygon":
            paths = [np.asarray(path, np.int32) for path in self.paths if path]
            if paths:
                cv2.drawContours(selected, paths, -1, 1, cv2.FILLED)
        else:
            (x0, y0), (x1, y1) = self.paths[0]
            if self.kind == "rectangle":
                cv2.rectangle(selected, (min(x0, x1), min(y0, y1)), (max(x0, x1), max(y0, y1)), 1, cv2.FILLED)
            else:
                cv2.ellipse(selected, (x0+x1, y0+y1), (abs(x1-x0), abs(y1-y0)), 0, 0, 360,
                            1, cv2.FILLED, shift=1)
        return selected != 0


class MaskDraft:
    """A paint session that leaves inputs untouched until an explicit save."""

    def __init__(self, shape, path, *, region=None, valid=None):
        self.path = Path(path)
        if self.path.suffix.lower() != ".png":
            raise ValueError("Label masks must use PNG.")
        self.allowed = _mask(region, shape) & _mask(valid, shape)
        self._file_bytes = _existing_bytes(self.path)
        if self._file_bytes is None:
            self.labels = np.zeros(shape, dtype=np.uint8)
        else:
            self.labels = cv2.imdecode(np.frombuffer(self._file_bytes, np.uint8), cv2.IMREAD_UNCHANGED)
            if (self.labels is None or self.labels.dtype != np.uint8 or self.labels.shape != shape
                    or np.any(self.labels > DEFECT)):
                raise ValueError("Existing labels must be aligned uint8 values 0, 1, or 2.")
        self._saved = self.labels.copy()
        self._undo = []
        self._undo_limit = max(1, min(24, (48 * 1024**2) // max(1, self.labels.nbytes)))
        self._before = None
        self._changed = False

    @property
    def dirty(self):
        return not np.array_equal(self.labels, self._saved)

    def begin_stroke(self):
        self.end_stroke()
        self._before = self.labels.copy()
        self._changed = False

    def paint(self, start, end, label, width):
        """Paint a line in source pixel coordinates and return the changed rectangle."""
        if label not in (IGNORE, NORMAL, DEFECT) or type(width) is not int or width < 1:
            raise ValueError("Choose a label and a positive brush width.")
        if self._before is None:
            raise RuntimeError("Begin a stroke before painting.")
        height, columns = self.labels.shape
        x0 = max(0, min(start[0], end[0]) - width)
        x1 = min(columns, max(start[0], end[0]) + width + 1)
        y0 = max(0, min(start[1], end[1]) - width)
        y1 = min(height, max(start[1], end[1]) + width + 1)
        if x0 >= x1 or y0 >= y1:
            return None
        ink = np.zeros((y1 - y0, x1 - x0), dtype=np.uint8)
        a = start[0] - x0, start[1] - y0
        b = end[0] - x0, end[1] - y0
        cv2.line(ink, a, b, 1, thickness=width, lineType=cv2.LINE_8)
        patch = np.s_[y0:y1, x0:x1]
        changed = (ink != 0) & self.allowed[patch] & (self.labels[patch] != label)
        if not changed.any():
            return None
        self.labels[patch][changed] = label
        self._changed = True
        return x0, y0, x1 - x0, y1 - y0

    def end_stroke(self):
        edited = self._before is not None and self._changed
        if edited:
            self._undo.append(self._before)
            if len(self._undo) > self._undo_limit:
                self._undo.pop(0)
        self._before = None
        self._changed = False
        return edited

    def apply_selection(self, selected, label, *, replace=None):
        if label not in (IGNORE, NORMAL, DEFECT):
            raise ValueError("Choose a label for the selected region.")
        selected = _mask(selected, self.labels.shape)
        replace = _mask(replace, self.labels.shape) if replace is not None else None
        updated = self.labels.copy()
        if replace is not None:
            updated[replace & self.allowed] = IGNORE
        updated[selected & self.allowed] = label
        return self._apply(updated)

    def import_labels(self, labels):
        if labels.shape != self.labels.shape or labels.dtype != np.uint8 or np.any(labels > DEFECT):
            raise ValueError("Import aligned 8-bit grayscale labels with values 0, 1, and 2.")
        return self._apply(np.where(self.allowed, labels, self.labels))

    def _apply(self, updated):
        self.end_stroke()
        if np.array_equal(updated, self.labels):
            return False
        self.begin_stroke()
        self.labels[:] = updated
        self._changed = True
        self.end_stroke()
        return True

    def undo(self):
        self.end_stroke()
        if not self._undo:
            return False
        self.labels[:] = self._undo.pop()
        return True

    def save(self):
        self.end_stroke()
        ok, encoded = cv2.imencode(".png", self.labels)
        if not ok:
            raise OSError("OpenCV could not encode the label mask.")
        data = encoded.tobytes()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = None
        try:
            with NamedTemporaryFile(dir=self.path.parent, prefix=".labels-", suffix=".png", delete=False) as stream:
                temporary = Path(stream.name)
                stream.write(data)
            if _existing_bytes(self.path) != self._file_bytes:
                raise OSError("The label file changed on disk. Reopen it before saving.")
            temporary.replace(self.path)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)
        self._file_bytes = data
        self._saved = self.labels.copy()
