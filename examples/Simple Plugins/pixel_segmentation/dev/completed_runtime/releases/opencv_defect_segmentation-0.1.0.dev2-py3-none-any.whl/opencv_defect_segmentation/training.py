"""Fit and check a candidate on the registered patch grid."""

from collections import Counter
from concurrent.futures import CancelledError
from dataclasses import dataclass
from hashlib import sha256

import cv2
import numpy as np

from . import DEFECT, NORMAL, PixelSegmenter, TrainingImage, _mask, _score_options, defect_mask_from_scores
from .detail_training import augment_details
from .evaluation import _COMPARISON_COLORS, _comparison_classes, _comparison_counts, metrics
from .image_io import label_entries, read_training_sample


@dataclass(frozen=True)
class TrainingCandidate:
    model: PixelSegmenter
    image_count: int
    normal_pixels: int
    defect_pixels: int
    validation_count: int
    validation_metrics: dict
    preview_name: str | None
    preview: np.ndarray | None
    skipped_drafts: int = 0
    training_fingerprints: frozenset[bytes] = frozenset()
    grid: tuple | None = None


@dataclass(frozen=True)
class ValidationReview:
    image_count: int
    counts: dict[tuple[float, int], dict[str, int]]
    unobserved_labels: int
    preview_name: str | None
    preview: np.ndarray | None


def fit_samples(samples, *, detail_examples=None, reference=None):
    """Use the same supervised fit for CLI and inspector training."""
    if detail_examples is not None:
        samples = augment_details(samples, detail_examples)
        cv2.setRNGSeed(0)
    return PixelSegmenter.train(samples, reference=reference)


def _labeled_sample(entry, region, grid):
    sample = read_training_sample(entry)
    pixels, labels = sample.pixels, sample.labels
    if pixels.ndim != 2 or not pixels.size or pixels.dtype not in (np.uint8, np.uint16):
        raise ValueError(f"{entry.name} must be a native grayscale image.")
    if labels.shape != pixels.shape or labels.dtype != np.uint8 or np.any(labels > DEFECT):
        raise ValueError(f"{entry.name} needs aligned uint8 labels with values 0, 1, or 2.")
    if grid is not None and grid != (pixels.shape, pixels.dtype):
        raise ValueError(f"{entry.name} must use the training patch grid and bit depth.")
    if region is not None:
        labels = np.where(_mask(region, pixels.shape), labels, 0).astype(np.uint8)
    return TrainingImage(pixels, labels, sample.valid)


def _dataset(manifest, region, grid=None, *, skip_missing=False):
    records = []
    skipped = 0
    for entry in label_entries(manifest):
        if skip_missing and not entry.labels.exists():
            skipped += 1
            continue
        sample = _labeled_sample(entry, region, grid)
        if grid is None:
            grid = sample.pixels.shape, sample.pixels.dtype
        records.append((entry.name, sample))
    if not records:
        if skipped:
            raise ValueError("Save training masks for the patches you want to fit.")
        raise ValueError("A selected training or validation manifest is empty.")
    return records, grid, skipped


def _preview(pixels, labels, inspected, predicted):
    top = np.iinfo(pixels.dtype).max
    low, high = 0, top
    if inspected.any():
        low, high = np.percentile(pixels[inspected], (1, 99))
        if high <= low:
            low, high = 0, top
    gray = np.clip((pixels.astype(np.float32) - low) * (255 / (high - low)), 0, 255).astype(np.uint8)
    rgb = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
    rgb[~inspected] //= 2
    classes = _comparison_classes(labels, inspected, predicted)
    for code in (1, 3, 4, 5):
        selected = classes == code
        rgb[selected] = (.4 * rgb[selected] + .6 * _COMPARISON_COLORS[code]).astype(np.uint8)
    scale = min(1., 640 / max(pixels.shape))
    if scale < 1.:
        size = tuple(max(1, round(length * scale)) for length in pixels.shape[::-1])
        rgb = cv2.resize(rgb, size, interpolation=cv2.INTER_AREA)
    return rgb


def _check_cancelled(cancelled):
    if cancelled is not None and cancelled():
        raise CancelledError("Validation cancelled.")


def _review_records(model, records, settings, region, cancelled=None):
    totals = {pair: Counter() for pair in dict.fromkeys(settings)}
    if not totals:
        raise ValueError("Supply a cutoff and minimum area for validation.")
    for pair in totals:
        _score_options(*pair)
    first = next(iter(totals))
    image_count = unobserved = 0
    preview_name = preview = None
    for name, sample in records:
        _check_cancelled(cancelled)
        result = model.segment(sample.pixels, region=region, valid=sample.valid,
                               threshold=first[0], min_area_px=first[1])
        _check_cancelled(cancelled)
        unobserved += int(np.count_nonzero((sample.labels != 0) & ~result.inspected))
        for pair, counts in totals.items():
            mask = result.defect if pair == first else defect_mask_from_scores(
                result.score, threshold=pair[0], min_area_px=pair[1])
            counts.update(_comparison_counts(_comparison_classes(sample.labels, result.inspected, mask)))
        if preview is None:
            preview_name = name
            preview = _preview(sample.pixels, sample.labels, result.inspected, mask)
        image_count += 1
    _check_cancelled(cancelled)
    return ValidationReview(image_count, {pair: dict(counts) for pair, counts in totals.items()},
                            unobserved, preview_name, preview)


def _fingerprint(sample):
    return sha256(memoryview(sample.pixels)).digest()


def evaluate_validation(model, manifest, settings, *, region=None, grid=None,
                        training_fingerprints=(), cancelled=None):
    """Review settings with one inference per image, without caching the dataset."""
    def records():
        expected_grid = grid
        seen = set()
        for entry in label_entries(manifest):
            _check_cancelled(cancelled)
            sample = _labeled_sample(entry, region, expected_grid)
            expected_grid = sample.pixels.shape, sample.pixels.dtype
            fingerprint = _fingerprint(sample)
            if fingerprint in training_fingerprints:
                raise ValueError("A validation image duplicates a training or detail image. Split by physical part.")
            if fingerprint in seen:
                raise ValueError("The validation manifest repeats the same image pixels.")
            seen.add(fingerprint)
            yield entry.name, sample
        if not seen:
            raise ValueError("The validation manifest is empty.")

    return _review_records(model, records(), settings, region, cancelled)


def train_candidate(manifest, *, region=None, detail_manifest=None, validation_manifest=None,
                    threshold=.5, min_area_px=1, use_saved_masks_only=False):
    """Fit on saved masks and return optional read-only validation evidence."""
    training, grid, skipped = _dataset(manifest, region, skip_missing=use_saved_masks_only)
    details = _dataset(detail_manifest, region, grid)[0] if detail_manifest is not None else []
    validation = _dataset(validation_manifest, region, grid)[0] if validation_manifest is not None else []
    fingerprints = frozenset(_fingerprint(sample) for _, sample in (*training, *details))
    if any(_fingerprint(sample) in fingerprints for _, sample in validation):
        raise ValueError("A validation image duplicates a training or detail image. Split by physical part.")
    normal_pixels = defect_pixels = 0
    for _, sample in training:
        valid = _mask(sample.valid, sample.pixels.shape)
        normal_pixels += int(np.count_nonzero((sample.labels == NORMAL) & valid))
        defect_pixels += int(np.count_nonzero((sample.labels == DEFECT) & valid))
    cv2.setRNGSeed(0)
    model = fit_samples((sample for _, sample in training),
                        detail_examples=(sample for _, sample in details) if details else None)
    pair = threshold, min_area_px
    review = _review_records(model, validation, (pair,), region) if validation else None
    return TrainingCandidate(model, len(training), normal_pixels, defect_pixels, len(validation),
                             metrics(review.counts[pair]) if review else {},
                             review.preview_name if review else None, review.preview if review else None,
                             skipped, fingerprints, grid)
