"""Read-only completed segmentation and reported sampled-grid component selection."""

import uuid
from pathlib import Path

import cv2
import numpy as np
from opencv_dataflow.canvas import pixmap
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from opencv_dataflow.images import ImageArray
from PySide6.QtCore import QRectF, Qt, QSignalBlocker, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
)


class _PickedView(FilmstripImageView):
    picked = Signal(float, float)

    def mousePressEvent(self, event):
        self._press = (
            event.position() if event.button() == Qt.MouseButton.LeftButton else None
        )
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        pressed = getattr(self, "_press", None)
        self._press = None
        super().mouseReleaseEvent(event)
        if pressed is not None and (pressed - event.position()).manhattanLength() <= 5:
            point = self.mapToScene(event.position().toPoint())
            if self.image_item.boundingRect().contains(point):
                self.picked.emit(point.x() - 0.5, point.y() - 0.5)


class CompletedSegmentationReviewDialog(QDialog):
    def __init__(self, parent, context, capture):
        super().__init__(parent)
        self.resize(1280, 960)
        self.setWindowTitle("Completed segmentation review")
        self.snapshot = None
        self.selected_part = self.selected_region = None
        self._capture = capture
        self._closed = False
        layout = QVBoxLayout(self)
        actions = QHBoxLayout()
        self.capture_button = QPushButton("Capture latest completed run")
        self.capture_button.clicked.connect(self.capture_latest)
        actions.addWidget(self.capture_button)
        self.overview_button = QPushButton("All parts overview")
        self.overview_button.clicked.connect(self.overview)
        actions.addWidget(self.overview_button)
        self.focus_button = QPushButton("Focus selected")
        self.focus_button.clicked.connect(self.focus)
        actions.addWidget(self.focus_button)
        self.export_button = QPushButton("Export frozen review…")
        self.export_button.clicked.connect(self.choose_export)
        actions.addWidget(self.export_button)
        close = QPushButton("Close review")
        close.clicked.connect(self.reject)
        actions.addWidget(close)
        layout.addLayout(actions)
        self.identity = QLabel("No completed frame captured")
        self.identity.setWordWrap(True)
        layout.addWidget(self.identity)
        self.status = QLabel()
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.summary = QLabel()
        self.summary.setWordWrap(True)
        layout.addWidget(self.summary)
        selection = QHBoxLayout()
        selection.addWidget(QLabel("Reported part/image"))
        self.part = QComboBox()
        self.part.currentIndexChanged.connect(self.select_part)
        selection.addWidget(self.part, 1)
        self.details = QLabel()
        self.details.setWordWrap(True)
        selection.addWidget(self.details, 2)
        layout.addLayout(selection)
        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(
            [
                "Region",
                "Patch X",
                "Patch Y",
                "Width",
                "Height",
                "Sampled area",
                "Local mean vote",
            ]
        )
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setMaximumHeight(155)
        self.table.itemSelectionChanged.connect(self.select_region)
        layout.addWidget(self.table)
        self.tabs = QTabWidget()
        self.views = {}
        for key, label in (
            ("overlay", "Source union + selected bounds"),
            ("votes", "Forest vote fractions"),
            ("coverage", "Inspected coverage"),
        ):
            view = _PickedView(self)
            view.picked.connect(self.pick)
            self.views[key] = view
            self.tabs.addTab(view, label)
        self.source_view = FilmstripImageView(self)
        self.tabs.addTab(self.source_view, "Exact consumed input")
        self.assessment_view = FilmstripImageView(self)
        self.tabs.addTab(self.assessment_view, "Assessment display")
        self.tabs.currentChanged.connect(self.render)
        layout.addWidget(self.tabs, 1)
        self.legend = QLabel(
            "Red foreground · green inspected background · gray checks excluded/unobserved · cyan projected sampled-grid bounds/center. "
            "Votes: fixed 0..1 Viridis, not calibrated probability. Source overlap uses maximum votes; local component statistics stay on each sampled patch."
        )
        self.legend.setWordWrap(True)
        layout.addWidget(self.legend)
        self.export_status = QLabel()
        self.export_status.setWordWrap(True)
        layout.addWidget(self.export_status)
        self.finished.connect(lambda *_: setattr(self, "_closed", True))
        unsubscribe = context.subscribe_outputs(self.publication_changed)
        self.finished.connect(unsubscribe)
        self.destroyed.connect(unsubscribe)
        self.capture_latest()

    def publication_changed(self, revision):
        if self.snapshot is not None and not self._closed:
            self.status.setText(
                "Editor publication changed. This frozen frame stays unchanged; capture latest explicitly."
            )

    def capture_latest(self):
        if self._closed:
            return
        try:
            snapshot = self._capture()
        except (ValueError, RuntimeError, KeyError) as error:
            self.status.setText(
                str(error)
                + (
                    " Previous frozen frame remains displayed."
                    if self.snapshot is not None
                    else ""
                )
            )
            self.export_button.setEnabled(self.snapshot is not None)
            return
        self.snapshot = snapshot
        record, p = snapshot.record, snapshot.provenance
        report, parameters = record.report, record.parameters
        details = snapshot.report()
        self.identity.setText(
            f"{p['block_id']} · completion {p['execution_count']} · {details['state'].replace('_', ' ').upper()} · "
            f"model {str(report['model_sha256'])[:16]} · input {snapshot.source_sha256[:16]}"
        )
        self.status.setText(
            "Frozen completed segmentation. No new inference, model reload, rethresholding or annotation changes. "
            + (
                "Votes were not retained. Enable Emit score map or Render heatmap and run again to retain them."
                if snapshot.scores is None
                else "Votes retained from this completed run; excluded zeros are not observed background."
            )
        )
        self.summary.setText(
            f"{report['count']} parts/images; {report['incomplete_count']} with incomplete coverage · "
            f"{details['source_inspected_pixels']} source pixels inspected; {details['source_foreground_pixels']} foreground · "
            f"cutoff {parameters['threshold']:g}, minimum area {parameters['min_area_px']} sampled pixels · "
            "Block judgment reports available observations, not part quality acceptance."
        )
        self.source_view.set_image(
            pixmap(ImageArray(snapshot.source_pixels, snapshot.source_format))
        )
        with QSignalBlocker(self.part):
            self.part.clear()
            self.part.addItem("All parts overview", None)
            for index, item in enumerate(report["parts"]):
                self.part.addItem(
                    f"{index + 1}: {item['inspected_fraction']:.0%} observed, {len(item['regions'])} regions",
                    index,
                )
        self.selected_part = self.selected_region = None
        self.export_button.setEnabled(True)
        self.select_part()

    def select_part(self):
        if self.snapshot is None:
            return
        self.selected_part = self.part.currentData()
        self.selected_region = None
        rows = (
            []
            if self.selected_part is None
            else self.snapshot.record.report["parts"][self.selected_part]["regions"]
        )
        with QSignalBlocker(self.table):
            self.table.setRowCount(len(rows))
            for i, row in enumerate(rows):
                values = [
                    i + 1,
                    row["x"],
                    row["y"],
                    row["width"],
                    row["height"],
                    row["area_px"],
                    f"{row['mean_score']:.5g}",
                ]
                for j, value in enumerate(values):
                    self.table.setItem(i, j, QTableWidgetItem(str(value)))
        self.table.resizeColumnsToContents()
        self.render()

    def select_region(self):
        rows = self.table.selectionModel().selectedRows()
        self.selected_region = rows[0].row() if rows else None
        self.render()

    def overview(self):
        self.part.setCurrentIndex(0)
        self.selected_part = self.selected_region = None
        self.select_part()

    def render(self):
        if self.snapshot is None:
            return
        snapshot = self.snapshot
        selection = snapshot.selection(self.selected_part, self.selected_region)
        if selection is None:
            self.details.setText(
                "Overview: source union. Choose a part/image to see its reported components."
            )
        else:
            item = selection["part"]
            self.details.setText(
                f"Sampled grid {item['patch_size']}; {item['inspected_pixels']}/{item['requested_pixels']} inspected; "
                f"{item['defect_pixels']} foreground. Bounds show a footprint, not isolated component pixels."
            )
        self.focus_button.setEnabled(selection is not None)
        active = self.tabs.currentWidget()
        for mode, view in self.views.items():
            if active is not view:
                continue
            if mode == "votes" and snapshot.scores is None:
                pixels = np.full((*snapshot.image.shape, 3), 55, np.uint8)
                cv2.putText(
                    pixels,
                    "Votes not retained",
                    (8, min(25, pixels.shape[0] - 1)),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (240, 240, 240),
                    1,
                    cv2.LINE_AA,
                )
            else:
                pixels = snapshot.render(mode, self.selected_part, self.selected_region)
            view.set_image(pixmap(pixels))
        if active is self.assessment_view:
            self.assessment_view.set_image(
                pixmap(snapshot.assessment(self.selected_part, self.selected_region))
            )

    def pick(self, x, y):
        if self.snapshot is None:
            return
        parts = self.snapshot.record.report["parts"]
        candidates = (
            range(len(parts)) if self.selected_part is None else (self.selected_part,)
        )
        for p in candidates:
            for r in range(len(parts[p]["regions"])):
                polygon = np.asarray(
                    self.snapshot.selection(p, r)["source_polygon"], np.float32
                )
                if cv2.pointPolygonTest(polygon, (x, y), False) >= 0:
                    self.part.setCurrentIndex(p + 1)
                    self.table.selectRow(r)
                    return

    def focus(self):
        if self.snapshot is None:
            return
        bounds = self.snapshot.bounds(self.selected_part, self.selected_region)
        for view in self.views.values():
            view.fitInView(QRectF(*bounds), Qt.AspectRatioMode.KeepAspectRatio)
            view._fitted = False

    def export_to(self, directory):
        if self.snapshot is None:
            raise ValueError("Capture a completed run before exporting")
        return self.snapshot.export(directory, self.selected_part, self.selected_region)

    def choose_export(self):
        parent = QFileDialog.getExistingDirectory(
            self, "Directory for a new frozen segmentation review"
        )
        if parent:
            try:
                target = self.export_to(
                    Path(parent) / f"segmentation-review-{uuid.uuid4().hex[:12]}"
                )
                self.export_status.setText(
                    f"Saved {target}. Configuration and annotations unchanged."
                )
            except (OSError, ValueError, cv2.error) as error:
                self.export_status.setText(str(error))
