"""Read native image data and resolve label manifests."""

import json
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

from . import TrainingImage


@dataclass(frozen=True)
class LabelEntry:
    name: str
    image: Path
    labels: Path
    valid: Path | None


def read_image(path):
    image = cv2.imdecode(np.frombuffer(path.read_bytes(), dtype=np.uint8), cv2.IMREAD_UNCHANGED)
    if image is None:
        raise ValueError(f"Could not decode {path}")
    return image


def label_entries(path):
    records = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(records, list):
        raise ValueError("The label manifest must be an array of image entries.")
    for record in records:
        if (not isinstance(record, dict) or not {"image", "labels"} <= record.keys() <= {"image", "labels", "valid"}
                or any(not isinstance(name, str) or not name.strip() for name in record.values())):
            raise ValueError("Each label entry needs image and labels paths, with optional valid.")
        yield LabelEntry(record["image"], path.parent / record["image"], path.parent / record["labels"],
                         path.parent / record["valid"] if "valid" in record else None)


def read_training_sample(entry):
    return TrainingImage(read_image(entry.image), read_image(entry.labels),
                         read_image(entry.valid) if entry.valid is not None else None)


def training_samples(path):
    """Read the native images, saved labels, and optional observation masks."""
    for entry in label_entries(path):
        yield entry.name, read_training_sample(entry)
