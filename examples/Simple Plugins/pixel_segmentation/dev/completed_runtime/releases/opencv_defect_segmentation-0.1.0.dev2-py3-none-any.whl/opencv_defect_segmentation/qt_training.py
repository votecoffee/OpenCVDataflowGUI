"""Optional DataflowGUI setup dialog for a pinned segmentation candidate."""

from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from pathlib import Path
from threading import Event

import cv2
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QImage, QPixmap
from PySide6.QtWidgets import (
    QCheckBox, QDialog, QFileDialog, QFormLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit, QPushButton, QVBoxLayout,
)

from .annotation import annotation_entries
from .capture import capture_patches
from .dataflow import _REGION_EXTENSIONS, _asset_path, _decode_region, _digest, capture_directory, stage_candidate
from .qt_annotation import AnnotationWindow
from .evaluation import metrics
from .training import evaluate_validation, train_candidate


class SegmentationTrainingDialog(QDialog):
    def __init__(self, parent, parameters, context, *, block=None):
        super().__init__(parent)
        if context.project_dir is None:
            raise ValueError("Save the project before training a segmentation candidate.")
        self.setWindowTitle("Train segmentation candidate")
        self.resize(720, 520)
        self._project = Path(context.project_dir)
        self._block, self._context = block, context
        self._parameters = parameters
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="segment-training")
        self._future = self._candidate = self._editor = None
        self._reviewed_settings = None
        self._validation_review = None
        self._job = None
        self._cancel_work = Event()
        self._region_bytes = None
        self._pinned_region_hash = None
        self._region_error = None
        self._closing = False
        self._poll = QTimer(self)
        self._poll.setInterval(35)
        self._poll.timeout.connect(self._receive)
        self.finished.connect(self._shutdown)

        layout = QVBoxLayout(self)
        guidance = QLabel("Capture the last Debug run or choose a registered training manifest.")
        guidance.setWordWrap(True)
        layout.addWidget(guidance)
        self.form = QGroupBox("Training inputs")
        layout.addWidget(self.form)
        self.paths = {}
        fields = QFormLayout(self.form)
        self._path_row(fields, "training", "Training manifest", "Label manifests (*.json)")
        self._path_row(fields, "region", "Patch region", "Region masks (*.png)", optional=True)
        self._path_row(fields, "details", "Detail examples", "Label manifests (*.json)", optional=True)
        self._path_row(fields, "validation", "Validation manifest", "Label manifests (*.json)", optional=True)
        self.saved_only = QCheckBox("Use saved masks only")
        self.saved_only.toggled.connect(self._saved_only_changed)
        fields.addRow("", self.saved_only)

        labeling = QHBoxLayout()
        self.capture = QPushButton("Capture last run")
        self.capture.setToolTip("Run the block in Debug with its required inputs connected.")
        self.capture.clicked.connect(self._capture)
        self.labels = QPushButton("Open training labels")
        self.labels.clicked.connect(lambda: self._open_labels("training"))
        self.validation_labels = QPushButton("Open validation labels")
        self.validation_labels.clicked.connect(lambda: self._open_labels("validation"))
        for widget in (self.capture, self.labels, self.validation_labels):
            labeling.addWidget(widget)
        labeling.addStretch()
        layout.addLayout(labeling)

        actions = QHBoxLayout()
        self.train = QPushButton("Train candidate")
        self.train.clicked.connect(self._train)
        self.evaluate = QPushButton("Evaluate validation set")
        self.evaluate.clicked.connect(self._evaluate)
        self.stage = QPushButton("Stage candidate")
        self.stage.setAutoDefault(False)
        self.stage.clicked.connect(self.accept)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        for widget in (self.train, self.evaluate, self.stage, cancel):
            actions.addWidget(widget)
        layout.addLayout(actions)

        self.summary = QLabel("Choose a training manifest to begin.")
        self.summary.setWordWrap(True)
        self.summary.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.summary)
        self.reviewed_summary = QLabel()
        self.reviewed_summary.setWordWrap(True)
        self.reviewed_summary.hide()
        layout.addWidget(self.reviewed_summary)
        self.preview_title = QLabel()
        self.preview_title.setWordWrap(True)
        self.preview_title.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.preview_title)
        self.preview = QLabel()
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.preview, 1)
        self._initial_region()
        self._sync()

    def _path_row(self, form, key, title, file_filter, *, optional=False):
        row = QHBoxLayout()
        field = QLineEdit()
        field.setReadOnly(True)
        if optional:
            field.setPlaceholderText("Optional")
        self.paths[key] = field
        row.addWidget(field, 1)
        pick = QPushButton("Browse…")
        pick.clicked.connect(lambda: self._pick(key, title, file_filter))
        row.addWidget(pick)
        if optional:
            clear = QPushButton("Clear")
            clear.clicked.connect(lambda: self._set_path(key, ""))
            row.addWidget(clear)
        form.addRow(title, row)

    def _pick(self, key, title, file_filter):
        current = self.paths[key].text()
        directory = Path(current).parent if current else self._project
        path, _ = QFileDialog.getOpenFileName(self, f"Select {title.lower()}", str(directory), file_filter)
        if path:
            self._set_path(key, path)

    def _set_path(self, key, path):
        self.paths[key].setText(str(path))
        if key == "training":
            self.saved_only.setChecked(False)
        if key == "region":
            self._pinned_region_hash = self._region_error = None
        if key == "validation" and self._candidate is not None:
            self._candidate = replace(self._candidate, validation_count=0, validation_metrics={},
                                      preview_name=None, preview=None)
            self._set_reviewed_settings(None)
            self._clear_validation_preview()
            self._show_candidate()
        else:
            self._clear_candidate()
        if self._region_error is None and self._candidate is None:
            self.summary.setText("Training inputs updated.")
        self._sync()

    def _saved_only_changed(self):
        self._clear_candidate()
        self._sync()

    def _initial_region(self):
        path = self._parameters["region_path"]
        if not path and not self._parameters["region_sha256"]:
            return
        try:
            resolved = _asset_path(self._project, path, _REGION_EXTENSIONS)
            self.paths["region"].setText(str(resolved))
            self._pinned_region_hash = self._parameters["region_sha256"].lower()
            self._read_region()
        except (OSError, ValueError, cv2.error) as error:
            self._region_error = str(error)
            self.summary.setText(f"Existing region could not be verified. Select a region or clear it.\n{error}")

    def _read_region(self):
        path = self.paths["region"].text()
        if not path:
            return None, None
        data = Path(path).read_bytes()
        if self._pinned_region_hash is not None and _digest(data) != self._pinned_region_hash:
            raise ValueError("The region asset SHA-256 does not match its pin.")
        return data, _decode_region(data)

    def _sync(self):
        available = self._future is None and self._editor is None
        ready = available and self._region_error is None
        self.form.setEnabled(available)
        self.capture.setEnabled(ready and self._block is not None
                                and self._block.can_capture_patches())
        self.labels.setEnabled(ready and bool(self.paths["training"].text()))
        self.validation_labels.setEnabled(ready and bool(self.paths["validation"].text()))
        self.train.setEnabled(self.labels.isEnabled())
        can_evaluate = self._candidate is not None or (
            self._block is not None and bool(self._parameters["model_path"])
        )
        self.evaluate.setEnabled(self.validation_labels.isEnabled() and can_evaluate)
        self.stage.setText("Stage candidate" if self._candidate is not None else "Stage settings")
        self.stage.setEnabled(available and (self._candidate is not None or self._reviewed_settings is not None))

    def _clear_candidate(self):
        self._candidate = self._region_bytes = None
        self._set_reviewed_settings(None)
        self._clear_validation_preview()

    def _clear_validation_preview(self):
        self._validation_review = None
        self.preview.clear()
        self.preview_title.clear()

    def _set_reviewed_settings(self, settings):
        self._reviewed_settings = settings
        if settings is not None:
            cutoff, area = settings
            self.reviewed_summary.setText(f"Kept cutoff {cutoff:g} and minimum area {area} px for staging.")
        self.reviewed_summary.setVisible(settings is not None)

    def _keep_settings(self, cutoff, area):
        pair = cutoff, area
        if self._validation_review is not None and pair != next(reversed(self._validation_review.counts)):
            self._clear_validation_preview()
            if self._candidate is not None:
                self._show_candidate()
            else:
                self.summary.setText("Evaluate the validation set at the kept settings.")
        self._set_reviewed_settings(pair)

    def _labels_saved(self):
        if self._candidate is not None:
            self._editor.disable_settings_handoff()
        self._clear_candidate()

    def _open_labels(self, key):
        validating = key == "validation"
        button = self.validation_labels if validating else self.labels
        if not button.isEnabled():
            return
        candidate = self._candidate
        model = candidate.model if candidate is not None else None
        pinned = None
        if model is None and self._block is not None and self._parameters["model_path"]:
            try:
                pinned, model, _ = self._block._verified_assets(self._parameters)
            except (OSError, ValueError, cv2.error) as error:
                self.summary.setText(f"Prediction unavailable. {error}")
        try:
            if candidate is None:
                region_bytes, region = self._read_region()
            else:
                region_bytes = self._region_bytes
                region = _decode_region(region_bytes) if region_bytes is not None else None
            manifest = Path(self.paths[key].text())
            region_path = self._optional_path("region")
            entries = annotation_entries(manifest, region_path=region_path)
            region_hash = _digest(region_bytes) if region_bytes is not None else None
            can_stage_pinned = (pinned is not None and pinned[1] == region_hash
                                and not self._parameters["capture_only"])
            cutoff, area = self._reviewed_settings or (
                self._parameters["threshold"], self._parameters["min_area_px"]
            )
            editor = AnnotationWindow(entries, region=region, model=model, parent=self,
                                      threshold=cutoff, min_area_px=area, compare_labels=validating,
                                      allow_keep_settings=validating and (candidate is not None or can_stage_pinned))
        except (OSError, ValueError, cv2.error) as error:
            self.summary.setText(f"Could not open labels. {error}")
            return
        self._editor = editor
        editor.setWindowModality(Qt.WindowModality.WindowModal)
        editor.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        editor.labels_saved.connect(self._labels_saved)
        editor.settings_kept.connect(self._keep_settings)
        editor.destroyed.connect(self._labels_closed)
        editor.show()
        self._sync()

    def _labels_closed(self):
        if self._closing:
            return
        self._editor = None
        if self._candidate is None and self._reviewed_settings is None and self._validation_review is None:
            self.summary.setText("Train using the saved masks.")
        self._sync()

    def _capture(self):
        if not self.capture.isEnabled():
            return
        try:
            _, region = self._read_region()
            image, valid, placements, frame = self._block.training_snapshot(self._context)
            directory = capture_directory(self._project)
            self._future = self._executor.submit(
                capture_patches, image, placements, directory,
                samples_per_pixel=self._parameters["samples_per_pixel"],
                source_valid=valid, region=region, frame_payload=frame, cancelled=self._cancel_work.is_set,
            )
        except (OSError, ValueError, RuntimeError, cv2.error) as error:
            self.summary.setText(f"Could not start capture. {error}")
            return
        self._job = "Capture"
        self.summary.setText("Capturing native registered patches…")
        self._poll.start()
        self._sync()

    def _train(self):
        if not self.train.isEnabled():
            return
        self._clear_candidate()
        try:
            self._region_bytes, region = self._read_region()
            self._future = self._executor.submit(
                train_candidate, Path(self.paths["training"].text()), region=region,
                detail_manifest=self._optional_path("details"), validation_manifest=self._optional_path("validation"),
                threshold=self._parameters["threshold"], min_area_px=self._parameters["min_area_px"],
                use_saved_masks_only=self.saved_only.isChecked(),
            )
        except (OSError, ValueError, cv2.error) as error:
            self.summary.setText(f"Could not start training. {error}")
            self._sync()
            return
        self.summary.setText("Training from saved masks…")
        self._job = "Training"
        self._poll.start()
        self._sync()

    def _evaluate(self):
        if not self.evaluate.isEnabled():
            return
        candidate = self._candidate
        try:
            if candidate is not None:
                model = candidate.model
                region = _decode_region(self._region_bytes) if self._region_bytes is not None else None
            else:
                pinned, model, region = self._block._verified_assets(self._parameters)
                region_bytes, _ = self._read_region()
                region_hash = _digest(region_bytes) if region_bytes is not None else None
                if pinned[1] != region_hash:
                    raise ValueError("Train a candidate to evaluate the selected inspection region.")
            inspector_pair = self._parameters["threshold"], self._parameters["min_area_px"]
            settings = (inspector_pair, self._reviewed_settings or inspector_pair)
            self._future = self._executor.submit(
                evaluate_validation, model, self._optional_path("validation"), settings, region=region,
                grid=candidate.grid if candidate is not None else None,
                training_fingerprints=candidate.training_fingerprints if candidate is not None else (),
                cancelled=self._cancel_work.is_set,
            )
        except (OSError, ValueError, RuntimeError, cv2.error) as error:
            self.summary.setText(f"Could not start validation. {error}")
            return
        self._clear_validation_preview()
        self._job = "Validation"
        self.summary.setText("Evaluating saved validation labels…")
        self._poll.start()
        self._sync()

    def _optional_path(self, key):
        name = self.paths[key].text()
        return Path(name) if name else None

    def _receive(self):
        if self._future is None or not self._future.done():
            return
        self._poll.stop()
        future, self._future = self._future, None
        job, self._job = self._job, None
        try:
            result = future.result()
        except Exception as error:
            self.summary.setText(f"{job} failed. {error}")
        else:
            if job == "Capture":
                self._set_path("training", result.manifest)
                self.saved_only.setChecked(True)
                self.summary.setText(f"Saved {result.captured} unlabeled patches · {result.incomplete} incomplete"
                                     f" · {result.skipped} unobserved skipped. Open training labels to begin.")
            elif job == "Validation":
                self._validation_review = result
                self._show_validation(result)
            else:
                self._candidate = result
                self._show_candidate()
        self._sync()

    def _show_candidate(self):
        item = self._candidate
        description = (f"{item.image_count} training images · {item.normal_pixels:,} background pixels"
                       f" · {item.defect_pixels:,} foreground pixels")
        if item.skipped_drafts:
            description += f" · {item.skipped_drafts} unlabeled patches skipped"
        if item.validation_count:
            measures = [f"{name.title()} {value:.1%}" if value is not None else f"{name.title()} unavailable"
                        for name, value in item.validation_metrics.items()]
            description += (f"\n{item.validation_count} validation images at cutoff {self._parameters['threshold']:g}"
                            f" and min area {self._parameters['min_area_px']} px · " + " · ".join(measures))
            self._show_preview(item.preview, item.preview_name)
        self.summary.setText(description)

    def _show_validation(self, review):
        first = next(iter(review.counts.values()))
        model = "Candidate" if self._candidate is not None else "Pinned model"
        images = "image" if review.image_count == 1 else "images"
        lines = [f"{model} · {review.image_count} validation {images} · {sum(first.values()):,} labeled pixels observed"
                 f" · {review.unobserved_labels:,} labeled pixels unobserved"]
        for index, ((cutoff, area), counts) in enumerate(review.counts.items()):
            source = "Inspector" if index == 0 else "Kept"
            values = [f"{name.title()} {value:.2%}" if value is not None else f"{name.title()} unavailable"
                      for name, value in metrics(counts).items()]
            lines.append(f"{source} · Cutoff {cutoff:g} · min area {area} px · " + " · ".join(values))
        cutoff, area = next(reversed(review.counts))
        self._show_preview(review.preview, f"{review.preview_name} at cutoff {cutoff:g}, min area {area} px")
        self.summary.setText("\n".join(lines))

    def _show_preview(self, rgb, name):
        image = QImage(rgb.data, rgb.shape[1], rgb.shape[0], rgb.strides[0], QImage.Format.Format_RGB888).copy()
        self.preview.setPixmap(QPixmap.fromImage(image).scaled(560, 310, Qt.AspectRatioMode.KeepAspectRatio,
                                                               Qt.TransformationMode.SmoothTransformation))
        self.preview_title.setText(f"{name} · Green hit · Red missed · Amber extra · Purple unlabeled")

    def accept(self):
        if not self.stage.isEnabled():
            return
        try:
            updates = {}
            if self._candidate is not None:
                updates = stage_candidate(self._project, self._candidate.model, self._region_bytes)
                updates["capture_only"] = False
            else:
                self._block._verified_assets(self._parameters)
        except (OSError, ValueError, RuntimeError, cv2.error) as error:
            self.summary.setText(f"Could not stage the review. {error}")
            return
        if self._reviewed_settings is not None:
            updates["threshold"], updates["min_area_px"] = self._reviewed_settings
        self._parameters.update(updates)
        super().accept()

    def _shutdown(self, _result):
        self._closing = True
        self._cancel_work.set()
        self._poll.stop()
        self._executor.shutdown(wait=False, cancel_futures=True)
