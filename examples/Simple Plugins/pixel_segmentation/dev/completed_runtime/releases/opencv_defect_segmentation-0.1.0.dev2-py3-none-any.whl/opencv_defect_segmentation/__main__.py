"""Train or apply a supervised pixel segmentation model."""

import argparse
import json
from collections import Counter
from dataclasses import asdict
from pathlib import Path

import cv2
import numpy as np

from . import NormalReference, PixelSegmenter
from .evaluation import metrics, offset_brightness, score_area, score_labels, score_region_sizes, score_repeatability
from .image_io import read_image, training_samples as _samples
from .label_audit import audit_labels
from .region_tone import calibrate_tone
from .training import fit_samples


def _normal_reference(path):
    records = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(records, list) or any(not isinstance(name, str) or not name for name in records):
        raise ValueError("The normal reference manifest must be an array of image paths.")
    return NormalReference.fit(read_image(path.parent / name) for name in records)


def _region_options(parser):
    parser.add_argument("--region", type=Path)
    parser.add_argument("--threshold", type=float, default=0.5)
    parser.add_argument("--min-area", type=int, default=1)


def _evaluate(model, manifest, options, area_bands=None, *, area_error=False, brightness_offset_dn=None):
    totals = Counter()
    scenes = []
    for name, sample in _samples(manifest):
        pixels = sample.pixels if brightness_offset_dn is None else offset_brightness(sample.pixels, brightness_offset_dn)
        result = model.segment(pixels, valid=sample.valid, **options)
        scored = score_labels(sample.labels, result)
        totals.update(scored["counts"])
        scene = {"image": name, "inspection_coverage": result.inspected_fraction, **scored}
        if area_error:
            scene["area"] = score_area(sample.labels, result)
        scenes.append(scene)
    if not scenes:
        raise ValueError("The evaluation manifest is empty.")
    report = {"threshold": options["threshold"], "min_area_px": options["min_area_px"],
              "counts": dict(totals), "metrics": metrics(totals), "images": scenes}
    if brightness_offset_dn is not None:
        report["brightness_offset_dn"] = brightness_offset_dn
    if area_bands is not None:
        report["size_bands"] = score_region_sizes(
            (region for scene in scenes for region in scene["positive_regions"]), area_bands,
        )
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_subparsers(dest="action", required=True)
    train = actions.add_parser("train")
    train.add_argument("manifest", type=Path)
    train.add_argument("model", type=Path)
    train.add_argument("--normal-reference", type=Path, help="Experimental reference manifest of aligned normal images")
    train.add_argument("--detail-examples", type=Path, help="Experimental manifest of marked small defects and their normal context")
    predict = actions.add_parser("segment")
    predict.add_argument("model", type=Path)
    predict.add_argument("image", type=Path)
    predict.add_argument("result", type=Path, help="New NPZ file for score, defect, and inspected arrays")
    predict.add_argument("--valid", type=Path)
    _region_options(predict)
    evaluate = actions.add_parser("evaluate")
    evaluate.add_argument("model", type=Path)
    evaluate.add_argument("manifest", type=Path)
    evaluate.add_argument("--area-bands", type=int, nargs="+", metavar="PX",
                          help="Inclusive upper labeled-area bounds for separate region metrics")
    evaluate.add_argument("--area-error", action="store_true",
                          help="Report defect-area error bounds from the observed labels")
    evaluate.add_argument("--brightness-offset-dn", type=int, metavar="DN",
                          help="Add a signed native digital-count offset for an exposure sensitivity replay")
    _region_options(evaluate)
    repeatability = actions.add_parser("repeatability", help="Compare registered captures of the same part")
    repeatability.add_argument("model", type=Path)
    repeatability.add_argument("first", type=Path)
    repeatability.add_argument("second", type=Path)
    repeatability.add_argument("--first-valid", type=Path)
    repeatability.add_argument("--second-valid", type=Path)
    repeatability.add_argument("--tolerance-px", type=int, default=0)
    _region_options(repeatability)
    annotate = actions.add_parser("annotate", help="Paint training or evaluation masks")
    annotate.add_argument("manifest", type=Path)
    annotate.add_argument("--region", type=Path)
    annotate.add_argument("--model", type=Path, help="Optional model for a separately toggled overlay")
    audit = actions.add_parser("audit-labels", help="Check the labeled training data before fitting")
    audit.add_argument("manifest", type=Path)
    audit.add_argument("--region", type=Path)
    tone = actions.add_parser("calibrate-tone", help="Check whole-region brightness separation on labeled examples")
    tone.add_argument("controls", type=Path)
    tone.add_argument("affected", type=Path)
    tone.add_argument("--region", type=Path, required=True)
    tone.add_argument("--brightness-drift-dn", type=int, default=0, metavar="DN")
    args = parser.parse_args(argv)
    try:
        if args.action == "audit-labels":
            region = read_image(args.region) if args.region is not None else None
            print(json.dumps(audit_labels(args.manifest, region=region)))
            return 0
        if args.action == "calibrate-tone":
            calibration = calibrate_tone(
                (sample for _, sample in _samples(args.controls)),
                (sample for _, sample in _samples(args.affected)),
                read_image(args.region), brightness_drift_dn=args.brightness_drift_dn,
            )
            print(json.dumps(calibration.report()))
            return 0
        if args.action == "annotate":
            try:
                from .qt_annotation import launch
            except ImportError as error:
                raise ValueError("The annotation editor requires PySide6. Install the gui extra.") from error
            return launch(args.manifest, region_path=args.region, model_path=args.model)
        if args.action == "train":
            reference = _normal_reference(args.normal_reference) if args.normal_reference is not None else None
            samples = (sample for _, sample in _samples(args.manifest))
            examples = ((sample for _, sample in _samples(args.detail_examples))
                        if args.detail_examples is not None else None)
            fit_samples(samples, detail_examples=examples, reference=reference).save(args.model)
            return 0
        model = PixelSegmenter.load(args.model)
        options = {"region": read_image(args.region) if args.region is not None else None,
                   "threshold": args.threshold, "min_area_px": args.min_area}
        if args.action == "evaluate":
            print(json.dumps(_evaluate(model, args.manifest, options, args.area_bands, area_error=args.area_error,
                                       brightness_offset_dn=args.brightness_offset_dn)))
        elif args.action == "repeatability":
            first = model.segment(read_image(args.first), valid=read_image(args.first_valid)
                                  if args.first_valid is not None else None, **options)
            second = model.segment(read_image(args.second), valid=read_image(args.second_valid)
                                   if args.second_valid is not None else None, **options)
            report = score_repeatability(first, second, tolerance_px=args.tolerance_px)
            print(json.dumps({"threshold": args.threshold, "min_area_px": args.min_area, **report}))
        else:
            result = model.segment(
                read_image(args.image), valid=read_image(args.valid) if args.valid is not None else None, **options,
            )
            with args.result.open("xb") as stream:
                np.savez_compressed(stream, score=result.score, defect=result.defect, inspected=result.inspected)
            print(json.dumps({"inspected_fraction": result.inspected_fraction, "defect_fraction": result.defect_fraction,
                              "regions": [asdict(region) for region in result.regions]}))
    except (OSError, ValueError, TypeError, cv2.error) as error:
        parser.error(str(error))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
