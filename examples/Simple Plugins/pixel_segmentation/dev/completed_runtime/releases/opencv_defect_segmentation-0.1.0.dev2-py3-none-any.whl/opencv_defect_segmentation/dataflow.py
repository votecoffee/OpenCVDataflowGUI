"""Trusted DataflowGUI block for segmentation at registered match positions."""

import hashlib
import re
from contextlib import suppress
from dataclasses import asdict
from pathlib import Path, PurePosixPath
from uuid import uuid4

import cv2
import numpy as np
from opencv_dataflow.core import Block, Port, Result
from opencv_dataflow.payloads import NO_VALUE, ValuePacket, check_spatial, metadata, require_same_frame
from opencv_dataflow.processing import gray_image

from . import PixelSegmenter
from .graphics import draw_heatmap, draw_overlay
from .parts import MAX_PART_WORKERS, PatchPlacement, inspect_image, inspect_parts
from .completed_review import BINDING, CompletedSegmentationRecord, capture_completed


_MODEL_EXTENSIONS = {".yml", ".yaml"}
_REGION_EXTENSIONS = {".png"}


def _asset_path(project_dir, name, extensions):
    if project_dir is None:
        raise ValueError("Save the project before pinning segmentation assets.")
    if not isinstance(name, str) or not name.strip():
        raise ValueError("Select a project-relative segmentation asset.")
    portable = PurePosixPath(name)
    if (portable.is_absolute() or "\\" in name or ":" in name or ".." in portable.parts
            or portable.suffix.lower() not in extensions):
        raise ValueError("Segmentation assets need project-relative paths and supported extensions.")
    root = Path(project_dir).resolve()
    path = (root / portable).resolve()
    if not path.is_relative_to(root):
        raise ValueError("Segmentation asset resolves outside the project directory.")
    return path


def _digest(content):
    return hashlib.sha256(content).hexdigest()


def _decode_region(content):
    region = cv2.imdecode(np.frombuffer(content, np.uint8), cv2.IMREAD_UNCHANGED)
    if region is None or region.ndim != 2 or region.dtype != np.uint8 or not region.any():
        raise ValueError("The region must be a nonempty 8-bit grayscale PNG mask.")
    return region


def pin_assets(project_dir, model_path, region_path=None):
    """Validate assets and return parameters for a saved host block."""
    model = _asset_path(project_dir, model_path, _MODEL_EXTENSIONS).read_bytes()
    PixelSegmenter._from_yaml(model.decode("utf-8"))
    options = {"model_path": model_path, "model_sha256": _digest(model)}
    if region_path is not None:
        region = _asset_path(project_dir, region_path, _REGION_EXTENSIONS).read_bytes()
        _decode_region(region)
        options.update(region_path=region_path, region_sha256=_digest(region))
    return options


def stage_candidate(project_dir, model, region_bytes=None):
    """Write a new candidate revision and return verified inspector pins."""
    revision = f"assets/segmentation/{uuid4().hex}"
    model_name = f"{revision}/model.yml"
    region_name = f"{revision}/region.png" if region_bytes is not None else None
    model_file = _asset_path(project_dir, model_name, _MODEL_EXTENSIONS)
    region_file = None
    if region_name is not None:
        _decode_region(region_bytes)
        region_file = _asset_path(project_dir, region_name, _REGION_EXTENSIONS)
    model_file.parent.mkdir(parents=True, exist_ok=False)
    try:
        model.save(model_file)
        if region_file is not None:
            with region_file.open("xb") as stream:
                stream.write(region_bytes)
        pins = pin_assets(project_dir, model_name, region_name)
    except Exception:
        for file in (model_file, region_file):
            if file is not None:
                with suppress(OSError):
                    file.unlink(missing_ok=True)
        with suppress(OSError):
            model_file.parent.rmdir()
        raise
    return {"region_path": "", "region_sha256": "", **pins}


def _placements(image, matches):
    if not isinstance(matches, dict) or matches.get("model") != "pattern_matches_v1":
        raise ValueError("Connect a pattern match collection.")
    items = matches.get("items")
    if not isinstance(items, list) or type(matches.get("count")) is not int or matches["count"] != len(items):
        raise ValueError("The pattern match collection has an invalid count.")
    image_size = list(image.shape[1::-1])
    image_payload = metadata(image)
    spatial = image_payload.get("spatial") or {}
    for item in items:
        transform = item.get("transform") if isinstance(item, dict) else None
        if not isinstance(transform, dict) or transform.get("model") != "image_pattern_pose_v1":
            raise ValueError("Each match needs a trained patch-to-image transform.")
        size = transform.get("source_size")
        if not isinstance(size, (tuple, list)) or len(size) != 2:
            raise ValueError("Each match needs trained patch dimensions.")
        target = transform.get("target_payload")
        if transform.get("target_size") != image_size or not isinstance(target, dict):
            raise ValueError("The match transform must target the input image grid.")
        check_spatial(target, image_size)
        if spatial.get("root_id") is not None and (target.get("spatial") or {}).get("root_id") is None:
            raise ValueError("The match transform is missing its target coordinate frame.")
        require_same_frame((image, ValuePacket(None, target)),
                           message="The match transform targets another image coordinate frame.")
        if "ticket" in image_payload and "ticket" in target and image_payload["ticket"] != target["ticket"]:
            raise ValueError("The match belongs to a different image ticket.")
        yield PatchPlacement(tuple(size), np.asarray(transform.get("source_to_target"), dtype=np.float64))


def _segmentation_frame(inputs):
    image = inputs["image"]
    native = gray_image(image, (np.uint8, np.uint16))
    valid = inputs.get("valid")
    if valid is NO_VALUE:
        valid = None
    if valid is not None:
        require_same_frame((image, valid), message="The validity mask must use the source image frame.")
    return native, valid


def capture_directory(project_dir):
    relative = f".local/segmentation-captures/{uuid4().hex}/training.json"
    return _asset_path(project_dir, relative, {".json"}).parent


class SegmentMatchedParts(Block):
    """Apply a pinned pixel classifier to the trained patch of every match."""

    type_id = "inspection.ocv_segment_parts"
    title, category = "Segment matched parts", "Inspection"
    block_type, subtype = "Inspection", "Segmentation"
    parallel_safe = True
    process_inputs_readonly = True
    payload_reference = "image"
    plugin_dialog_label = "Train segmentation candidate…"
    plugin_review_dialog_label = "Review completed segmentation…"
    project_asset_parameters = ("model_path", "region_path")
    _subjects = "matched parts"
    _report_model = "part_defects_v1"
    payload_reference = "image"
    inputs = (Port("image"), Port("matches", "data"), Port("valid", required=False, required_when_connected=True))
    outputs = (Port("mask"), Port("inspected"), Port("report", "data"), Port("count", "number"),
               Port("overlay"), Port("score_map"), Port("heatmap", required=False))
    defaults = {
        "model_path": "", "model_sha256": "", "region_path": "", "region_sha256": "",
        "samples_per_pixel": 1, "threshold": .5, "min_area_px": 1, "workers": 1, "render_overlay": True,
        "capture_only": False, "emit_score_map": False, "render_heatmap": False,
    }
    parameter_help = {
        "model_path": "Project-relative saved classifier YAML.",
        "model_sha256": "Hash of the classifier bytes.",
        "region_path": "Optional project-relative 8-bit mask on the sampled patch grid.",
        "region_sha256": "Hash of the optional region mask.",
        "samples_per_pixel": "Sampling factor relative to the trained locator patch. Match the segmentation training grid.",
        "threshold": "Minimum foreground vote fraction.",
        "min_area_px": "Minimum connected foreground area in sampled pixels.",
        "workers": "Maximum parallel parts, or voting workers for a lone patch. One runs serially.",
        "render_overlay": "Show red foreground, green inspected background, gold coverage edges "
                          "and gray excluded pixels in the result filmstrip. Disable to skip rendering.",
        "render_heatmap": "Render foreground vote fractions on a fixed 0..1 Viridis scale "
                          "(purple low, yellow high). Gray checks are uninspected. Not calibrated confidence.",
        "emit_score_map": "Output raw foreground vote fractions as a float image. Use Inspected to identify valid scores.",
        "capture_only": "Prepare inputs for training capture in Debug. Segmentation outputs wait in this mode.",
    }
    input_help = {
        "image": "The same frame supplied to the pattern matcher.",
        "matches": "Pattern match collection including patch transforms.",
        "valid": "Optional source-aligned binary observation mask.",
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._asset_cache = None
        self._asset_sources = None
        self._completed_review = None

    def copy_runtime_from(self, other):
        super().copy_runtime_from(other)
        self._completed_review = other._completed_review

    def reset_runtime(self):
        super().reset_runtime()
        self._completed_review = None

    def close(self):
        self._completed_review = None
        self._asset_sources = None
        self._asset_cache = None
        super().close()

    def capture_completed_review(self, context):
        snapshot = getattr(context, "snapshot_processed_execution", None)
        if snapshot is None:
            raise ValueError("Completed review needs the host's paired execution-snapshot API")
        record = self._completed_review
        ports = ("report", "mask", "inspected")
        if record is not None and record.score_source == "output":
            ports += ("score_map",)
        return capture_completed(record, snapshot(output_ports=ports))

    def create_plugin_review_dialog(self, parent, context):
        from .qt_completed_review import CompletedSegmentationReviewDialog

        return CompletedSegmentationReviewDialog(parent, context, lambda: self.capture_completed_review(context))

    @property
    def preview_image_port(self):
        if self.parameters["render_overlay"]:
            return "overlay"
        return "heatmap" if self.parameters["render_heatmap"] else None

    filmstrip_output = preview_image_port

    def create_plugin_dialog(self, parent, parameters, context):
        from .qt_training import SegmentationTrainingDialog

        return SegmentationTrainingDialog(parent, parameters, context, block=self)

    def can_capture_patches(self):
        return self.last_result is not None and {p.name for p in self.inputs if p.required} <= self.last_inputs.keys()

    def _inputs(self, inputs):
        native, valid = _segmentation_frame(inputs)
        return native, valid, list(_placements(inputs["image"], inputs["matches"]))

    def training_snapshot(self, context):
        """Use the frame and poses actually consumed together by this block."""
        if not self.can_capture_patches():
            raise ValueError("Run this block in Debug with its required inputs connected.")
        context.refresh_images()
        frame = context.snapshot_input_image("image", source="processed")
        inputs = {**self.last_inputs, "image": frame.value}
        if self.last_inputs.get("valid") is not None and self.last_inputs["valid"] is not NO_VALUE:
            inputs["valid"] = context.snapshot_input_image("valid", source="processed").value
        native, valid, placements = self._inputs(inputs)
        placements = [PatchPlacement(part.size, part.to_source.copy()) for part in placements]
        source = {key: frame.payload[key] for key in ("spatial", "ticket") if key in frame.payload}
        source["block_id"] = self.id
        return native, valid, placements, source

    def validate_parameters(self, parameters=None):
        super().validate_parameters(parameters)
        values = self.parameters if parameters is None else parameters
        if type(values["capture_only"]) is not bool:
            raise ValueError("capture_only must be boolean.")
        for name, extensions in (("model", _MODEL_EXTENSIONS), ("region", _REGION_EXTENSIONS)):
            path, digest = values[f"{name}_path"], values[f"{name}_sha256"]
            if (name == "region" or values["capture_only"]) and path == "" and digest == "":
                continue
            _asset_path(self.project_dir, path, extensions)
            if not isinstance(digest, str) or re.fullmatch(r"[0-9a-fA-F]{64}", digest) is None:
                raise ValueError(f"Supply the SHA-256 for the {name} asset.")
        for name in ("samples_per_pixel", "min_area_px"):
            if type(values[name]) is not int or values[name] < 1:
                raise ValueError(f"{name} must be a positive integer.")
        if type(values["workers"]) is not int or not 1 <= values["workers"] <= MAX_PART_WORKERS:
            raise ValueError(f"Part workers must be an integer from 1 to {MAX_PART_WORKERS}.")
        threshold = values["threshold"]
        if type(threshold) not in (float, int) or not 0 < threshold <= 1:
            raise ValueError("Threshold must be in (0, 1].")
        for name in ("render_overlay", "emit_score_map", "render_heatmap"):
            if type(values[name]) is not bool:
                raise ValueError(f"{name} must be boolean.")

    def _asset(self, name, extensions, parameters):
        path = parameters[f"{name}_path"]
        if not path:
            return None, None
        content = _asset_path(self.project_dir, path, extensions).read_bytes()
        actual = _digest(content)
        if actual != parameters[f"{name}_sha256"].lower():
            raise ValueError(f"The {name} asset SHA-256 does not match its pin.")
        return content, actual

    def _verified_assets(self, parameters=None):
        values = self.parameters if parameters is None else parameters
        model_bytes, model_hash = self._asset("model", _MODEL_EXTENSIONS, values)
        region_bytes, region_hash = self._asset("region", _REGION_EXTENSIONS, values)
        key = model_hash, region_hash
        if self._asset_cache is None or self._asset_cache[0] != key:
            model = PixelSegmenter._from_yaml(model_bytes.decode("utf-8"))
            region = _decode_region(region_bytes) if region_bytes is not None else None
            self._asset_cache = key, model, region
            self._asset_sources = key, model_bytes, region_bytes
        return self._asset_cache

    def _inspect(self, model, native, placements, **options):
        return inspect_parts(model, native, placements, samples_per_pixel=self.parameters["samples_per_pixel"],
                             workers=self.parameters["workers"], **options)

    def process(self, inputs):
        self._completed_review = None
        image = inputs["image"]
        native, valid, placements = self._inputs(inputs)
        values = self.parameters
        if values["capture_only"]:
            return Result({port.name: NO_VALUE for port in self.outputs}, passed=False,
                          message=f"{len(placements)} {self._subjects} ready for training capture")
        (model_hash, region_hash), model, region = self._verified_assets()
        result = self._inspect(
            model, native, placements, region=region, source_valid=valid,
            threshold=values["threshold"], min_area_px=values["min_area_px"],
            cancelled=getattr(self, "_cancelled", None),
            include_scores=values["emit_score_map"] or values["render_heatmap"],
        )
        parts = [{"match_index": index, **asdict(part), "inspected_fraction": part.inspected_fraction,
                  "defect_fraction": part.defect_fraction, "foreground_pixels": part.defect_pixels,
                  "foreground_fraction": part.defect_fraction}
                 for index, part in enumerate(result.parts, 1)]
        incomplete = sum(part["inspected_fraction"] < 1 for part in parts)
        report = {"model": self._report_model, "count": len(parts), "incomplete_count": incomplete, "parts": parts,
                  "image_size": list(native.shape[::-1]), "model_sha256": model_hash, "region_sha256": region_hash}
        overlay = draw_overlay(image, result) if values["render_overlay"] else NO_VALUE
        heatmap = draw_heatmap(image, result) if values["render_heatmap"] else NO_VALUE
        scores = result.score_map if values["emit_score_map"] else NO_VALUE
        payloads = {}
        if self.run_profile.input_previews and self.run_profile.output_previews:
            assets = self._asset_sources
            if assets is not None and assets[0] != (model_hash, region_hash):
                assets = None
            record = CompletedSegmentationRecord.create(
                uuid4().hex, self.type_id, report, result, values, assets,
            )
            self._completed_review = record
            payloads["report"] = {BINDING: {"id": record.identifier, "model_sha256": model_hash,
                                           "region_sha256": region_hash}}
        return Result({"mask": result.mask, "inspected": result.inspected, "report": report, "count": len(parts),
                       "overlay": overlay, "score_map": scores, "heatmap": heatmap},
                      payloads=payloads,
                      passed=any(part["inspected_pixels"] for part in parts),
                      message=f"{len(parts)} {self._subjects} measured · {incomplete} with incomplete coverage · "
                              f"{np.count_nonzero(result.inspected)} source pixels inspected · "
                              f"{np.count_nonzero(result.mask)} foreground",
                      event_data={"filmstrip_priority": -1} if self.preview_image_port else {})


class SegmentImage(SegmentMatchedParts):
    """Apply the same model to the input image grid with no pose input."""

    type_id = "inspection.ocv_segment_image"
    title = "Segment image"
    _subjects = "images"
    _report_model = "image_segmentation_v1"
    inputs = (SegmentMatchedParts.inputs[0], SegmentMatchedParts.inputs[2])
    input_help = {"image": "8- or 16-bit grayscale image, or a color image converted to grayscale.",
                  "valid": SegmentMatchedParts.input_help["valid"]}
    parameter_help = {
        **SegmentMatchedParts.parameter_help,
        "samples_per_pixel": "Sampling factor relative to the source image. Use 1 for native pixels.",
        "workers": "Maximum voting workers for the image. Small batches use fewer workers.",
    }

    def _inputs(self, inputs):
        native, valid = _segmentation_frame(inputs)
        return native, valid, [PatchPlacement(native.shape[::-1], np.eye(3))]

    def _inspect(self, model, native, placements, **options):
        if self.parameters["samples_per_pixel"] == 1:
            return inspect_image(model, native, workers=self.parameters["workers"], **options)
        return super()._inspect(model, native, placements, **options)


def register(registry):
    registry.register(SegmentMatchedParts)
    registry.register(SegmentImage)
