"""Train and run a binary pixel classifier on grayscale inspection images."""

from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np


IGNORE = 0
NORMAL = 1
DEFECT = 2
_SCHEMA = 1
_REFERENCE_SCHEMA = 2
_SIGMAS = (1.0, 3.0, 8.0, 18.0)
# OpenCV's automatic Gaussian kernel for float32 has a radius of 4 × sigma.
_FEATURE_HALO = int(4 * max(_SIGMAS))
_FILTER_ALIGNMENT = 64
_FEATURE_COUNT = 8
_REFERENCE_FEATURE_COUNT = 12
_MAX_SEGMENT_WORKERS = 8
_MIN_VOTE_ROWS_PER_WORKER = 8192


@dataclass(frozen=True)
class TrainingImage:
    pixels: np.ndarray
    labels: np.ndarray
    valid: np.ndarray | None = None


@dataclass(frozen=True)
class Region:
    x: int
    y: int
    width: int
    height: int
    area_px: int
    mean_score: float


@dataclass(frozen=True)
class Segmentation:
    score: np.ndarray
    defect: np.ndarray
    inspected: np.ndarray
    requested_pixels: int
    regions: tuple[Region, ...]

    @property
    def inspected_fraction(self) -> float:
        return np.count_nonzero(self.inspected) / self.requested_pixels if self.requested_pixels else 0.0

    @property
    def defect_fraction(self) -> float | None:
        count = np.count_nonzero(self.inspected)
        return np.count_nonzero(self.defect) / count if count else None


def _check_pixels(pixels):
    if pixels.ndim != 2 or not pixels.size or pixels.dtype not in (np.uint8, np.uint16):
        raise ValueError("Supply a nonempty 8- or 16-bit grayscale image.")


def _image(pixels):
    _check_pixels(pixels)
    image = pixels.astype(np.float32)
    image /= np.iinfo(pixels.dtype).max
    return image


def _mask(mask, shape):
    if mask is None:
        return np.ones(shape, dtype=bool)
    if mask.shape != shape or mask.dtype not in (np.uint8, np.bool_):
        raise ValueError("Supply an aligned binary mask as bool or uint8.")
    return mask != 0


def _score_options(threshold, min_area_px):
    if not 0 < threshold <= 1:
        raise ValueError("Threshold must be in (0, 1].")
    if type(min_area_px) is not int or min_area_px < 1:
        raise ValueError("Minimum area must be a positive integer.")


def _components(foreground, min_area_px):
    _, components, stats, _ = cv2.connectedComponentsWithStats(foreground.view(np.uint8))
    keep = stats[:, cv2.CC_STAT_AREA] >= min_area_px
    keep[0] = False
    return components, stats, keep


def defect_mask_from_scores(score, *, threshold=.5, min_area_px=1):
    """Apply a new cutoff and area filter to an existing defect score map."""
    _score_options(threshold, min_area_px)
    if score.ndim != 2 or not score.size or score.dtype.kind != "f":
        raise ValueError("Supply a nonempty floating-point defect score map.")
    foreground = score >= threshold
    if min_area_px == 1:
        return foreground
    x, y, width, height = cv2.boundingRect(foreground.view(np.uint8))
    if not width:
        return foreground
    if width * height * 4 <= foreground.size * 3:
        window = np.s_[y:y + height, x:x + width]
        components, _, keep = _components(foreground[window], min_area_px)
        foreground[window] = keep[components]
        return foreground
    components, _, keep = _components(foreground, min_area_px)
    return keep[components]


class NormalReference:
    """Typical intensity and fine contrast at each point on a registered grid."""

    def __init__(self, center, upper):
        self._center = np.array(center, dtype=np.float32, copy=True)
        self._upper = np.array(upper, dtype=np.float32, copy=True)
        if (self._center.ndim != 3 or self._center.shape[0] != 2 or not self._center.size
                or self._center.shape != self._upper.shape or not np.isfinite(self._center).all()
                or not np.isfinite(self._upper).all()):
            raise ValueError("Invalid normal reference grids.")
        self._center.flags.writeable = False
        self._upper.flags.writeable = False

    @property
    def shape(self):
        return self._center.shape[1:]

    @classmethod
    def fit(cls, images):
        """Learn a reference from at least three fully observed normal images."""
        fields = []
        for pixels in images:
            image = _image(pixels)
            if fields and image.shape != fields[0].shape[1:]:
                raise ValueError("Normal reference images must use the same registered grid.")
            fine = cv2.GaussianBlur(image, (0, 0), _SIGMAS[0])
            near = cv2.GaussianBlur(image, (0, 0), _SIGMAS[1])
            fields.append(np.stack((fine, fine - near)))
        if len(fields) < 3:
            raise ValueError("Supply at least three normal reference images.")
        center = np.median(fields, axis=0)
        upper = np.percentile(fields, 75, axis=0).astype(np.float32)
        # Include modest local shifts of normal edges in the upper envelope.
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
        return cls(center, np.stack([cv2.dilate(channel, kernel) for channel in upper]))


def _feature_window(selected):
    height, width = selected.shape
    x, y, roi_width, roi_height = cv2.boundingRect(selected.view(np.uint8))
    # Preserve horizontal SIMD alignment and the component labeler's 2×2 block origin.
    left = max(0, (x - _FEATURE_HALO) // _FILTER_ALIGNMENT * _FILTER_ALIGNMENT)
    top = max(0, (y - _FEATURE_HALO) & ~1)
    padded_right = x + roi_width + _FEATURE_HALO
    right = min(width, (padded_right + _FILTER_ALIGNMENT - 1) // _FILTER_ALIGNMENT * _FILTER_ALIGNMENT)
    bottom = min(height, y + roi_height + _FEATURE_HALO)
    if (right - left) * (bottom - top) * 4 <= selected.size * 3:
        return np.s_[top:bottom, left:right]
    return None


def _features(pixels, valid, selected, reference=None, *, window=None):
    # Use the frame's coverage path even when a cropped window is fully observed.
    complete = valid is None or valid.all()
    if window is not None:
        pixels, selected = pixels[window], selected[window]
        if valid is not None:
            valid = valid[window]
    image = _image(pixels)
    source = image if complete else image * valid
    mask = None if complete else valid.astype(np.float32)

    def coverage(sigma):
        return None if mask is None else np.maximum(cv2.GaussianBlur(mask, (0, 0), sigma), 1e-6)

    def smooth(pixels, sigma, weights):
        blurred = cv2.GaussianBlur(pixels, (0, 0), sigma)
        if weights is not None:
            blurred /= weights
        return blurred

    squared = source ** 2

    def moments(sigma):
        weights = coverage(sigma)
        mean = smooth(source, sigma, weights)
        texture = np.sqrt(np.maximum(smooth(squared, sigma, weights) - mean ** 2, 0))
        return mean, texture

    fine = smooth(source, _SIGMAS[0], coverage(_SIGMAS[0]))
    near, near_texture = moments(_SIGMAS[1])
    middle = smooth(source, _SIGMAS[2], coverage(_SIGMAS[2]))
    broad, broad_texture = moments(_SIGMAS[3])
    del squared
    # Retain the absolute transmission at two scales. A completely bright
    # defect can have negligible local contrast across the entire region.
    detail = fine - near
    channels = (image, fine, broad, detail, near - middle, middle - broad, near_texture, broad_texture)
    feature_count = _FEATURE_COUNT if reference is None else _REFERENCE_FEATURE_COUNT
    row_count = np.count_nonzero(selected)
    dense = row_count == selected.size
    features = np.empty((row_count, feature_count), dtype=np.float32)

    def gather(channel):
        return channel.ravel() if dense else channel[selected]

    for column, channel in enumerate(channels):
        features[:, column] = gather(channel)
    if reference is not None:
        reference_slice = (slice(None), *window) if window is not None else (slice(None),)
        center = reference._center[reference_slice]
        upper = reference._upper[reference_slice]
        for band, column in enumerate((1, 3)):
            features[:, _FEATURE_COUNT + band] = features[:, column] - gather(center[band])
            features[:, _FEATURE_COUNT + 2 + band] = features[:, column] - gather(upper[band])
    return features


class PixelSegmenter:
    """Supervised foreground segmentation from multiscale grayscale features."""

    def __init__(self, forest, reference=None):
        self._forest = forest
        self._reference = reference

    @classmethod
    def train(cls, samples, *, max_pixels_per_class=2500, seed=0, reference: NormalReference | None = None):
        """Fit labels 0 (ignored), 1 (background), and 2 (foreground) on the image grid."""
        if type(max_pixels_per_class) is not int or max_pixels_per_class < 1:
            raise ValueError("The per-image class sample cap must be a positive integer.")
        random = np.random.default_rng(seed)
        features, targets = [], []
        counts = {NORMAL: 0, DEFECT: 0}
        for sample in samples:
            pixels = sample.pixels
            _check_pixels(pixels)
            if reference is not None and pixels.shape != reference.shape:
                raise ValueError("Training images must use the normal reference grid.")
            labels = sample.labels
            if labels.shape != pixels.shape or labels.dtype != np.uint8 or np.any(labels > DEFECT):
                raise ValueError("Labels must be aligned uint8 values 0, 1, or 2.")
            valid = _mask(sample.valid, pixels.shape)
            selected = np.zeros(pixels.shape, dtype=bool)
            for label in counts:
                candidates = np.flatnonzero((labels == label) & valid)
                if len(candidates) > max_pixels_per_class:
                    candidates = random.choice(candidates, max_pixels_per_class, replace=False)
                selected.flat[candidates] = True
                counts[label] += len(candidates)
            if selected.any():
                features.append(_features(pixels, valid, selected, reference))
                targets.append(labels[selected].astype(np.int32))
        if not all(counts.values()):
            raise ValueError("Training requires background and foreground labels on observed pixels.")

        forest = cv2.ml.RTrees_create()
        forest.setMaxDepth(10)
        forest.setMinSampleCount(5)
        forest.setTermCriteria((cv2.TERM_CRITERIA_MAX_ITER, 64, 0.0))
        if not forest.train(np.concatenate(features), cv2.ml.ROW_SAMPLE, np.concatenate(targets)):
            raise RuntimeError("OpenCV could not train the pixel forest.")
        return cls(forest, reference)

    def _vote_batch(self, features):
        votes = self._forest.getVotes(features, 0)
        defect_column = int(np.flatnonzero(votes[0] == DEFECT)[0])
        return (votes[1:, defect_column] / votes[1:].sum(axis=1)).astype(np.float32)

    def _vote_scores(self, features, workers):
        workers = min(workers, max(1, len(features) // _MIN_VOTE_ROWS_PER_WORKER))
        if workers == 1:
            return self._vote_batch(features)
        # Each worker reads the same trained forest and owns its output rows.
        with ThreadPoolExecutor(max_workers=workers) as pool:
            return np.concatenate(tuple(pool.map(self._vote_batch, np.array_split(features, workers))))

    def segment(self, pixels, *, region=None, valid=None, threshold=0.5, min_area_px=1, vote_workers=1):
        """Score the observed part of a region and return the mask and 8-connected regions."""
        _score_options(threshold, min_area_px)
        if type(vote_workers) is not int or not 1 <= vote_workers <= _MAX_SEGMENT_WORKERS:
            raise ValueError(f"Vote workers must be an integer from 1 to {_MAX_SEGMENT_WORKERS}.")
        _check_pixels(pixels)
        if self._reference is not None and pixels.shape != self._reference.shape:
            raise ValueError("Inspection images must use the normal reference grid.")
        observed = _mask(valid, pixels.shape) if valid is not None else None
        requested = _mask(region, pixels.shape) if region is not None else None
        if requested is None:
            inspected = observed if observed is not None else np.ones(pixels.shape, dtype=bool)
        else:
            inspected = requested if observed is None else requested & observed
        requested_pixels = pixels.size if requested is None else int(np.count_nonzero(requested))
        score = np.full(pixels.shape, np.nan, np.float32)
        if not inspected.any():
            return Segmentation(score, np.zeros(pixels.shape, dtype=bool), inspected, requested_pixels, ())

        window = _feature_window(inspected) if region is not None or valid is not None else None
        if window is None:
            local_score, local_inspected = score, inspected
            x0 = y0 = 0
        else:
            local_score, local_inspected = score[window], inspected[window]
            y0, x0 = window[0].start, window[1].start
        local_score[local_inspected] = self._vote_scores(
            _features(pixels, observed, inspected, self._reference, window=window), vote_workers,
        )
        component, stats, keep = _components(local_score >= threshold, min_area_px)
        local_defect = keep[component]
        defect = local_defect
        if window is not None:
            defect = np.zeros(pixels.shape, dtype=bool)
            defect[window] = local_defect
        regions = []
        for index in np.flatnonzero(keep):
            x, y, width, height, area = map(int, stats[index])
            patch = np.s_[y:y + height, x:x + width]
            mean = local_score[patch][component[patch] == index].mean()
            regions.append(Region(x + x0, y + y0, width, height, area, float(mean)))
        return Segmentation(score, defect, inspected, requested_pixels, tuple(regions))

    def save(self, path):
        """Write the forest and its feature schema to a new OpenCV YAML file."""
        flags = cv2.FILE_STORAGE_WRITE | cv2.FILE_STORAGE_MEMORY | cv2.FILE_STORAGE_FORMAT_YAML
        if self._reference is not None:
            flags |= cv2.FILE_STORAGE_BASE64
        storage = cv2.FileStorage("", flags)
        storage.write("schema", _SCHEMA if self._reference is None else _REFERENCE_SCHEMA)
        if self._reference is not None:
            width = self._reference.shape[1]
            storage.write("reference_center", self._reference._center.reshape(-1, width))
            storage.write("reference_upper", self._reference._upper.reshape(-1, width))
        self._forest.write(storage, "forest")
        serialized = storage.releaseAndGetString()
        with Path(path).open("x", encoding="utf-8", newline="\n") as stream:
            stream.write(serialized)

    @classmethod
    def load(cls, path):
        return cls._from_yaml(Path(path).read_text(encoding="utf-8"))

    @classmethod
    def _from_yaml(cls, data):
        storage = cv2.FileStorage(data, cv2.FILE_STORAGE_READ | cv2.FILE_STORAGE_MEMORY)
        try:
            schema = storage.getNode("schema").real() if storage.isOpened() else None
            if schema not in (_SCHEMA, _REFERENCE_SCHEMA):
                raise ValueError("Unsupported pixel model schema.")
            node = storage.getNode("forest")
            if node.empty():
                raise ValueError("The pixel model has no forest.")
            forest = cv2.ml.RTrees_create()
            forest.read(node)
            count = _FEATURE_COUNT if schema == _SCHEMA else _REFERENCE_FEATURE_COUNT
            if not forest.isTrained() or not forest.isClassifier() or forest.getVarCount() != count:
                raise ValueError("The saved classifier does not match the pixel feature schema.")
            reference = None
            if schema == _REFERENCE_SCHEMA:
                center = storage.getNode("reference_center").mat()
                upper = storage.getNode("reference_upper").mat()
                if (center is None or upper is None or center.ndim != 2
                        or center.shape != upper.shape or center.shape[0] % 2):
                    raise ValueError("Invalid saved normal reference grids.")
                shape = (2, center.shape[0] // 2, center.shape[1])
                reference = NormalReference(center.reshape(shape), upper.reshape(shape))
        finally:
            storage.release()
        return cls(forest, reference)
