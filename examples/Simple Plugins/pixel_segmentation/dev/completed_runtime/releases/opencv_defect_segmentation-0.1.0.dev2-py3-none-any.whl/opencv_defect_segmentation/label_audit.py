"""Inspect the available training labels before fitting a model."""

import cv2
import numpy as np

from . import DEFECT, NORMAL, _mask
from .image_io import label_entries, read_image


def audit_labels(manifest, *, region=None):
    """Report observed classes, missing masks, and the size of each positive mark."""
    entries = []
    for entry in label_entries(manifest):
        image = read_image(entry.image)
        if image.ndim != 2 or not image.size or image.dtype not in (np.uint8, np.uint16):
            raise ValueError(f"Supply an 8- or 16-bit grayscale image for {entry.name}.")
        shape = image.shape
        valid = read_image(entry.valid) if entry.valid is not None else None
        observed = _mask(valid, shape) & _mask(region, shape)
        try:
            labels = read_image(entry.labels)
        except FileNotFoundError:
            labels = None
        row = {
            "image": entry.name, "size": list(shape[::-1]), "dtype": str(image.dtype),
            "mask_present": labels is not None, "observed_pixels": int(np.count_nonzero(observed)),
            "normal_pixels": 0, "defect_pixels": 0, "unobserved_labeled_pixels": 0, "positive_regions": [],
        }
        if labels is not None:
            if labels.shape != shape or labels.dtype != np.uint8 or np.any(labels > DEFECT):
                raise ValueError(f"Labels for {entry.name} must be aligned uint8 values 0, 1, or 2.")
            positive = labels == DEFECT
            row["normal_pixels"] = int(np.count_nonzero((labels == NORMAL) & observed))
            row["defect_pixels"] = int(np.count_nonzero(positive & observed))
            row["unobserved_labeled_pixels"] = int(np.count_nonzero((labels != 0) & ~observed))
            count, connected, stats, _ = cv2.connectedComponentsWithStats(positive.astype(np.uint8))
            coverage = np.bincount(connected[positive & observed], minlength=count)
            for index in range(1, count):
                x, y, width, height, area = map(int, stats[index])
                row["positive_regions"].append({"bounds": [x, y, width, height],
                                                "labeled_pixels": area, "observed_pixels": int(coverage[index])})
        row["unlabeled_observed_pixels"] = row["observed_pixels"] - row["normal_pixels"] - row["defect_pixels"]
        entries.append(row)
    if not entries:
        raise ValueError("The label manifest is empty.")
    return {
        "images": entries,
        "masks_missing": sum(not row["mask_present"] for row in entries),
        "images_with_normal": sum(row["normal_pixels"] > 0 for row in entries),
        "images_with_defect": sum(row["defect_pixels"] > 0 for row in entries),
        "normal_pixels": sum(row["normal_pixels"] for row in entries),
        "defect_pixels": sum(row["defect_pixels"] for row in entries),
    }
