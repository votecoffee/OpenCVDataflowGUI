"""Native ordered X/Y image teaching without hand-authoring a capture manifest."""

from pathlib import Path

import numpy as np
from opencv_simple_fringe_scan.cli import load_plane
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from .core import AxisSequence, Capture, Sequence
from .recipe import DeflectRecipe


class OrderedCaptureDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Teach from ordered X/Y images")
        self.resize(820, 710)
        self.recipe = None
        layout = QVBoxLayout(self)
        hint = QLabel(
            "Add the observed images for each axis, review their order and applied phase "
            "shifts, then retain them. Source pose and exposure must stay fixed. "
            "The fit convention is I = background + amplitude*cos(phase + shift)."
        )
        hint.setWordWrap(True)
        layout.addWidget(hint)
        form = QFormLayout()
        self.fields = {}
        for key, label, value in (
            ("capture_id", "Reference name", "reference"),
            ("setup_id", "Camera/screen setup name", "camera-screen"),
            ("pixel_grid", "Original source grid name", "camera-original"),
            ("exposure_s", "Common exposure (seconds)", "0.01"),
            ("scale", "Source code scale (blank = full dtype range)", ""),
        ):
            self.fields[key] = QLineEdit(value)
            form.addRow(label, self.fields[key])
        self.response = QComboBox()
        self.response.addItems(["linear", "sRGB", "uncalibrated codes"])
        form.addRow("Source response", self.response)
        layout.addLayout(form)
        tabs = QTabWidget()
        self.tables = {}
        for axis in "xy":
            page, table = QWidget(), QTableWidget(0, 2)
            table.setHorizontalHeaderLabels(["Observed source image", "Applied shift (degrees)"])
            table.horizontalHeader().setStretchLastSection(True)
            table.setColumnWidth(0, 500)
            box = QVBoxLayout(page)
            box.addWidget(table)
            row = QHBoxLayout()
            for label, action in (
                ("Add images…", lambda a=axis: self.add_images(a)),
                ("Move up", lambda a=axis: self.move_row(a, -1)),
                ("Move down", lambda a=axis: self.move_row(a, 1)),
                ("Remove", lambda a=axis: self.remove_row(a)),
                ("+ shifts", lambda a=axis: self.reset_angles(a, 1)),
                ("− shifts", lambda a=axis: self.reset_angles(a, -1)),
            ):
                button = QPushButton(label)
                button.clicked.connect(lambda checked=False, f=action: self.safe(f))
                row.addWidget(button)
            box.addLayout(row)
            tabs.addTab(page, axis.upper() + " observations")
            self.tables[axis] = table
        layout.addWidget(tabs, 1)
        self.status = QLabel(
            "Frame order is declared here; filenames do not prove synchronization."
        )
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        row = QHBoxLayout()
        for label, action in (("Retain reference", self.retain), ("Cancel", self.reject)):
            button = QPushButton(label)
            button.clicked.connect(lambda checked=False, f=action: self.safe(f))
            row.addWidget(button)
        layout.addLayout(row)

    def safe(self, action):
        try:
            action()
        except Exception as error:
            self.status.setText(str(error))

    def add_images(self, axis):
        files, _ = QFileDialog.getOpenFileNames(
            self,
            "Observed " + axis.upper() + " images",
            "",
            "Images (*.png *.tif *.tiff *.bmp *.jpg *.npy)",
        )
        if files:
            self.set_files(axis, [*self.paths(axis), *map(Path, files)])

    def paths(self, axis):
        table = self.tables[axis]
        return [
            Path(table.item(i, 0).data(Qt.ItemDataRole.UserRole)) for i in range(table.rowCount())
        ]

    def set_files(self, axis, files):
        table = self.tables[axis]
        if len(files) > 32:
            raise ValueError("Use at most 32 phase observations per axis")
        table.setRowCount(len(files))
        for i, path in enumerate(files):
            item = QTableWidgetItem(Path(path).name)
            item.setData(Qt.ItemDataRole.UserRole, str(path))
            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            item.setToolTip(str(path))
            table.setItem(i, 0, item)
        self.reset_angles(axis, 1)

    def reset_angles(self, axis, direction):
        table = self.tables[axis]
        for i in range(table.rowCount()):
            table.setItem(i, 1, QTableWidgetItem(repr(direction * 360.0 * i / table.rowCount())))

    def move_row(self, axis, direction):
        table = self.tables[axis]
        current = table.currentRow()
        target = current + direction
        if 0 <= current < table.rowCount() and 0 <= target < table.rowCount():
            # Move the observed image; shift slots stay in declared capture order.
            item, other = table.takeItem(current, 0), table.takeItem(target, 0)
            table.setItem(current, 0, other)
            table.setItem(target, 0, item)
            table.setCurrentCell(target, 0)

    def remove_row(self, axis):
        table = self.tables[axis]
        if table.currentRow() >= 0:
            table.removeRow(table.currentRow())

    def build_recipe(self):
        axes, stacks, names = {}, [], []
        shape = None
        encoding = self.response.currentText()
        scale = float(self.fields["scale"].text()) if self.fields["scale"].text().strip() else None
        total = sum(table.rowCount() for table in self.tables.values())
        for axis, table in self.tables.items():
            if not 3 <= table.rowCount() <= 32:
                raise ValueError("Select 3..32 images for both axes")
            angles = tuple(
                float(table.item(i, 1).text()) * np.pi / 180 for i in range(table.rowCount())
            )
            axes[axis] = AxisSequence(tuple(f"{axis}:{i}" for i in range(table.rowCount())), angles)
            planes = []
            for path in self.paths(axis):
                image = load_plane(path, "gray")
                if shape is None:
                    shape = image.shape
                    if image.size * total > 16_000_000:
                        raise ValueError("Capture exceeds 16 million samples")
                    if scale is None:
                        scale = (
                            float(np.iinfo(image.dtype).max) if image.dtype.kind in "ui" else 1.0
                        )
                if image.shape != shape:
                    raise ValueError("Every observation must share source dimensions")
                if not np.isfinite(scale) or scale <= 0:
                    raise ValueError("Use a positive source code scale")
                values = image.astype(np.float32) / scale
                if np.any(np.isfinite(values) & ((values < 0) | (values > 1))):
                    raise ValueError("Source code scale must produce normalized 0..1 observations")
                if encoding == "sRGB":
                    values = np.where(
                        values <= 0.04045, values / 12.92, ((values + 0.055) / 1.055) ** 2.4
                    )
                planes.append(values)
                names.append(path.name)
            stacks.append(np.stack(planes))
        text = self.fields["exposure_s"].text().strip()
        exposure = float(text) if text else None
        sequence = Sequence(
            axes["x"],
            axes["y"],
            self.fields["setup_id"].text(),
            self.fields["pixel_grid"].text(),
            exposure,
            "uncalibrated_codes" if encoding == "uncalibrated codes" else "linear",
        )
        return DeflectRecipe(
            Capture(sequence, self.fields["capture_id"].text(), *stacks),
            notes=dict(
                reference_import=dict(
                    source_names=names, source_encoding=encoding, input_scale=scale
                ),
                source_provenance=dict(
                    kind="User-selected ordered source images; setup/order/response declarations"
                ),
            ),
        )

    def retain(self):
        self.recipe = self.build_recipe()
        self.accept()
