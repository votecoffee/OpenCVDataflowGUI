"""Retained frame filmstrip, editable source region and transactional native teaching."""

import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from pathlib import Path
from threading import Event

import cv2
import numpy as np
from opencv_dataflow.canvas import pixmap
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from opencv_dataflow.images import ImageArray
from opencv_simple_fringe_scan.cli import load_plane
from opencv_simple_fringe_scan.phase import PhaseSettings
from opencv_simple_fringe_scan.qt_region import FringeRegionView
from PySide6.QtCore import QSize, Qt, QTimer
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListView,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QScrollArea,
    QSplitter,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from .cli import read_capture
from .core import CompiledReference, source_mask
from .dataflow import recipe_path
from .execution import capture_bundle, execute, retain_bundle
from .qt_capture import OrderedCaptureDialog
from .recipe import DeflectRecipe, import_reference, load_recipe, save_recipe


def rectangle(mask):
    yy, xx = np.nonzero(mask)
    if not len(xx):
        return None
    x, y, r, b = int(xx.min()), int(yy.min()), int(xx.max()) + 1, int(yy.max()) + 1
    return (x, y, r - x, b - y) if mask.sum() == (r - x) * (b - y) else None


class DeflectTrainingDialog(QDialog):
    def __init__(self, parent, parameters, context):
        super().__init__(parent)
        self.setWindowTitle("SimpleDeflectometry — train phase reference")
        self.resize(1360, 920)
        self.parameters, self.context = parameters, context
        self.reference = self.mask = self.candidate = self.compiled = None
        self.reference_result = self.last_result = self.pending = None
        self.revision, self.closed, self.restoring = 0, False, False
        self.unsubscribe = None
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="deflect-training")
        layout = QVBoxLayout(self)
        self.identity = QLabel(
            "Teach from ordered images, import a capture/recipe, or capture the wired stack."
        )
        self.identity.setWordWrap(True)
        layout.addWidget(self.identity)
        self.frame_list = QListWidget()
        self.frame_list.setFlow(QListView.Flow.LeftToRight)
        self.frame_list.setWrapping(False)
        self.frame_list.setIconSize(QSize(76, 56))
        self.frame_list.setFixedHeight(108)
        self.frame_list.currentRowChanged.connect(self.show_source)
        layout.addWidget(self.frame_list)
        split = QSplitter(Qt.Orientation.Horizontal)
        layout.addWidget(split, 1)
        side = QWidget()
        controls = QVBoxLayout(side)
        for label, action in (
            ("Teach from X/Y image files…", self.teach_files),
            ("Import ordered capture…", self.import_reference),
            ("Import retained training…", self.import_recipe),
            ("Capture connected reference", self.capture_reference),
            ("Import exact inspection mask…", self.import_mask),
            ("Use full source region", lambda: self.set_mask(None)),
            ("Draw new rectangle", lambda: self.region_mode("draw")),
            ("Adjust rectangle / handles", lambda: self.region_mode("edit")),
            ("Pan source image", lambda: self.region_mode("pan")),
        ):
            self.button(controls, label, action)
        form = QFormLayout()
        self.fields = {}
        for key, label, value in (
            ("angles_x", "X shifts (radians)", ""),
            ("angles_y", "Y shifts (radians)", ""),
            ("exposure", "Exposure seconds (blank if unknown)", "0.01"),
            ("amplitude", "Minimum amplitude (0–1)", "0.03"),
            ("rms", "Maximum relative fit RMS", "0.15"),
            ("ceiling", "Input clipping ceiling (0–1)", "1.0"),
            ("coverage", "Minimum comparable fraction (0–1)", "0.95"),
            ("change", "Maximum phase-vector change (radians)", "0.45"),
        ):
            field = QLineEdit(value)
            field.textChanged.connect(self.invalidate)
            self.fields[key] = field
            form.addRow(label, field)
        self.response = QComboBox()
        self.response.addItems(["linear", "uncalibrated_codes"])
        self.response.currentTextChanged.connect(self.invalidate)
        form.addRow("Retained response declaration", self.response)
        self.limit_change = QCheckBox("Apply phase-change limit")
        self.limit_change.toggled.connect(self.invalidate)
        form.addRow(self.limit_change)
        controls.addLayout(form)
        self.preview_button = self.button(controls, "Preview reference", self.preview_reference)
        self.test_button = self.button(controls, "Preview another capture…", self.preview_file)
        self.wire_button = self.button(
            controls, "Preview connected capture", self.preview_connected
        )
        self.reference_health = QLabel("Reference health appears after a fresh fit.")
        self.reference_health.setWordWrap(True)
        controls.addWidget(self.reference_health)
        self.preview_health = QLabel("")
        self.preview_health.setWordWrap(True)
        controls.addWidget(self.preview_health)
        controls.addStretch()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(side)
        split.addWidget(scroll)
        self.tabs = QTabWidget()
        self.editor = FringeRegionView(self.tabs)
        self.editor.region_changed.connect(lambda roi: self.safe(lambda: self.set_region(roi)))
        self.views = {}
        self.add_view(self.editor, "Retained source / region")
        for key, label in (
            ("overview", "Overview"),
            ("overlay", "Change / unavailable overlay"),
            ("reference_phase_x", "Reference X phase"),
            ("test_phase_x", "Test X phase"),
            ("reference_phase_y", "Reference Y phase"),
            ("test_phase_y", "Test Y phase"),
            ("change_x", "Signed X change"),
            ("change_y", "Signed Y change"),
            ("magnitude", "Change magnitude"),
            ("amplitude_x", "X amplitude"),
            ("amplitude_y", "Y amplitude"),
            ("residual_x", "X fit residual"),
            ("residual_y", "Y fit residual"),
            ("quality", "Comparison availability"),
        ):
            view = FilmstripImageView(self.tabs)
            self.views[key] = view
            self.add_view(view, label)
        split.addWidget(self.tabs)
        split.setSizes([430, 930])
        self.status = QLabel(
            "Reference and test captures remain separate. Whole-period phase ambiguity remains."
        )
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        hint = QLabel(
            "Scroll to zoom; Pan moves the view. Imported masks stay exact until replaced. "
            "This trainer compares wrapped phase, with no metric height. Changes require a fresh "
            "reference preview. Stage edits the inspector draft; Apply configuration commits it."
        )
        hint.setWordWrap(True)
        layout.addWidget(hint)
        row = QHBoxLayout()
        self.stage_button = self.button(row, "Stage training", self.stage)
        self.button(row, "Cancel", self.reject)
        layout.addLayout(row)
        self.timer = QTimer(self)
        self.timer.setInterval(40)
        self.timer.timeout.connect(self.poll)
        if hasattr(context, "subscribe_outputs"):
            self.unsubscribe = context.subscribe_outputs(self.outputs_changed)
        if parameters.get("recipe_path"):
            self.safe(
                lambda: self.restore(
                    load_recipe(
                        recipe_path(context.project_dir, parameters["recipe_path"]),
                        sha256=parameters["sha256"],
                    ),
                    preview=True,
                )
            )
        self.finished.connect(lambda *_: self.shutdown())
        self.refresh()

    def button(self, layout, label, action):
        button = QPushButton(label)
        button.setAutoDefault(False)
        button.clicked.connect(lambda checked=False: self.safe(action))
        layout.addWidget(button)
        return button

    def add_view(self, view, label):
        page, row = QWidget(), QHBoxLayout()
        box = QVBoxLayout(page)
        box.addWidget(view, 1)
        for text, action in (
            ("−", lambda: view.zoom(0.8)),
            ("+", lambda: view.zoom(1.25)),
            ("Fit", view.fit_image),
            ("100%", view.actual_size),
        ):
            self.button(row, text, action)
        box.addLayout(row)
        self.tabs.addTab(page, label)

    def safe(self, action):
        try:
            action()
        except Exception as error:
            self.status.setText(str(error))

    def choose(self, title, pattern):
        path, _ = QFileDialog.getOpenFileName(self, title, "", pattern)
        return Path(path) if path else None

    def restore(self, recipe, *, preview=False):
        self.restoring = True
        try:
            self.reference, self.mask = recipe, recipe.reference.mask
            source = recipe.reference
            self.frame_list.clear()
            self.frames = []
            names = recipe.notes.get("reference_import", {}).get("source_names", [])
            for axis, stack in (
                (source.sequence.x, source.x_images),
                (source.sequence.y, source.y_images),
            ):
                for identity, plane in zip(axis.frame_ids, stack):
                    index = len(self.frames)
                    self.frames.append(plane)
                    gray = np.rint(np.clip(np.nan_to_num(plane), 0, 1) * 255).astype(np.uint8)
                    icon = pixmap(ImageArray(gray, "gray")).scaled(
                        76, 56, Qt.AspectRatioMode.KeepAspectRatio
                    )
                    item = QListWidgetItem(QIcon(icon), identity)
                    item.setToolTip(identity + (" / " + names[index] if index < len(names) else ""))
                    self.frame_list.addItem(item)
            values = dict(
                amplitude=recipe.phase.minimum_amplitude,
                rms=recipe.phase.maximum_relative_rms,
                ceiling=recipe.phase.input_ceiling,
                coverage=recipe.minimum_coverage,
                change=recipe.maximum_change_rad if recipe.maximum_change_rad is not None else 0.45,
            )
            for key, value in values.items():
                self.fields[key].setText(repr(float(value)))
            for axis in "xy":
                self.fields["angles_" + axis].setText(
                    ", ".join(repr(v) for v in getattr(source.sequence, axis).phase_angles)
                )
            self.fields["exposure"].setText(
                ""
                if source.sequence.exposure_s is None
                else repr(float(source.sequence.exposure_s))
            )
            self.response.setCurrentText(source.sequence.response)
            self.limit_change.setChecked(recipe.maximum_change_rad is not None)
            self.identity.setText(
                f"Retained {len(self.frames)} observations · "
                f"{source.mask.shape[1]} × {source.mask.shape[0]}\n"
                f"{source.capture_id} / {source.sequence.setup_id} / {source.sequence.pixel_grid}\n"
                "Wrapped reference comparison; no metric shape"
            )
            self.frame_list.setCurrentRow(
                min(
                    max(int(recipe.notes.get("selected_reference_frame", 0)), 0),
                    len(self.frames) - 1,
                )
            )
        finally:
            self.restoring = False
        self.invalidate()
        self.show_source()
        if preview:
            self.preview_reference()

    def clear_views(self):
        self.last_result = None
        self.preview_health.setText("")
        for view in self.views.values():
            view.image_item.setPixmap(QPixmap())

    def invalidate(self, *_):
        if self.restoring or self.closed:
            return
        self.revision += 1
        self.candidate = self.compiled = self.reference_result = None
        if self.pending:
            self.pending[1].set()
            self.pending[0].cancel()
        self.clear_views()
        self.reference_health.setText("Draft changed. Preview the retained reference before Stage.")
        self.refresh()

    def show_source(self, *_):
        if self.reference is None or self.restoring:
            return
        index = max(self.frame_list.currentRow(), 0)
        raw = self.frames[index]
        gray = np.rint(np.clip(np.nan_to_num(raw), 0, 1) * 255).astype(np.uint8)
        rgb = np.repeat(gray[..., None], 3, axis=2)
        contours, _ = cv2.findContours(
            self.mask.astype(np.uint8), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE
        )
        cv2.drawContours(rgb, contours, -1, (30, 210, 230), 1)
        self.editor.set_image(pixmap(ImageArray(rgb, "rgb")))
        self.editor.set_roi(rectangle(self.mask))

    def teach_files(self):
        dialog = OrderedCaptureDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.restore(dialog.recipe)

    def import_reference(self):
        path = self.choose("Ordered X/Y reference", "Deflectometry capture (*.json)")
        if path:
            self.restore(import_reference(path))

    def import_recipe(self):
        path = self.choose("Retained reference training", "Deflectometry training (*.sdef)")
        if path:
            self.restore(load_recipe(path), preview=True)

    def connected(self):
        self.context.refresh_images()
        bundle = self.context.snapshot_connected_inputs(["capture"])
        if "capture" not in bundle.inputs:
            raise ValueError("Connect a declared X/Y capture first")
        capture, metadata = retain_bundle(bundle.inputs["capture"].value)
        return capture_bundle(capture, metadata), self.context.output_revision, bundle.snapshot_id

    def capture_reference(self):
        bundle, _, identity = self.connected()
        capture, metadata = retain_bundle(bundle)
        self.restore(
            DeflectRecipe(
                capture,
                notes=dict(
                    source_provenance=metadata,
                    editor_snapshot=dict(
                        id=identity, scope="Private copy, not synchronization proof"
                    ),
                ),
            )
        )

    def region_mode(self, mode):
        self.editor.mode = mode
        self.tabs.setCurrentIndex(0)

    def set_region(self, roi):
        if self.reference is None:
            raise ValueError("Retain source images first")
        x, y, w, h = roi
        rows, cols = self.mask.shape
        if (
            any(type(v) is not int for v in roi)
            or min(x, y) < 0
            or min(w, h) < 1
            or x + w > cols
            or y + h > rows
        ):
            raise ValueError("Keep a positive rectangle inside source pixels")
        mask = np.zeros((rows, cols), bool)
        mask[y : y + h, x : x + w] = True
        self.set_mask(mask)

    def set_mask(self, mask):
        if self.reference is None:
            raise ValueError("Retain source images first")
        selected = source_mask(mask, self.reference.reference.mask.shape)
        if not selected.any():
            raise ValueError("Retain a nonempty inspection region")
        self.mask = selected
        self.invalidate()
        self.show_source()

    def import_mask(self):
        path = self.choose("Inspection mask", "Masks (*.png *.tif *.tiff *.npy)")
        if path:
            self.set_mask(load_plane(path, "gray"))

    def build_candidate(self):
        if self.reference is None:
            raise ValueError("Teach or import a reference first")
        old = self.reference.reference
        exposure = self.fields["exposure"].text().strip()
        axes = {
            axis: replace(
                getattr(old.sequence, axis),
                phase_angles=tuple(
                    float(v.strip()) for v in self.fields["angles_" + axis].text().split(",")
                ),
            )
            for axis in "xy"
        }
        sequence = replace(
            old.sequence,
            **axes,
            exposure_s=float(exposure) if exposure else None,
            response=self.response.currentText(),
        )
        source = replace(old, sequence=sequence, mask=self.mask)
        return DeflectRecipe(
            source,
            phase=PhaseSettings(
                float(self.fields["amplitude"].text()),
                float(self.fields["rms"].text()),
                float(self.fields["ceiling"].text()),
            ),
            minimum_coverage=float(self.fields["coverage"].text()),
            maximum_change_rad=float(self.fields["change"].text())
            if self.limit_change.isChecked()
            else None,
            notes=self.reference.notes,
        )

    def submit(self, function, callback, *, publication=None):
        if self.closed:
            return
        if self.pending:
            self.pending[1].set()
            self.pending[0].cancel()
        cancellation = Event()
        self.pending = (
            self.pool.submit(function, cancellation.is_set),
            cancellation,
            self.revision,
            callback,
            publication,
        )
        self.timer.start()
        self.status.setText("Fitting a frozen reference/preview…")
        self.refresh()

    def preview_reference(self):
        recipe = self.build_candidate()
        self.clear_views()

        def work(cancelled):
            if cancelled():
                raise RuntimeError("Preview cancelled")
            model = CompiledReference(recipe.reference, phase=recipe.phase)
            return model, execute(recipe, model=model, cancelled=cancelled)

        def completed(value):
            self.compiled, output = value
            self.candidate, self.reference_result = recipe, output
            report = output["report"]
            self.reference_health.setText(
                f"Reference: {report['comparable_pixels']}/{report['active_pixels']} "
                f"comparable ({report['coverage']:.2%})\n"
                f"{report['response']} · whole-period ambiguity\n"
                + (
                    "Below your coverage limit; review the region/fit."
                    if not report["passed"]
                    else "Availability passes the retained limit; physical accuracy is unqualified."
                )
            )
            self.show_result(output, "Reference preview")

        self.submit(work, completed)

    def preview_capture(self, bundle, *, title="Independent capture", publication=None):
        if self.candidate is None:
            raise ValueError("Preview the current reference before another capture")
        capture, metadata = retain_bundle(bundle)
        private = capture_bundle(capture, metadata)
        recipe, model = self.candidate, self.compiled
        self.clear_views()
        self.submit(
            lambda cancelled: execute(recipe, private, model=model, cancelled=cancelled),
            lambda output: self.show_result(output, title),
            publication=publication,
        )

    def preview_file(self):
        path = self.choose("Independent X/Y test capture", "Deflectometry capture (*.json)")
        if path:
            capture, data = read_capture(path)
            self.preview_capture(
                capture_bundle(capture, data.get("provenance", {})),
                title=path.name,
            )

    def preview_connected(self):
        bundle, revision, _ = self.connected()
        self.preview_capture(bundle, title="Connected preview", publication=revision)

    def poll(self):
        if self.closed or self.pending is None or not self.pending[0].done():
            return
        future, cancellation, revision, callback, publication = self.pending
        self.pending = None
        self.timer.stop()
        try:
            output = future.result()
            if (
                not cancellation.is_set()
                and revision == self.revision
                and (publication is None or publication == self.context.output_revision)
            ):
                callback(output)
            else:
                self.status.setText("Discarded stale work; preview the current draft/capture.")
        except Exception as error:
            self.status.setText(str(error))
        self.refresh()

    def show_result(self, output, title):
        self.last_result = output
        for key, view in self.views.items():
            view.set_image(pixmap(ImageArray(output["views"][key], "rgb")))
        report = output["report"]
        self.preview_health.setText(
            f"{title}: {report['comparable_pixels']}/{report['active_pixels']} "
            f"comparable ({report['coverage']:.2%})\n"
            f"Changed pixels: {report['changed_pixels']} · "
            + ("PASS" if report["passed"] else "FAIL: " + ", ".join(report["fail_reasons"]))
        )
        self.status.setText(
            title + ": source-aligned phase/change/fit evidence; no measured height."
        )
        self.tabs.setCurrentIndex(1)

    def stage(self):
        if (
            self.pending
            or self.candidate is None
            or self.reference_result is None
            or not (self.reference_result["report"]["comparable_pixels"])
        ):
            raise ValueError("Preview the current reference with comparable samples before Stage")
        notes = self.candidate.notes
        notes["reference_fit"] = self.reference_result["report"]
        notes["selected_reference_frame"] = self.frame_list.currentRow()
        candidate = self.candidate
        recipe = DeflectRecipe(
            candidate.reference,
            phase=candidate.phase,
            minimum_coverage=candidate.minimum_coverage,
            maximum_change_rad=candidate.maximum_change_rad,
            notes=notes,
        )
        relative = f"assets/deflectometry/{uuid.uuid4().hex}.sdef"
        path = recipe_path(self.context.project_dir, relative)
        path.parent.mkdir(parents=True, exist_ok=True)
        digest = save_recipe(path, recipe)
        self.parameters.update(recipe_path=relative, sha256=digest)
        self.accept()

    def refresh(self):
        busy = self.pending is not None
        self.fields["change"].setEnabled(self.limit_change.isChecked())
        self.preview_button.setEnabled(self.reference is not None and not busy)
        self.test_button.setEnabled(self.candidate is not None and not busy)
        self.wire_button.setEnabled(self.candidate is not None and not busy)
        self.stage_button.setEnabled(
            not busy
            and self.reference_result is not None
            and self.reference_result["report"]["comparable_pixels"] > 0
        )

    def outputs_changed(self, *_):
        if not self.closed:
            self.status.setText(
                "Connected results changed; Preview connected capture uses a private snapshot."
            )

    def shutdown(self):
        if self.closed:
            return
        self.closed = True
        self.timer.stop()
        if self.pending:
            self.pending[1].set()
            self.pending[0].cancel()
        if self.unsubscribe:
            self.unsubscribe()
        self.pool.shutdown(wait=False, cancel_futures=True)

    def done(self, result):
        self.shutdown()
        super().done(result)
