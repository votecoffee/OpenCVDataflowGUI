"""Fixed-scale source-aligned comparison views; no reconstructed height graphic."""

import cv2
import numpy as np
from opencv_simple_fringe_scan.render import COLORS, panel, scalar


def signed(value, limit):
    strength = np.clip(np.nan_to_num(value) / limit, -1, 1)
    rgb = np.full((*value.shape, 3), 225.0)
    rgb[..., 0] -= 185 * np.maximum(-strength, 0)
    rgb[..., 1] -= 170 * np.abs(strength)
    rgb[..., 2] -= 185 * np.maximum(strength, 0)
    rgb[~np.isfinite(value)] = (75, 35, 85)
    return np.rint(rgb).astype(np.uint8)


def source(images):
    # The average of equally represented shifts is useful illumination context,
    # not a normalization of individual observations or an inference input.
    mean = np.mean(images, axis=0)
    gray = np.rint(np.clip(np.nan_to_num(mean), 0, 1) * 255).astype(np.uint8)
    return np.repeat(gray[..., None], 3, axis=2)


def comparison_views(reference, test, maps, report):
    reference_source, test_source = source(reference.x_images), source(test.x_images)
    output = dict(reference_source=reference_source, test_source=test_source)
    for index, axis in enumerate(("x", "y")):
        output["reference_phase_" + axis] = scalar(
            maps["reference_wrapped"][..., index], 2 * np.pi, cyclic=True
        )
        output["test_phase_" + axis] = scalar(
            maps["test_wrapped"][..., index], 2 * np.pi, cyclic=True
        )
        output["change_" + axis] = signed(maps["change_rad"][..., index], np.pi)
        output["amplitude_" + axis] = scalar(maps["test_amplitude"][..., index], 0.5)
        output["residual_" + axis] = scalar(maps["test_relative_rms"][..., index], 0.3)
    output["magnitude"] = scalar(maps["magnitude_rad"], np.sqrt(2) * np.pi)
    output["quality"] = COLORS[maps["reason"]]
    overlay = test_source.copy()
    overlay[maps["reason"] == 2] = COLORS[2]
    overlay[maps["reason"] == 3] = COLORS[3]
    overlay[maps["reason"] == 4] = COLORS[4]
    overlay[maps["reason"] == 1] = COLORS[1]
    overlay[maps["changed"]] = (245, 55, 65)
    output["overlay"] = overlay
    rows = (
        (
            (reference_source, "Reference / mean X source", "Retained illumination context"),
            (test_source, "Test / mean X source", "Capture ID: " + test.capture_id[:48]),
            (
                output["quality"],
                "Comparable / unavailable",
                f"Compared {report['coverage']:.1%} of ROI",
            ),
        ),
        (
            (output["reference_phase_x"], "Reference X phase", "Cyclic 0..2pi radians"),
            (output["test_phase_x"], "Test X phase", "Cyclic 0..2pi radians"),
            (output["change_x"], "Signed X change", "Blue -pi / white 0 / red +pi"),
        ),
        (
            (output["change_y"], "Signed Y change", "Blue -pi / white 0 / red +pi"),
            (output["magnitude"], "Phase-change magnitude", "Fixed 0..sqrt(2)*pi radians"),
            (
                overlay,
                "Configured change / unavailable",
                "Red exceeds limit; other colors are reasons",
            ),
        ),
    )
    board = np.vstack([np.hstack([panel(*item) for item in row]) for row in rows])
    footer = np.full((66, board.shape[1], 3), 25, np.uint8)
    lines = (
        "WRAPPED PHASE ONLY: whole-fringe ambiguity; no measured slope or height.",
        "Reasons: green comparable | gray outside ROI | purple reference | orange test | blue both",
        "Response: "
        + report["response"]
        + "; exposure "
        + (str(report["exposure_s"]) + " s" if report["exposure_s"] is not None else "unknown")
        + ". Mean source is context only; complete stacks are fitted.",
    )
    for i, line in enumerate(lines):
        cv2.putText(
            footer, line, (10, 16 + i * 21), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (225, 225, 225), 1
        )
    output["overview"] = np.vstack((board, footer))
    return output
