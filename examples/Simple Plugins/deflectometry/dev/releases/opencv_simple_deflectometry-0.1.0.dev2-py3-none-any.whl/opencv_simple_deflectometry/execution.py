"""Array-preserving runtime capture bundles; explicit retained-reference execution."""

from dataclasses import asdict

import numpy as np
from opencv_simple_fringe_scan.recipe import json_copy

from .core import Capture, CompiledReference
from .recipe import DeflectRecipe, sequence_record


def capture_bundle(capture, metadata=None):
    return dict(
        schema="simple_deflectometry_stack/v1",
        sequence=asdict(capture.sequence),
        capture_id=capture.capture_id,
        x_images=capture.x_images,
        y_images=capture.y_images,
        mask=capture.mask,
        metadata=json_copy(metadata or {}),
    )


def retain_bundle(bundle, *, sequence=None):
    if not isinstance(bundle, dict) or bundle.get("schema") != "simple_deflectometry_stack/v1":
        raise ValueError("Provide an explicit simple_deflectometry_stack/v1 capture")
    for key in ("x_images", "y_images"):
        if np.asarray(bundle.get(key)).dtype.str not in ("<f4", "<f8"):
            raise ValueError("Connected source arrays must be normalized float32/float64 codes")
    metadata = json_copy(bundle.get("metadata", {}))
    if sequence is None:
        sequence = sequence_record(bundle["sequence"])
    else:
        # Validate changing wire metadata against the taught sequence without
        # rebuilding two least-squares bases on every connected invocation.
        wire = json_copy(bundle["sequence"])
        if wire != json_copy(asdict(sequence)):
            raise ValueError("Match retained setup, exposure, grid, order, angles and source shape")
        if wire["exposure_s"] is not None and type(wire["exposure_s"]) not in (int, float):
            raise ValueError("Declare numeric exposure, not a boolean")
        for axis in (wire["x"], wire["y"]):
            if (
                type(axis["direction"]) is not int
                or any(type(v) not in (int, float) for v in axis["phase_angles"])
                or any(
                    axis[k] is not None and type(axis[k]) not in (int, float)
                    for k in ("period_px", "origin_rad")
                )
            ):
                raise ValueError(
                    "Declare numeric sequence angles/period/origin and integer direction"
                )
    capture = Capture(
        sequence,
        bundle["capture_id"],
        bundle["x_images"],
        bundle["y_images"],
        bundle.get("mask"),
    )
    return capture, metadata


def execute(recipe, bundle=None, *, model=None, graphics=True, cancelled=lambda: False):
    if not isinstance(recipe, DeflectRecipe):
        raise ValueError("Use a retained deflectometry recipe")
    if bundle is None:
        capture, metadata = recipe.reference, recipe.notes.get("source_provenance", {})
    else:
        capture, metadata = retain_bundle(bundle, sequence=recipe.reference.sequence)
    model = CompiledReference(recipe.reference, phase=recipe.phase) if model is None else model
    if (
        not isinstance(model, CompiledReference)
        or model.reference is not recipe.reference
        or (model.phase != recipe.phase)
    ):
        raise ValueError("Compiled reference differs from the retained recipe")
    output = model.compare(
        capture,
        minimum_coverage=recipe.minimum_coverage,
        maximum_change_rad=recipe.maximum_change_rad,
        graphics=graphics,
        cancelled=cancelled,
    )
    output["report"]["source_records"] = dict(
        reference=recipe.notes.get("source_provenance", {}), test=metadata
    )
    return output
