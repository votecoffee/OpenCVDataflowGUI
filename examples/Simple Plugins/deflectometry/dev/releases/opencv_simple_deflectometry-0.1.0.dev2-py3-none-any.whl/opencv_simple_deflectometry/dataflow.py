"""One cached phase-comparison block; native training is imported only on request."""

import re
from pathlib import Path, PurePosixPath
from threading import RLock

from opencv_dataflow.core import Block, Port, Result
from opencv_dataflow.images import ImageArray
from opencv_dataflow.parameter_validation import ValidationError
from opencv_dataflow.payloads import NO_VALUE, frame

from .cli import read_capture
from .core import CompiledReference
from .execution import capture_bundle, execute
from .recipe import load_recipe


def recipe_path(project_dir, relative):
    if project_dir is None:
        raise ValueError("Save the project before staging reference training")
    path = PurePosixPath(relative)
    if (
        not relative
        or path.is_absolute()
        or ".." in path.parts
        or ":" in relative
        or ("\\" in relative or path.suffix != ".sdef")
    ):
        raise ValueError("Choose a project-contained .sdef recipe using forward slashes")
    root = Path(project_dir).resolve()
    target = (root / relative).resolve()
    if not target.is_relative_to(root):
        raise ValueError("Recipe resolves outside the project directory")
    return target


def signature(path):
    info = path.stat()
    return info.st_size, info.st_mtime_ns, info.st_ctime_ns, info.st_ino


class RecipeCache:
    def __init__(self):
        self.lock = RLock()
        self.key = self.recipe = self.model = None

    def get(self, path, digest):
        with self.lock:
            key = str(path), digest, signature(path)
            if key != self.key:
                recipe = load_recipe(path, sha256=digest)
                model = CompiledReference(recipe.reference, phase=recipe.phase)
                if signature(path) != key[2]:
                    raise ValueError("Recipe changed during loading; retry")
                self.key, self.recipe, self.model = key, recipe, model
            return self.recipe, self.model


class SimpleDeflectometry(Block):
    type_id, title = "image.simple_deflectometry", "SimpleDeflectometry"
    category = block_type = "Image processing"
    subtype = "Reflected-pattern inspection"
    parallel_safe = process_inputs_readonly = preview_safe = True
    plugin_dialog_label = "Train reference and inspection region…"
    plugin_dialog_modeless = True
    inputs = (
        Port(
            "capture",
            "any",
            required=False,
            required_when_connected=True,
            visual_type="deflectometry_capture_stack",
        ),
    )
    outputs = (
        Port("image", "image"),
        Port("maps", "any", visual_type="deflectometry_phase_maps"),
        Port("report", "data"),
        Port("coverage", "number"),
        Port("count", "integer"),
        Port("changed_pixels", "integer", required=False),
        Port("overlay", "image", required=False),
        Port("overview", "image", required=False),
    )
    defaults = dict(
        recipe_path="",
        sha256="",
        source="connected capture",
        capture_manifest="",
        render_graphics=True,
    )
    parameter_choices = {"source": ("connected capture", "capture manifest")}
    project_path_parameters = ("capture_manifest",)
    parameter_help = {
        "recipe_path": "Retained source, sequence, region and fit/decision recipe; use training.",
        "sha256": "Pinned checksum. Reference fits and phase bases are cached per unchanged asset.",
        "source": "Explicitly choose a connected stack or offline capture manifest.",
        "capture_manifest": "Manifest/image paths resolve from the capture folder. Connected mode "
        "never substitutes training images.",
        "render_graphics": "Create source-aligned review maps/overlay. Off preserves numerical "
        "maps, report and judgment.",
    }
    input_help = {
        "capture": "simple_deflectometry_stack/v1 array bundle with complete observed X/Y "
        "sequence, source grid and radiometry; no implicit exposure compensation."
    }
    output_help = {
        "image": "Raw wrapped phase-change magnitude in radians, original grid; unavailable NaN.",
        "maps": "Signed X/Y changes, fit/modulation/reasons and reference/test validity.",
        "report": "Coverage, trained limits, actual/reference identities and radiometry. "
        "Whole-period phase ambiguity remains; no measured height is produced.",
        "overlay": "Source context with selected change exceedances and unavailable regions.",
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.preview_output = "overlay"
        self.cache = RecipeCache()

    def validate_parameters(self, parameters=None):
        super().validate_parameters(parameters)
        p = self.parameters if parameters is None else parameters
        if not all(
            isinstance(p[key], str) for key in ("recipe_path", "sha256", "capture_manifest")
        ):
            raise ValidationError("Choose retained recipe/capture paths and checksum")
        if type(p["render_graphics"]) is not bool:
            raise ValidationError("Choose graphics on or off", "render_graphics")
        if p["recipe_path"]:
            recipe_path(
                Path.cwd() if self.project_dir is None else self.project_dir, p["recipe_path"]
            )
            if not re.fullmatch("[0-9a-f]{64}", p["sha256"]):
                raise ValidationError("Pin the retained recipe checksum", "sha256")

    def process(self, inputs):
        p = self.parameters
        if not p["recipe_path"]:
            raise ValidationError("Train a reference first", "recipe_path")
        recipe, model = self.cache.get(recipe_path(self.project_dir, p["recipe_path"]), p["sha256"])
        if p["source"] == "connected capture":
            if "capture" not in inputs:
                raise ValidationError("Connect a capture or explicitly select capture manifest")
            bundle = inputs["capture"]
        else:
            if "capture" in inputs:
                raise ValidationError("Select connected capture to use the wired source")
            if not p["capture_manifest"]:
                raise ValidationError("Choose a capture manifest", "capture_manifest")
            path = Path(p["capture_manifest"])
            if not path.is_absolute():
                path = self.project_dir / path
            capture, data = read_capture(path)
            bundle = capture_bundle(capture, data.get("provenance", {}))
        output = execute(
            recipe,
            bundle,
            model=model,
            graphics=self.generate_graphics and p["render_graphics"],
            cancelled=self._cancelled,
        )
        maps, report, views = output["maps"], output["report"], output["views"]
        spatial = frame(
            list(maps["valid"].shape[::-1]),
            "deflect-source:" + recipe.reference.sequence.pixel_grid,
        )
        payloads = {key: {"spatial": spatial} for key in ("image", "maps", "overlay")}
        if views:
            payloads["overview"] = {
                "spatial": frame(
                    list(views["overview"].shape[1::-1]), "deflect-overview:" + self.id
                )
            }
        return Result(
            outputs=dict(
                image=ImageArray(maps["magnitude_rad"], "gray"),
                maps=maps,
                report=report,
                coverage=report["coverage"],
                count=report["comparable_pixels"],
                changed_pixels=report["changed_pixels"]
                if report["changed_pixels"] is not None
                else NO_VALUE,
                overlay=ImageArray(views["overlay"], "rgb") if views else NO_VALUE,
                overview=ImageArray(views["overview"], "rgb") if views else NO_VALUE,
            ),
            payloads=payloads,
            graphics={key: ImageArray(rgb, "rgb") for key, rgb in views.items()},
            passed=report["passed"],
            fail_reasons=report["fail_reasons"],
            message=f"{report['comparable_pixels']}/{report['active_pixels']} comparable pixels; "
            "wrapped phase only",
        )

    def create_plugin_dialog(self, parent, parameters, context):
        from .qt_training import DeflectTrainingDialog

        return DeflectTrainingDialog(parent, parameters, context)

    def close(self):
        self.cache = RecipeCache()


def register(registry):
    registry.register(SimpleDeflectometry)
