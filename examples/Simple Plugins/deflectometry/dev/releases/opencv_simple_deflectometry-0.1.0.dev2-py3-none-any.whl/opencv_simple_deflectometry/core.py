"""Private retained inputs, compiled temporal reference and circular phase differences."""

from dataclasses import asdict, dataclass

import numpy as np
from opencv_simple_fringe_scan.patterns import frozen
from opencv_simple_fringe_scan.phase import PHASE_REASONS, PhaseBasis, PhaseSettings, demodulate

REASONS = (
    "comparable",
    "outside_reference_roi",
    "reference_unavailable",
    "test_unavailable",
    "both_unavailable",
)


def name(value):
    if not isinstance(value, str) or not 0 < len(value.strip()) <= 128 or not value.isprintable():
        raise ValueError("Use a printable nonempty identity of at most 128 characters")
    return value


def positive(value, limit, label):
    if type(value) not in (int, float) or not np.isfinite(value) or not 0 < value <= limit:
        raise ValueError("Declare a bounded positive " + label)
    return float(value)


@dataclass(frozen=True)
class AxisSequence:
    frame_ids: tuple
    phase_angles: tuple
    period_px: float = None
    origin_rad: float = None
    direction: int = 1

    def __post_init__(self):
        ids = tuple(name(v) for v in self.frame_ids)
        basis = PhaseBasis(self.phase_angles)
        if len(ids) != len(basis.angles) or len(set(ids)) != len(ids):
            raise ValueError("Declare unique frame IDs in observed phase-step order")
        if self.period_px is not None:
            positive(self.period_px, 1_000_000, "screen period in pixels")
        if self.origin_rad is not None and (
            type(self.origin_rad) not in (int, float) or not np.isfinite(self.origin_rad)
        ):
            raise ValueError("Declare a finite screen-pattern phase origin in radians")
        if type(self.direction) is not int or self.direction not in (-1, 1):
            raise ValueError("Declare screen phase direction as +1 or -1")
        object.__setattr__(self, "frame_ids", ids)
        object.__setattr__(self, "phase_angles", tuple(float(v) for v in basis.angles))


@dataclass(frozen=True)
class Sequence:
    x: AxisSequence
    y: AxisSequence
    setup_id: str
    pixel_grid: str
    exposure_s: float
    response: str = "linear"

    def __post_init__(self):
        if not all(isinstance(axis, AxisSequence) for axis in (self.x, self.y)):
            raise ValueError("Declare X and Y observed phase sequences")
        if set(self.x.frame_ids) & set(self.y.frame_ids):
            raise ValueError("X and Y observations need distinct frame IDs")
        name(self.setup_id)
        name(self.pixel_grid)
        if self.response not in ("linear", "uncalibrated_codes"):
            raise ValueError("Declare linear response or explicit uncalibrated-code diagnostics")
        if self.exposure_s is not None or self.response == "linear":
            positive(self.exposure_s, 3600, "common exposure in seconds")


def source_mask(value, shape):
    if value is None:
        return frozen(np.ones(shape, bool))
    raw = np.asarray(value)
    if raw.shape != shape or raw.dtype.kind not in "bui" or np.any(raw < 0):
        raise ValueError("Use a source-sized nonnegative integer or boolean mask")
    return frozen(raw != 0)


@dataclass(frozen=True)
class Capture:
    sequence: Sequence
    capture_id: str
    x_images: np.ndarray
    y_images: np.ndarray
    mask: np.ndarray = None

    def __post_init__(self):
        if not isinstance(self.sequence, Sequence):
            raise ValueError("Use a declared deflectometry sequence")
        name(self.capture_id)
        arrays = [np.asarray(self.x_images), np.asarray(self.y_images)]
        if sum(a.size for a in arrays) > 16_000_000:
            raise ValueError("Capture exceeds 16 million total X/Y samples")
        for axis, array in zip((self.sequence.x, self.sequence.y), arrays):
            if (
                array.dtype.kind != "f"
                or array.ndim != 3
                or (
                    array.shape[0] != len(axis.frame_ids)
                    or min(array.shape[1:]) < 2
                    or max(array.shape[1:]) > 16384
                )
            ):
                raise ValueError("Use observed normalized floating N×H×W phase stacks")
            if np.any(np.isfinite(array) & ((array < 0) | (array > 1))):
                raise ValueError("Linear phase source codes must be normalized to 0..1")
        if arrays[0].shape[1:] != arrays[1].shape[1:]:
            raise ValueError("Use registered X/Y stacks with at most 16 million total samples")
        object.__setattr__(self, "x_images", frozen(arrays[0]))
        object.__setattr__(self, "y_images", frozen(arrays[1]))
        object.__setattr__(self, "mask", source_mask(self.mask, arrays[0].shape[1:]))


class CompiledReference:
    """Fit the retained reference and compile each distinct shift basis only once."""

    def __init__(self, reference, *, phase=None):
        if not isinstance(reference, Capture) or not reference.mask.any():
            raise ValueError("Retain a reference capture with an active inspection region")
        self.reference = reference
        self.phase = PhaseSettings() if phase is None else phase
        if not isinstance(self.phase, PhaseSettings):
            raise ValueError("Use validated phase settings")
        angles = (reference.sequence.x.phase_angles, reference.sequence.y.phase_angles)
        self.bases = {value: PhaseBasis(value) for value in dict.fromkeys(angles)}
        self.fits = self.fit(reference, reference.mask)

    def fit(self, capture, mask):
        return tuple(
            demodulate(
                images,
                axis.phase_angles,
                settings=self.phase,
                mask=mask,
                basis=self.bases[axis.phase_angles],
            )
            for images, axis in zip(
                (capture.x_images, capture.y_images), (capture.sequence.x, capture.sequence.y)
            )
        )

    def compare(
        self,
        capture,
        *,
        minimum_coverage=0.0,
        maximum_change_rad=None,
        graphics=True,
        cancelled=lambda: False,
    ):
        if (
            not isinstance(capture, Capture)
            or capture.sequence != self.reference.sequence
            or (
                capture.x_images.shape != self.reference.x_images.shape
                or capture.y_images.shape != self.reference.y_images.shape
            )
        ):
            raise ValueError("Match retained setup, exposure, grid, order, angles and source shape")
        if type(minimum_coverage) not in (int, float) or not (
            np.isfinite(minimum_coverage) and 0 <= minimum_coverage <= 1
        ):
            raise ValueError("Minimum compared coverage must be in 0..1")
        if maximum_change_rad is not None:
            positive(maximum_change_rad, np.sqrt(2) * np.pi, "phase-change vector limit in radians")
        if cancelled():
            raise RuntimeError("Deflectometry cancelled; no result published")
        active = self.reference.mask
        test = self.fit(capture, active & capture.mask)
        if cancelled():
            raise RuntimeError("Deflectometry cancelled; no result published")
        ref_valid = np.logical_and.reduce([fit.valid for fit in self.fits])
        test_valid = np.logical_and.reduce([fit.valid for fit in test])
        valid = ref_valid & test_valid
        reason = np.zeros(active.shape, np.uint8)
        reason[~ref_valid] = 2
        reason[~test_valid] = 3
        reason[~ref_valid & ~test_valid] = 4
        reason[~active] = 1
        maps = dict(valid=frozen(valid), reason=frozen(reason))
        for prefix, fits in (("reference", self.fits), ("test", test)):
            for field in ("wrapped", "amplitude", "background", "relative_rms", "valid", "reason"):
                maps[prefix + "_" + field] = frozen(np.stack([getattr(f, field) for f in fits], -1))
        raw = maps["test_wrapped"] - maps["reference_wrapped"]
        delta = np.arctan2(np.sin(raw), np.cos(raw))
        delta[~valid] = np.nan
        magnitude = np.linalg.norm(delta, axis=2)
        changed = (
            (magnitude > maximum_change_rad) & valid
            if maximum_change_rad
            else (np.zeros(active.shape, bool))
        )
        maps.update(
            change_rad=frozen(delta),
            magnitude_rad=frozen(magnitude),
            changed=frozen(changed),
            near_wrap_boundary=frozen(valid & (np.abs(delta) >= 0.95 * np.pi).any(axis=2)),
        )
        count, total = int(valid.sum()), int(active.sum())
        coverage = count / total
        available = count > 0 and coverage >= minimum_coverage
        failures = [] if available else ["insufficient_comparable_coverage"]
        if maximum_change_rad is not None and changed.any():
            failures.append("configured_phase_change_exceeded")
        report = dict(
            schema="simple_deflectometry_phase_result/v1",
            scope="Wrapped reference difference",
            response=capture.sequence.response,
            exposure_s=capture.sequence.exposure_s,
            photometry_qualified=False,
            radiometry_scope=(
                "Caller-declared normalized linear response"
                if capture.sequence.response == "linear"
                else "Uncalibrated normalized code-value diagnostics; no linear-response claim"
            ),
            reference_capture_id=self.reference.capture_id,
            capture_id=capture.capture_id,
            setup_id=capture.sequence.setup_id,
            pixel_grid=capture.sequence.pixel_grid,
            sequence=asdict(capture.sequence),
            phase_settings=asdict(self.phase),
            active_pixels=total,
            reference_valid_pixels=int(ref_valid.sum()),
            test_valid_pixels=int(test_valid.sum()),
            comparable_pixels=count,
            coverage=coverage,
            denominator="Retained reference ROI; test masks reduce comparable coverage",
            reference_coverage=float(ref_valid.sum() / total),
            test_coverage=float(test_valid.sum() / total),
            maximum_observed_change_rad=float(magnitude[valid].max()) if count else None,
            minimum_coverage=minimum_coverage,
            maximum_change_rad=maximum_change_rad,
            changed_pixels=int(changed.sum()) if maximum_change_rad is not None else None,
            decision_scope="Availability and optional user-specified wrapped-phase vector limit",
            passed=not failures,
            fail_reasons=failures,
            whole_period_ambiguity=True,
            metric_height=False,
            phase_reason_labels=list(PHASE_REASONS),
            comparison_reason_counts={
                label: int((reason == i).sum()) for i, label in enumerate(REASONS)
            },
            no_phase_redundancy={
                axis: len(getattr(capture.sequence, axis).phase_angles) == 3 for axis in ("x", "y")
            },
        )
        views = {}
        if graphics:
            from .render import comparison_views

            views = comparison_views(self.reference, capture, maps, report)
        if cancelled():
            raise RuntimeError("Deflectometry cancelled; no result published")
        return dict(maps=maps, report=report, views=views)
