"""Reflection normals on an explicit assumed reference plane; not reconstructed shape."""

from dataclasses import dataclass

import numpy as np
from opencv_simple_fringe_scan.geometry import Pinhole, PreparedCameraRays, numeric
from opencv_simple_fringe_scan.patterns import frozen

from .core import name, positive

REFLECTION_REASONS = (
    "valid_assumed_plane_estimate",
    "unavailable_correspondence",
    "outside_screen",
    "camera_ray_unavailable",
    "parallel_reference_plane",
    "behind_camera_plane",
    "screen_surface_coincident",
    "grazing_reflection",
    "normal_not_graph_form",
)


@dataclass(frozen=True)
class Screen:
    origin_m: np.ndarray
    axis_u: np.ndarray
    axis_v: np.ndarray
    pitch_m: tuple
    image_size: tuple
    camera_frame: str

    def __post_init__(self):
        for key in ("origin_m", "axis_u", "axis_v"):
            object.__setattr__(self, key, numeric(getattr(self, key), (3,), key))
        axes = np.stack((self.axis_u, self.axis_v))
        if np.any(np.abs(self.origin_m) > 100):
            raise ValueError("Screen origin must be within 100 meters per camera axis")
        if not np.allclose(axes @ axes.T, np.eye(2), atol=1e-8, rtol=0):
            raise ValueError("Screen axes must be orthonormal unit vectors in the camera frame")
        pitch, size = tuple(self.pitch_m), tuple(self.image_size)
        if len(pitch) != 2:
            raise ValueError("Declare U and V screen pixel pitches in meters")
        for value in pitch:
            positive(value, 1, "screen pixel pitch in meters")
        if len(size) != 2 or any(type(v) is not int or not 2 <= v <= 16384 for v in size):
            raise ValueError("Declare bounded screen width and height")
        name(self.camera_frame)
        object.__setattr__(self, "pitch_m", pitch)
        object.__setattr__(self, "image_size", size)

    def points(self, uv):
        return self.origin_m + (
            uv[..., :1] * self.pitch_m[0] * self.axis_u
            + uv[..., 1:] * self.pitch_m[1] * self.axis_v
        )


@dataclass(frozen=True)
class Plane:
    normal: np.ndarray
    offset_m: float

    def __post_init__(self):
        normal = numeric(self.normal, (3,), "reference-plane unit normal")
        if not np.isclose(np.linalg.norm(normal), 1, atol=1e-8, rtol=0):
            raise ValueError("Use a unit reference-plane normal")
        if (
            type(self.offset_m) not in (int, float)
            or not np.isfinite(self.offset_m)
            or not (1e-6 <= abs(self.offset_m) <= 100)
        ):
            raise ValueError("Declare plane n dot X = offset_m, in camera meters")
        object.__setattr__(self, "normal", normal)


class ReflectionModel:
    def __init__(self, camera, screen, plane):
        if (
            not isinstance(camera, Pinhole)
            or not isinstance(screen, Screen)
            or not (isinstance(plane, Plane) and screen.camera_frame == camera.frame)
        ):
            raise ValueError("Use known camera/screen/plane geometry in one named camera frame")
        self.camera, self.screen, self.plane = camera, screen, plane
        w, h = camera.image_size
        if w * h > 1_000_000:
            raise ValueError("Initial reflection model supports at most one million camera rays")
        yy, xx = np.indices((h, w))
        self.prepared = PreparedCameraRays(camera, np.c_[xx.ravel(), yy.ravel()])
        self.rays = self.prepared.rays.reshape(h, w, 3)
        denominator = self.rays @ plane.normal
        self.parallel = frozen(np.abs(denominator) <= 1e-8)
        distance = np.divide(
            plane.offset_m, denominator, out=np.full((h, w), np.nan), where=~self.parallel
        )
        self.forward = frozen(np.isfinite(distance) & (distance > 1e-6))
        self.assumed_points = frozen(self.rays * distance[..., None])

    def estimate(
        self, screen_uv, *, valid=None, minimum_incidence_cosine=0.01, minimum_abs_normal_z=0.001
    ):
        positive(minimum_incidence_cosine, 1, "minimum reflection incidence cosine")
        positive(minimum_abs_normal_z, 1, "minimum graph-form normal Z magnitude")
        uv = np.asarray(screen_uv)
        shape = self.rays.shape[:2]
        if uv.shape != (*shape, 2) or uv.dtype.kind not in "iuf":
            raise ValueError("Supply decoded screen U/V pixels on the original camera grid")
        if valid is None:
            selected = np.ones(shape, bool)
        else:
            selected = np.asarray(valid)
            if selected.shape != shape or selected.dtype != bool:
                raise ValueError("Correspondence validity must be a source-sized boolean mask")
        reason = np.zeros(shape, np.uint8)
        finite = np.isfinite(uv).all(axis=2)
        inside = (uv >= -0.5).all(axis=2) & (uv <= np.array(self.screen.image_size) - 0.5).all(
            axis=2
        )
        reason[~inside] = 2
        reason[~finite | ~selected] = 1
        ray_finite = np.isfinite(self.rays).all(axis=2)
        reason[(reason == 0) & ~ray_finite] = 3
        reason[(reason == 0) & self.parallel] = 4
        reason[(reason == 0) & ~self.forward] = 5
        # Invalid UV must not trigger overflow/inf arithmetic while retaining its reason.
        screen_points = self.screen.points(np.where((finite & inside)[..., None], uv, 0))
        vector = screen_points - self.assumed_points
        distance = np.linalg.norm(vector, axis=2)
        reason[(reason == 0) & (distance <= 1e-9)] = 6
        toward_screen = np.divide(
            vector,
            distance[..., None],
            out=np.full_like(vector, np.nan),
            where=(distance > 1e-9)[..., None],
        )
        bisector = toward_screen - self.rays
        length = np.linalg.norm(bisector, axis=2)
        normals = np.divide(
            bisector,
            length[..., None],
            out=np.full_like(bisector, np.nan),
            where=(length > 1e-12)[..., None],
        )
        incidence = np.sum(normals * -self.rays, axis=2)
        reason[
            (reason == 0) & (~np.isfinite(incidence) | (incidence < minimum_incidence_cosine))
        ] = 7
        reason[(reason == 0) & (np.abs(normals[..., 2]) < minimum_abs_normal_z)] = 8
        accepted = reason == 0
        slopes = np.divide(
            -normals[..., :2],
            normals[..., 2:],
            out=np.full((*shape, 2), np.nan),
            where=(np.abs(normals[..., 2:]) >= minimum_abs_normal_z),
        )
        normals[~accepted], slopes[~accepted] = np.nan, np.nan
        return dict(
            normal=frozen(normals),
            slope=frozen(slopes),
            valid=frozen(accepted),
            reason=frozen(reason),
            incidence_cosine=frozen(incidence),
            assumed_plane_xyz_m=self.assumed_points,
            scope="Normal/slope estimate on an assumed reference plane; not measured height",
            frame=self.camera.frame,
            reason_labels=REFLECTION_REASONS,
        )
