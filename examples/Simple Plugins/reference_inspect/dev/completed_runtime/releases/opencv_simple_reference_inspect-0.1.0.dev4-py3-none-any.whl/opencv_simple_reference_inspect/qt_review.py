"""Zoomable comparisons of a cached inspection; no new inference or training."""

import uuid
from pathlib import Path

import cv2
from opencv_dataflow.canvas import pixmap
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from .result_review import ResultReview


class _CompareView(FilmstripImageView):
    moved = Signal()

    def wheelEvent(self, event):
        super().wheelEvent(event)
        self.moved.emit()

    def scrollContentsBy(self, dx, dy):
        super().scrollContentsBy(dx, dy)
        self.moved.emit()


class ReferenceReviewDialog(QDialog):
    def __init__(self, parent, image, model, inspection, *, review=None, export_handler=None):
        super().__init__(parent)
        self.setWindowTitle("Review inspected image")
        self.resize(1280, 850)
        self.review = ResultReview(image, model, inspection) if review is None else review
        self._export_handler = export_handler
        self._syncing = False
        self._rendered_tabs = set()
        layout = QVBoxLayout(self)
        report = self.review.summary()
        label = QLabel(
            report["state"].replace("_", " ").upper()
            + " · "
            + (
                ", ".join(inspection.report["failures"])
                or "No failed inspection gates."
            )
            + f" · {report['inspected_reference_pixels']} / "
            + f"{report['expected_inspection_pixels']} expected reference pixels inspected."
            + " "
            + " ".join(model.health.get("warnings", []))
        )
        label.setWordWrap(True)
        layout.addWidget(label)
        controls = QHBoxLayout()
        controls.addWidget(QLabel("Compare reference mean with"))
        self.mode = QComboBox()
        self.mode.addItems(
            [
                "Normalized current",
                "Signed residual",
                "Deviation / tolerance",
                "Inspected coverage",
            ]
        )
        controls.addWidget(self.mode)
        for title, action in (
            ("Fit comparisons", self._fit),
            ("100%", self._actual_size),
            ("Export review…", self._export),
        ):
            button = QPushButton(title)
            button.clicked.connect(action)
            controls.addWidget(button)
        controls.addStretch()
        layout.addLayout(controls)
        self.tabs = QTabWidget()
        comparison = QWidget()
        row = QHBoxLayout(comparison)
        self.left, self.right = _CompareView(self), _CompareView(self)
        row.addWidget(self.left)
        row.addWidget(self.right)
        self.tabs.addTab(comparison, "Reference grid comparisons")
        self.source = FilmstripImageView(self)
        self.sheet = FilmstripImageView(self)
        self.tabs.addTab(self.source, "Input overlay · input grid")
        self.tabs.addTab(self.sheet, "Assessment")
        layout.addWidget(self.tabs, 1)
        self.legend = QLabel(
            "Scroll zooms; drag pans both comparisons. Same reference grid and intensity scale. "
            "Residual: blue darker, white zero, red brighter. Deviation: 0 blue, 1 yellow-green, "
            "2+ red (tolerance ratio, not probability); gray = not inspected. Coverage: "
            "green inspected, red accepted change, amber expected but not inspected, dark excluded."
        )
        self.legend.setWordWrap(True)
        layout.addWidget(self.legend)
        table = QTableWidget(len(report["metrics"]), 4)
        table.setHorizontalHeaderLabels(
            ["Measurement / units", "Value", "Limits", "Meaning"]
        )
        table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        table.setMaximumHeight(180)
        for row, metric in enumerate(report["metrics"]):
            value = (
                "unavailable" if metric["value"] is None else f"{metric['value']:.5g}"
            )
            low = "unset" if metric["minimum"] is None else f"{metric['minimum']:.4g}"
            high = "unset" if metric["maximum"] is None else f"{metric['maximum']:.4g}"
            for column, text in enumerate(
                (
                    f"{metric['name']} ({metric['units']})",
                    value,
                    f"{low} … {high}",
                    metric["status"],
                )
            ):
                table.setItem(row, column, QTableWidgetItem(text))
        table.resizeColumnsToContents()
        table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(table)
        self.export_status = QLabel()
        self.export_status.setWordWrap(True)
        layout.addWidget(self.export_status)
        self.left.set_image(pixmap(self.review.view("Reference mean")))
        self.right.set_image(pixmap(self.review.view(self.mode.currentText())))
        self.left.moved.connect(lambda: self._sync(self.left, self.right))
        self.right.moved.connect(lambda: self._sync(self.right, self.left))
        self.mode.currentTextChanged.connect(self._view_changed)
        self.tabs.currentChanged.connect(self._tab_changed)

    def _sync(self, source, target):
        if self._syncing:
            return
        self._syncing = True
        try:
            target.setTransform(source.transform())
            target.centerOn(source.mapToScene(source.viewport().rect().center()))
            target._fitted = source._fitted
        finally:
            self._syncing = False

    def _view_changed(self):
        self._syncing = True
        try:
            self.right.set_image(pixmap(self.review.view(self.mode.currentText())))
        finally:
            self._syncing = False
        self._sync(self.left, self.right)

    def _fit(self):
        self.left.fit_image()
        self._sync(self.left, self.right)

    def _actual_size(self):
        self.left.actual_size()
        self._sync(self.left, self.right)

    def _tab_changed(self, index):
        if index in self._rendered_tabs or not index:
            return
        pixels = (
            self.review.view("Input overlay")
            if index == 1
            else self.review.assessment()
        )
        (self.source if index == 1 else self.sheet).set_image(pixmap(pixels))
        self._rendered_tabs.add(index)

    def _export(self):
        directory = QFileDialog.getExistingDirectory(
            self, "Directory for a new inspection review"
        )
        if directory:
            try:
                target = (self.review.save if self._export_handler is None else self._export_handler)(
                    Path(directory) / f"reference-review-{uuid.uuid4().hex[:12]}"
                )
                self.export_status.setText(
                    f"Saved {target}. Training and measurements unchanged."
                )
            except (ValueError, TypeError, OSError, cv2.error) as error:
                self.export_status.setText(f"Could not export review: {error}")
