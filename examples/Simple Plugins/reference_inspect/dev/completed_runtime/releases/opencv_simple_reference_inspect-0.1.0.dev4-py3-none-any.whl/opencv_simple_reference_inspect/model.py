"""Learn normal intensity variation after explicit geometric alignment."""

from dataclasses import asdict, dataclass, field
from numbers import Real

import cv2
import numpy as np

MAX_BYTES = 256 * 1024 * 1024


@dataclass(frozen=True)
class Settings:
    absolute_threshold: float = 12.
    variation_multiplier: float = 3.
    edge_tolerance_px: float = .75
    normalization: str = "gain_offset"
    min_gain: float = .5
    max_gain: float = 2.
    min_correlation: float | None = .85
    min_coverage: float = .98
    min_defect_area: int = 9
    max_total_defect_area: int = 0

    def __post_init__(self):
        ranges = {
            "absolute_threshold": (1e-6, 1e12), "variation_multiplier": (0, 100),
            "edge_tolerance_px": (0, 4),
            "min_gain": (1e-6, 100), "max_gain": (1e-6, 100), "min_coverage": (0, 1),
        }
        if self.min_correlation is not None:
            ranges["min_correlation"] = (-1, 1)
        for name, (low, high) in ranges.items():
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, Real) or not np.isfinite(value) or not low <= value <= high:
                raise ValueError(f"{name} must be finite and within [{low}, {high}].")
        if self.min_gain > self.max_gain:
            raise ValueError("min_gain must not exceed max_gain.")
        for name, low in (("min_defect_area", 1), ("max_total_defect_area", 0)):
            if type(getattr(self, name)) is not int or not low <= getattr(self, name) <= 16_000_000:
                raise ValueError(f"{name} must be an integer in [{low}, 16000000].")
        if self.normalization not in ("none", "offset", "gain_offset"):
            raise ValueError("normalization must be none, offset, or gain_offset.")


def _image(value):
    image = np.asarray(value)
    if (image.ndim != 2 or image.dtype not in (np.uint8, np.uint16, np.float32)
            or min(image.shape) < 2 or max(image.shape) >= 32767 or image.size > 16_000_000
            or not np.isfinite(image).all()):
        raise ValueError("Expected a finite grayscale uint8, uint16, or float32 image, at most 16 million pixels.")
    return image


def _mask(value, shape):
    if value is None:
        return np.ones(shape, bool)
    array = np.asarray(value)
    if array.shape != shape or array.dtype not in (np.bool_, np.uint8):
        raise ValueError("Masks must be boolean or uint8 and match their image grid.")
    return array != 0


def _affine(value):
    matrix = np.asarray(value, np.float64)
    if (matrix.shape != (2, 3) or not np.isfinite(matrix).all()
            or np.linalg.cond(matrix[:, :2]) > 1e10):
        raise ValueError("reference_to_image requires a finite, invertible 2 by 3 affine matrix.")
    return matrix


def _aligned(image, shape, transform):
    if transform is None:
        if image.shape != shape:
            raise ValueError("Image size differs from the reference. Supply reference_to_image.")
        return image.astype(np.float32), np.ones(shape, bool)
    matrix = _affine(transform)
    size = shape[::-1]
    flags = cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP
    aligned = cv2.warpAffine(image.astype(np.float32), matrix, size, flags=flags)
    support = cv2.warpAffine(np.ones(image.shape, np.float32), matrix, size, flags=flags)
    return aligned, support == 1


def _normalize(image, reference, mask, settings):
    if np.count_nonzero(mask) < 16:
        raise ValueError("Normalization needs at least 16 supported pixels.")
    x, y = image[mask].astype(np.float64), reference[mask].astype(np.float64)
    dx, dy = x - x.mean(), y - y.mean()
    xx, yy = np.dot(dx, dx), np.dot(dy, dy)
    correlation = float(np.clip(np.dot(dx, dy) / np.sqrt(xx * yy), -1, 1)) if xx > 0 and yy > 0 else None
    gain, offset = 1., 0.
    if settings.normalization == "gain_offset":
        gain = float(np.dot(dx, dy) / xx) if xx > 0 else 1.
    if settings.normalization != "none":
        offset = float(y.mean() - gain * x.mean())
    reasons = []
    if not settings.min_gain <= gain <= settings.max_gain:
        reasons.append("normalization_gain_out_of_range")
    if settings.min_correlation is not None:
        if correlation is None:
            reasons.append("reference_agreement_unmeasurable")
        elif correlation < settings.min_correlation:
            reasons.append("reference_agreement_below_minimum")
    normalized = image * gain + offset
    if not np.isfinite(normalized).all():
        raise ValueError("Normalization produced nonfinite intensities.")
    return normalized, {"gain": gain, "offset": offset, "correlation": correlation}, reasons


@dataclass(frozen=True)
class ReferenceModel:
    samples: np.ndarray
    mean: np.ndarray
    deviation: np.ndarray
    inspection_mask: np.ndarray
    normalization_mask: np.ndarray
    settings: Settings
    health: dict
    sample_support: np.ndarray | None = None
    reference_fixture: np.ndarray | None = None
    tolerance: np.ndarray = field(init=False, repr=False)

    def __post_init__(self):
        if not isinstance(self.settings, Settings):
            raise ValueError("settings must be a Settings value.")
        samples = np.asarray(self.samples)
        shape = np.shape(self.mean)
        if (len(shape) != 2 or min(shape) < 2 or max(shape) >= 32767 or np.prod(shape) > 16_000_000
                or samples.ndim != 3 or not 1 <= len(samples) <= 128 or samples.shape[1:] != shape
                or samples.nbytes > MAX_BYTES):
            raise ValueError("Invalid model dimensions or training sample budget.")
        for name in ("samples", "mean", "deviation"):
            value = np.asarray(getattr(self, name), np.float32)
            if (not np.isfinite(value).all() or (name != "samples" and value.shape != shape)
                    or (name == "deviation" and np.any(value < 0))):
                raise ValueError(f"Invalid model array {name}.")
            value = value.copy()
            value.flags.writeable = False
            object.__setattr__(self, name, value)
        gradient = cv2.magnitude(
            cv2.Sobel(self.mean, cv2.CV_32F, 1, 0, ksize=3, scale=.125),
            cv2.Sobel(self.mean, cv2.CV_32F, 0, 1, ksize=3, scale=.125),
        )
        tolerance = np.maximum(
            np.maximum(self.settings.absolute_threshold, self.settings.variation_multiplier * self.deviation),
            gradient * self.settings.edge_tolerance_px,
        )
        if not np.isfinite(tolerance).all():
            raise ValueError("Trained tolerance contains nonfinite values.")
        tolerance.flags.writeable = False
        object.__setattr__(self, "tolerance", tolerance)
        for name in ("inspection_mask", "normalization_mask"):
            value = _mask(getattr(self, name), shape)
            if np.count_nonzero(value) < 16:
                raise ValueError(f"{name} requires at least 16 pixels.")
            value.flags.writeable = False
            object.__setattr__(self, name, value)
        support = np.ones(self.samples.shape, bool) if self.sample_support is None else np.asarray(self.sample_support)
        if support.shape != self.samples.shape or support.dtype not in (np.bool_, np.uint8):
            raise ValueError("Sample support must match the aligned training stack.")
        support = support != 0
        if not np.all(support[:, self.inspection_mask | self.normalization_mask]):
            raise ValueError("Training samples must cover both model masks.")
        support.flags.writeable = False
        object.__setattr__(self, "sample_support", support)
        if self.reference_fixture is not None:
            fixture = _affine(self.reference_fixture).copy()
            fixture.flags.writeable = False
            object.__setattr__(self, "reference_fixture", fixture)

    def inspect(self, image, *, reference_to_image=None, mask=None):
        return inspect(self, image, reference_to_image=reference_to_image, mask=mask)


def train(images, *, settings=Settings(), inspection_mask=None, normalization_mask=None, reference_to_images=None,
          sample_support=None, reference_fixture=None):
    """Fit a reference from good samples. Supplied affine maps run from reference to each image."""
    if not isinstance(settings, Settings):
        raise ValueError("settings must be a Settings value.")
    images = list(images)
    if not 1 <= len(images) <= 128:
        raise ValueError("Train with 1 to 128 good images.")
    reference = _image(images[0])
    if len(images) * reference.size * 4 > MAX_BYTES:
        raise ValueError("Aligned training samples exceed the 256 MiB budget.")
    region = _mask(inspection_mask, reference.shape)
    stable = region.copy() if normalization_mask is None else _mask(normalization_mask, reference.shape)
    if min(np.count_nonzero(region), np.count_nonzero(stable)) < 16:
        raise ValueError("Inspection and normalization masks need at least 16 pixels.")
    transforms = [None] * len(images) if reference_to_images is None else list(reference_to_images)
    if len(transforms) != len(images) or transforms[0] is not None:
        raise ValueError("Supply one transform per sample, with None for the first reference image.")
    support_masks = [None] * len(images) if sample_support is None else list(sample_support)
    if len(support_masks) != len(images):
        raise ValueError("Supply one support mask per training image.")
    raw, normalized, rows, supported = [], [], [], []
    for index, (image, transform, support) in enumerate(zip(images, transforms, support_masks, strict=True)):
        source = _image(image)
        aligned, valid = _aligned(source, reference.shape, transform)
        if support is not None:
            selection, _ = _aligned(_mask(support, source.shape).astype(np.float32), reference.shape, transform)
            valid &= selection == 1
        # Full support keeps interpolation borders and missing pixels out of learned variation.
        if not np.all(valid[region | stable]):
            raise ValueError(f"Training sample {index + 1} does not cover both training masks.")
        current, info, reasons = _normalize(aligned, reference, stable, settings)
        if reasons:
            raise ValueError(f"Training sample {index + 1} failed " + ", ".join(reasons))
        raw.append(aligned)
        supported.append(valid)
        normalized.append(current)
        rows.append(info)
    stack = np.stack(normalized)
    mean = stack.mean(axis=0, dtype=np.float64).astype(np.float32)
    deviation = stack.std(axis=0, ddof=1, dtype=np.float64).astype(np.float32) if len(stack) > 1 else np.zeros_like(mean)
    health = {
        "sample_count": len(images), "samples": rows,
        "warnings": ["Fewer than five good samples. Validate against independent images."] if len(images) < 5 else [],
        "mean_standard_deviation": float(deviation[region].mean()),
    }
    return ReferenceModel(np.stack(raw), mean, deviation, region, stable, settings, health,
                          np.stack(supported), reference_fixture)


@dataclass(frozen=True)
class Inspection:
    residual: np.ndarray
    deviation_map: np.ndarray
    inspected_mask: np.ndarray
    defect_mask: np.ndarray
    reference_to_image: np.ndarray
    source_shape: tuple
    report: dict

    @property
    def passed(self):
        return self.report["passed"]

    def source_maps(self):
        """Resample result maps onto the input image grid."""
        size = self.source_shape[::-1]
        return {
            "residual": cv2.warpAffine(self.residual, self.reference_to_image, size),
            "deviation_map": cv2.warpAffine(self.deviation_map, self.reference_to_image, size),
            "inspected_mask": cv2.warpAffine(self.inspected_mask, self.reference_to_image, size, flags=cv2.INTER_NEAREST),
            "defect_mask": cv2.warpAffine(self.defect_mask, self.reference_to_image, size, flags=cv2.INTER_NEAREST),
        }


def inspect(model, image, *, reference_to_image=None, mask=None):
    source = _image(image)
    matrix = np.array([[1., 0, 0], [0, 1., 0]]) if reference_to_image is None else _affine(reference_to_image)
    aligned, valid = _aligned(source, model.mean.shape, reference_to_image)
    coverage = min(float(valid[m].mean()) for m in (model.inspection_mask, model.normalization_mask))
    reasons = ["reference_coverage_below_minimum"] if coverage < model.settings.min_coverage else []
    stable = model.normalization_mask & valid
    if np.count_nonzero(stable) >= 16:
        normalized, exposure, agreement = _normalize(aligned, model.mean, stable, model.settings)
    else:
        normalized = aligned
        exposure = {"gain": None, "offset": None, "correlation": None}
        agreement = ["normalization_support_below_minimum"]
    reasons.extend(agreement)
    selected = model.inspection_mask & valid
    if mask is not None:
        selection = _mask(mask, source.shape).astype(np.float32)
        selection, _ = _aligned(selection, model.mean.shape, reference_to_image)
        selected &= selection == 1
    if not np.any(selected):
        reasons.append("no_inspection_pixels")
    evaluated = not reasons
    residual = np.zeros_like(model.mean)
    scores = np.zeros_like(model.mean)
    defects = np.zeros(model.mean.shape, np.uint8)
    components = []
    if evaluated:
        residual[selected] = normalized[selected] - model.mean[selected]
        scores[selected] = np.abs(residual[selected]) / model.tolerance[selected]
        count, labels, stats, _ = cv2.connectedComponentsWithStats((scores > 1).astype(np.uint8), connectivity=8)
        retained = np.zeros(count, np.uint8)
        for label in np.flatnonzero(stats[1:, cv2.CC_STAT_AREA] >= model.settings.min_defect_area) + 1:
            x, y, width, height, area = map(int, stats[label])
            retained[label] = 255
            components.append({"reference_bounds": [x, y, width, height], "area": area})
        defects = retained[labels]
    area = sum(component["area"] for component in components)
    if area > model.settings.max_total_defect_area:
        reasons.append("defect_area_above_maximum")
    report = {
        "model": "simple_reference_inspect_v1", "passed": not reasons, "evaluated": evaluated,
        "failures": reasons, "coverage": coverage, "exposure": exposure,
        "inspected_pixels": int(selected.sum()) if evaluated else 0,
        "defect_area": area, "defects": components, "area_units": "reference_pixels",
        "max_deviation": float(scores[selected].max()) if evaluated else None,
        "settings": asdict(model.settings),
    }
    return Inspection(residual, scores, selected.astype(np.uint8) * 255 if evaluated else np.zeros_like(defects),
                      defects, matrix, source.shape, report)
