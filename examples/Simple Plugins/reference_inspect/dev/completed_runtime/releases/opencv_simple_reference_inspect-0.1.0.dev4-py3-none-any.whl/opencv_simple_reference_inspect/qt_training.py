"""Review good samples and stage an inspection model through the host editor."""

import uuid
from dataclasses import fields

import cv2
import numpy as np
from opencv_dataflow.canvas import pixmap
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from opencv_dataflow.processing import gray_image
from PySide6.QtCore import QSize
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from .cli import read_image
from .dataflow import fixture_for_capture, recipe_path, relative_fixture
from .graphics import backdrop, draw_overlay
from .model import Settings, _aligned, _image, _mask, train
from .persistence import load_model, save_model
from .qt_masks import MaskEditor
from .result_review import draw_assessment

_IMAGES = "Images (*.png *.tif *.tiff *.bmp);;All files (*)"


class ReferenceTrainingDialog(QDialog):
    def __init__(self, parent, parameters, context):
        super().__init__(parent)
        self.setWindowTitle("Train reference inspection")
        self.resize(1100, 720)
        self.parameters, self.context = parameters, context
        self.samples = []
        self.sample_support = []
        self.reference_fixture = None
        self.inspection_mask = self.normalization_mask = None
        self.model = self.test_image = self.inspection = None
        layout = QVBoxLayout(self)
        actions = QHBoxLayout()
        self.capture_pose_button = self._button("Capture image + pose", self._capture_pose)
        self.capture_pose_button.setEnabled(hasattr(context, "snapshot_input_data"))
        self.capture_pose_button.setToolTip("Capture matching image and fixture pose, aligning later samples to the first.")
        for title, action in (
            ("Add good images…", self._add_files), ("Capture aligned image", self._capture),
            ("Remove selected", self._remove), ("Test image…", self._open_test),
        ):
            actions.addWidget(self._button(title, action))
        actions.addWidget(self.capture_pose_button)
        self.new_set_button = self._button("New reference set", self._new_set)
        actions.addWidget(self.new_set_button)
        layout.addLayout(actions)
        fixture_row = QHBoxLayout()
        self.fixture_label = QLabel()
        self.fixture_label.setWordWrap(True)
        fixture_row.addWidget(self.fixture_label, 1)
        self.clear_fixture_button = self._button("Clear reference pose", self._clear_fixture)
        fixture_row.addWidget(self.clear_fixture_button)
        layout.addLayout(fixture_row)
        masks = QHBoxLayout()
        self.inspection_mask_button = self._button("Edit inspection mask…", lambda: self._edit_mask("inspection_mask"))
        self.normalization_mask_button = self._button("Edit normalization mask…", lambda: self._edit_mask("normalization_mask"))
        for button in (
            self.inspection_mask_button, self._button("Import inspection mask…", lambda: self._open_mask("inspection_mask")),
            self.normalization_mask_button, self._button("Import normalization mask…", lambda: self._open_mask("normalization_mask")),
        ):
            masks.addWidget(button)
        layout.addLayout(masks)
        hint = QLabel("Use good samples aligned to the first image. Edit or import masks for inspection and stable exposure features.")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.filmstrip = QListWidget(self)
        self.filmstrip.setViewMode(QListWidget.ViewMode.IconMode)
        self.filmstrip.setIconSize(QSize(100, 76))
        self.filmstrip.setMaximumHeight(120)
        self.filmstrip.currentRowChanged.connect(self._show_sample)
        layout.addWidget(self.filmstrip)
        body = QHBoxLayout()
        self.viewer = FilmstripImageView(self)
        body.addWidget(self.viewer, 1)
        panel = QWidget()
        form = QFormLayout(panel)
        self.fields = {}
        for field in fields(Settings):
            name, value = field.name, getattr(Settings(), field.name)
            if name == "normalization":
                widget = QComboBox()
                widget.addItems(["none", "offset", "gain_offset"])
                widget.setCurrentText(value)
                widget.currentTextChanged.connect(self._invalidate)
            else:
                widget = QLineEdit(str(value))
                widget.textChanged.connect(self._invalidate)
            self.fields[name] = widget
            form.addRow(name.replace("_", " ").capitalize(), widget)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(panel)
        body.addWidget(scroll)
        layout.addLayout(body, 1)
        self.status = QLabel("Add aligned good images, select masks, then train.")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        bottom = QHBoxLayout()
        self.train_button = self._button("Train references", self._train)
        self.preview_button = self._button("Inspect test / selected image", self._preview)
        self.stage_button = self._button("Stage recipe", self._stage)
        self.review_button = self._button("Review last inspection…", self._review)
        self.review_button.setEnabled(False)
        self.wired_preview_button = self._button("Inspect wired image + pose", self._preview_wired)
        self.wired_preview_button.setEnabled(hasattr(context, "snapshot_input_data"))
        for button in (self.train_button, self.preview_button, self.wired_preview_button, self.stage_button):
            bottom.addWidget(button)
        bottom.addWidget(self.review_button)
        self.view_mode = QComboBox()
        self.view_mode.addItems(["Reference mean", "Normal variation", "Inspection mask", "Normalization mask",
                                 "Inspection overlay", "Deviation map", "Common sample coverage", "Assessment"])
        self.view_mode.activated.connect(lambda _: self._perform(self._show_model))
        bottom.addWidget(self.view_mode)
        layout.addLayout(bottom)
        self._perform(self._restore)
        self._show_fixture()

    def _button(self, title, action):
        button = QPushButton(title)
        button.clicked.connect(lambda: self._perform(action))
        return button

    def _perform(self, action):
        try:
            action()
        except (ValueError, OSError, TypeError, cv2.error) as error:
            self.status.setText(str(error))

    def _invalidate(self, *_):
        self.model = None
        self.inspection = None
        if hasattr(self, "review_button"):
            self.review_button.setEnabled(False)
        if hasattr(self, "status"):
            self.status.setText("Training changed. Train references before previewing or staging.")

    def _append(self, image, name, *, support=None):
        image = _image(image).copy()
        if self.samples and image.shape != self.samples[0].shape:
            raise ValueError("Training samples must share the aligned reference grid.")
        support = _mask(support, image.shape)
        self.samples.append(image)
        self.sample_support.append(support)
        item = QListWidgetItem(QIcon(pixmap(backdrop(image))), name)
        self.filmstrip.addItem(item)
        self._invalidate()
        self.filmstrip.setCurrentRow(len(self.samples) - 1)

    def _add_files(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Good aligned samples", "", _IMAGES)
        for path in paths:
            self._append(read_image(path), path.replace("\\", "/").rsplit("/", 1)[-1])

    def _capture(self):
        if self.reference_fixture is not None:
            raise ValueError("Use Capture image + pose while a reference pose is set.")
        self.context.refresh_images()
        image = self.context.snapshot_input_image("image").value
        self._append(gray_image(image, (np.uint8, np.uint16, np.float32)), "Captured aligned sample")

    def _capture_packets(self):
        self.context.refresh_images()
        image = self.context.snapshot_input_image("image")
        pose = self.context.snapshot_input_data("pose")
        return image.value, fixture_for_capture(image, pose)

    def _new_set(self):
        self.samples.clear()
        self.sample_support.clear()
        self.filmstrip.clear()
        self.inspection_mask = self.normalization_mask = self.reference_fixture = self.test_image = None
        self._invalidate()
        self._show_fixture()
        self.viewer.set_image(QPixmap())
        self.status.setText("New reference set. Capture image + pose to teach its origin, or add aligned images.")

    def _capture_pose(self):
        source, current = self._capture_packets()
        image = gray_image(source, (np.uint8, np.uint16, np.float32))
        reference = self.reference_fixture
        if reference is None and self.samples:
            raise ValueError("Start with an empty training set to teach its reference pose.")
        if reference is None:
            self._append(image, "Captured reference + pose")
            self.reference_fixture = current
        else:
            aligned, valid = _aligned(image, self.samples[0].shape, relative_fixture(current, reference))
            self._append(aligned, "Pose-aligned captured sample", support=valid)
        self._show_fixture()
        self.status.setText("Image and pose captured together. Review the masks, then train references.")

    def _show_fixture(self):
        self.clear_fixture_button.setEnabled(self.reference_fixture is not None)
        if self.reference_fixture is None:
            self.fixture_label.setText("Reference alignment uses the taught image grid.")
        else:
            x, y = self.reference_fixture[:, 2]
            self.fixture_label.setText(f"Captured reference fixture · Origin x {x:.2f}, y {y:.2f} pixels")

    def _clear_fixture(self):
        self.reference_fixture = None
        self._invalidate()
        self._show_fixture()

    def _remove(self):
        index = self.filmstrip.currentRow()
        if index >= 0:
            self.samples.pop(index)
            self.sample_support.pop(index)
            self.filmstrip.takeItem(index)
            self._invalidate()
        if not self.samples:
            self._new_set()

    def _show_sample(self, index):
        if 0 <= index < len(self.samples):
            self.viewer.set_image(pixmap(backdrop(self.samples[index])))

    def _open_mask(self, name):
        if not self.samples:
            raise ValueError("Add a reference image before importing masks.")
        path, _ = QFileDialog.getOpenFileName(self, name.replace("_", " "), "", _IMAGES)
        if path:
            value = _mask(read_image(path), self.samples[0].shape)
            setattr(self, name, value)
            self._invalidate()
            self.viewer.set_image(pixmap(backdrop(value.astype(np.uint8) * 255)))

    def _open_test(self):
        path, _ = QFileDialog.getOpenFileName(self, "Independent aligned test image", "", _IMAGES)
        if path:
            self.inspection = None
            self.review_button.setEnabled(False)
            self.test_image = _image(read_image(path))
            self.viewer.set_image(pixmap(backdrop(self.test_image)))
            self.status.setText("Test image loaded. Inspect it before reviewing results.")

    def _edit_mask(self, name):
        if not self.samples:
            raise ValueError("Add a reference image before editing masks.")
        value = getattr(self, name)
        if value is None and name == "normalization_mask":
            value = self.inspection_mask
        current = _mask(value, self.samples[0].shape)
        dialog = MaskEditor(self.samples[0], current, self, title="Edit " + name.replace("_", " "))
        try:
            if dialog.exec() == QDialog.DialogCode.Accepted:
                updated = dialog.mask
                if not np.array_equal(updated, current):
                    setattr(self, name, updated)
                    self._invalidate()
                    overlay = backdrop(self.samples[0])
                    overlay[~updated] //= 3
                    self.viewer.set_image(pixmap(overlay))
        finally:
            dialog.deleteLater()

    def _settings(self):
        values = {}
        for name, widget in self.fields.items():
            if name == "normalization":
                values[name] = widget.currentText()
            else:
                text = widget.text().strip()
                if name == "min_correlation" and not text:
                    values[name] = None
                else:
                    values[name] = int(text) if name in ("min_defect_area", "max_total_defect_area") else float(text)
        return Settings(**values)

    def _train(self):
        self.inspection = None
        self.review_button.setEnabled(False)
        self.model = train(self.samples, settings=self._settings(), inspection_mask=self.inspection_mask,
                           normalization_mask=self.normalization_mask, sample_support=self.sample_support,
                           reference_fixture=self.reference_fixture)
        health = self.model.health
        self.status.setText(
            f"{health['sample_count']} good samples · Mean variation {health['mean_standard_deviation']:.3g} intensity units · "
            + " ".join(health["warnings"])
        )
        self.view_mode.setCurrentIndex(0)
        self._show_model()

    def _show_model(self):
        if self.view_mode.currentIndex() == 6:
            if not self.sample_support:
                raise ValueError("Add training samples before reviewing coverage.")
            support = np.logical_and.reduce(self.sample_support)
            image = backdrop(self.samples[0])
            image[~support] //= 3
            self.viewer.set_image(pixmap(image))
            self.status.setText(f"{int(support.sum())} pixels supported by every training sample in the reference grid.")
            return
        if self.model is None:
            raise ValueError("Train references before reviewing the model.")
        if self.view_mode.currentIndex() >= 4:
            if self.inspection is None:
                raise ValueError("Inspect an image before reviewing its result maps.")
            result, source = self.inspection
            mode = self.view_mode.currentIndex()
            image = (draw_assessment(source, self.model, result) if mode == 7 else
                     draw_overlay(source, result) if mode == 4 else backdrop(result.deviation_map))
            self.viewer.set_image(pixmap(image))
            return
        image = (self.model.mean, self.model.deviation, self.model.inspection_mask.astype(np.uint8) * 255,
                 self.model.normalization_mask.astype(np.uint8) * 255)[self.view_mode.currentIndex()]
        self.viewer.set_image(pixmap(backdrop(image)))

    def _preview(self):
        if self.model is None:
            raise ValueError("Train references before previewing.")
        image = self.test_image
        if image is None:
            index = self.filmstrip.currentRow()
            image = self.samples[max(0, index)]
        self._show_inspection(image, self.model.inspect(image))

    def _preview_wired(self):
        if self.model is None:
            raise ValueError("Train references before previewing.")
        if self.model.reference_fixture is None:
            raise ValueError("Teach a reference with Capture image + pose before using the wired pose preview.")
        source, current = self._capture_packets()
        image = gray_image(source, (np.uint8, np.uint16, np.float32))
        result = self.model.inspect(image, reference_to_image=relative_fixture(current, self.model.reference_fixture))
        self._show_inspection(image, result)

    def _show_inspection(self, image, result):
        self.inspection = result, image
        self.review_button.setEnabled(True)
        self.viewer.set_image(pixmap(draw_overlay(image, result)))
        label = (f"{'Pass' if result.passed else 'Fail'} · {result.report['defect_area']} reference pixels"
                 if result.report["evaluated"] else "Not evaluated")
        self.status.setText(label + " · " + ", ".join(result.report["failures"]))

    def _review(self):
        if self.model is None or self.inspection is None:
            raise ValueError("Inspect an image before reviewing its result.")
        from .qt_review import ReferenceReviewDialog

        result, image = self.inspection
        dialog = ReferenceReviewDialog(self, image, self.model, result)
        try:
            dialog.exec()
        finally:
            dialog.deleteLater()

    def _restore(self):
        if not self.parameters["recipe_path"]:
            return
        model = load_model(recipe_path(self.context.project_dir, self.parameters["recipe_path"]),
                           sha256=self.parameters["sha256"])
        for index, (image, support) in enumerate(zip(model.samples, model.sample_support, strict=True)):
            self._append(image, f"Good sample {index + 1}", support=support)
        for name, widget in self.fields.items():
            value = getattr(model.settings, name)
            if name == "normalization":
                widget.setCurrentText(value)
            else:
                widget.setText("" if value is None else str(value))
        self.inspection_mask, self.normalization_mask = model.inspection_mask, model.normalization_mask
        self.reference_fixture = model.reference_fixture
        self.model = model
        self.status.setText(f"Restored {len(model.samples)} good samples and their trained variation.")
        self._show_model()

    def _stage(self):
        if self.model is None:
            raise ValueError("Train references before staging.")
        relative = f"assets/reference_inspect/{uuid.uuid4().hex}.sri"
        target = recipe_path(self.context.project_dir, relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        digest = save_model(target, self.model)
        self.parameters.update(recipe_path=relative, sha256=digest)
        self.accept()
