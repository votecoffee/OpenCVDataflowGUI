"""Train and inspect reference recipes from grayscale files."""

import argparse
import json
from pathlib import Path

import cv2
import numpy as np

from .graphics import draw_overlay
from .model import Settings, train
from .persistence import load_model, save_model


def read_image(path):
    image = cv2.imdecode(np.fromfile(path, np.uint8), cv2.IMREAD_UNCHANGED)
    if image is None:
        raise ValueError(f"Cannot read image {path}.")
    return image


def write_image(path, image):
    ok, encoded = cv2.imencode(Path(path).suffix, image)
    if not ok:
        raise ValueError(f"Cannot encode image {path}.")
    Path(path).write_bytes(encoded.tobytes())


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    training = commands.add_parser("train")
    training.add_argument("recipe", type=Path)
    training.add_argument("images", type=Path, nargs="+")
    training.add_argument("--settings", type=Path)
    training.add_argument("--inspection-mask", type=Path)
    training.add_argument("--normalization-mask", type=Path)
    training.add_argument("--poses", type=Path, help="JSON list of reference-to-image affine matrices, first entry null.")
    running = commands.add_parser("inspect")
    running.add_argument("recipe", type=Path)
    running.add_argument("image", type=Path)
    running.add_argument("--pose", type=Path)
    running.add_argument("--mask", type=Path)
    running.add_argument("--report", type=Path)
    running.add_argument("--overlay", type=Path)
    running.add_argument("--defect-mask", type=Path)
    args = parser.parse_args(argv)
    try:
        if args.command == "train":
            settings = Settings(**json.loads(args.settings.read_text(encoding="utf-8"))) if args.settings else Settings()
            model = train(
                [read_image(path) for path in args.images], settings=settings,
                inspection_mask=read_image(args.inspection_mask) if args.inspection_mask else None,
                normalization_mask=read_image(args.normalization_mask) if args.normalization_mask else None,
                reference_to_images=json.loads(args.poses.read_text(encoding="utf-8")) if args.poses else None,
            )
            save_model(args.recipe, model)
            print(json.dumps(model.health, allow_nan=False))
            return 0
        model = load_model(args.recipe)
        image = read_image(args.image)
        result = model.inspect(
            image, reference_to_image=json.loads(args.pose.read_text(encoding="utf-8")) if args.pose else None,
            mask=read_image(args.mask) if args.mask else None,
        )
        report = json.dumps(result.report, indent=2, allow_nan=False) + "\n"
        if args.report:
            args.report.write_text(report, encoding="utf-8")
        else:
            print(report, end="")
        if args.overlay:
            write_image(args.overlay, draw_overlay(image, result))
        if args.defect_mask:
            write_image(args.defect_mask, result.source_maps()["defect_mask"])
        return 0 if result.passed else 1
    except (ValueError, OSError, cv2.error) as error:
        parser.error(str(error))
