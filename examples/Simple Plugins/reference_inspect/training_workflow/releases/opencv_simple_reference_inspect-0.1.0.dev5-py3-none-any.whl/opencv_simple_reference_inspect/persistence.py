"""Atomic, bounded recipes retaining all aligned training samples."""

import hashlib
import io
import json
import os
from dataclasses import asdict
from pathlib import Path
from tempfile import NamedTemporaryFile
from zipfile import ZIP_DEFLATED, BadZipFile, ZipFile

import numpy as np

from .model import MAX_BYTES, ReferenceModel, Settings

_ARRAYS_V1 = ("samples", "mean", "deviation", "inspection_mask", "normalization_mask")
_ARRAYS = (*_ARRAYS_V1, "sample_support")


def save_model(path, model):
    entries = {}
    for name in _ARRAYS:
        stream = io.BytesIO()
        np.save(stream, getattr(model, name), allow_pickle=False)
        entries[name + ".npy"] = stream.getvalue()
    manifest = {
        "version": 2, "settings": asdict(model.settings), "health": model.health,
        "reference_fixture": None if model.reference_fixture is None else model.reference_fixture.tolist(),
        "sha256": {name: hashlib.sha256(raw).hexdigest() for name, raw in entries.items()},
    }
    entries["recipe.json"] = json.dumps(manifest, allow_nan=False, indent=2).encode("utf-8")
    target = Path(path)
    with NamedTemporaryFile(dir=target.parent, prefix=f".{target.name}.", delete=False) as stream:
        temporary = Path(stream.name)
    try:
        with ZipFile(temporary, "w", compression=ZIP_DEFLATED) as archive:
            for name, raw in entries.items():
                archive.writestr(name, raw)
        os.replace(temporary, target)
    finally:
        temporary.unlink(missing_ok=True)
    return hashlib.sha256(target.read_bytes()).hexdigest()


def load_model(path, *, sha256=None, cached=None):
    path = Path(path)
    if path.stat().st_size > 2 * MAX_BYTES:
        raise ValueError("Recipe exceeds its 512 MiB budget.")
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if sha256 is not None and digest != sha256:
        raise ValueError("Recipe SHA-256 mismatch. Stage the intended recipe again.")
    if cached is not None and cached[0] == digest:
        return cached[1]
    try:
        with ZipFile(io.BytesIO(raw)) as archive:
            if sum(info.file_size for info in archive.infolist()) > 2 * MAX_BYTES:
                raise ValueError("Uncompressed recipe exceeds its 512 MiB budget.")
            if archive.getinfo("recipe.json").file_size > 1024 * 1024:
                raise ValueError("Recipe metadata exceeds 1 MiB.")
            manifest = json.loads(archive.read("recipe.json"))
            if type(manifest["version"]) is not int or manifest["version"] not in (1, 2):
                raise ValueError("Unsupported reference recipe version.")
            names = _ARRAYS_V1 if manifest["version"] == 1 else _ARRAYS
            expected = {"recipe.json", *(name + ".npy" for name in names)}
            if len(archive.namelist()) != len(expected) or set(archive.namelist()) != expected:
                raise ValueError("Unexpected or duplicate recipe entries.")
            arrays = {}
            for name in names:
                data = archive.read(name + ".npy")
                if hashlib.sha256(data).hexdigest() != manifest["sha256"][name + ".npy"]:
                    raise ValueError("Recipe array checksum mismatch.")
                arrays[name] = np.load(io.BytesIO(data), allow_pickle=False)
        fixture = manifest["reference_fixture"] if manifest["version"] == 2 else None
        return ReferenceModel(**arrays, settings=Settings(**manifest["settings"]), health=manifest["health"],
                              reference_fixture=fixture)
    except (BadZipFile, KeyError, TypeError, OSError) as error:
        raise ValueError(f"Invalid reference recipe. {error}") from error
