"""Inspection graphics in the source image grid."""

import cv2
import numpy as np


def backdrop(image):
    image = np.asarray(image)
    gray = image if image.dtype == np.uint8 else cv2.normalize(
        image, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U,
    )
    return cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)


def draw_overlay(image, inspection, *, maps=None):
    output = backdrop(image)
    maps = inspection.source_maps() if maps is None else maps
    selected = maps["inspected_mask"] != 0
    output[selected] = np.rint(output[selected] * .85 + np.array([50, 190, 80]) * .15).astype(np.uint8)
    contours, _ = cv2.findContours(maps["defect_mask"], cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(output, contours, -1, (60, 65, 245), 2, cv2.LINE_AA)
    caption = "PASS" if inspection.passed else "FAIL " + ", ".join(inspection.report["failures"])
    cv2.putText(output, caption, (8, 21), cv2.FONT_HERSHEY_SIMPLEX, .45, (240, 240, 240), 1, cv2.LINE_AA)
    return output
