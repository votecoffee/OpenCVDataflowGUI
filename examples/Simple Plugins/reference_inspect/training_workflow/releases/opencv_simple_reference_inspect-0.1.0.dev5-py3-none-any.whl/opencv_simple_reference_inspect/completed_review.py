"""Exact completed reference/model/map review; no inference or exposure refitting."""

import copy
import hashlib
import json
from dataclasses import dataclass, field, fields

import numpy as np

from .model import Inspection, ReferenceModel
from .persistence import save_model
from .result_review import ResultReview

BINDING = "sri_completed_review"
MAPS = ("residual", "deviation_map", "inspected_mask", "defect_mask")


def _readonly(value):
    array = np.asarray(value)
    return np.frombuffer(array.tobytes(), dtype=array.dtype).reshape(array.shape)


def _json(value):
    return json.dumps(value, sort_keys=True, allow_nan=False).encode("utf-8")


class _FrozenModel(ReferenceModel):
    @property
    def health(self):
        return json.loads(self._health_json)

    def __deepcopy__(self, memo):
        return self


class _FrozenInspection(Inspection):
    @property
    def report(self):
        return json.loads(self._report_json)

    def __deepcopy__(self, memo):
        return self


def freeze_model(model):
    """Copy model buffers only on explicit review capture; retain exact tolerance."""
    frozen = object.__new__(_FrozenModel)
    object.__setattr__(frozen, "_health_json", _json(model.health))
    for spec in fields(ReferenceModel):
        if spec.name == "health":
            continue
        value = getattr(model, spec.name)
        object.__setattr__(
            frozen,
            spec.name,
            _readonly(value) if isinstance(value, np.ndarray) else value,
        )
    return frozen


@dataclass(frozen=True)
class CompletedReferenceRecord:
    identifier: str
    recipe_sha256: str
    model: ReferenceModel
    _reference_maps: tuple = field(repr=False, compare=False)
    _matrix: tuple
    source_shape: tuple
    report_json: bytes

    @classmethod
    def create(cls, identifier, pin, model, inspection):
        # These reference-grid arrays are private runtime-owned intermediates,
        # distinct from published source-map outputs. Retain without new copies.
        arrays = tuple(getattr(inspection, name) for name in MAPS)
        for array in arrays:
            array.flags.writeable = False
        return cls(
            identifier,
            pin,
            model,
            arrays,
            tuple(map(tuple, inspection.reference_to_image.tolist())),
            tuple(inspection.source_shape),
            _json(inspection.report),
        )

    def freeze_inspection(self):
        frozen = object.__new__(_FrozenInspection)
        for name, array in zip(MAPS, self._reference_maps):
            object.__setattr__(frozen, name, _readonly(array))
        object.__setattr__(
            frozen, "reference_to_image", _readonly(np.asarray(self._matrix))
        )
        object.__setattr__(frozen, "source_shape", self.source_shape)
        object.__setattr__(frozen, "_report_json", self.report_json)
        return frozen

    def __deepcopy__(self, memo):
        return self


@dataclass(frozen=True)
class CompletedReferenceCapture:
    record: CompletedReferenceRecord
    model: ReferenceModel
    inspection: Inspection
    source_pixels: np.ndarray = field(repr=False, compare=False)
    image: np.ndarray = field(repr=False, compare=False)
    source_format: str
    _source_maps: tuple = field(repr=False, compare=False)
    _provenance: dict = field(repr=False, compare=False)

    @property
    def provenance(self):
        return copy.deepcopy(self._provenance)

    @property
    def source_maps(self):
        return dict(zip(MAPS, self._source_maps))

    @property
    def source_sha256(self):
        return hashlib.sha256(self.source_pixels.tobytes()).hexdigest()

    def review(self):
        return ResultReview(
            self.image, self.model, self.inspection, maps=self.source_maps
        )

    def report(self):
        return dict(
            model="simple_reference_completed_review_v1",
            execution_binding=self.record.identifier,
            original_recipe_sha256=self.record.recipe_sha256,
            source_image=dict(
                shape=list(self.source_pixels.shape),
                dtype=self.source_pixels.dtype.str,
                format=self.source_format,
                sha256=self.source_sha256,
            ),
            measurement_image=dict(
                shape=list(self.image.shape), dtype=self.image.dtype.str
            ),
            reference_size=list(self.model.mean.shape[::-1]),
            reference_to_image=self.inspection.reference_to_image.tolist(),
            inspection=self.inspection.report,
            source_maps={
                name: dict(
                    shape=list(array.shape),
                    dtype=array.dtype.str,
                    sha256=hashlib.sha256(array.tobytes()).hexdigest(),
                )
                for name, array in self.source_maps.items()
            },
            provenance=self.provenance,
            coordinate_scope="Reference maps, exact consumed-input maps and assessment display grids remain distinct",
            identity_scope="Software completion identifiers do not establish physical exposure identity",
            review_reconstruction="Normalized current is resampled with captured pose/exposure; no exposure refitting",
            inspection_reexecuted=False,
            exposure_refitted=False,
            recipe_reloaded=False,
            training_changed=False,
        )

    def export(self, directory):
        review = self.review()
        target = review.save(directory)
        for name, array in (
            ("consumed_input", self.source_pixels),
            ("measurement_input", self.image),
            *(("source_" + name, value) for name, value in self.source_maps.items()),
        ):
            np.save(target / f"{name}.npy", array, allow_pickle=False)
        current = review.normalized_current()
        if current is not None:
            np.save(target / "normalized_current.npy", current[0], allow_pickle=False)
            np.save(target / "normalized_support.npy", current[1], allow_pickle=False)
        digest = save_model(target / "executed_model.sri", self.model)
        path = target / "review.json"
        document = json.loads(path.read_bytes())
        completed = self.report()
        completed["exported_model"] = dict(
            file="executed_model.sri",
            sha256=digest,
            scope="Re-encoded executed model; archive bytes may differ from original pin",
        )
        document["completed_execution"] = completed
        path.write_text(
            json.dumps(document, indent=2, allow_nan=False) + "\n", encoding="utf-8"
        )
        return target


def capture_completed(record, bundle, *, frozen_model=None):
    from opencv_dataflow.images import image_format
    from opencv_dataflow.processing import gray_image

    if record is None:
        raise ValueError(
            "No retained completed reference inspection; execute in Debug before reviewing"
        )
    packet = bundle.outputs["inspection"]
    binding = packet.payload.get(BINDING, {})
    if (
        binding.get("id") != record.identifier
        or binding.get("recipe_sha256") != record.recipe_sha256
        or _json(packet.value) != record.report_json
    ):
        raise ValueError(
            "Completed model/inspection evidence changed; capture the latest run again"
        )
    source = bundle.inputs["image"].value
    image = gray_image(source, (np.uint8, np.uint16, np.float32))
    if tuple(image.shape) != record.source_shape:
        raise ValueError(
            "Completed input dimensions differ from the captured inspection"
        )
    maps = tuple(_readonly(bundle.outputs[name].value) for name in MAPS)
    if any(array.shape != image.shape for array in maps):
        raise ValueError(
            "Completed source map dimensions differ from the consumed input"
        )
    provenance = dict(
        snapshot_id=bundle.snapshot_id,
        block_id=bundle.block_id,
        output_revision=bundle.output_revision,
        execution_count=bundle.execution_count,
        passed=bool(bundle.passed),
        score=bundle.score,
        message=bundle.message,
        inputs={
            name: copy.deepcopy(packet.payload)
            for name, packet in bundle.inputs.items()
        },
        outputs={
            name: copy.deepcopy(packet.payload)
            for name, packet in bundle.outputs.items()
        },
    )
    return CompletedReferenceCapture(
        record,
        freeze_model(record.model) if frozen_model is None else frozen_model,
        record.freeze_inspection(),
        _readonly(source),
        _readonly(image),
        image_format(source),
        maps,
        provenance,
    )
