"""Review good samples and stage an inspection model through the host editor."""

import copy
import json
import uuid
from concurrent.futures import CancelledError, ThreadPoolExecutor
from dataclasses import fields
from pathlib import Path
from threading import Event

import cv2
import numpy as np
from opencv_dataflow.canvas import pixmap
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from opencv_dataflow.processing import gray_image
from PySide6.QtCore import QSize, Qt, QTimer
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from .cli import read_image
from .dataflow import fixture_for_capture, recipe_path, relative_fixture
from .graphics import backdrop, draw_overlay
from .model import MAX_BYTES, Settings, _affine, _aligned, _image, _mask, train
from .persistence import load_model, save_model
from .qt_masks import MaskEditor
from .result_review import draw_assessment

_IMAGES = "Images (*.png *.tif *.tiff *.bmp *.jpg *.jpeg);;All files (*)"
_TRAINERS = ThreadPoolExecutor(max_workers=1, thread_name_prefix="reference-training")


def _fit_training(samples, support, settings, region, stable, fixture, sources, cancelled):
    model = train(samples, sample_support=support, settings=settings, inspection_mask=region,
                  normalization_mask=stable, reference_fixture=fixture, cancelled=cancelled)
    model.health["training_sources"] = sources
    return model


class ReferenceTrainingDialog(QDialog):
    def __init__(self, parent, parameters, context):
        super().__init__(parent)
        self.setWindowTitle("Train reference inspection")
        self.resize(1100, 720)
        self.parameters, self.context = parameters, context
        self.samples = []
        self.sample_support = []
        self.sample_sources = []
        self.future = None
        self._revision = 0
        self._training_revision = None
        self._cancelled = Event()
        self._closing = self._restoring = False
        self._actions = []
        self._coverage_key = self._common_support = None
        self._review_window = None
        self.timer = QTimer(self)
        self.timer.setInterval(40)
        self.timer.timeout.connect(self._training_finished)
        self.finished.connect(self._stop_training)
        self.reference_fixture = None
        self.inspection_mask = self.normalization_mask = None
        self.model = self.test_image = self.inspection = None
        layout = QVBoxLayout(self)
        actions = QHBoxLayout()
        self.capture_pose_button = self._button("Capture image + pose", self._capture_pose)
        self.capture_pose_button.setEnabled(hasattr(context, "snapshot_input_data"))
        self.capture_pose_button.setToolTip("Capture matching image and fixture pose, aligning later samples to the first.")
        for title, action in (
            ("Add good images…", self._add_files), ("Capture aligned image", self._capture),
            ("Remove selected", self._remove), ("Test image…", self._open_test),
        ):
            actions.addWidget(self._button(title, action))
        actions.addWidget(self.capture_pose_button)
        self.new_set_button = self._button("New reference set", self._new_set)
        actions.addWidget(self.new_set_button)
        layout.addLayout(actions)
        import_row = QHBoxLayout()
        import_row.addWidget(self._button("Import image + alignment…", self._import_aligned))
        import_hint = QLabel("Use a reference-to-source 2 × 3 affine matrix; review the aligned pixels and support before training.")
        import_hint.setWordWrap(True)
        import_row.addWidget(import_hint, 1)
        layout.addLayout(import_row)
        fixture_row = QHBoxLayout()
        self.fixture_label = QLabel()
        self.fixture_label.setWordWrap(True)
        fixture_row.addWidget(self.fixture_label, 1)
        self.clear_fixture_button = self._button("Clear reference pose", self._clear_fixture)
        fixture_row.addWidget(self.clear_fixture_button)
        layout.addLayout(fixture_row)
        masks = QHBoxLayout()
        self.inspection_mask_button = self._button("Edit inspection mask…", lambda: self._edit_mask("inspection_mask"))
        self.normalization_mask_button = self._button("Edit normalization mask…", lambda: self._edit_mask("normalization_mask"))
        for button in (
            self.inspection_mask_button, self._button("Import inspection mask…", lambda: self._open_mask("inspection_mask")),
            self.normalization_mask_button, self._button("Import normalization mask…", lambda: self._open_mask("normalization_mask")),
        ):
            masks.addWidget(button)
        layout.addLayout(masks)
        hint = QLabel("Use good samples aligned to the first image. Edit or import masks for inspection and stable exposure features.")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.filmstrip = QListWidget(self)
        self.filmstrip.setViewMode(QListWidget.ViewMode.IconMode)
        self.filmstrip.setIconSize(QSize(100, 76))
        self.filmstrip.setMaximumHeight(120)
        self.filmstrip.currentRowChanged.connect(self._show_sample)
        layout.addWidget(self.filmstrip)
        self.sample_label = QLabel("No training sample selected.")
        self.sample_label.setWordWrap(True)
        self.sample_label.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.sample_label)
        body = QHBoxLayout()
        self.viewer = FilmstripImageView(self)
        body.addWidget(self.viewer, 1)
        panel = QWidget()
        form = QFormLayout(panel)
        self.fields = {}
        for field in fields(Settings):
            name, value = field.name, getattr(Settings(), field.name)
            if name == "normalization":
                widget = QComboBox()
                widget.addItems(["none", "offset", "gain_offset"])
                widget.setCurrentText(value)
                widget.currentTextChanged.connect(self._invalidate)
            else:
                widget = QLineEdit(str(value))
                widget.textChanged.connect(self._invalidate)
            self.fields[name] = widget
            form.addRow(name.replace("_", " ").capitalize(), widget)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(panel)
        body.addWidget(scroll)
        layout.addLayout(body, 1)
        self.setup_label = QLabel()
        self.setup_label.setWordWrap(True)
        self.setup_label.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.setup_label)
        self.health_label = QLabel("No trained model for this draft.")
        self.health_label.setWordWrap(True)
        layout.addWidget(self.health_label)
        self.status = QLabel("Add aligned good images, select masks, then train.")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        job_row = QHBoxLayout()
        job_row.addWidget(QLabel("Training runs in the background; cancellation stops between samples/native phases."), 1)
        self.cancel_button = QPushButton("Cancel training")
        self.cancel_button.clicked.connect(self._cancel_training)
        self.cancel_button.setEnabled(False)
        job_row.addWidget(self.cancel_button)
        layout.addLayout(job_row)
        bottom = QHBoxLayout()
        self.train_button = self._button("Train references", self._train)
        self.preview_button = self._button("Inspect test / selected image", self._preview)
        self.stage_button = self._button("Stage recipe", self._stage)
        self.review_button = self._button("Review last inspection…", self._review)
        self.review_button.setEnabled(False)
        self.wired_preview_button = self._button("Inspect wired image + pose", self._preview_wired)
        self.wired_preview_button.setEnabled(hasattr(context, "snapshot_input_data"))
        for button in (self.train_button, self.preview_button, self.wired_preview_button, self.stage_button):
            bottom.addWidget(button)
        bottom.addWidget(self.review_button)
        self.view_mode = QComboBox()
        self.view_mode.addItems(["Reference mean", "Normal variation", "Inspection mask", "Normalization mask",
                                 "Inspection overlay", "Deviation map", "Common sample coverage", "Assessment"])
        self.view_mode.activated.connect(lambda _: self._perform(self._show_model))
        bottom.addWidget(self.view_mode)
        layout.addLayout(bottom)
        self._restoring = True
        try:
            self._perform(self._restore)
        finally:
            self._restoring = False
        self._show_fixture()
        self._refresh_controls()

    def _button(self, title, action):
        button = QPushButton(title)
        button.clicked.connect(lambda: self._perform(action))
        self._actions.append(button)
        return button

    def _perform(self, action):
        try:
            action()
        except (ValueError, OSError, TypeError, cv2.error) as error:
            self.status.setText(str(error))

    def _invalidate(self, *_):
        self._revision += 1
        if self.future is not None:
            self._cancelled.set()
        self.model = None
        self.inspection = None
        if self._review_window is not None:
            self._review_window.reject()
        if hasattr(self, "health_label"):
            self.health_label.setText("Draft changed. Train again before previewing or staging; the applied recipe is unchanged.")
        if hasattr(self, "review_button"):
            self.review_button.setEnabled(False)
        if hasattr(self, "status"):
            self.status.setText("Training changed. Train references before previewing or staging.")
        if not self._restoring and hasattr(self, "stage_button"):
            self._refresh_controls()

    def _append(self, image, name, *, support=None, source_metadata=None):
        if self.future is not None or self._closing:
            raise ValueError("Wait for training to finish before adding samples.")
        image = _image(image)
        if self.samples and image.shape != self.samples[0].shape:
            raise ValueError("Training samples must share the aligned reference grid.")
        if len(self.samples) >= 128 or (len(self.samples) + 1) * image.size * 4 > MAX_BYTES:
            raise ValueError("Aligned samples exceed the 128-image / 256 MiB training budget.")
        image = image.copy()
        support = _mask(support, image.shape)
        image.flags.writeable = support.flags.writeable = False
        self.samples.append(image)
        self.sample_support.append(support)
        source = {"name": str(name)[:256], "kind": "already aligned"}
        if source_metadata:
            source.update(copy.deepcopy(source_metadata))
        source["name"] = str(source.get("name", name))[:256]
        self.sample_sources.append(source)
        item = QListWidgetItem(QIcon(pixmap(backdrop(image))), name)
        self.filmstrip.addItem(item)
        self._invalidate()
        self.filmstrip.setCurrentRow(len(self.samples) - 1)

    def _add_files(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Good aligned samples", "", _IMAGES)
        for path in paths:
            self._append(read_image(path), path.replace("\\", "/").rsplit("/", 1)[-1])

    def add_aligned_sample(self, image, reference_to_image, name):
        if not self.samples:
            raise ValueError("Add the first reference image before importing an aligned sample.")
        if self.future is not None or self._closing:
            raise ValueError("Wait for training to finish before importing samples.")
        source = _image(image)
        matrix = _affine(reference_to_image)
        aligned, support = _aligned(source, self.samples[0].shape, matrix)
        self._append(aligned, name, support=support, source_metadata={
            "kind": "affine import", "reference_to_image": matrix.tolist(),
            "source_size": list(source.shape[::-1]), "source_dtype": str(source.dtype),
        })
        self.status.setText("Imported into the reference grid. Dim pixels are unsupported; both masks must fit the common support.")

    def _import_aligned(self):
        if not self.samples:
            raise ValueError("Add the first reference image before importing an aligned sample.")
        image_path, _ = QFileDialog.getOpenFileName(self, "Good source image to align", "", _IMAGES)
        if not image_path:
            return
        transform_path, _ = QFileDialog.getOpenFileName(self, "Reference-to-source 2 × 3 affine matrix", "", "JSON (*.json)")
        if transform_path:
            data = json.loads(Path(transform_path).read_bytes())
            matrix = data["reference_to_image"] if isinstance(data, dict) else data
            self.add_aligned_sample(read_image(image_path), matrix, Path(image_path).name)

    def _capture(self):
        if self.reference_fixture is not None:
            raise ValueError("Use Capture image + pose while a reference pose is set.")
        self.context.refresh_images()
        image = self.context.snapshot_input_image("image").value
        self._append(gray_image(image, (np.uint8, np.uint16, np.float32)), "Captured aligned sample")

    def _capture_packets(self):
        self.context.refresh_images()
        image = self.context.snapshot_input_image("image")
        pose = self.context.snapshot_input_data("pose")
        return image.value, fixture_for_capture(image, pose)

    def _new_set(self):
        self.samples.clear()
        self.sample_support.clear()
        self.sample_sources.clear()
        self._coverage_key = self._common_support = None
        self.filmstrip.clear()
        self.inspection_mask = self.normalization_mask = self.reference_fixture = self.test_image = None
        self._invalidate()
        self._show_fixture()
        self.viewer.set_image(QPixmap())
        self.status.setText("New reference set. Capture image + pose to teach its origin, or add aligned images.")

    def _capture_pose(self):
        source, current = self._capture_packets()
        image = gray_image(source, (np.uint8, np.uint16, np.float32))
        reference = self.reference_fixture
        if reference is None and self.samples:
            raise ValueError("Start with an empty training set to teach its reference pose.")
        if reference is None:
            self._append(image, "Captured reference + pose", source_metadata={"kind": "captured reference + pose"})
            self.reference_fixture = current
        else:
            matrix = relative_fixture(current, reference)
            aligned, valid = _aligned(image, self.samples[0].shape, matrix)
            self._append(aligned, "Pose-aligned captured sample", support=valid, source_metadata={
                "kind": "fixture-aligned capture", "reference_to_image": matrix.tolist(),
                "source_size": list(image.shape[::-1]), "source_dtype": str(image.dtype),
            })
        self._show_fixture()
        self.status.setText("Image and pose captured together. Review the masks, then train references.")

    def _show_fixture(self):
        self.clear_fixture_button.setEnabled(self.reference_fixture is not None)
        if self.reference_fixture is None:
            self.fixture_label.setText("Reference alignment uses the taught image grid.")
        else:
            x, y = self.reference_fixture[:, 2]
            self.fixture_label.setText(f"Captured reference fixture · Origin x {x:.2f}, y {y:.2f} pixels")

    def _clear_fixture(self):
        self.reference_fixture = None
        self._invalidate()
        self._show_fixture()

    def _remove(self):
        index = self.filmstrip.currentRow()
        if index >= 0:
            self.samples.pop(index)
            self.sample_support.pop(index)
            self.sample_sources.pop(index)
            self.filmstrip.takeItem(index)
            self._invalidate()
        if not self.samples:
            self._new_set()

    def _show_sample(self, index):
        if 0 <= index < len(self.samples):
            image = backdrop(self.samples[index])
            image[~self.sample_support[index]] //= 3
            self.viewer.set_image(pixmap(image))
            source = self.sample_sources[index]
            text = f"{source['name']} · {source.get('kind', 'saved aligned pixels')} · {np.count_nonzero(self.sample_support[index])} supported reference pixels."
            if "reference_to_image" in source:
                text += " Reference → source affine: " + json.dumps(source["reference_to_image"])
            self.sample_label.setText(text + " Saved recipes retain aligned pixels/support, not the original pre-alignment acquisition.")
        elif hasattr(self, "sample_label"):
            self.sample_label.setText("No training sample selected.")

    def _open_mask(self, name):
        if not self.samples:
            raise ValueError("Add a reference image before importing masks.")
        path, _ = QFileDialog.getOpenFileName(self, name.replace("_", " "), "", _IMAGES)
        if path:
            value = _mask(read_image(path), self.samples[0].shape)
            setattr(self, name, value)
            self._invalidate()
            self.viewer.set_image(pixmap(backdrop(value.astype(np.uint8) * 255)))

    def _open_test(self):
        path, _ = QFileDialog.getOpenFileName(self, "Independent aligned test image", "", _IMAGES)
        if path:
            self.inspection = None
            self.review_button.setEnabled(False)
            self.test_image = _image(read_image(path))
            self.viewer.set_image(pixmap(backdrop(self.test_image)))
            self.status.setText("Test image loaded. Inspect it before reviewing results.")

    def _edit_mask(self, name):
        if not self.samples:
            raise ValueError("Add a reference image before editing masks.")
        value = getattr(self, name)
        if value is None and name == "normalization_mask":
            value = self.inspection_mask
        current = _mask(value, self.samples[0].shape)
        dialog = MaskEditor(self.samples[0], current, self, title="Edit " + name.replace("_", " "))
        try:
            if dialog.exec() == QDialog.DialogCode.Accepted:
                updated = dialog.mask
                if not np.array_equal(updated, current):
                    setattr(self, name, updated)
                    self._invalidate()
                    overlay = backdrop(self.samples[0])
                    overlay[~updated] //= 3
                    self.viewer.set_image(pixmap(overlay))
        finally:
            dialog.deleteLater()

    def _settings(self):
        values = {}
        for name, widget in self.fields.items():
            if name == "normalization":
                values[name] = widget.currentText()
            else:
                text = widget.text().strip()
                if name == "min_correlation" and not text:
                    values[name] = None
                else:
                    values[name] = int(text) if name in ("min_defect_area", "max_total_defect_area") else float(text)
        return Settings(**values)

    def _train(self):
        if self.future is not None or self._closing:
            return
        self._refresh_controls()
        if not self._training_ready:
            raise ValueError(self._setup_error)
        settings = self._settings()
        # Samples/support are private read-only arrays, so a tuple freezes the
        # collection without copying a large stack on the GUI thread. Editable
        # masks/fixture/metadata get separate snapshots before starting work.
        samples, support = tuple(self.samples), tuple(self.sample_support)
        shape = samples[0].shape
        region = _mask(self.inspection_mask, shape)
        stable = region.copy() if self.normalization_mask is None else _mask(self.normalization_mask, shape)
        fixture = None if self.reference_fixture is None else _affine(self.reference_fixture).copy()
        sources = copy.deepcopy(self.sample_sources)
        self._invalidate()
        self.inspection = None
        self.review_button.setEnabled(False)
        self._cancelled.clear()
        self._training_revision = self._revision
        self.future = _TRAINERS.submit(
            _fit_training, samples, support, settings, region, stable, fixture, sources, self._cancelled.is_set,
        )
        self.status.setText(f"Training snapshot of {len(samples)} good samples in the background…")
        self.timer.start()
        self._refresh_controls()

    def _training_finished(self):
        if self._closing or self.future is None or not self.future.done():
            return
        self.timer.stop()
        future, self.future = self.future, None
        try:
            model = future.result()
            if self._cancelled.is_set() or self._training_revision != self._revision:
                raise CancelledError("Training changed or was cancelled; completed work was discarded.")
        except CancelledError as error:
            self.status.setText(str(error) or "Training cancelled.")
            self.health_label.setText("No trained model for this draft. The applied recipe is unchanged.")
        except Exception as error:  # noqa: BLE001 - report any worker failure on the owning GUI thread.
            self.status.setText(f"Training failed: {error}")
            self.health_label.setText("Training failed. Correct the sample/masks/settings and train again.")
        else:
            self.model = model
            self._show_health()
            self.status.setText("Training finished. Review the model and independent images, then Stage and Apply.")
            self.view_mode.setCurrentIndex(0)
            self._show_model()
        self._refresh_controls()

    def _cancel_training(self):
        if self.future is not None:
            self._cancelled.set()
            self.future.cancel()
            self.status.setText("Cancellation requested. Waiting for the current native operation to finish…")
            self.cancel_button.setEnabled(False)

    def _stop_training(self, *_):
        self._closing = True
        self._cancelled.set()
        self.timer.stop()
        if self.future is not None:
            self.future.cancel()
        if self._review_window is not None:
            self._review_window.reject()

    def _show_health(self):
        health = self.model.health
        self.health_label.setText(
            f"{health['sample_count']} good samples · Mean variation {health['mean_standard_deviation']:.3g} native intensity units · "
            + " ".join(health["warnings"]) + " Reference health is not independent accuracy qualification."
        )

    def _refresh_controls(self):
        busy = self.future is not None or self._closing
        for button in self._actions:
            button.setEnabled(not busy)
        for widget in self.fields.values():
            widget.setEnabled(not busy)
        self.cancel_button.setEnabled(self.future is not None and not self._cancelled.is_set())
        self.capture_pose_button.setEnabled(not busy and hasattr(self.context, "snapshot_input_data"))
        self.clear_fixture_button.setEnabled(not busy and self.reference_fixture is not None)
        self._training_ready = False
        self._setup_error = "Add good images in the first reference's coordinate grid."
        lines = ["Reference grid → aligned good samples → inspection/stable masks → Train → independent review → Stage → Apply."]
        if self.samples:
            try:
                self._settings()
                shape = self.samples[0].shape
                if len(self.samples) > 128 or len(self.samples) * self.samples[0].size * 4 > MAX_BYTES:
                    raise ValueError("Aligned samples exceed the 128-image / 256 MiB training budget.")
                key = (tuple(self.sample_support), self.inspection_mask, self.normalization_mask)
                changed = (self._coverage_key is None or len(key[0]) != len(self._coverage_key[0])
                           or any(a is not b for a, b in zip(key[0], self._coverage_key[0]))
                           or key[1] is not self._coverage_key[1] or key[2] is not self._coverage_key[2])
                if changed:
                    self._common_support = np.logical_and.reduce(self.sample_support)
                    self._common_count = int(np.count_nonzero(self._common_support))
                    region = _mask(self.inspection_mask, shape)
                    stable = region if self.normalization_mask is None else _mask(self.normalization_mask, shape)
                    self._mask_counts = tuple(int(np.count_nonzero(mask)) for mask in (region, stable))
                    self._unsupported_counts = tuple(int(np.count_nonzero(mask & ~self._common_support)) for mask in (region, stable))
                    self._coverage_key = key
                lines.append(f"{len(self.samples)} good samples · {shape[1]} × {shape[0]} reference pixels · Inspection/stable masks: {self._mask_counts[0]} / {self._mask_counts[1]} px.")
                lines.append(f"Common support: {self._common_count} px · Unsupported inspection/stable mask pixels: {self._unsupported_counts[0]} / {self._unsupported_counts[1]}.")
                if min(self._mask_counts) < 16:
                    raise ValueError("Both masks need at least 16 selected pixels.")
                if any(self._unsupported_counts):
                    raise ValueError("Every training sample must cover both masks. Edit masks inside Common sample coverage, or remove/re-align unsupported samples.")
                self._training_ready = True
                self._setup_error = ""
            except (ValueError, TypeError) as error:
                self._setup_error = str(error)
        if self._setup_error:
            lines.append("Fix setup: " + self._setup_error)
        self.setup_label.setText("\n".join(lines))
        self.train_button.setEnabled(not busy and self._training_ready)
        self.stage_button.setEnabled(not busy and self.model is not None and self.context.project_dir is not None)
        self.stage_button.setToolTip("Save the project before staging." if self.context.project_dir is None else "")
        self.preview_button.setEnabled(not busy and self.model is not None)
        self.wired_preview_button.setEnabled(not busy and self.model is not None and self.model.reference_fixture is not None and hasattr(self.context, "snapshot_input_data"))
        self.review_button.setEnabled(not busy and self.inspection is not None)

    def _show_model(self):
        if self.view_mode.currentIndex() == 6:
            if not self.sample_support:
                raise ValueError("Add training samples before reviewing coverage.")
            support = np.logical_and.reduce(self.sample_support)
            image = backdrop(self.samples[0])
            image[~support] //= 3
            self.viewer.set_image(pixmap(image))
            self.status.setText(f"{int(support.sum())} pixels supported by every training sample in the reference grid.")
            return
        if self.model is None:
            raise ValueError("Train references before reviewing the model.")
        if self.view_mode.currentIndex() >= 4:
            if self.inspection is None:
                raise ValueError("Inspect an image before reviewing its result maps.")
            result, source = self.inspection
            mode = self.view_mode.currentIndex()
            image = (draw_assessment(source, self.model, result) if mode == 7 else
                     draw_overlay(source, result) if mode == 4 else backdrop(result.deviation_map))
            self.viewer.set_image(pixmap(image))
            return
        image = (self.model.mean, self.model.deviation, self.model.inspection_mask.astype(np.uint8) * 255,
                 self.model.normalization_mask.astype(np.uint8) * 255)[self.view_mode.currentIndex()]
        self.viewer.set_image(pixmap(backdrop(image)))

    def _preview(self):
        if self.model is None:
            raise ValueError("Train references before previewing.")
        image = self.test_image
        if image is None:
            index = self.filmstrip.currentRow()
            image = self.samples[max(0, index)]
        self._show_inspection(image, self.model.inspect(image))

    def _preview_wired(self):
        if self.model is None:
            raise ValueError("Train references before previewing.")
        if self.model.reference_fixture is None:
            raise ValueError("Teach a reference with Capture image + pose before using the wired pose preview.")
        source, current = self._capture_packets()
        image = gray_image(source, (np.uint8, np.uint16, np.float32))
        result = self.model.inspect(image, reference_to_image=relative_fixture(current, self.model.reference_fixture))
        self._show_inspection(image, result)

    def _show_inspection(self, image, result):
        self.inspection = result, image
        self.review_button.setEnabled(True)
        self.viewer.set_image(pixmap(draw_overlay(image, result)))
        label = (f"{'Pass' if result.passed else 'Fail'} · {result.report['defect_area']} reference pixels"
                 if result.report["evaluated"] else "Not evaluated")
        self.status.setText(label + " · " + ", ".join(result.report["failures"]))

    def _review(self):
        if self.model is None or self.inspection is None:
            raise ValueError("Inspect an image before reviewing its result.")
        from .qt_review import ReferenceReviewDialog

        result, image = self.inspection
        dialog = ReferenceReviewDialog(self, image, self.model, result)
        self._review_window = dialog
        try:
            dialog.exec()
        finally:
            self._review_window = None
            dialog.deleteLater()

    def _restore(self):
        if not self.parameters["recipe_path"]:
            return
        model = load_model(recipe_path(self.context.project_dir, self.parameters["recipe_path"]),
                           sha256=self.parameters["sha256"])
        sources = model.health.get("training_sources", [])
        if not isinstance(sources, list) or len(sources) != len(model.samples):
            sources = [{} for _ in model.samples]
        for index, (image, support) in enumerate(zip(model.samples, model.sample_support, strict=True)):
            source = sources[index] if isinstance(sources[index], dict) else {}
            name = source.get("name", f"Good sample {index + 1}")
            self._append(image, str(name), support=support, source_metadata=source)
        for name, widget in self.fields.items():
            value = getattr(model.settings, name)
            if name == "normalization":
                widget.setCurrentText(value)
            else:
                widget.setText("" if value is None else str(value))
        self.inspection_mask, self.normalization_mask = model.inspection_mask, model.normalization_mask
        self.reference_fixture = model.reference_fixture
        self.model = model
        self._show_health()
        self.status.setText(f"Restored {len(model.samples)} good samples and their trained variation.")
        self._show_model()

    def _stage(self):
        if self.model is None or self.future is not None or self._closing:
            raise ValueError("Train references before staging.")
        if self.context.project_dir is None:
            raise ValueError("Save the project before staging.")
        relative = f"assets/reference_inspect/{uuid.uuid4().hex}.sri"
        target = recipe_path(self.context.project_dir, relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        digest = save_model(target, self.model)
        self.parameters.update(recipe_path=relative, sha256=digest)
        self.accept()
