"""Independent completed-run Results entry using the existing reference/map viewer."""

from opencv_dataflow.canvas import pixmap
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from opencv_dataflow.images import ImageArray
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTabWidget,
    QVBoxLayout,
)

from .qt_review import ReferenceReviewDialog


class CompletedReferenceReviewDialog(QDialog):
    def __init__(self, parent, context, capture):
        super().__init__(parent)
        self.resize(1320, 1000)
        self.setWindowTitle("Completed reference inspection review")
        self.snapshot = None
        self.panel = None
        self._capture = capture
        self._closed = False
        layout = QVBoxLayout(self)
        actions = QHBoxLayout()
        self.capture_button = QPushButton("Capture latest completed run")
        self.capture_button.clicked.connect(self.capture_latest)
        actions.addWidget(self.capture_button)
        close = QPushButton("Close review")
        close.clicked.connect(self.reject)
        actions.addWidget(close)
        layout.addLayout(actions)
        self.identity = QLabel("No completed frame captured")
        self.identity.setWordWrap(True)
        layout.addWidget(self.identity)
        self.status = QLabel()
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.tabs = QTabWidget()
        self.source_view = FilmstripImageView(self)
        self.tabs.addTab(self.source_view, "Exact consumed input")
        layout.addWidget(self.tabs, 1)
        self.finished.connect(lambda *_: setattr(self, "_closed", True))
        unsubscribe = context.subscribe_outputs(self.publication_changed)
        self.finished.connect(unsubscribe)
        self.destroyed.connect(unsubscribe)
        self.capture_latest()

    def publication_changed(self, revision):
        if self.snapshot is not None and not self._closed:
            self.status.setText(
                "Editor publication changed. This frozen review stays unchanged; capture latest explicitly."
            )

    def capture_latest(self):
        if self._closed:
            return
        try:
            snapshot = self._capture()
        except (ValueError, RuntimeError, KeyError) as error:
            suffix = (
                " Previous frozen frame remains displayed."
                if self.snapshot is not None
                else ""
            )
            self.status.setText(str(error) + suffix)
            return
        panel = ReferenceReviewDialog(
            self,
            snapshot.image,
            snapshot.model,
            snapshot.inspection,
            review=snapshot.review(),
            export_handler=snapshot.export,
        )
        panel.setWindowFlags(Qt.WindowType.Widget)
        if self.panel is not None:
            self.tabs.removeTab(self.tabs.indexOf(self.panel))
            self.panel.deleteLater()
        self.panel = panel
        self.snapshot = snapshot
        self.tabs.insertTab(0, panel, "Completed reference / maps / coverage")
        self.tabs.setCurrentIndex(0)
        self.source_view.set_image(
            pixmap(ImageArray(snapshot.source_pixels, snapshot.source_format))
        )
        summary, p = panel.review.summary(), snapshot.provenance
        self.identity.setText(
            f"{p['block_id']} · completion {p['execution_count']} · {summary['state'].replace('_', ' ').upper()} · "
            f"recipe {snapshot.record.recipe_sha256[:16]} · input {snapshot.source_sha256[:16]} · "
            f"{snapshot.source_pixels.shape[1]}×{snapshot.source_pixels.shape[0]} {snapshot.source_format}"
        )
        self.status.setText(
            "Frozen completed input, trained model and residual/coverage maps. No new inspection, exposure fit or recipe reload. "
            "Reference/input/display grids stay separate; unavailable measurements are not zero. Training is unchanged."
        )
