"""A reusable reference inspection block for OpenCVDataflowGUI."""

import re
import uuid
from pathlib import Path, PurePosixPath

import numpy as np
from opencv_dataflow.core import Block, Port, Result
from opencv_dataflow.payloads import NO_VALUE, frame
from opencv_dataflow.poses import pose_for_image
from opencv_dataflow.processing import gray_image
from opencv_dataflow.selection import SELECTION_INPUTS, selection_mask
from opencv_dataflow.tickets import ticket_key

from .graphics import draw_overlay
from .completed_review import BINDING, CompletedReferenceRecord, capture_completed
from .model import _affine
from .persistence import load_model
from .result_review import draw_assessment


def recipe_path(project_dir, relative):
    if project_dir is None:
        raise ValueError("Save the project before choosing a reference recipe.")
    if not isinstance(relative, str) or not relative:
        raise ValueError("Choose a project-relative .sri recipe.")
    portable = PurePosixPath(relative)
    if portable.is_absolute() or "\\" in relative or ":" in relative or ".." in portable.parts or portable.suffix != ".sri":
        raise ValueError("Recipe must be a project-relative .sri path using forward slashes.")
    root = Path(project_dir).resolve()
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise ValueError("Recipe resolves outside the project directory.")
    return path


def relative_fixture(current, reference):
    """Map the taught reference pixels into the current image pixels."""
    return _affine(current) @ np.linalg.inv(np.vstack((_affine(reference), [0., 0., 1.])))


def reference_to_image(pose, image, reference_fixture=None):
    if pose is None:
        if reference_fixture is not None:
            raise ValueError("The trained reference fixture requires a current image pose.")
        return None
    if not isinstance(pose, dict):
        raise ValueError("Expected a reference-to-image affine pose.")
    if pose.get("model") == "image_pose_v1":
        matrix = pose_for_image(pose, image)["source_to_target"]
    elif pose.get("model") == "image_affine_v1" and reference_fixture is None:
        matrix = pose.get("source_to_target")
    else:
        raise ValueError("A captured fixture requires image_pose_v1. Direct alignment also accepts image_affine_v1.")
    matrix = np.asarray(matrix, np.float64)
    if matrix.shape == (3, 3) and np.allclose(matrix[2], [0, 0, 1], rtol=0, atol=1e-10):
        matrix = matrix[:2]
    matrix = _affine(matrix)
    return matrix if reference_fixture is None else relative_fixture(matrix, reference_fixture)


def fixture_for_capture(image_packet, pose_packet):
    """Validate a paired cached image and pose before changing a training draft."""
    pose = pose_packet.value
    if not isinstance(pose, dict) or pose.get("model") != "image_pose_v1":
        raise ValueError("Capture requires a valid image_pose_v1 on the pose input.")
    current = reference_to_image(pose, image_packet.value)
    image_payload, pose_payload = image_packet.payload, pose.get("target_payload", {})
    if not all(payload.get("spatial", {}).get("root_id") for payload in (image_payload, pose_payload)):
        raise ValueError("Image and pose capture requires a shared coordinate root.")
    image_ticket, pose_ticket = image_payload.get("ticket"), pose_payload.get("ticket")
    if image_ticket is None or pose_ticket is None:
        raise ValueError("Capture needs acquisition tickets on both the image and pose.")
    identity = (*ticket_key(image_ticket), image_ticket["sequence"])
    for ticket in (pose_ticket, pose_packet.payload.get("ticket", pose_ticket)):
        if (*ticket_key(ticket), ticket["sequence"]) != identity:
            raise ValueError("Image and pose belong to different acquisitions. Run the graph again.")
    return current


class SimpleReferenceInspect(Block):
    type_id, title = "inspect.simple_reference", "SimpleReferenceInspect"
    category, block_type, subtype = "Inspection", "Inspection", "Reference inspection"
    process_inputs_readonly = True
    parallel_safe = True
    composes_result_image = True
    plugin_dialog_label = "Train reference inspection…"
    plugin_dialog_modeless = True
    plugin_review_dialog_label = "Review completed reference inspection…"
    inputs = (*SELECTION_INPUTS, Port("pose", "data", required=False, required_when_connected=True))
    outputs = (
        Port("inspection", "data"), Port("defect_mask"), Port("inspected_mask"),
        Port("deviation_map"), Port("residual"), Port("defect_area", "number"),
        Port("overlay", required=False),
        Port("assessment", required=False),
    )
    defaults = {"recipe_path": "", "sha256": "", "render_overlay": True, "render_assessment": False}
    _verified = None
    _completed_review = None
    _review_model_cache = None

    def copy_runtime_from(self, other):
        super().copy_runtime_from(other)
        self._completed_review = other._completed_review

    def reset_runtime(self):
        super().reset_runtime()
        self._completed_review = None
        self._review_model_cache = None

    def close(self):
        self._completed_review = None
        self._review_model_cache = None
        self._verified = None
        super().close()

    def capture_completed_review(self, context):
        snapshot = getattr(context, "snapshot_processed_execution", None)
        if snapshot is None:
            raise ValueError("Completed review needs the host's paired execution-snapshot API")
        bundle = snapshot(output_ports=("inspection", "residual", "deviation_map", "inspected_mask", "defect_mask"))
        cache = self._review_model_cache
        frozen_model = cache[1] if cache is not None and self._completed_review is not None and cache[0] is self._completed_review.model else None
        capture = capture_completed(self._completed_review, bundle, frozen_model=frozen_model)
        self._review_model_cache = capture.record.model, capture.model
        return capture

    def create_plugin_review_dialog(self, parent, context):
        from .qt_completed_review import CompletedReferenceReviewDialog

        return CompletedReferenceReviewDialog(parent, context, lambda: self.capture_completed_review(context))
    parameter_help = {
        "recipe_path": "Project-relative .sri recipe staged by the trainer.",
        "sha256": "SHA-256 of the complete trained recipe.",
        "render_overlay": "Show defect contours and inspected coverage in the result filmstrip.",
        "render_assessment": "Show reference/current/residual/deviation/coverage with gates in a separate result image.",
    }
    input_help = {
        "pose": "Reference-to-image map, or current fixture pose when the recipe stores a captured reference fixture.",
    }
    output_help = {
        "deviation_map": "Absolute normalized residual divided by the learned tolerance. Above 1 exceeds tolerance.",
        "defect_area": "Accepted defect area measured in reference pixels.",
        "assessment": "Optional comparison page in its own display grid, not source-image coordinates.",
    }

    @property
    def filmstrip_output(self):
        if self.parameters.get("render_assessment", False):
            return "assessment"
        return "overlay" if self.parameters["render_overlay"] else None

    def validate_parameters(self, parameters=None):
        super().validate_parameters(parameters)
        p = self.parameters if parameters is None else parameters
        recipe_path(self.project_dir, p["recipe_path"])
        if not isinstance(p["sha256"], str) or re.fullmatch("[0-9a-f]{64}", p["sha256"]) is None:
            raise ValueError("Stage a recipe with a valid SHA-256.")
        if any(type(p.get(name, False)) is not bool for name in ("render_overlay", "render_assessment")):
            raise ValueError("Rendering options must be boolean.")

    def process(self, inputs):
        self._completed_review = None
        if not (self.run_profile.input_previews and self.run_profile.output_previews):
            self._review_model_cache = None
        p = self.parameters
        model = load_model(recipe_path(self.project_dir, p["recipe_path"]), sha256=p["sha256"], cached=self._verified)
        if self._review_model_cache is not None and self._review_model_cache[0] is not model:
            self._review_model_cache = None
        self._verified = p["sha256"], model
        source = inputs["image"]
        image = gray_image(source, (np.uint8, np.uint16, np.float32))
        matrix = reference_to_image(inputs.get("pose"), source, model.reference_fixture)
        result = model.inspect(image, reference_to_image=matrix, mask=selection_mask(inputs, source))
        maps = result.source_maps()
        overlay = draw_overlay(image, result, maps=maps) if p["render_overlay"] else NO_VALUE
        assessment = (draw_assessment(image, model, result, maps=maps)
                      if p.get("render_assessment", False) else NO_VALUE)
        contexts = {}
        if assessment is not NO_VALUE:
            contexts["assessment"] = {"spatial": frame(list(assessment.shape[1::-1]), f"{self.id}:assessment")}
        if self.run_profile.input_previews and self.run_profile.output_previews:
            record = CompletedReferenceRecord.create(uuid.uuid4().hex, p["sha256"], model, result)
            self._completed_review = record
            contexts["inspection"] = {BINDING: {"id": record.identifier, "recipe_sha256": record.recipe_sha256}}
        return Result(
            {"inspection": result.report, **maps, "defect_area": result.report["defect_area"],
             "overlay": overlay, "assessment": assessment},
            payloads=contexts,
            passed=result.passed, fail_reasons=result.report["failures"],
            event_data={"filmstrip_priority": -1} if self.filmstrip_output else {},
            message=(f"{result.report['defect_area']} reference pixels in {len(result.report['defects'])} regions"
                     if result.report["evaluated"] else
                     "Not evaluated · " + ", ".join(result.report["failures"])),
        )

    def create_plugin_dialog(self, parent, parameters, context):
        from .qt_training import ReferenceTrainingDialog

        return ReferenceTrainingDialog(parent, parameters, context)


def register(registry):
    registry.register(SimpleReferenceInspect)
