"""Read-only assessment of an existing inspection, without inspecting again."""

import hashlib
import json
from pathlib import Path

import cv2
import numpy as np

from .graphics import draw_overlay
from .model import _aligned, _image

VIEWS = (
    "Reference mean",
    "Normalized current",
    "Signed residual",
    "Deviation / tolerance",
    "Inspected coverage",
    "Input overlay",
)


def _hash(array):
    return hashlib.sha256(np.asarray(array).tobytes()).hexdigest()


def _write_png(path, pixels):
    ok, encoded = cv2.imencode(".png", pixels)
    if not ok:
        raise ValueError("Could not encode a reference inspection review.")
    path.write_bytes(encoded.tobytes())


def _text(image, value, x, y, *, scale=0.48, width=1450):
    value = str(value).encode("ascii", "replace").decode()[:240]
    while (
        value
        and cv2.getTextSize(value, cv2.FONT_HERSHEY_SIMPLEX, scale, 1)[0][0] > width
    ):
        value = value[:-4] + "..." if len(value) > 4 else ""
    cv2.putText(
        image,
        value,
        (x, y),
        cv2.FONT_HERSHEY_SIMPLEX,
        scale,
        (232, 235, 240),
        1,
        cv2.LINE_AA,
    )


class ResultReview:
    """The caller supplies the exact inspected input and its pinned trained model."""

    def __init__(self, image, model, inspection, *, maps=None):
        self.image = _image(image)
        if tuple(image.shape) != tuple(inspection.source_shape):
            raise ValueError("Review input dimensions differ from the inspected input.")
        if inspection.residual.shape != model.mean.shape:
            raise ValueError("Review model and result have different reference grids.")
        if inspection.report["settings"] != vars(model.settings):
            raise ValueError("Review needs the settings used for this inspection.")
        self.model, self.inspection = model, inspection
        self._maps = maps
        self.intensity_range = (float(model.mean.min()), float(model.mean.max()))
        self.residual_limit = 2 * float(model.tolerance[model.inspection_mask].max())
        self._current = None

    def summary(self):
        result, model = self.inspection, self.model
        report, settings = result.report, model.settings
        evaluated = report["evaluated"]
        rows = []

        def metric(name, value, units, low=None, high=None):
            state = "unavailable" if value is None else "diagnostic"
            if value is not None and (low is not None or high is not None):
                state = (
                    "outside limits"
                    if (
                        low is not None
                        and value < low
                        or high is not None
                        and value > high
                    )
                    else "within limits"
                )
            rows.append(
                dict(
                    name=name,
                    value=value,
                    units=units,
                    minimum=low,
                    maximum=high,
                    status=state,
                )
            )

        metric(
            "Geometric support", report["coverage"], "fraction", settings.min_coverage
        )
        metric(
            "Exposure gain",
            report["exposure"]["gain"],
            "ratio",
            settings.min_gain,
            settings.max_gain,
        )
        metric(
            "Reference correlation",
            report["exposure"]["correlation"],
            "correlation",
            settings.min_correlation,
        )
        metric(
            "Accepted change area",
            report["defect_area"] if evaluated else None,
            "reference pixels",
            high=settings.max_total_defect_area,
        )
        # A pixel ratio above one need not fail: connected-component area filtering
        # and the accepted-area gate determine the verdict.
        metric("Maximum deviation", report["max_deviation"], "tolerance ratio")
        return {
            "model": "simple_reference_inspect_review_v1",
            "state": ("pass" if report["passed"] else "fail")
            if evaluated
            else "not_evaluated",
            "inspection": report,
            "metrics": rows,
            "expected_inspection_pixels": int(model.inspection_mask.sum()),
            "inspected_reference_pixels": int(np.count_nonzero(result.inspected_mask)),
            "reference_size": list(model.mean.shape[::-1]),
            "input_size": list(self.image.shape[::-1]),
            "input_dtype": str(self.image.dtype),
            "input_pixels_sha256": _hash(self.image),
            "reference_mean_sha256": _hash(model.mean),
            "reference_tolerance_sha256": _hash(model.tolerance),
            "inspection_region_sha256": _hash(model.inspection_mask),
            "normalization_region_sha256": _hash(model.normalization_mask),
            "reference_to_image": result.reference_to_image.tolist(),
            "display": {
                "intensity_range": list(self.intensity_range),
                "signed_residual_range": [-self.residual_limit, self.residual_limit],
                "deviation_range": [0.0, 2.0],
                "tolerance_boundary": 1.0,
            },
            "training_health": model.health,
        }

    def _gray(self, value):
        low, high = self.intensity_range
        gray = np.rint(
            np.clip((value - low) / max(high - low, 1e-6), 0, 1) * 255
        ).astype(np.uint8)
        return cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)

    def normalized_current(self):
        exposure = self.inspection.report["exposure"]
        if exposure["gain"] is None or exposure["offset"] is None:
            return None
        if self._current is None:
            aligned, valid = _aligned(
                self.image,
                self.model.mean.shape,
                self.inspection.reference_to_image,
            )
            self._current = aligned * exposure["gain"] + exposure["offset"], valid
        return self._current

    def view(self, name):
        result, model = self.inspection, self.model
        observed = result.inspected_mask != 0
        if name == "Input overlay":
            return draw_overlay(self.image, result, maps=self._maps)
        if name == "Reference mean":
            return self._gray(model.mean)
        if name == "Normalized current":
            current = self.normalized_current()
            if current is None:
                return np.full((*model.mean.shape, 3), 55, np.uint8)
            output = self._gray(current[0])
            output[~current[1]] = (55, 55, 55)
            return output
        if name == "Signed residual":
            ratio = np.clip(result.residual / self.residual_limit, -1, 1)
            color = np.where(
                (ratio < 0)[..., None],
                np.array([245, 120, 45]),
                np.array([45, 80, 245]),
            )
            output = np.rint(
                235 * (1 - np.abs(ratio[..., None])) + color * np.abs(ratio[..., None])
            ).astype(np.uint8)
        elif name == "Deviation / tolerance":
            gray = np.rint(np.clip(result.deviation_map / 2, 0, 1) * 255).astype(
                np.uint8
            )
            output = cv2.applyColorMap(gray, cv2.COLORMAP_TURBO)
        elif name == "Inspected coverage":
            output = np.full((*model.mean.shape, 3), 45, np.uint8)
            output[model.inspection_mask] = (35, 180, 245)
            output[observed] = (75, 175, 75)
            output[result.defect_mask != 0] = (60, 65, 245)
            return output
        else:
            raise ValueError("Unknown reference inspection review view.")
        output[~observed] = (55, 55, 55)
        return output

    def assessment(self):
        summary = self.summary()
        result = self.inspection
        output = np.full((1050, 1500, 3), (30, 25, 20), np.uint8)
        title = summary["state"].replace("_", " ").upper()
        _text(output, f"Reference inspection | {title}", 15, 30, scale=0.72)
        _text(
            output,
            ", ".join(result.report["failures"]) or "No failed inspection gates.",
            15,
            57,
        )
        _text(
            output,
            "Reference/current share the reference grid and intensity scale. "
            "Input overlay retains its own image grid.",
            15,
            82,
        )
        for index, name in enumerate(VIEWS):
            x, y = 10 + index % 3 * 500, 120 + index // 3 * 340
            _text(output, name, x, y - 10, scale=0.58, width=480)
            pixels = self.view(name)
            height, width = pixels.shape[:2]
            scale = min(480 / width, 285 / height)
            size = max(1, round(width * scale)), max(1, round(height * scale))
            resized = cv2.resize(pixels, size, interpolation=cv2.INTER_NEAREST)
            left, top = x + (480 - size[0]) // 2, y + (285 - size[1]) // 2
            output[top : top + size[1], left : left + size[0]] = resized
        _text(
            output,
            f"Residual: blue darker / white zero / red brighter; "
            f"display +/-{self.residual_limit:.3g} native intensity.",
            15,
            790,
        )
        _text(
            output,
            "Deviation: tolerance ratio, not probability. "
            "0 blue / 1 yellow-green / 2+ red; gray = not inspected.",
            15,
            815,
        )
        _text(
            output,
            "Coverage: green inspected / red accepted change / "
            "amber expected but not inspected / dark excluded.",
            15,
            840,
        )
        _text(
            output,
            f"Inspected {summary['inspected_reference_pixels']} / "
            f"{summary['expected_inspection_pixels']} expected reference pixels. "
            "Geometric support and runtime selection are separate.",
            15,
            865,
        )
        for index, row in enumerate(summary["metrics"]):
            value = (
                "not evaluated"
                if row["value"] is None
                else f"{row['value']:.5g} {row['units']}"
            )
            low = "unset" if row["minimum"] is None else f"{row['minimum']:.4g}"
            high = "unset" if row["maximum"] is None else f"{row['maximum']:.4g}"
            _text(
                output,
                f"{row['name']}: {value} | limits [{low}, {high}] | {row['status']}",
                15,
                895 + index * 26,
            )
        _text(
            output,
            f"Accepted regions require >= {self.model.settings.min_defect_area} reference pixels. "
            f"Training samples: {len(self.model.samples)}. "
            + " ".join(self.model.health.get("warnings", [])),
            15,
            1032,
        )
        return output

    def save(self, directory):
        """Export reference-grid maps and source-grid overlay into a new folder."""
        target = Path(directory)
        summary = self.summary()
        summary["arrays"] = {
            name: {
                "grid": "reference",
                "dtype": str(getattr(self.inspection, name).dtype),
                "sha256": _hash(getattr(self.inspection, name)),
            }
            for name in ("residual", "deviation_map", "inspected_mask", "defect_mask")
        }
        summary["images"] = {
            f"{index}_{name.lower().replace(' / ', '_').replace(' ', '_')}.png": {
                "view": name,
                "grid": "input" if name == "Input overlay" else "reference",
            }
            for index, name in enumerate(VIEWS)
        }
        document = (json.dumps(summary, indent=2, allow_nan=False) + "\n").encode()
        target.mkdir(parents=True, exist_ok=False)
        for filename, description in summary["images"].items():
            _write_png(target / filename, self.view(description["view"]))
        _write_png(target / "assessment.png", self.assessment())
        for name in summary["arrays"]:
            np.save(
                target / f"{name}.npy",
                getattr(self.inspection, name),
                allow_pickle=False,
            )
        (target / "review.json").write_bytes(document)
        return target


def draw_assessment(image, model, inspection, *, maps=None):
    return ResultReview(image, model, inspection, maps=maps).assessment()
