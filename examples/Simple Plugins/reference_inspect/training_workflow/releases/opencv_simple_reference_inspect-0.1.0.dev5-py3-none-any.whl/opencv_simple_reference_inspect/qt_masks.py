"""Transactional binary mask editing using the host's region geometry."""

import copy

import cv2
import numpy as np
from opencv_dataflow.region_editor import RegionCanvas
from opencv_dataflow.selection import rasterize
from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QColor, QImage, QPainter, QShortcut
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
)

from .graphics import backdrop
from .model import _image, _mask


class MaskCanvas(RegionCanvas):
    def __init__(self, image, parent=None):
        height, width = image.shape
        parameters = {
            "shape": "rectangle", "invert": False, "rectangle": [0, 0, width, height],
            "center": [width // 2, height // 2], "radius": max(1, min(width, height) // 4),
            "vertices": [[0, 0], [width - 1, 0], [width - 1, height - 1], [0, height - 1]],
        }
        super().__init__(image, parameters, parent)
        self.active = False
        self._zoom = 1.
        self._pan = QPointF()
        self._panning = None
        self._rgb = cv2.cvtColor(backdrop(image), cv2.COLOR_BGR2RGB)
        self.setToolTip("Scroll to zoom · Middle-drag or Alt-drag to pan · Shift-click polygon edges to insert points")

    def set_mask(self, mask):
        shown = self._rgb.copy()
        shown[~mask] //= 3
        contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(shown, contours, -1, (60, 220, 120), 1)
        self.image = QImage(shown.data, shown.shape[1], shown.shape[0], shown.strides[0],
                            QImage.Format.Format_RGB888).copy()
        self.update()

    def image_rect(self):
        rect = super().image_rect()
        center = rect.center() + self._pan
        rect.setSize(rect.size() * self._zoom)
        rect.moveCenter(center)
        return rect

    def fit(self):
        self._zoom, self._pan = 1., QPointF()
        self.update()

    def wheelEvent(self, event):
        if not event.angleDelta().y():
            return
        rect, point = self.image_rect(), event.position()
        fraction = (point - rect.topLeft()) / rect.width()
        self._zoom = float(np.clip(self._zoom * 1.25 ** (event.angleDelta().y() / 120), .1, 32))
        enlarged = self.image_rect()
        self._pan += point - (enlarged.topLeft() + fraction * enlarged.width())
        self.update()
        event.accept()

    def new_shape(self):
        super().new_shape()
        self.active = True
        self.changed.emit()

    def discard_shape(self):
        self.cancel_gesture()
        self.active = False
        self.changed.emit()
        self.update()

    def _polygon_edit(self, event):
        if not self.active or self.drawing or self.parameters["shape"] != "polygon":
            return False
        point = self.to_image(event.position())
        if point is None:
            return False
        vertices = self.parameters["vertices"]
        if event.button() == Qt.MouseButton.RightButton:
            nearest = min(range(len(vertices)), key=lambda i: (self.to_widget(vertices[i]) - event.position()).manhattanLength())
            if len(vertices) > 3 and (self.to_widget(vertices[nearest]) - event.position()).manhattanLength() <= 12:
                vertices.pop(nearest)
                self.changed.emit()
                self.update()
            return True
        if event.button() == Qt.MouseButton.LeftButton and event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
            if len(vertices) >= 10000:
                return True
            points = np.asarray(vertices, float)
            segments = np.roll(points, -1, axis=0) - points
            fraction = np.sum((point - points) * segments, axis=1) / np.maximum(np.sum(segments**2, axis=1), 1e-12)
            nearest = points + np.clip(fraction, 0, 1)[:, None] * segments
            distances = np.linalg.norm(nearest - point, axis=1)
            index = int(distances.argmin())
            if distances[index] * self.image_rect().width() / self.image_shape[1] <= 10:
                self._backup = copy.deepcopy(self.parameters)
                vertices.insert(index + 1, point)
                self.drag, self._start = index + 1, point
                self.changed.emit()
                self.update()
            return True
        return False

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.MiddleButton or (
            event.button() == Qt.MouseButton.LeftButton and event.modifiers() & Qt.KeyboardModifier.AltModifier
        ):
            self._panning = event.position()
        elif self.active and not self._polygon_edit(event):
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._panning is not None:
            self._pan += event.position() - self._panning
            self._panning = event.position()
            self.update()
        elif self.active:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if self._panning is not None:
            self._panning = None
        elif self.active:
            super().mouseReleaseEvent(event)

    def paintEvent(self, event):
        if self.active:
            super().paintEvent(event)
        else:
            painter = QPainter(self)
            painter.fillRect(self.rect(), QColor("#111b29"))
            painter.drawImage(self.image_rect(), self.image)


class MaskEditor(QDialog):
    def __init__(self, image, mask, parent=None, *, title="Edit mask"):
        super().__init__(parent)
        image = _image(image)
        self._mask = _mask(mask, image.shape)
        self._history = []
        self._history_limit = max(1, min(16, 64 * 1024 * 1024 // self._mask.nbytes))
        self.setWindowTitle(title)
        self.resize(980, 730)
        layout = QVBoxLayout(self)
        tools = QHBoxLayout()
        self.shape = QComboBox()
        self.shape.addItems(["rectangle", "circle", "polygon"])
        tools.addWidget(self.shape)
        self.operation = QComboBox()
        self.operation.addItems(["Replace mask", "Add to mask", "Exclude from mask"])
        tools.addWidget(self.operation)
        self.draw_button = QPushButton("Draw shape")
        self.apply_button = QPushButton("Apply shape")
        self.cancel_button = QPushButton("Discard shape")
        for button in (self.draw_button, self.apply_button, self.cancel_button):
            tools.addWidget(button)
        layout.addLayout(tools)
        hint = QLabel(
            "Drag rectangles and circles. Click polygon points, then Enter to finish. "
            "Drag handles to resize or the shape to move. Shift-click an edge to insert a polygon point, "
            "right-click a point to remove it. Scroll to zoom, middle-drag or Alt-drag to pan."
        )
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.canvas = MaskCanvas(image, self)
        self.canvas.set_mask(self._mask)
        layout.addWidget(self.canvas, 1)
        actions = QHBoxLayout()
        self.undo_button = QPushButton("Undo")
        self.clear_button = QPushButton("Clear mask")
        self.whole_button = QPushButton("Use whole image")
        self.fit_button = QPushButton("Fit")
        for button in (self.undo_button, self.clear_button, self.whole_button, self.fit_button):
            actions.addWidget(button)
        layout.addLayout(actions)
        self.status = QLabel()
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.ok = buttons.button(QDialogButtonBox.StandardButton.Ok)
        self.ok.setText("Use mask")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.draw_button.clicked.connect(self.draw_shape)
        self.shape.currentTextChanged.connect(lambda _: self.draw_shape())
        self.apply_button.clicked.connect(self.apply_shape)
        self.cancel_button.clicked.connect(self.canvas.discard_shape)
        self.undo_button.clicked.connect(self.undo)
        self.clear_button.clicked.connect(lambda: self._commit(np.zeros_like(self._mask)))
        self.whole_button.clicked.connect(lambda: self._commit(np.ones_like(self._mask)))
        self.fit_button.clicked.connect(self.canvas.fit)
        self.canvas.changed.connect(self.refresh)
        self.undo_shortcut = QShortcut("Ctrl+Z", self)
        self.undo_shortcut.activated.connect(self.undo)
        self.refresh()

    @property
    def mask(self):
        return self._mask.copy()

    def draw_shape(self):
        self.canvas.discard_shape()
        self.canvas.parameters["shape"] = self.shape.currentText()
        self.canvas.new_shape()

    def apply_shape(self):
        if not self.canvas.active or self.canvas.drawing or self.canvas.drag is not None:
            return
        try:
            selected = rasterize(self.canvas.region(), self._mask.shape) != 0
        except ValueError as error:
            self.status.setText(str(error))
            return
        mode = self.operation.currentIndex()
        if mode == 0:
            updated = selected
        elif mode == 1:
            updated = self._mask | selected
        else:
            updated = self._mask & ~selected
        self._commit(updated)

    def _commit(self, updated):
        self.canvas.discard_shape()
        if not np.array_equal(updated, self._mask):
            self._history.append(self._mask)
            self._history = self._history[-self._history_limit:]
            self._mask = updated.copy()
            self.canvas.set_mask(self._mask)
        self.refresh()

    def undo(self):
        if self.canvas.active:
            self.canvas.discard_shape()
        elif self._history:
            self._mask = self._history.pop()
            self.canvas.set_mask(self._mask)
        self.refresh()

    def refresh(self):
        count = int(np.count_nonzero(self._mask))
        pending = self.canvas.active
        complete = pending and not self.canvas.drawing and self.canvas.drag is None
        self.apply_button.setEnabled(complete)
        self.cancel_button.setEnabled(pending)
        self.undo_button.setEnabled(pending or bool(self._history))
        self.ok.setEnabled(count >= 16 and not pending)
        self.status.setText(
            f"{count} pixels selected · "
            + ("Finish and apply the draft shape, or discard it." if pending else "At least 16 selected pixels are required.")
        )

    def accept(self):
        self.refresh()
        if self.ok.isEnabled():
            super().accept()
