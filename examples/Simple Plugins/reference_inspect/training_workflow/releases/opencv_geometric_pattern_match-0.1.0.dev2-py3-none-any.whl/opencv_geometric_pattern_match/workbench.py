"""Interactive image-pattern training and inspection with Tk."""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from queue import Empty, Queue
from threading import Thread
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import cv2
import numpy as np

from .image_input import input_scale, read_gray, read_mask
from .locator import RejectedCandidate, Search, _crop, draw_matches, draw_rejections, draw_training
from .persistence import InspectionRecipe, load_pattern, load_recipe, save_pattern, save_recipe
from .training_draft import ImageSnapshot, InspectionPreview, TrainingDraft, draw_training_mask, draw_training_selection
from .workbench_mask import MaskEditor
from .workbench_view import ImageView

_IMAGES = (("Images", "*.png *.bmp *.jpg *.jpeg *.tif *.tiff"), ("All files", "*"))
_MODELS = (("Trained patterns", "*.npz"),)
_RECIPES = (("Inspection recipes", "*.npz"),)
_REASONS = {
    "coarse_cutoff": "Below coarse cutoff",
    "insufficient_edges": "Too few matching edges",
    "underconstrained_pose": "Pose underconstrained",
    "score_cutoff": "Below final score cutoff",
    "contrast_cutoff": "Below contrast cutoff",
    "clutter_penalty": "Below cutoff after clutter penalty",
    "overlap": "Overlaps a selected match",
    "result_limit": "Result limit reached",
}


class Workbench:
    def __init__(self, root: tk.Tk):
        self.root = root
        root.title("OpenCV Geometric Pattern Match")
        root.geometry("1200x780")
        root.minsize(900, 680)
        self.reference_snapshot = self.scene_snapshot = None
        self.reference_path = self.scene_path = self.mask_path = None
        self.training_mask = None
        self.pattern = self.preview_pattern = None
        self.search_defaults = Search()
        self.matches = []
        self.rejected = []
        self.rejection_filters = {}
        self.visible_results = []
        self.pending_run = None
        self.drag = None
        self.fields = {}
        self.status = tk.StringVar(root, "Open a reference image or load a saved pattern.")
        self.model_label = tk.StringVar(root, "No active model")
        self.reference_label = tk.StringVar(root)
        self.scene_label = tk.StringVar(root)
        self.mask_label = tk.StringVar(root, "No training mask")
        self.feature_level = tk.StringVar(root, "Fine")
        self.ignore_polarity = tk.BooleanVar(root)
        self.aspect_fallback = tk.BooleanVar(root)
        self.result_kind = tk.StringVar(root, "Accepted")
        self.result_details = tk.StringVar(root, "Run an inspection to review results.")

        toolbar = ttk.Frame(root, padding=(10, 8))
        toolbar.pack(fill="x")
        self._button(toolbar, "Load pattern…", self.load_model).pack(side="left", padx=(0, 6))
        self._button(toolbar, "Save active pattern…", self.save_model).pack(side="left", padx=(0, 12))
        self._button(toolbar, "Load recipe…", self.load_recipe).pack(side="left", padx=(0, 6))
        self._button(toolbar, "Save recipe…", self.save_recipe).pack(side="left", padx=(0, 12))
        ttk.Label(toolbar, textvariable=self.model_label).pack(side="left")
        ttk.Label(root, textvariable=self.status, padding=(10, 7), wraplength=870).pack(side="bottom", fill="x")
        body = ttk.Frame(root, padding=(10, 0))
        body.pack(fill="both", expand=True)
        self.tabs = ttk.Notebook(body, width=370)
        self.tabs.pack(side="left", fill="y", padx=(0, 8))
        self.view = ImageView(body)
        self.view.pack(side="left", fill="both", expand=True)
        self.train_tab = ttk.Frame(self.tabs, padding=10)
        self.run_tab = ttk.Frame(self.tabs, padding=10)
        self.tabs.add(self.train_tab, text="Train")
        self.tabs.add(self.run_tab, text="Inspect")
        self._train_panel(self.train_tab)
        self._run_panel(self.run_tab)
        self.tabs.bind("<<NotebookTabChanged>>", lambda _: self.render())
        self.view.bind("<ButtonPress-1>", self._start_drag)
        self.view.bind("<B1-Motion>", self._drag_rectangle)
        self.view.bind("<ButtonRelease-1>", self._finish_drag)
        self.view.bind("<Shift-Button-1>", self._place_origin)

    @property
    def reference(self):
        return None if self.reference_snapshot is None else self.reference_snapshot.pixels

    @property
    def scene(self):
        return None if self.scene_snapshot is None else self.scene_snapshot.pixels

    def _button(self, parent, label, action):
        return ttk.Button(parent, text=label, command=lambda: self._action(action))

    def _field(self, parent, row, key, label, default="", *, training=False):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=3)
        value = self.fields[key] = tk.StringVar(self.root, default)
        entry = ttk.Entry(parent, textvariable=value, width=19)
        entry.grid(row=row, column=1, sticky="ew", padx=(7, 0), pady=3)
        if training:
            value.trace_add("write", lambda *_: self._draft_changed())
        return entry

    def _train_panel(self, panel):
        self._button(panel, "Open reference…", self.open_reference).grid(row=0, columnspan=2, sticky="ew")
        ttk.Label(panel, textvariable=self.reference_label, wraplength=315).grid(row=1, columnspan=2, sticky="w", pady=5)
        self._field(panel, 2, "max_side", "Max side when opening", "1024")
        self._field(panel, 3, "train_roi", "ROI   X Y W H", training=True)
        self._field(panel, 4, "origin", "Origin   X Y", training=True)
        ttk.Label(panel, text="Drag a region. Shift-click to place its origin.\nBlank uses the full frame or region center.",
                  wraplength=315).grid(row=5, columnspan=2, sticky="w", pady=(3, 8))
        self._button(panel, "Open training mask…", self.open_mask).grid(row=6, column=0, sticky="ew")
        self._button(panel, "Clear mask", self.clear_mask).grid(row=6, column=1, sticky="ew", padx=(7, 0))
        self._button(panel, "Edit training mask…", self.edit_mask).grid(row=7, columnspan=2, sticky="ew", pady=(4, 0))
        ttk.Label(panel, textvariable=self.mask_label, wraplength=315).grid(row=8, columnspan=2, sticky="w", pady=4)
        self._field(panel, 9, "edge", "Edge threshold", "45", training=True)
        self._field(panel, 10, "coarse", "Coarse factor", "auto", training=True)
        self._field(panel, 11, "sigma", "Fine smoothing", "0.85", training=True)
        ttk.Checkbutton(panel, text="Ignore edge polarity", variable=self.ignore_polarity,
                        command=self._draft_changed).grid(row=12, columnspan=2, sticky="w", pady=6)
        self._button(panel, "Train pattern", self.train_pattern).grid(row=13, column=0, sticky="ew")
        picker = ttk.Combobox(panel, textvariable=self.feature_level, values=("Fine", "Coarse"), state="readonly", width=17)
        picker.grid(row=13, column=1, sticky="ew", padx=(7, 0))
        picker.bind("<<ComboboxSelected>>", lambda _: self.render())

    def _run_panel(self, panel):
        self._button(panel, "Open scene…", self.open_scene).grid(row=0, columnspan=2, sticky="ew")
        ttk.Label(panel, textvariable=self.scene_label, wraplength=315).grid(row=1, columnspan=2, sticky="w", pady=5)
        self._field(panel, 2, "search_roi", "ROI   X Y W H")
        self._field(panel, 3, "angle", "Angle   MIN MAX STEP", "-30 30 5")
        self._field(panel, 4, "scale", "Scale   MIN MAX STEP", "0.85 1.15 0.05")
        self._field(panel, 5, "accept", "Final score cutoff", "0.55")
        self._field(panel, 6, "coarse_accept", "Coarse cutoff (optional)")
        self._field(panel, 7, "count", "Maximum results", "1")
        self._field(panel, 8, "overlap", "Area overlap limit", "0.8")
        self._field(panel, 9, "outside_region", "Outside region allowance", "0")
        self._field(panel, 10, "aspect", "Aspect   MIN MAX", "1 1")
        ttk.Checkbutton(panel, text="Aspect fallback only", variable=self.aspect_fallback).grid(
            row=11, columnspan=2, sticky="w")
        self.run_button = self._button(panel, "Run search", self.run_search)
        self.run_button.grid(row=12, columnspan=2, sticky="ew", pady=7)
        ttk.Label(panel, text="Result view · source-image pixels").grid(row=13, column=0, sticky="w")
        self.result_picker = ttk.Combobox(panel, textvariable=self.result_kind, values=("Accepted",),
                                          state="readonly", width=20)
        self.result_picker.grid(row=13, column=1, sticky="ew", padx=(7, 0))
        self.result_picker.bind("<<ComboboxSelected>>", lambda _: self._fill_results())
        table = ttk.Frame(panel)
        table.grid(row=14, columnspan=2, sticky="ew")
        columns = ("rank", "x", "y", "angle", "score", "coverage")
        self.results = ttk.Treeview(table, columns=columns, show="headings", height=7, selectmode="browse")
        for key, title, width in zip(columns, ("#", "X", "Y", "Deg", "Score", "Coverage"), (30, 54, 54, 52, 54, 67)):
            self.results.heading(key, text=title)
            self.results.column(key, width=width, stretch=False, anchor="e")
        scroll = ttk.Scrollbar(table, orient="vertical", command=self.results.yview)
        self.results.configure(yscrollcommand=scroll.set)
        self.results.pack(side="left")
        scroll.pack(side="right", fill="y")
        self.results.bind("<<TreeviewSelect>>", lambda _: self._show_result())
        ttk.Label(panel, textvariable=self.result_details, wraplength=335).grid(row=15, columnspan=2, sticky="w", pady=4)
        ttk.Button(panel, text="Show all in view", command=self._show_all).grid(row=16, columnspan=2, sticky="ew")
        ttk.Label(panel, text="Cyan pose axes · Green found · Red missing\nAmber projected without a measured fit",
                  wraplength=335).grid(row=17, columnspan=2, sticky="w", pady=(5, 0))

    def _action(self, action):
        if self.pending_run is not None:
            self.status.set("Search is running. Wait for its result before changing images or models.")
            return
        try:
            action()
        except (OSError, ValueError, cv2.error) as error:
            self.status.set(str(error))
            messagebox.showerror("Pattern workbench", str(error), parent=self.root)

    def _value(self, key, convert, *, optional=False):
        raw = self.fields[key].get().strip()
        return None if optional and not raw else convert(raw)

    def _coordinates(self, key, length, convert, *, optional=False):
        values = self._value(key, lambda s: tuple(map(convert, s.split())), optional=optional)
        if values is not None and len(values) != length:
            raise ValueError(f"Enter {length} space-separated values for {key.replace('_', ' ')}.")
        return values

    def _set_fields(self, **values):
        for key, value in values.items():
            self.fields[key].set(value)

    def _draft_changed(self):
        self.preview_pattern = None
        if self.pattern is not None:
            self.status.set("Training settings changed. Train to replace the active model.")
        self.root.after_idle(self.render)

    def _training_visible(self):
        return self.tabs.select() == str(self.train_tab)

    def _start_drag(self, event):
        if self._training_visible():
            point = self.view.pixel_at(event.x, event.y)
            self.drag = (point, event.x, event.y) if point is not None else None

    def _drag_rectangle(self, event):
        if self.drag is not None:
            _, x, y = self.drag
            self.view.delete("selection")
            self.view.create_rectangle(x, y, event.x, event.y, outline="#62b5ff", width=2, tags="selection")

    def _finish_drag(self, event):
        if self.drag is None:
            return
        (x, y), _, _ = self.drag
        self.drag = None
        self.view.delete("selection")
        point = self.view.pixel_at(event.x, event.y, clamp=True)
        if point is None:
            return
        x1, y1 = point
        if abs(x - x1) >= 7 and abs(y - y1) >= 7:
            self.fields["train_roi"].set(f"{min(x, x1)} {min(y, y1)} {abs(x - x1) + 1} {abs(y - y1) + 1}")

    def _place_origin(self, event):
        if self._training_visible():
            self.drag = None
            point = self.view.pixel_at(event.x, event.y)
            if point is not None:
                self.fields["origin"].set(f"{point[0]} {point[1]}")
        return "break"

    def _open_path(self, types):
        value = filedialog.askopenfilename(parent=self.root, filetypes=types)
        return Path(value) if value else None

    def open_reference(self):
        path = self._open_path(_IMAGES)
        if path is None:
            return
        raw = read_gray(path)
        scale = input_scale(raw.shape, self._value("max_side", int, optional=True))
        self.reference_snapshot = ImageSnapshot(raw, scale)
        self.reference_path = path
        working = self.reference
        self.reference_label.set(f"{path.name}\nWorking image {working.shape[1]} × {working.shape[0]}")
        self.mask_path = None
        self.training_mask = None
        self.mask_label.set("No training mask")
        self._set_fields(train_roi="", origin="")
        self.status.set("Select a training region and train the pattern.")
        self.render()

    def open_mask(self):
        if self.reference is None:
            raise ValueError("Open a reference image before selecting its mask.")
        path = self._open_path(_IMAGES)
        if path is not None:
            self.training_mask = read_mask(path, self.reference_snapshot.source_shape, self.reference.shape, training=True)
            self.mask_path = path
            self.mask_label.set(path.name)
            self._draft_changed()

    def clear_mask(self):
        self.mask_path = None
        self.training_mask = None
        self.mask_label.set("No training mask")
        self._draft_changed()

    def edit_mask(self):
        if self.reference is None:
            raise ValueError("Open a reference image before editing its mask.")
        roi = self._coordinates("train_roi", 4, int, optional=True)
        region, (x, y) = _crop(self.reference, roi)
        height, width = region.shape
        window = np.s_[y:y + height, x:x + width]
        initial = (self.training_mask[window] if self.training_mask is not None else
                   np.full(region.shape, 255, dtype=np.uint8))

        def apply(mask):
            if np.array_equal(mask, initial):
                return
            if self.training_mask is None:
                self.training_mask = np.full(self.reference.shape, 255, dtype=np.uint8)
            self.training_mask[window] = mask
            self.mask_label.set("Edited training mask")
            self._draft_changed()

        return MaskEditor(self.root, region, initial, apply)

    def train_pattern(self):
        if self.reference is None:
            raise ValueError("Open a reference image first.")
        roi = self._coordinates("train_roi", 4, int, optional=True)
        origin = self._coordinates("origin", 2, float, optional=True)
        edge = self._value("edge", lambda s: None if s.lower() == "auto" else float(s))
        coarse = self._value("coarse", lambda s: None if s.lower() == "auto" else int(s))
        sigma = self._value("sigma", lambda s: None if s.lower() == "auto" else float(s))
        draft = TrainingDraft(
            self.reference_snapshot, roi=roi, origin=origin, mask=self.training_mask,
            edge_threshold=edge, coarse_factor=coarse, fine_sigma=sigma, ignore_polarity=self.ignore_polarity.get(),
        )
        trained = self.preview_pattern = draft.train()
        self.search_defaults = Search()
        self._activate(self.preview_pattern, f"Trained from {self.reference_path.name}")
        weak = ", ".join(trained.diagnostics.fine.weak_dofs) or "none"
        self.status.set(f"Trained {len(trained.points)} fine and {len(trained.coarse_points)} coarse features. Weak fine axes: {weak}.")

    def _activate(self, pattern, label):
        if self.pattern is None or self.pattern.input_scale != pattern.input_scale:
            self.scene_snapshot = self.scene_path = None
            self.scene_label.set("")
            self._set_fields(search_roi="")
        self.pattern = pattern
        self.model_label.set(label)
        self._publish([])

    def load_model(self):
        path = self._open_path(_MODELS)
        if path is not None:
            pattern = load_pattern(path)
            self.preview_pattern = None
            self.search_defaults = Search()
            self._activate(pattern, f"Loaded {path.name}")
            self.tabs.select(self.run_tab)
            next_step = "Run a search on the current scene." if self.scene is not None else "Open an inspection scene."
            self.status.set(f"Loaded {len(pattern.points)} fine features. {next_step}")

    def save_model(self):
        if self.pattern is None:
            raise ValueError("Train or load a pattern before saving.")
        path = self._save_path(_MODELS)
        if path is not None:
            save_pattern(path, self.pattern)
            self.model_label.set(f"Saved {path.name}")
            self.status.set(f"Saved active model to {path}.")

    def _save_path(self, filetypes):
        name = filedialog.asksaveasfilename(parent=self.root, filetypes=filetypes, defaultextension=".npz")
        if not name:
            return None
        path = Path(name)
        inputs = {p.resolve() for p in (self.reference_path, self.mask_path, self.scene_path) if p is not None}
        if path.resolve() in inputs:
            raise ValueError("The output path is an active input file.")
        return path

    def load_recipe(self):
        path = self._open_path(_RECIPES)
        if path is None:
            return
        recipe = load_recipe(path)
        search = self.search_defaults = recipe.search
        self.preview_pattern = None
        self._activate(recipe.pattern, f"Loaded {path.name}")
        self._set_fields(
            search_roi="" if recipe.search_roi is None else " ".join(map(str, recipe.search_roi)),
            angle=" ".join(map(str, search.angle)), scale=" ".join(map(str, search.scale)),
            accept=str(search.accept), coarse_accept="" if search.coarse_accept is None else str(search.coarse_accept),
            count=str(search.max_results), overlap=str(search.xy_overlap),
            outside_region=str(search.outside_region_threshold), aspect=" ".join(map(str, search.aspect)),
        )
        self.aspect_fallback.set(search.aspect_fallback)
        self.tabs.select(self.run_tab)
        next_step = "Run a search on the current scene." if self.scene is not None else "Open an inspection scene."
        self.status.set(f"Loaded pattern and search settings from {path.name}. {next_step}")

    def save_recipe(self):
        if self.pattern is None:
            raise ValueError("Train or load a pattern before saving a recipe.")
        recipe = self._inspection_recipe()
        path = self._save_path(_RECIPES)
        if path is not None:
            save_recipe(path, recipe)
            self.model_label.set(f"Saved {path.name}")
            self.status.set(f"Saved pattern and search settings to {path}.")

    def open_scene(self):
        if self.pattern is None:
            raise ValueError("Train or load a pattern first.")
        path = self._open_path(_IMAGES)
        if path is not None:
            raw = read_gray(path)
            self.scene_snapshot = ImageSnapshot(raw, self.pattern.input_scale)
            self.scene_path = path
            scene = self.scene
            self.scene_label.set(f"{path.name}\nWorking image {scene.shape[1]} × {scene.shape[0]}")
            self._publish([])
            self.status.set("Scene loaded. Set search options and run the search.")

    def _inspection_recipe(self):
        roi = self._coordinates("search_roi", 4, int, optional=True)
        search = replace(
            self.search_defaults,
            angle=self._coordinates("angle", 3, float), scale=self._coordinates("scale", 3, float),
            accept=self._value("accept", float), coarse_accept=self._value("coarse_accept", float, optional=True),
            max_results=self._value("count", int), xy_overlap=self._value("overlap", float),
            outside_region_threshold=self._value("outside_region", float),
            aspect=self._coordinates("aspect", 2, float), aspect_fallback=self.aspect_fallback.get(),
        )
        return InspectionRecipe(self.pattern, search, roi)

    def run_search(self):
        if self.scene is None or self.pattern is None:
            raise ValueError("Train or load a pattern, then open a scene.")
        preview = InspectionPreview(self._inspection_recipe(), self.scene_snapshot)
        reply = self.pending_run = Queue()
        self._publish([])
        self.status.set("Searching the working image…")
        self.run_button.state(["disabled"])

        def inspect():
            try:
                reply.put((preview.review(), None))
            except Exception as error:
                reply.put((None, error))

        Thread(target=inspect, daemon=True).start()
        self.root.after(50, self._receive)

    def _receive(self):
        try:
            review, error = self.pending_run.get_nowait()
        except Empty:
            self.root.after(50, self._receive)
            return
        self.pending_run = None
        self.run_button.state(["!disabled"])
        if error is None:
            self._publish(review.matches, review.rejected, review.rejection_counts)
            self.status.set(f"{len(review.matches)} accepted matches.")
        else:
            self._publish([])
            self.status.set(str(error))
            messagebox.showerror("Search failed", str(error), parent=self.root)

    def _publish(self, matches, rejected=(), counts=None):
        self.matches = matches
        self.rejected = rejected
        self.rejection_filters = {}
        if counts:
            self.rejection_filters["All rejected"] = None
            self.rejection_filters.update({f"{_REASONS[reason]} ({count})": reason for reason, count in sorted(counts.items())})
        self.result_picker.configure(values=("Accepted", *self.rejection_filters))
        self.result_kind.set("All rejected" if rejected and not matches else "Accepted")
        self._fill_results()

    def _fill_results(self):
        kind = self.result_kind.get()
        if kind == "Accepted":
            self.visible_results = self.matches
        else:
            reason = self.rejection_filters.get(kind)
            self.visible_results = [candidate for candidate in self.rejected if reason is None or candidate.reason == reason]
        self.results.delete(*self.results.get_children())
        if self.visible_results:
            matrix = self.scene_snapshot.working_to_source()
            for index, result in enumerate(self.visible_results):
                pose = result.pose
                x, y = matrix @ [pose.x, pose.y, 1]
                score = f"{result.score:.3f}" if result.score is not None else "—"
                coverage = f"{result.coverage:.3f}" if result.coverage is not None else "—"
                self.results.insert("", "end", iid=str(index), values=(index + 1, f"{x:.1f}", f"{y:.1f}",
                                    f"{pose.angle_deg:.1f}", score, coverage))
        self._show_result()

    def _show_result(self):
        selected = self.results.selection()
        if not selected:
            if self.result_kind.get() == "Accepted":
                self.result_details.set(f"{len(self.visible_results)} accepted. Select a row to isolate its overlay.")
            else:
                self.result_details.set(f"{len(self.visible_results)} shown. Up to 20 candidates per rejection reason.")
        else:
            result = self.visible_results[int(selected[0])]
            reason = _REASONS[result.reason] if isinstance(result, RejectedCandidate) else "Accepted"
            metrics = [reason, f"Scale {result.pose.scale:.3f}"]
            if result.pose.aspect != 1:
                metrics.append(f"Aspect {result.pose.aspect:.3f}")
            if result.edge_matches is not None:
                metrics.append(f"Edges {len(result.edge_matches)}/{len(self.pattern.points)}")
            if result.outside_region_fraction:
                metrics.append(f"Outside {result.outside_region_fraction:.1%}")
            for value, name, unit in ((result.coarse_score, "Coarse", ""),
                                      (result.fit_error_px, "Fit", " px"),
                                      (result.contrast, "Contrast", ""), (result.clutter, "Clutter", "")):
                if value is not None:
                    metrics.append(f"{name} {value:.3f}{unit}")
            self.result_details.set("  ·  ".join(metrics))
        self.render()

    def _show_all(self):
        self.results.selection_remove(*self.results.selection())
        self._show_result()

    def render(self):
        if self._training_visible():
            image = self.reference
            if image is not None and self.preview_pattern is not None:
                image = draw_training(image, self.preview_pattern, coarse=self.feature_level.get() == "Coarse")
            elif image is not None:
                image = self._draw_draft(image)
            if image is not None and self.training_mask is not None:
                image = draw_training_mask(image, self.training_mask)
        else:
            image = self.scene
            if image is not None and self.visible_results:
                selection = self.results.selection()
                results = (self.visible_results[int(selection[0])],) if selection else self.visible_results
                draw = draw_matches if self.result_kind.get() == "Accepted" else draw_rejections
                image = draw(image, self.pattern, results)
        self.view.show(image)

    def _draw_draft(self, image):
        try:
            roi = self._coordinates("train_roi", 4, int, optional=True)
            origin = self._coordinates("origin", 2, float, optional=True)
        except ValueError:
            return cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        return draw_training_selection(image, roi, origin)


def launch():
    root = tk.Tk()
    Workbench(root)
    root.mainloop()
