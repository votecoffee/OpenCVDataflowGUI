"""Locate one trained edge pattern in a grayscale image with OpenCV and NumPy.

The coarse search votes over position at sampled angles and uniform scales.
Fine alignment fits the pose to nearby oriented edges at full resolution.
"""

from __future__ import annotations

import math
from collections import Counter
from collections.abc import Callable, Iterable
from concurrent.futures import CancelledError
from dataclasses import dataclass, field, replace
from numbers import Integral
from typing import TYPE_CHECKING

import cv2
import numpy as np

if TYPE_CHECKING:
    from .runtime import SearchRuntime

_BIN_WIDTH = math.tau / 12
_MIN_AGREEMENT = math.cos(math.radians(35))
_FINAL_FIT_RADIUS = 2
_DOFS = ("x", "y", "angle", "scale")
_EDGE_FOUND = (69, 225, 63)
_EDGE_MISSING = (49, 66, 252)
_EDGE_UNMEASURED = (40, 182, 245)
_POSE_AXIS = (249, 230, 36)

# Model point index followed by the corresponding scene edge's subpixel x and y.
EdgeMatch = tuple[int, float, float]
CancelCheck = Callable[[], bool] | None


def _check_cancelled(cancelled: Callable[[], bool]) -> None:
    if cancelled():
        raise CancelledError("Pattern operation cancelled.")


@dataclass(frozen=True)
class FeatureDiagnostics:
    detected: int
    eligible: int
    retained: int
    weak_dofs: tuple[str, ...]


@dataclass(frozen=True)
class CompositeDiagnostics:
    images: int
    min_occurrence: float
    required_images: int
    tolerance_px: float


@dataclass(frozen=True)
class TrainingDiagnostics:
    auto_edge_threshold: bool
    auto_coarse_factor: bool
    auto_fine_sigma: bool
    coarse: FeatureDiagnostics
    fine: FeatureDiagnostics
    composite: CompositeDiagnostics | None = None


@dataclass(frozen=True)
class Pattern:
    """A trained pattern with edge offsets relative to its internal search anchor."""

    origin: tuple[float, float]
    anchor: tuple[float, float]
    training_roi: tuple[int, int, int, int]
    factor: int
    coarse_points: np.ndarray
    coarse_normals: np.ndarray
    points: np.ndarray
    normals: np.ndarray
    edge_threshold: float
    fine_sigma: float
    ignore_polarity: bool
    mask: np.ndarray | None
    diagnostics: TrainingDiagnostics | None = None
    input_scale: float = 1.0
    coarse_weights: np.ndarray | None = None
    weights: np.ndarray | None = None


@dataclass(frozen=True)
class Pose:
    x: float
    y: float
    angle_deg: float
    scale: float
    aspect: float = 1.0

    def matrix(self) -> np.ndarray:
        """Map pattern coordinates, relative to its training origin, to the scene."""
        transform = cv2.getRotationMatrix2D((0, 0), self.angle_deg, self.scale)
        if self.aspect != 1:
            root = math.sqrt(self.aspect)
            transform[:, :2] *= (root, 1 / root)
        transform[:, 2] = (self.x, self.y)
        return transform

    def _axis_scales(self) -> tuple[float, float]:
        root = math.sqrt(self.aspect)
        return self.scale * root, self.scale / root


@dataclass(frozen=True)
class Match:
    """Coverage is the matched probe fraction. Fit error is inlier normal RMS in pixels."""

    pose: Pose
    score: float
    coverage: float
    fit_error_px: float
    coarse_score: float | None = None
    contrast: float | None = None
    clutter: float | None = None
    edge_matches: tuple[EdgeMatch, ...] | None = field(default=None, repr=False, compare=False)
    outside_region_fraction: float | None = None
    outside_region_indices: tuple[int, ...] = field(default=(), repr=False, compare=False)


@dataclass(frozen=True)
class RejectedCandidate:
    """A candidate stopped by a search gate, with the measurements available at that stage."""

    pose: Pose
    reason: str
    coarse_score: float | None = None
    score: float | None = None
    coverage: float | None = None
    fit_error_px: float | None = None
    contrast: float | None = None
    clutter: float | None = None
    edge_matches: tuple[EdgeMatch, ...] | None = field(default=None, repr=False, compare=False)
    outside_region_fraction: float | None = None
    outside_region_indices: tuple[int, ...] = field(default=(), repr=False, compare=False)


@dataclass(frozen=True)
class SearchReview:
    matches: list[Match]
    rejected: list[RejectedCandidate]
    rejection_counts: dict[str, int]


@dataclass(frozen=True)
class Search:
    angle: tuple[float, float, float] = (-30.0, 30.0, 5.0)
    scale: tuple[float, float, float] = (0.85, 1.15, 0.05)
    accept: float = 0.55
    ignore_polarity: bool | None = None
    start_pose: Pose | None = None
    start_window: float = 8.0
    max_results: int = 1
    xy_overlap: float = 0.8
    angle_overlap_deg: float = 360.0
    scale_overlap: float = 1.4
    coarse_accept: float | None = None
    min_contrast: float = 0.0
    score_using_clutter: bool = False
    outside_region_threshold: float = 0.0
    aspect: tuple[float, float] = (1.0, 1.0)
    aspect_fallback: bool = False


def _crop(image: np.ndarray, roi: tuple[int, int, int, int] | None):
    if image.ndim != 2 or image.dtype != np.uint8 or min(image.shape) < 8:
        raise ValueError("Expected an 8-bit grayscale image at least 8 by 8 pixels.")
    if roi is None:
        return image, (0, 0)
    x, y, width, height = roi
    if min(x, y) < 0 or min(width, height) < 8 or x + width > image.shape[1] or y + height > image.shape[0]:
        raise ValueError("ROI must be inside the image and at least 8 by 8 pixels.")
    return image[y:y + height, x:x + width], (x, y)


def _subsample(image: np.ndarray, factor: int) -> np.ndarray:
    if factor == 1:
        return image
    height, width = image.shape
    padded = cv2.copyMakeBorder(image, 0, -height % factor, 0, -width % factor, cv2.BORDER_REPLICATE)
    return cv2.resize(padded, (padded.shape[1] // factor, padded.shape[0] // factor), interpolation=cv2.INTER_AREA)


def _subsample_care(care: np.ndarray | None, factor: int) -> np.ndarray | None:
    if care is None:
        return None
    return _subsample(care.astype(np.uint8) * 255, factor) == 255


def _bilinear(image: np.ndarray, points: np.ndarray) -> np.ndarray:
    lower = np.floor(points).astype(np.int32)
    x, y = lower.T
    u, v = (points - lower).T
    top = (1 - u) * image[y, x] + u * image[y, x + 1]
    bottom = (1 - u) * image[y + 1, x] + u * image[y + 1, x + 1]
    return (1 - v) * top + v * bottom


def _derivatives(image: np.ndarray, sigma: float):
    smooth = cv2.GaussianBlur(image, (0, 0), sigma)
    return cv2.Sobel(smooth, cv2.CV_16S, 1, 0), cv2.Sobel(smooth, cv2.CV_16S, 0, 1)


def _interior_samples(values: np.ndarray, care: np.ndarray | None) -> np.ndarray:
    values = values[2:-2, 2:-2]
    if care is not None:
        values = values[care[2:-2, 2:-2]]
    if not values.size:
        raise ValueError("The training mask has no care pixels inside the usable image region.")
    return values.ravel()


def _auto_sigma(image: np.ndarray, care: np.ndarray | None) -> float:
    source = image.astype(np.float32)
    residual = _interior_samples(source - cv2.GaussianBlur(source, (0, 0), 0.85), care)
    noise = float(1.4826 * np.median(np.abs(residual - np.median(residual))))
    return float(np.clip(0.85 + 0.15 * (noise - 1.5), 0.85, 2.0))


def _auto_threshold(image: np.ndarray, sigma: float, care: np.ndarray | None) -> float:
    dx, dy = _derivatives(image, sigma)
    magnitude = _interior_samples(np.hypot(dx.astype(np.float32), dy), care)
    median = np.median(magnitude)
    deviation = 1.4826 * np.median(np.abs(magnitude - median))
    nonzero = magnitude[magnitude > 0]
    signal = np.percentile(nonzero, 90) if nonzero.size else 0
    # Leave headroom for a lower-contrast instance while rejecting ordinary background noise.
    return float(max(3.0, median + 4 * deviation, 0.25 * signal))


def _edges(image: np.ndarray, high: float, sigma: float = 0.85):
    dx, dy = _derivatives(image, sigma)
    edge = cv2.Canny(dx, dy, high * 0.4, high, L2gradient=True)
    # Leave room to sample the gradient on both sides of an edge peak.
    y, x = np.nonzero(edge[2:-2, 2:-2])
    x += 2
    y += 2
    pixels = np.column_stack((x, y))
    magnitude = cv2.magnitude(dx.astype(np.float32), dy.astype(np.float32))
    center = magnitude[y, x]
    normals = np.column_stack((dx[y, x], dy[y, x])) / center[:, None]
    before = _bilinear(magnitude, pixels - normals)
    after = _bilinear(magnitude, pixels + normals)
    curvature = before + after - 2 * center
    offset = np.divide(before - after, 2 * curvature, out=np.zeros_like(curvature), where=curvature < -1e-6)
    return pixels, pixels + np.clip(offset, -0.5, 0.5)[:, None] * normals, normals


def _filter_edges(pixels, points, normals, care: np.ndarray | None):
    if care is None:
        return pixels, points, normals
    x, y = pixels.T
    keep = care[y, x]
    return pixels[keep], points[keep], normals[keep]


def _sample_edges(image: np.ndarray, high: float, limit: int, *, sigma: float = 0.85, care: np.ndarray | None = None):
    pixels, points, normals = _edges(image, high, sigma)
    detected = len(points)
    _, points, normals = _filter_edges(pixels, points, normals, care)
    indices = np.linspace(0, len(points) - 1, min(limit, len(points)), dtype=int)
    retained_points, retained_normals = points[indices], normals[indices]
    weak = _weak_dofs(retained_points, retained_normals) if len(indices) >= 12 else _DOFS
    return retained_points, retained_normals, FeatureDiagnostics(detected, len(points), len(indices), weak)


def _weak_dofs(points: np.ndarray, normals: np.ndarray) -> tuple[str, ...]:
    centered = points - np.mean(points, axis=0)
    radius = np.sqrt(np.mean(np.sum(centered**2, axis=1)))
    if radius == 0:
        return _DOFS
    # Normalize the rotation and scale columns by model size before comparing pose constraints.
    jacobian = _fit_system(centered / radius, normals) / np.sqrt(len(points))
    weak = []
    for index, name in enumerate(_DOFS):
        column = jacobian[:, index]
        others = np.delete(jacobian, index, axis=1)
        weights = np.linalg.lstsq(others, column, rcond=1e-5)[0]
        if np.linalg.norm(column - others @ weights) < 0.12:
            weak.append(name)
    return tuple(weak)


def _validate_training_options(edge_threshold, coarse_factor, fine_sigma, origin):
    if edge_threshold is not None and (not math.isfinite(edge_threshold) or edge_threshold <= 0):
        raise ValueError("Edge threshold must be positive and finite.")
    if fine_sigma is not None and not 0.2 <= fine_sigma <= 8:
        raise ValueError("Fine smoothing sigma must be between 0.2 and 8 pixels.")
    if coarse_factor is not None and (not isinstance(coarse_factor, int) or not 1 <= coarse_factor <= 8):
        raise ValueError("Coarse factor must be a whole number from 1 through 8.")
    if origin is not None and (len(origin) != 2 or not all(map(math.isfinite, origin))):
        raise ValueError("Training origin must contain two finite coordinates.")


def _coarse_factors(width: int, height: int, coarse_factor: int | None):
    return (coarse_factor,) if coarse_factor is not None else range(min(4, max(1, min(width, height) // 16)), 0, -1)


def _crop_training_mask(mask, source_shape, offset, size):
    if mask is None:
        return None
    if mask.shape != source_shape or mask.dtype != np.uint8:
        raise ValueError("Training mask must be 8-bit grayscale and match the source image size.")
    if np.any((mask >= 128) & (mask < 192)):
        raise ValueError("Training mask values 128 through 191 are reserved.")
    x, y = offset
    height, width = size
    return mask[y:y + height, x:x + width].copy()


def train(
    image: np.ndarray,
    roi: tuple[int, int, int, int] | None = None,
    *,
    origin: tuple[float, float] | None = None,
    mask: np.ndarray | None = None,
    edge_threshold: float | None = 45.0,
    coarse_factor: int | None = None,
    fine_sigma: float | None = 0.85,
    ignore_polarity: bool = False,
    cancelled: CancelCheck = None,
) -> Pattern:
    """Train an image pattern. A true cancellation check raises CancelledError."""
    if cancelled is not None:
        _check_cancelled(cancelled)
    _validate_training_options(edge_threshold, coarse_factor, fine_sigma, origin)
    source_shape = image.shape
    image, (x, y) = _crop(image, roi)
    height, width = image.shape
    mask = _crop_training_mask(mask, source_shape, (x, y), image.shape)
    care = None if mask is None else mask >= 192
    automatic_threshold = edge_threshold is None
    automatic_sigma = fine_sigma is None
    if automatic_sigma:
        fine_sigma = _auto_sigma(image, care)
    if automatic_threshold:
        edge_threshold = _auto_threshold(image, fine_sigma, care)
    if cancelled is not None:
        _check_cancelled(cancelled)
    center = np.array([(width - 1) / 2, (height - 1) / 2])
    anchor = (float(center[0] + x), float(center[1] + y))
    origin = anchor if origin is None else tuple(map(float, origin))
    points, normals, fine_report = _sample_edges(image, edge_threshold, 480, sigma=fine_sigma, care=care)
    if cancelled is not None:
        _check_cancelled(cancelled)
    if len(points) < 12:
        raise ValueError("Too few fine training edges. Check the region, mask, and edge threshold.")
    selected_level = None
    lost_dofs = len(_DOFS) + 1
    for factor in _coarse_factors(width, height, coarse_factor):
        if cancelled is not None:
            _check_cancelled(cancelled)
        # Test the mask after edge extraction so the mask itself contributes no edges.
        coarse_care = _subsample_care(care, factor)
        coarse_points, coarse_normals, coarse_report = _sample_edges(_subsample(image, factor), edge_threshold, 96, care=coarse_care)
        if len(coarse_points) < 12:
            continue
        lost = len(set(coarse_report.weak_dofs) - set(fine_report.weak_dofs))
        if lost < lost_dofs:
            selected_level = (factor, coarse_points, coarse_normals, coarse_report)
            lost_dofs = lost
        if lost_dofs == 0:
            break
    if cancelled is not None:
        _check_cancelled(cancelled)
    if selected_level is None:
        raise ValueError("Too few coarse training edges. Choose a finer coarse factor or check the mask.")
    factor, coarse_points, coarse_normals, coarse_report = selected_level
    coarse_points = (coarse_points + 0.5) * factor - 0.5 - center
    diagnostics = TrainingDiagnostics(automatic_threshold, coarse_factor is None, automatic_sigma, coarse_report, fine_report)
    return Pattern(origin, anchor, (int(x), int(y), width, height), factor, coarse_points, coarse_normals,
                   points - center, normals, float(edge_threshold), float(fine_sigma), bool(ignore_polarity), mask, diagnostics)


def _grid_size(bounds: tuple[float, float, float]) -> int:
    low, high, step = bounds
    intervals = (high - low) / step
    if not math.isfinite(intervals) or intervals > 2500:
        raise ValueError("Search grid is too large. Increase the step or narrow the range.")
    return math.ceil(intervals - 1e-10) + 1


def _rotation(angle: float) -> np.ndarray:
    c, s = math.cos(angle), math.sin(angle)
    return np.array([[c, s], [-s, c]])


def _bins(normals: np.ndarray, count: int) -> np.ndarray:
    directions = np.arctan2(normals[:, 1], normals[:, 0])
    return np.rint(directions / _BIN_WIDTH).astype(int) % count


def _coarse_maps(image: np.ndarray, pattern: Pattern, unsigned: bool, care: np.ndarray | None):
    reduced = _subsample(image, pattern.factor)
    pixels, _, normals = _filter_edges(*_edges(reduced, pattern.edge_threshold), _subsample_care(care, pattern.factor))
    maps = []
    for angle in np.arange(6 if unsigned else 12) * _BIN_WIDTH:
        dot = normals @ [math.cos(angle), math.sin(angle)]
        if unsigned:
            dot = np.abs(dot)
        x, y = pixels[dot >= _MIN_AGREEMENT].T
        if not len(x):
            maps.append(np.zeros(reduced.shape, dtype=np.float32))
            continue
        mask = np.ones(reduced.shape, dtype=np.uint8)
        mask[y, x] = 0
        distance = cv2.distanceTransform(mask, cv2.DIST_L2, cv2.DIST_MASK_3)
        maps.append(np.exp(-0.5 * (distance / 1.25) ** 2))
    return maps


def _shift_add(target: np.ndarray, source: np.ndarray, x: int, y: int, weight: float = 1.0) -> None:
    # For each anchor (u, v), look up the response at (u + x, v + y).
    height, width = target.shape
    x0, x1 = max(0, -x), min(width, width - x)
    y0, y1 = max(0, -y), min(height, height - y)
    if x1 > x0 and y1 > y0:
        window = source[y0 + y:y1 + y, x0 + x:x1 + x]
        destination = target[y0:y1, x0:x1]
        if weight == 1:
            cv2.add(destination, window, dst=destination)
        else:
            # Keep the higher-precision product through the weighted sum.
            destination += weight * window


def _shortlist(image: np.ndarray, pattern: Pattern, search: Search, angles: np.ndarray, scales: np.ndarray,
               care: np.ndarray | None, rejected: list[RejectedCandidate] | None, cancelled: CancelCheck = None):
    maps = _coarse_maps(image, pattern, search.ignore_polarity, care)
    candidates = []
    response = np.empty_like(maps[0])
    factor = pattern.factor
    coarse_accept = search.coarse_accept if search.coarse_accept is not None else 0
    coarse_weights = pattern.coarse_weights
    if coarse_weights is not None and np.all(coarse_weights == 1):
        coarse_weights = None
    for degrees in angles:
        angle = math.radians(degrees)
        rotation = _rotation(angle)
        points = pattern.coarse_points @ rotation.T / factor
        bins = _bins(pattern.coarse_normals @ rotation.T, len(maps))
        for scale in scales:
            if cancelled is not None:
                _check_cancelled(cancelled)
            shifts = np.rint(points * scale).astype(int)
            offsets = np.column_stack((shifts, bins))
            response.fill(0)
            if coarse_weights is None:
                probes = np.unique(offsets, axis=0)
                total_weight = len(probes)
                for x, y, bin_id in probes:
                    _shift_add(response, maps[bin_id], x, y)
            else:
                probes, inverse = np.unique(offsets, axis=0, return_inverse=True)
                weights = np.zeros(len(probes))
                # A quantized probe votes once even when several features land on it.
                np.maximum.at(weights, inverse.ravel(), coarse_weights)
                total_weight = weights.sum()
                for (x, y, bin_id), weight in zip(probes, weights):
                    _shift_add(response, maps[bin_id], x, y, weight)
            for _ in range(2 * search.max_results):
                if cancelled is not None:
                    _check_cancelled(cancelled)
                _, peak, _, (x, y) = cv2.minMaxLoc(response)
                if peak <= 0:
                    break
                score = min(1.0, peak / total_weight)
                cx, cy = (x + 0.5) * factor - 0.5, (y + 0.5) * factor - 0.5
                if score < coarse_accept:
                    if rejected is not None:
                        rejected.append(RejectedCandidate(Pose(cx, cy, float(degrees), float(scale)),
                                                           "coarse_cutoff", coarse_score=score))
                    break
                candidates.append((score, cx, cy, angle, math.log(scale)))
                cv2.circle(response, (x, y), 3, 0, thickness=-1)

    shortlist = []
    cells = {}
    position_separation = factor * 2
    angle_separation = math.radians(search.angle[2] * 1.1)
    scale_separation = search.scale[2] * 1.1
    scale_ratio_limit = math.inf
    if search.max_results > 1:
        angle_separation = min(angle_separation, math.radians(search.angle_overlap_deg))
        scale_ratio_limit = math.log(search.scale_overlap)
    for candidate in sorted(candidates, reverse=True):
        if cancelled is not None:
            _check_cancelled(cancelled)
        _, x, y, angle, log_scale = candidate
        # A neighbor within the position tolerance is in this cell or one
        # of its eight neighbors. Keep the original tests for suppression.
        cell_x, cell_y = int(x // position_separation), int(y // position_separation)
        similar = any(
            math.hypot(x - px, y - py) <= position_separation
            and abs(math.remainder(angle - pa, math.tau)) <= angle_separation
            and abs(log_scale - ps) <= scale_ratio_limit
            and abs(math.exp(log_scale) - math.exp(ps)) <= scale_separation
            for j in range(cell_y - 1, cell_y + 2)
            for i in range(cell_x - 1, cell_x + 2)
            for _, px, py, pa, ps in cells.get((i, j), ())
        )
        if not similar:
            shortlist.append(candidate)
            cells.setdefault((cell_x, cell_y), []).append(candidate)
        if len(shortlist) == 18 * search.max_results:
            break
    return shortlist


def _direction_lookup(shape: tuple[int, int], pixels: np.ndarray, normals: np.ndarray, unsigned: bool):
    count = 6 if unsigned else 12
    bins = _bins(normals, count)
    lookup = np.zeros((count, *shape), dtype=np.int32)
    for orientation in range(count):
        indices = np.flatnonzero(bins == orientation)
        if not len(indices):
            continue
        x, y = pixels[indices].T
        mask = np.ones(shape, dtype=np.uint8)
        mask[y, x] = 0
        _, labels = cv2.distanceTransformWithLabels(mask, cv2.DIST_L2, cv2.DIST_MASK_5,
                                                    labelType=cv2.DIST_LABEL_PIXEL)
        edge_id = np.zeros(len(indices) + 1, dtype=np.int32)
        edge_id[labels[y, x]] = indices + 1
        lookup[orientation] = edge_id[labels]
    return lookup


def _edge_lookup(image: np.ndarray, pattern: Pattern, unsigned: bool, care: np.ndarray | None):
    pixels, points, normals = _filter_edges(*_edges(image, pattern.edge_threshold, pattern.fine_sigma), care)
    lookup = _direction_lookup(image.shape, pixels, normals, unsigned)
    # The 2-pixel border left by _edges allows these samples to stay inside the image.
    contrast = np.abs(_bilinear(image, points + 1.25 * normals) - _bilinear(image, points - 1.25 * normals))
    # Index zero represents the absence of an edge in a direction bin.
    edges = np.vstack((np.zeros((1, 5)), np.column_stack((points, normals, contrast))))
    return lookup, edges


def _inside_region(points: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    # Working coordinates put integer centers half a pixel inside the crop boundaries.
    height, width = shape
    x, y = points.T
    return (x >= -0.5) & (x < width - 0.5) & (y >= -0.5) & (y < height - 0.5)


def _nearest_edges(lookup: np.ndarray, edges: np.ndarray, predicted: np.ndarray, normals: np.ndarray,
                   radius: float, unsigned: bool, *, in_region_only: bool = False):
    count, height, width = lookup.shape
    u, v = np.rint(predicted).astype(np.int32).T
    directions = (_bins(normals, count)[:, None] + np.arange(-2, 3)) % count
    ids = lookup[directions, v.clip(0, height - 1)[:, None], u.clip(0, width - 1)[:, None]]
    # Work on the two coordinate columns directly. Each probe still checks the
    # same five bins, in the same order for equal costs.
    edge_x, edge_y, edge_nx, edge_ny = edges.T[:4]
    dx = predicted[:, 0, None] - edge_x[ids]
    dy = predicted[:, 1, None] - edge_y[ids]
    dist2 = dx * dx + dy * dy
    agreement = normals[:, 0, None] * edge_nx[ids] + normals[:, 1, None] * edge_ny[ids]
    if unsigned:
        agreement = np.abs(agreement)
    allowed = (ids > 0) & (dist2 <= radius * radius) & (agreement >= _MIN_AGREEMENT)
    if in_region_only:
        allowed &= _inside_region(predicted, (height, width))[:, None]
    cost = np.where(allowed, dist2 + 4.0 * (1 - agreement), np.inf)
    nearest = np.argmin(cost, axis=1)
    rows = np.arange(len(nearest))
    matched = np.isfinite(cost[rows, nearest])
    rows, nearest = rows[matched], nearest[matched]
    matched_ids = ids[rows, nearest]
    normal = edges[matched_ids, 2:4]
    residual = dx[rows, nearest] * normal[:, 0] + dy[rows, nearest] * normal[:, 1]
    return rows, matched_ids, normal, residual, dist2[rows, nearest], agreement[rows, nearest].clip(0, 1)


def _correspondences(lookup: np.ndarray, edges: np.ndarray, pattern: Pattern,
                     params: np.ndarray, radius: int, unsigned: bool, *, in_region_only: bool):
    x, y, angle, log_scale = params[:4]
    rotation = _rotation(angle)
    points, normals = pattern.points, pattern.normals
    if len(params) == 5:
        root = math.exp(params[4] / 2)
        stretch = (root, 1 / root)
        points = points * stretch
        # Edge normals transform by the inverse transpose of the point mapping.
        normals = normals / stretch
        normals /= np.linalg.norm(normals, axis=1)[:, None]
    rotated = points @ rotation.T * math.exp(log_scale)
    projected = rotated + [x, y]
    rows, matched, normal, residual, dist2, agreement = _nearest_edges(
        lookup, edges, projected, normals @ rotation.T, radius, unsigned, in_region_only=in_region_only)
    return rows, matched, rotated[rows], normal, residual, dist2, agreement, projected


def _fit_system(rotated: np.ndarray, normals: np.ndarray) -> np.ndarray:
    # Jacobian of signed point-to-line distance in x, y, angle, and log-scale.
    x, y = rotated.T
    nx, ny = normals.T
    return np.column_stack((normals, nx * y - ny * x, nx * x + ny * y))


def _refinement_system(rotated, normals, params, active):
    jacobian = _fit_system(rotated, normals)
    if len(params) == 5:
        rotation = _rotation(params[2])
        # The log-aspect derivative stretches one pattern axis while contracting the other.
        derivative = ((rotated @ rotation) * [0.5, -0.5]) @ rotation.T
        jacobian = np.column_stack((jacobian, np.sum(normals * derivative, axis=1)))
    return jacobian[:, active]


def _refine(lookup: np.ndarray, edges: np.ndarray, pattern: Pattern, start, search: Search, xy_bounds=None,
            *, capture_fit=False, cancelled: CancelCheck = None):
    _, height, width = lookup.shape
    a0, a1 = map(math.radians, search.angle[:2])
    s0, s1 = map(math.log, search.scale[:2])
    min_xy, max_xy = xy_bounds if xy_bounds is not None else ((0, 0), (width - 1, height - 1))
    use_aspect = tuple(search.aspect) != (1.0, 1.0)
    lower = [*min_xy, a0, s0]
    upper = [*max_xy, a1, s1]
    if use_aspect:
        lower.append(math.log(search.aspect[0]))
        upper.append(math.log(search.aspect[1]))
        if len(start) == 4:
            start = [*start, 0.0]
    lower, upper = np.array(lower), np.array(upper)
    full_turn = search.angle[1] - search.angle[0] == 360
    active = lower != upper
    active_dofs = np.count_nonzero(active)
    params = np.clip(start, lower, upper)
    initial_radius = 6 if xy_bounds is not None else max(4, pattern.factor + 2)
    allow_outside = search.outside_region_threshold > 0
    for radius, iterations in ((initial_radius, 7), (3, 5)):
        limit = np.array([radius, radius, math.radians(7), 0.08, 0.06][:len(params)])
        for _ in range(iterations):
            if cancelled is not None:
                _check_cancelled(cancelled)
            rows, _, rotated, normals, residual, _, agreement, _ = _correspondences(
                lookup, edges, pattern, params, radius, search.ignore_polarity, in_region_only=allow_outside)
            if len(rows) < 12 or not active_dofs:
                break
            jacobian = _refinement_system(rotated, normals, params, active)
            strength = agreement / (1 + (residual / 1.5) ** 2)
            if pattern.weights is not None:
                strength *= pattern.weights[rows]
            weight = np.sqrt(strength)
            update, _, rank, _ = np.linalg.lstsq(jacobian * weight[:, None], -residual * weight, rcond=1e-5)
            if rank < active_dofs:
                break
            delta = np.zeros_like(params)
            delta[active] = update
            updated = params + delta.clip(-limit, limit)
            if full_turn:
                updated[2] = a0 + (updated[2] - a0) % math.tau
            updated = updated.clip(lower, upper)
            if np.all(np.abs(updated - params) <= 0.001):
                break
            params = updated

    if cancelled is not None:
        _check_cancelled(cancelled)
    rows, matched_ids, rotated, normals, residual, dist2, agreement, projected = _correspondences(
        lookup, edges, pattern, params, _FINAL_FIT_RADIUS, search.ignore_polarity, in_region_only=allow_outside)
    x, y, angle, log_scale = params[:4]
    pose = Pose(float(x), float(y), math.degrees(angle), math.exp(log_scale), math.exp(params[4]) if use_aspect else 1.0)
    coverage = len(rows) / len(pattern.points)
    outside = ~_inside_region(projected, (height, width))
    outside_count = np.count_nonzero(outside)
    outside_fraction = outside_count / len(pattern.points)
    edge_matches = (tuple((int(index), float(px), float(py)) for index, (px, py) in zip(rows, edges[matched_ids, :2]))
                    if capture_fit else None)
    measurements = {"coverage": coverage, "edge_matches": edge_matches, "outside_region_fraction": outside_fraction,
                    "outside_region_indices": tuple(np.flatnonzero(outside).tolist()) if capture_fit else ()}
    if len(rows) < 12:
        return RejectedCandidate(pose, "insufficient_edges", **measurements)
    if active_dofs:
        singular_values = np.linalg.svd(_refinement_system(rotated, normals, params, active), compute_uv=False)
        if singular_values[-1] <= singular_values[0] * 1e-5:
            return RejectedCandidate(pose, "underconstrained_pose", **measurements)
    fit = np.exp(-0.5 * dist2 / 1.25**2) * agreement
    if pattern.weights is None:
        evidence, total_weight, outside_weight = fit.sum(), len(pattern.points), outside_count
    else:
        evidence, total_weight = np.dot(fit, pattern.weights[rows]), pattern.weights.sum()
        outside_weight = pattern.weights[outside].sum()
    if allow_outside and outside_count:
        forgiven_share = min(1.0, search.outside_region_threshold / outside_fraction)
        total_weight -= forgiven_share * outside_weight
    score = min(1.0, evidence / total_weight)
    return Match(pose, float(score), fit_error_px=float(np.sqrt(np.mean(residual**2))),
                 contrast=float(np.mean(edges[matched_ids, 4])), **measurements)


def _match_clutter(edges: np.ndarray, pattern: Pattern, pose: Pose, unsigned: bool) -> float:
    # Undo the scene rotation and translation, keeping distances in scene pixels.
    rotation = _rotation(math.radians(pose.angle_deg))
    local = (edges[:, :2] - (pose.x, pose.y)) @ rotation
    half_size = np.array(pattern.training_roi[2:]) / 2
    scale_axes = pose.scale if pose.aspect == 1 else np.array(pose._axis_scales())
    extent = half_size * scale_axes
    inside = np.all((local >= -extent) & (local < extent), axis=1)
    points = local[inside]
    normals = edges[inside, 2:4] @ rotation
    extras = 0
    if pattern.mask is not None:
        indices = np.floor(points / scale_axes + half_size).astype(int)
        x, y = np.clip(indices, 0, np.array(pattern.mask.shape[::-1]) - 1).T
        bands = pattern.mask[y, x]
        extras = np.count_nonzero((bands >= 64) & (bands < 128))
        care = bands >= 192
        points, normals = points[care], normals[care]

    trained_count = pattern.diagnostics.fine.eligible if pattern.diagnostics else len(pattern.points)
    # The retained probes sample the original edge set. Allow for their spacing as well as fit tolerance.
    sample_spacing = min(4.0, trained_count / len(pattern.points))
    radius_sq = max(2.0, sample_spacing * pose.scale) ** 2
    model_points = pattern.points * scale_axes
    model_normals = pattern.normals
    if pose.aspect != 1:
        model_normals = model_normals / scale_axes
        model_normals /= np.linalg.norm(model_normals, axis=1)[:, None]
    for start in range(0, len(points), 512):
        batch = slice(start, start + 512)
        delta = points[batch, None, :] - model_points[None, :, :]
        distance_sq = np.sum(delta**2, axis=2)
        agreement = normals[batch] @ model_normals.T
        if unsigned:
            agreement = np.abs(agreement)
        explained = np.any((distance_sq <= radius_sq) & (agreement >= _MIN_AGREEMENT), axis=1)
        extras += np.count_nonzero(~explained)
    return float(extras / max(1, trained_count * pose.scale))


def _seed_parameters(pose: Pose, pattern: Pattern, search: Search, offset: tuple[int, int]):
    values = (pose.x, pose.y, pose.angle_deg, pose.scale, pose.aspect, search.start_window)
    if not all(map(math.isfinite, values)) or search.start_window <= 0:
        raise ValueError("Start pose coordinates and window must be finite, with a positive window.")
    low, high = search.angle[:2]
    angle = pose.angle_deg
    if not low <= angle <= high:
        angle = low + (angle - low) % 360
    if not low <= angle <= high or not search.scale[0] <= pose.scale <= search.scale[1]:
        raise ValueError("Start pose angle and scale must be inside their configured search bounds.")
    if not search.aspect[0] <= pose.aspect <= search.aspect[1]:
        raise ValueError("Start pose aspect must be inside its configured search bounds.")
    # The seed maps the configured origin; the optimizer tracks the ROI-centered anchor.
    anchor_offset = np.subtract(pattern.anchor, pattern.origin)
    angle_rad = math.radians(angle)
    anchor = np.array((pose.x, pose.y)) + _rotation(angle_rad) @ (anchor_offset * pose._axis_scales()) - offset
    if not np.isfinite(anchor).all():
        raise ValueError("Start pose produces a nonfinite search anchor.")
    start = (*anchor, angle_rad, math.log(pose.scale))
    return start if tuple(search.aspect) == (1.0, 1.0) else (*start, math.log(pose.aspect))


def _reject_match(rejected: list[RejectedCandidate] | None, result: Match, reason: str) -> None:
    if rejected is not None:
        rejected.append(RejectedCandidate(result.pose, reason, result.coarse_score, result.score,
                                           result.coverage, result.fit_error_px, result.contrast, result.clutter,
                                           edge_matches=result.edge_matches, outside_region_fraction=result.outside_region_fraction,
                                           outside_region_indices=result.outside_region_indices))


def _intersection_area(first, second, smaller_area: float) -> float:
    # Use the rectangle-specific routine for nearly coincident long, narrow footprints.
    kind, vertices = cv2.rotatedRectangleIntersection(first, second)
    if kind == cv2.INTERSECT_FULL:
        return smaller_area
    return cv2.contourArea(cv2.convexHull(vertices)) if vertices is not None else 0.0


def _select_matches(results: list[Match], pattern: Pattern, search: Search,
                    rejected: list[RejectedCandidate] | None = None, cancelled: CancelCheck = None) -> list[Match]:
    ranked = sorted(results, key=lambda result: result.score, reverse=True)
    if search.aspect_fallback:
        # Preserve a passing similarity pose even if a different seed stretches to a higher score.
        ranked.sort(key=lambda result: result.pose.aspect == 1, reverse=True)
    if search.max_results == 1 or search.xy_overlap == 1 or len(ranked) <= 1:
        if rejected is not None:
            for result in ranked[search.max_results:]:
                _reject_match(rejected, result, "result_limit")
        return sorted(ranked[:search.max_results], key=lambda result: result.score, reverse=True)

    _, _, width, height = pattern.training_roi
    selected = []
    footprints = []
    for index, result in enumerate(ranked):
        if cancelled is not None:
            _check_cancelled(cancelled)
        pose = result.pose
        # At this stage the pose still maps the center of the training ROI.
        sx, sy = pose._axis_scales()
        size = (width * sx, height * sy)
        footprint = ((pose.x, pose.y), size, -pose.angle_deg)
        area = size[0] * size[1]
        if any(
            abs(math.remainder(pose.angle_deg - other.pose.angle_deg, 360)) <= search.angle_overlap_deg
            and max(pose.scale, other.pose.scale) <= min(pose.scale, other.pose.scale) * search.scale_overlap
            and _intersection_area(footprint, other_footprint, min(area, other_area)) > search.xy_overlap * min(area, other_area)
            for other, other_footprint, other_area in footprints
        ):
            _reject_match(rejected, result, "overlap")
            continue
        selected.append(result)
        footprints.append((result, footprint, area))
        if len(selected) == search.max_results:
            if rejected is not None:
                for remaining in ranked[index + 1:]:
                    _reject_match(rejected, remaining, "result_limit")
            break
    return sorted(selected, key=lambda result: result.score, reverse=True)


def _evaluate_candidate(lookup, edges, pattern, start, search, xy_bounds, capture_fit, cancelled=None):
    result = _refine(lookup, edges, pattern, start, search, xy_bounds, capture_fit=capture_fit, cancelled=cancelled)
    if isinstance(result, RejectedCandidate):
        return result, result.reason
    if result.score < search.accept:
        return result, "score_cutoff"
    if result.contrast < search.min_contrast:
        return result, "contrast_cutoff"
    if search.score_using_clutter:
        clutter = _match_clutter(edges[1:], pattern, result.pose, search.ignore_polarity)
        result = replace(result, score=result.score / (1 + clutter), clutter=clutter)
        if result.score < search.accept:
            return result, "clutter_penalty"
    return result, None


def _validate_search(search: Search, pattern: Pattern) -> tuple[int, int] | None:
    for bounds in (search.angle, search.scale):
        low, high, step = bounds
        if not all(map(math.isfinite, bounds)) or low > high or step <= 0:
            raise ValueError("Search ranges require finite MIN <= MAX and STEP > 0.")
    if search.angle[1] - search.angle[0] > 360 or search.scale[0] <= 0 or not 0 <= search.accept <= 1:
        raise ValueError("Use at most 360 degrees, positive scales, and an accept score in [0, 1].")
    if not isinstance(search.max_results, Integral) or isinstance(search.max_results, bool) or not 1 <= search.max_results <= 100:
        raise ValueError("Maximum results must be an integer from 1 to 100.")
    if not 0 <= search.xy_overlap <= 1 or not 0 <= search.angle_overlap_deg <= 360:
        raise ValueError("XY overlap must be in [0, 1] and angle overlap in [0, 360] degrees.")
    if not math.isfinite(search.scale_overlap) or search.scale_overlap < 1:
        raise ValueError("Scale overlap must be a finite ratio of at least 1.")
    if search.coarse_accept is not None and not 0 <= search.coarse_accept <= 1:
        raise ValueError("Coarse acceptance must be in [0, 1].")
    if not 0 <= search.min_contrast <= 255:
        raise ValueError("Minimum contrast must be in [0, 255] gray levels.")
    if not 0 <= search.outside_region_threshold <= 0.999:
        raise ValueError("Outside-region threshold must be in [0, 0.999].")
    low_aspect, high_aspect = search.aspect
    if not 0 < low_aspect <= high_aspect or not math.isfinite(high_aspect):
        raise ValueError("Aspect bounds require finite 0 < MIN <= MAX.")
    if search.aspect_fallback and (not low_aspect <= 1 <= high_aspect or low_aspect == high_aspect):
        raise ValueError("Aspect fallback requires a nontrivial aspect range that contains 1.")
    if search.aspect_fallback and search.start_pose is not None and search.start_pose.aspect != 1:
        raise ValueError("Aspect fallback requires a start pose with aspect 1.")
    largest_axis = search.scale[1] * math.sqrt(max(high_aspect, 1 / low_aspect))
    max_offset = largest_axis * np.max(np.linalg.norm(pattern.points, axis=1))
    if max_offset > np.iinfo(np.int32).max / 2:
        raise ValueError("The largest requested scale makes the pattern too large.")
    if search.start_pose is None:
        na, ns = _grid_size(search.angle), _grid_size(search.scale)
        if na * ns > 2500:
            raise ValueError("Search grid is too large. Increase the step or narrow the range.")
        return na, ns
    return None


def _fit_starts(lookup, edges, pattern, starts, search, first_search, xy_bounds, capture_fit, cancelled):
    for coarse_score, *start in starts:
        result, reason = _evaluate_candidate(lookup, edges, pattern, start, first_search, xy_bounds, capture_fit, cancelled)
        if search.aspect_fallback and reason is not None:
            result, reason = _evaluate_candidate(lookup, edges, pattern, start, search, xy_bounds, capture_fit, cancelled)
        yield replace(result, coarse_score=coarse_score), reason


def _locate_all(image, pattern, search, roi, mask, rejected, capture_fit, cancelled=None, runtime=None):
    if cancelled is not None:
        _check_cancelled(cancelled)
    source_shape = image.shape
    image, (offset_x, offset_y) = _crop(image, roi)
    height, width = image.shape
    care = None
    if mask is not None:
        if mask.shape != source_shape or mask.dtype != np.uint8:
            raise ValueError("Search mask must be 8-bit grayscale and match the source image size.")
        care = mask[offset_y:offset_y + height, offset_x:offset_x + width] >= 128
    if search.ignore_polarity is None:
        search = replace(search, ignore_polarity=pattern.ignore_polarity)
    grid = _validate_search(search, pattern)
    first_search = replace(search, aspect=(1.0, 1.0)) if search.aspect_fallback else search
    xy_bounds = None
    if grid is not None:
        na, ns = grid
        angles = np.linspace(*search.angle[:2], na)
        scales = np.linspace(*search.scale[:2], ns)
        starts = _shortlist(image, pattern, search, angles, scales, care, rejected, cancelled)
    else:
        start = _seed_parameters(search.start_pose, pattern, first_search, (offset_x, offset_y))
        anchor = np.array(start[:2])
        lower = np.maximum((0, 0), anchor - search.start_window)
        upper = np.minimum((width - 1, height - 1), anchor + search.start_window)
        if np.any(lower > upper):
            return []
        xy_bounds = (lower, upper)
        starts = ((None, *start),)
    results = []
    if starts:
        lookup, edges = _edge_lookup(image, pattern, search.ignore_polarity, care)
        fit = _fit_starts if runtime is None else runtime._fit
        for result, reason in fit(lookup, edges, pattern, starts, search, first_search, xy_bounds, capture_fit, cancelled):
            if reason is None:
                results.append(result)
            elif isinstance(result, RejectedCandidate):
                if rejected is not None:
                    rejected.append(result)
            else:
                _reject_match(rejected, result, reason)
    datum_offset = np.subtract(pattern.origin, pattern.anchor)

    def to_scene(result):
        pose = result.pose
        scene_x, scene_y = pose.matrix() @ [*datum_offset, 1]
        edge_matches = result.edge_matches
        if edge_matches and (offset_x or offset_y):
            edge_matches = tuple((index, x + offset_x, y + offset_y) for index, x, y in edge_matches)
        return replace(result, pose=replace(pose, x=float(scene_x + offset_x), y=float(scene_y + offset_y)),
                       edge_matches=edge_matches)

    matches = [to_scene(result) for result in _select_matches(results, pattern, search, rejected, cancelled)]
    if rejected is not None:
        rejected[:] = [to_scene(result) for result in rejected]
    if cancelled is not None:
        _check_cancelled(cancelled)
    return matches


def locate_all(image: np.ndarray, pattern: Pattern, search: Search = Search(), *,
               roi: tuple[int, int, int, int] | None = None, mask: np.ndarray | None = None,
               capture_fit: bool = False, cancelled: CancelCheck = None, runtime: SearchRuntime | None = None) -> list[Match]:
    """Return up to search.max_results accepted matches, strongest score first.

    An aligned uint8 mask excludes scene edges at values below 128. A start pose
    in source coordinates seeds a single local refinement at the pattern origin.
    Use capture_fit to include the measured scene edges used by the final pose.
    A true cancellation check raises CancelledError without returning partial matches.
    A reusable SearchRuntime can fit large shortlists across multiple processes.
    """
    return _locate_all(image, pattern, search, roi, mask, None, capture_fit, cancelled, runtime)


def review_search(image: np.ndarray, pattern: Pattern, search: Search = Search(), *,
                  roi: tuple[int, int, int, int] | None = None, mask: np.ndarray | None = None,
                  capture_fit: bool = False, cancelled: CancelCheck = None, runtime: SearchRuntime | None = None) -> SearchReview:
    """Run the usual search and retain up to 20 of the strongest rejections per reason."""
    rejected = []
    matches = _locate_all(image, pattern, search, roi, mask, rejected, capture_fit, cancelled, runtime)
    counts = Counter(candidate.reason for candidate in rejected)
    # Rank measured final scores before coarse scores, then retain a useful sample of each reason.
    ranked = sorted(rejected, key=lambda item: (item.score is not None, item.score or 0, item.coarse_score or 0),
                    reverse=True)
    retained = Counter()
    sample = []
    for candidate in ranked:
        if cancelled is not None:
            _check_cancelled(cancelled)
        if retained[candidate.reason] < 20:
            sample.append(candidate)
            retained[candidate.reason] += 1
    return SearchReview(matches, sample, dict(counts))


def locate(image: np.ndarray, pattern: Pattern, search: Search = Search(), *,
           roi: tuple[int, int, int, int] | None = None, mask: np.ndarray | None = None,
           capture_fit: bool = False, cancelled: CancelCheck = None, runtime: SearchRuntime | None = None) -> Match | None:
    """Return the strongest accepted match, in source-scene pixel coordinates."""
    matches = locate_all(image, pattern, search, roi=roi, mask=mask, capture_fit=capture_fit,
                         cancelled=cancelled, runtime=runtime)
    return matches[0] if matches else None


def draw_match(image: np.ndarray, pattern: Pattern, result: Match, *, layers=None) -> np.ndarray:
    """Draw one accepted match on a copy of the scene."""
    return draw_matches(image, pattern, (result,), layers=layers)


def draw_matches(image: np.ndarray, pattern: Pattern, results: Iterable[Match], *, layers=None) -> np.ndarray:
    """Draw accepted poses and the recorded found and missing edges."""
    return _draw_results(image, pattern, results, layers=layers)


def draw_rejections(image: np.ndarray, pattern: Pattern, rejected: Iterable[RejectedCandidate], *, layers=None) -> np.ndarray:
    """Draw rejected poses. Candidates without a fine fit have amber projections."""
    return _draw_results(image, pattern, rejected, layers=layers)


FIT_LAYERS = ("expected", "found", "missing", "unmeasured", "residuals", "pose")
DEFAULT_FIT_LAYERS = FIT_LAYERS[1:]


def _draw_results(image, pattern, results, *, layers=None):
    layers = set(DEFAULT_FIT_LAYERS if layers is None else layers)
    if not layers <= set(FIT_LAYERS):
        raise ValueError("Unknown fit graphics layer.")
    overlay = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    points = pattern.points + np.subtract(pattern.anchor, pattern.origin)
    poses = []
    for result in results:
        pose = result.pose
        poses.append(pose)
        transform = pose.matrix()
        projected = np.rint(points @ transform[:, :2].T + transform[:, 2]).astype(int)
        if "expected" in layers:
            for point in projected:
                cv2.circle(overlay, tuple(point), 1, (145, 145, 145), -1, cv2.LINE_AA)
        if result.edge_matches is None:
            if "unmeasured" in layers:
                for point in projected:
                    cv2.circle(overlay, tuple(point), 1, _EDGE_UNMEASURED, -1, cv2.LINE_AA)
            continue
        found = {index for index, _, _ in result.edge_matches}
        outside = set(result.outside_region_indices)
        for index, point in enumerate(projected):
            if index not in found:
                layer = "unmeasured" if index in outside else "missing"
                if layer not in layers:
                    continue
                color = _EDGE_UNMEASURED if index in outside else _EDGE_MISSING
                cv2.circle(overlay, tuple(point), 1, color, -1, cv2.LINE_AA)
        for index, x, y in result.edge_matches:
            observed = (round(x), round(y))
            expected = tuple(projected[index])
            if observed != expected and "residuals" in layers:
                cv2.line(overlay, expected, observed, (50, 150, 49), 1, cv2.LINE_AA)
            if "found" in layers:
                cv2.circle(overlay, observed, 1, _EDGE_FOUND, -1, cv2.LINE_AA)
    for pose in poses if "pose" in layers else ():
        _draw_pose_marker(overlay, pose)
    return overlay


def _draw_pose_marker(overlay, pose):
    height, width = overlay.shape[:2]
    if not (0 <= pose.x < width and 0 <= pose.y < height):
        return
    basis = _rotation(math.radians(pose.angle_deg))
    xy = np.array([pose.x, pose.y])
    origin = (round(pose.x), round(pose.y))
    end_x = tuple(np.rint(xy + basis[:, 0] * 19).astype(int))
    end_y = tuple(np.rint(xy + basis[:, 1] * 12).astype(int))
    for color, thickness in (((19, 19, 19), 4), (_POSE_AXIS, 2)):
        cv2.line(overlay, origin, end_y, color, thickness, cv2.LINE_AA)
        cv2.arrowedLine(overlay, origin, end_x, color, thickness, cv2.LINE_AA, tipLength=0.32)
    cv2.circle(overlay, origin, 3, _POSE_AXIS, -1, cv2.LINE_AA)


def draw_training(image: np.ndarray | None, pattern: Pattern, *, coarse: bool = False) -> np.ndarray:
    """Display trained geometry over a reference, or in a neutral ROI view."""
    x, y, width, height = pattern.training_roi
    points = pattern.coarse_points if coarse else pattern.points
    origin = pattern.origin
    if image is None:
        # Fit the ROI into a bounded preview without allocating a source-sized canvas.
        scale = min(1.0, 1023 / (max(width, height) - 1))
        padding = 12
        offset = np.array((x, y))
        points = (points + (pattern.anchor - offset)) * scale + padding
        origin = (origin - offset) * scale + padding
        width, height = (round((side - 1) * scale) + 1 for side in (width, height))
        x = y = padding
        image = np.full((height + 2 * padding, width + 2 * padding), 29, np.uint8)
        points = points[np.all((points >= -1) & (points <= image.shape[::-1]), axis=1)]
    else:
        image, _ = _crop(image, None)
        points = points + pattern.anchor
    overlay = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    cv2.rectangle(overlay, (x, y), (x + width - 1, y + height - 1), (210, 175, 60), 1)
    for point in np.rint(points).astype(int):
        cv2.circle(overlay, tuple(point), 1, (94, 231, 83), thickness=-1, lineType=cv2.LINE_AA)
    ox, oy = origin
    if 0 <= ox < image.shape[1] and 0 <= oy < image.shape[0]:
        cv2.drawMarker(overlay, (round(ox), round(oy)), (21, 214, 255), cv2.MARKER_CROSS, 17, 2, cv2.LINE_AA)
    return overlay
