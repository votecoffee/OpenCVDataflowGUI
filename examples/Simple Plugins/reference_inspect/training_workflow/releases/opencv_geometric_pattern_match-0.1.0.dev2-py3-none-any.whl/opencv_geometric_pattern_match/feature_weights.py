"""Assign relative search weights to a trained pattern."""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import replace

import numpy as np

from .locator import Pattern

_MIN_WEIGHT = 0.01
_MAX_WEIGHT = 100.0


def _validate_weights(weights: np.ndarray, count: int) -> None:
    if weights.shape != (count,) or weights.dtype.kind not in "fiu":
        raise ValueError("Supply one numeric weight per feature.")
    if not np.all((weights >= _MIN_WEIGHT) & (weights <= _MAX_WEIGHT)):
        raise ValueError(f"Feature weights must be in [{_MIN_WEIGHT}, {_MAX_WEIGHT}].")


def weight_pattern(
    pattern: Pattern, regions: Iterable[tuple[float, float, float, float, float]],
) -> Pattern:
    """Set absolute feature weights within half-open ROI-relative rectangles."""
    boxes = np.asarray(tuple(regions), dtype=float)
    if boxes.ndim != 2 or boxes.shape[1] != 5 or not np.isfinite(boxes).all():
        raise ValueError("Provide one or more finite weight regions as X Y W H WEIGHT.")
    size = np.array(pattern.training_roi[2:])
    starts, spans, values = boxes[:, :2], boxes[:, 2:4], boxes[:, 4]
    if np.any(starts < 0) or np.any(spans <= 0) or np.any(starts + spans > size):
        raise ValueError("Weight regions must have positive dimensions and lie inside the training ROI.")
    _validate_weights(values, len(boxes))
    center = (size - 1) / 2
    coarse_points, points = pattern.coarse_points + center, pattern.points + center
    coarse_weights = np.ones(len(coarse_points)) if pattern.coarse_weights is None else pattern.coarse_weights.astype(float)
    weights = np.ones(len(points)) if pattern.weights is None else pattern.weights.astype(float)
    for lower, span, value in zip(starts, spans, values):
        upper = lower + span
        coarse_inside = np.all((coarse_points >= lower) & (coarse_points < upper), axis=1)
        inside = np.all((points >= lower) & (points < upper), axis=1)
        if not (coarse_inside.any() or inside.any()):
            raise ValueError("Weight region contains no trained features.")
        coarse_weights[coarse_inside] = value
        weights[inside] = value
    if np.all(coarse_weights == 1) and np.all(weights == 1):
        return replace(pattern, coarse_weights=None, weights=None)
    return replace(pattern, coarse_weights=coarse_weights, weights=weights)
