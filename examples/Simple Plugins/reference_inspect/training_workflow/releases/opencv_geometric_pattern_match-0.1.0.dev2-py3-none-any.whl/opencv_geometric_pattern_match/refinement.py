"""Adapt fine training probes from a verified pose on another image."""

from dataclasses import dataclass, replace

import numpy as np

from .feature_weights import _MIN_WEIGHT
from .locator import (
    _FINAL_FIT_RADIUS,
    CancelCheck,
    Match,
    Pattern,
    Pose,
    Search,
    _check_cancelled,
    _crop,
    _edge_lookup,
    _evaluate_candidate,
    _seed_parameters,
    _validate_search,
    _weak_dofs,
)

_MIN_SUPPORT = 0.50
_MAX_FIT_ERROR = 1.25
_UNSUPPORTED_WEIGHT_FACTOR = 0.8
_MAX_SHIFT = 0.5


@dataclass(frozen=True)
class TrainingRefinement:
    pattern: Pattern
    before: Match
    after: Match
    moved: int
    downweighted: int


def _observable(projected, shape, care):
    """Ignore probes whose final correspondence window can touch excluded pixels."""
    center = np.rint(projected).astype(np.intp)
    radius = _FINAL_FIT_RADIUS + 1  # Allow for rounding the probe and the subpixel edge.
    seen = np.all((center >= radius) & (center < np.array(shape[::-1]) - radius), axis=1)
    if care is not None:
        x, y = center[seen].T
        shifts = np.arange(-radius, radius + 1)
        seen[seen] = care[y[:, None, None] + shifts[:, None],
                          x[:, None, None] + shifts].all(axis=(1, 2))
    return seen


def _refine_training(
    image: np.ndarray,
    pattern: Pattern,
    pose: Pose,
    search: Search,
    roi: tuple[int, int, int, int] | None,
    mask: np.ndarray | None,
    *,
    cancelled: CancelCheck = None,
) -> TrainingRefinement:
    """Score and adapt probes at the supplied datum pose in working image pixels."""
    if cancelled is not None:
        _check_cancelled(cancelled)
    image, offset = _crop(image, roi)
    x, y = offset
    height, width = image.shape
    care = None if mask is None else mask[y:y + height, x:x + width] >= 128
    # Use the same scene edges and pose to compare the old and new model.
    fixed = replace(
        search, angle=(pose.angle_deg, pose.angle_deg, 1.), scale=(pose.scale, pose.scale, 1.),
        aspect=(pose.aspect, pose.aspect), aspect_fallback=False, start_pose=pose, accept=0., min_contrast=0.,
        ignore_polarity=pattern.ignore_polarity if search.ignore_polarity is None else search.ignore_polarity,
    )
    _validate_search(fixed, pattern)
    start = _seed_parameters(pose, pattern, fixed, offset)
    anchor = np.array(start[:2])
    if not np.all((anchor >= 0) & (anchor < [width, height])):
        raise ValueError("The selected part's training center is outside the preview region.")
    linear = pose.matrix()[:, :2]
    projected = pattern.points @ linear.T + anchor
    observable = _observable(projected, image.shape, care)
    lookup, edges = _edge_lookup(image, pattern, fixed.ignore_polarity, care)
    bounds = (anchor, anchor)
    before, _ = _evaluate_candidate(lookup, edges, pattern, start, fixed, bounds, True, cancelled)
    if not isinstance(before, Match) or before.fit_error_px > _MAX_FIT_ERROR:
        raise ValueError("The selected pose has insufficient edge fit for training refinement.")
    hits = np.asarray(before.edge_matches)
    rows = hits[:, 0].astype(np.intp)
    supported = observable[rows]
    rows, observed = rows[supported], hits[supported, 1:]
    if len(rows) < max(12, _MIN_SUPPORT * len(pattern.points)):
        raise ValueError("The selected pose needs at least half of its fine edges in observable areas.")
    weak = set(_weak_dofs(pattern.points, pattern.normals))
    if set(_weak_dofs(pattern.points[rows], pattern.normals[rows])) - weak:
        raise ValueError("The measured edges do not constrain the selected pose well enough to refine training.")

    aligned = (observed - anchor) @ np.linalg.inv(linear).T
    normals = pattern.normals[rows]
    residual = np.sum((aligned - pattern.points[rows]) * normals, axis=1)
    shift = np.clip(residual * 0.5, -_MAX_SHIFT, _MAX_SHIFT)
    moved = pattern.points[rows] + shift[:, None] * normals
    size = np.array(pattern.training_roi[2:])
    pixels = np.rint(moved + (size - 1) / 2).astype(np.intp)
    inside = np.all((pixels >= 0) & (pixels < size), axis=1)
    if pattern.mask is not None:
        px, py = pixels[inside].T
        inside[inside] = pattern.mask[py, px] >= 192
    changed = inside & (np.abs(shift) >= 0.001)
    points = pattern.points.copy()
    points[rows[changed]] = moved[changed]

    observable[rows] = False
    original_weights = np.ones(len(points)) if pattern.weights is None else pattern.weights
    weights = original_weights.astype(float, copy=True)
    weights[observable] = np.maximum(_MIN_WEIGHT, weights[observable] * _UNSUPPORTED_WEIGHT_FACTOR)
    downweighted = int(np.count_nonzero(weights < original_weights))
    if not changed.any() and not downweighted:
        raise ValueError("The selected image did not provide a useful fine feature change.")
    coarse_weights = pattern.coarse_weights
    if downweighted and coarse_weights is None:
        coarse_weights = np.ones(len(pattern.coarse_points))
    diagnostics = pattern.diagnostics
    if diagnostics is not None:
        diagnostics = replace(diagnostics, fine=replace(diagnostics.fine, weak_dofs=_weak_dofs(points, pattern.normals)))
    refined = replace(
        pattern, points=points, weights=weights if downweighted else pattern.weights,
        coarse_weights=coarse_weights, diagnostics=diagnostics,
    )
    after, _ = _evaluate_candidate(lookup, edges, refined, start, fixed, bounds, True, cancelled)
    if (not isinstance(after, Match) or after.score < before.score - 1e-6
            or after.coverage < before.coverage - 0.02):
        raise ValueError("Refinement reduced fit quality at the selected pose. The current pattern is kept.")
    # The evaluator uses the search crop and its internal anchor as its frame.
    # Return the fit measurements in the same datum and image frame as the preview.
    def in_scene(fit):
        return replace(fit, pose=pose, edge_matches=tuple(
            (i, px + x, py + y) for i, px, py in fit.edge_matches))

    return TrainingRefinement(refined, in_scene(before), in_scene(after), int(changed.sum()), downweighted)
