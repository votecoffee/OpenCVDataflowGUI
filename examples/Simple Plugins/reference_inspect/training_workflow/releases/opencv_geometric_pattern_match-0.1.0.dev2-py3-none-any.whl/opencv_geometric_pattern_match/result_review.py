"""Selected-candidate measurements and display artifacts, without another search."""

import json
from pathlib import Path

import cv2
import numpy as np

from .locator import DEFAULT_FIT_LAYERS, draw_matches


def candidate_report(pattern, candidate, search, *, working_to_source=None):
    mapping = np.eye(3) if working_to_source is None else np.asarray(working_to_source, float)
    if mapping.shape == (2, 3):
        mapping = np.vstack((mapping, [0.0, 0.0, 1.0]))
    if mapping.shape != (3, 3) or not np.isfinite(mapping).all():
        raise ValueError("Supply a finite 3x3 working-to-source pixel transform.")
    if not np.allclose(mapping[2], [0.0, 0.0, 1.0]):
        raise ValueError("Working-to-source pixels require an affine transform.")
    pose = candidate.pose
    transform = np.eye(3)
    transform[:2] = pose.matrix()
    source = mapping @ transform
    reason = getattr(candidate, "reason", None)
    captured = candidate.edge_matches is not None
    found = {i for i, _, _ in candidate.edge_matches or ()}
    outside = set(candidate.outside_region_indices) - found
    total = len(pattern.points)
    metrics = []

    def metric(name, value, units, minimum=None):
        status = "not measured" if value is None else "diagnostic"
        if value is not None and minimum is not None:
            status = "below limit" if value < minimum else "meets limit"
        metrics.append(
            {"name": name, "value": value, "units": units, "minimum": minimum, "status": status}
        )

    metric("Fine score", candidate.score, "fit fraction", search.accept)
    metric("Coarse score", candidate.coarse_score, "coarse vote fraction", search.coarse_accept)
    metric("Contrast", candidate.contrast, "working 8-bit gradient", search.min_contrast)
    metric("Coverage", candidate.coverage, "probe fraction")
    metric("Fit RMS", candidate.fit_error_px, "working pixels")
    metric("Clutter", candidate.clutter, "extra edge fraction")
    metric("Outside image/ROI", candidate.outside_region_fraction, "probe fraction")
    notes = {
        "coarse_cutoff": "Stopped before a fine fit; amber probes are unmeasured.",
        "insufficient_edges": "Fewer than 12 fine correspondences; no fine score was computed.",
        "underconstrained_pose": "Fine correspondences could not constrain the active pose axes.",
        "score_cutoff": "Fine fit score is below the acceptance setting.",
        "contrast_cutoff": "Measured contrast is below the minimum setting.",
        "clutter_penalty": "The clutter-adjusted score is below the acceptance setting.",
        "overlap": "Suppressed by overlap with a higher-ranked candidate.",
        "result_limit": "Not returned because the maximum result count was reached.",
    }
    return {
        "model": "ogpm_candidate_review_v1",
        "accepted": reason is None,
        "reason": reason,
        "explanation": notes.get(reason, "Accepted geometric fit; its score is not a probability."),
        "pose_working": {
            "x": pose.x,
            "y": pose.y,
            "angle_deg": pose.angle_deg,
            "scale": pose.scale,
            "aspect": pose.aspect,
        },
        "datum_source": source[:2, 2].tolist(),
        "model_to_source": source.tolist(),
        "working_to_source": mapping.tolist(),
        "metrics": metrics,
        "edges": {
            "trained": total,
            "found": len(found) if captured else None,
            "missing": total - len(found) - len(outside) if captured else None,
            "unmeasured": len(outside) if captured else total,
            "correspondences_captured": captured,
        },
        "selection_limits": {
            "maximum_results": search.max_results,
            "xy_overlap": search.xy_overlap,
            "angle_overlap_deg": search.angle_overlap_deg,
            "scale_overlap": search.scale_overlap,
        },
        "score_using_clutter": search.score_using_clutter,
    }


def candidate_bounds(image, pattern, candidate):
    points = pattern.points + np.subtract(pattern.anchor, pattern.origin)
    matrix = candidate.pose.matrix()
    points = points @ matrix[:, :2].T + matrix[:, 2]
    measured = [(x, y) for _, x, y in candidate.edge_matches or ()]
    points = (
        np.vstack((points, measured, [[candidate.pose.x, candidate.pose.y]]))
        if measured
        else np.vstack((points, [[candidate.pose.x, candidate.pose.y]]))
    )
    low = np.maximum(0, np.floor(points.min(axis=0) - 16).astype(int))
    high = np.minimum(image.shape[1::-1], np.ceil(points.max(axis=0) + 17).astype(int))
    if np.any(high <= low):
        return 0, 0, image.shape[1], image.shape[0]
    return int(low[0]), int(low[1]), int(high[0] - low[0]), int(high[1] - low[1])


def _text(image, text, point, *, width=470, scale=0.5, color=(232, 236, 240)):
    text = str(text).encode("ascii", errors="replace").decode("ascii")[:240]
    if cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, scale, 1)[0][0] > width:
        while (
            text and cv2.getTextSize(text + "...", cv2.FONT_HERSHEY_SIMPLEX, scale, 1)[0][0] > width
        ):
            text = text[:-1]
        text += "..."
    cv2.putText(image, text, point, cv2.FONT_HERSHEY_SIMPLEX, scale, color, 1, cv2.LINE_AA)


def draw_assessment(image, pattern, candidate, search, *, working_to_source=None, layers=None):
    """A selected fit crop and separate measurements; its grid is display-only."""
    report = candidate_report(pattern, candidate, search, working_to_source=working_to_source)
    fit = draw_matches(image, pattern, [candidate], layers=layers)
    x, y, width, height = candidate_bounds(image, pattern, candidate)
    output = np.full((640, 1120, 3), (30, 25, 20), np.uint8)
    color = (125, 240, 155) if report["accepted"] else (90, 180, 255)
    title = "ACCEPTED" if report["accepted"] else "NOT RETURNED: " + report["reason"]
    _text(output, title, (16, 29), width=1080, scale=0.7, color=color)
    ratio = min(600 / width, 500 / height)
    resized = cv2.resize(
        fit[y : y + height, x : x + width],
        (max(1, round(width * ratio)), max(1, round(height * ratio))),
        interpolation=cv2.INTER_NEAREST,
    )
    top, left = 60 + (500 - resized.shape[0]) // 2, 14 + (600 - resized.shape[1]) // 2
    output[top : top + resized.shape[0], left : left + resized.shape[1]] = resized
    _text(
        output,
        f"Working crop {x}, {y}, {width}, {height} | display resized",
        (14, 582),
        width=600,
        scale=0.45,
    )
    _text(
        output,
        "Green found | Red missing | Amber unmeasured | Cyan pose",
        (14, 609),
        width=600,
        scale=0.45,
    )
    _text(output, "Expected probes: gray | Residuals: dark green", (14, 631), width=600, scale=0.43)
    _text(output, report["explanation"], (638, 66), scale=0.46)
    sx, sy = report["datum_source"]
    _text(output, f"Datum in source: X {sx:.3f}, Y {sy:.3f} px", (638, 96))
    _text(
        output,
        f"Working angle {candidate.pose.angle_deg:.3f} deg | "
        f"scale {candidate.pose.scale:.4f} | aspect {candidate.pose.aspect:.4f}",
        (638, 121),
        scale=0.46,
    )
    for row, item in enumerate(report["metrics"]):
        value = "not measured" if item["value"] is None else f"{item['value']:.4g}"
        limit = "" if item["minimum"] is None else f" / min {item['minimum']:.4g}"
        _text(
            output,
            f"{item['name']}: {value}{limit}",
            (638, 167 + row * 43),
            color=(110, 150, 255) if item["status"] == "below limit" else (232, 236, 240),
        )
        _text(output, f"{item['units']} | {item['status']}", (638, 184 + row * 43), scale=0.38)
    edges = report["edges"]
    found = "not captured" if edges["found"] is None else str(edges["found"])
    missing = "unknown" if edges["missing"] is None else str(edges["missing"])
    _text(output, f"Edges: found {found} / trained {edges['trained']}", (638, 501))
    _text(output, f"Missing {missing} | unmeasured {edges['unmeasured']}", (638, 525))
    _text(output, "Fit RMS and coverage are diagnostics, not extra gates.", (638, 568), scale=0.42)
    _text(output, "Fit score is not a probability.", (638, 592), scale=0.45)
    return output


def save_candidate_review(
    directory, image, pattern, candidate, search, *, working_to_source=None, layers=None
):
    """Write a new review folder; refuse to replace an existing folder."""
    target = Path(directory)
    report = candidate_report(pattern, candidate, search, working_to_source=working_to_source)
    report["layers"] = list(DEFAULT_FIT_LAYERS if layers is None else layers)
    report["working_image_size"] = list(image.shape[1::-1])
    report["display_crop_working"] = list(candidate_bounds(image, pattern, candidate))
    fit = draw_matches(image, pattern, [candidate], layers=layers)
    chart = draw_assessment(
        image, pattern, candidate, search, working_to_source=working_to_source, layers=layers
    )
    target.mkdir(parents=True, exist_ok=False)
    for name, pixels in (("fit.png", fit), ("assessment.png", chart)):
        ok, encoded = cv2.imencode(".png", pixels)
        if not ok:
            raise ValueError("Could not encode the review image.")
        (target / name).write_bytes(encoded.tobytes())
    (target / "review.json").write_bytes(
        (json.dumps(report, indent=2, allow_nan=False) + "\n").encode("utf-8")
    )
    return target
