"""Read and write trained patterns and inspections in a versioned NumPy archive."""

from __future__ import annotations

import json
import math
import os
from dataclasses import asdict, dataclass
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import BinaryIO
from zipfile import BadZipFile

import numpy as np

from .feature_weights import _validate_weights
from .locator import (
    CompositeDiagnostics, FeatureDiagnostics, Pattern, Pose, Search, TrainingDiagnostics, _DOFS,
    _seed_parameters, _validate_search,
)

_NATIVE_VERSION = 1
_SCALED_VERSION = 2
_WEIGHTED_VERSION = 3
_ARRAY_NAMES = ("coarse_points", "coarse_normals", "points", "normals")
_WEIGHT_NAMES = ("coarse_weights", "weights")
_INSPECTION_VERSION = 1
_INSPECTION_SEARCH_FIELDS = {
    "angle", "scale", "accept", "ignore_polarity", "start_pose", "start_window", "max_results", "xy_overlap",
    "angle_overlap_deg", "scale_overlap", "coarse_accept", "min_contrast", "score_using_clutter",
    "outside_region_threshold", "aspect", "aspect_fallback",
}
_ARCHIVE_ERRORS = (BadZipFile, EOFError, KeyError, OSError, OverflowError, TypeError, ValueError)


@dataclass(frozen=True)
class InspectionRecipe:
    """Trained pattern and runtime search settings in working pixel coordinates."""

    pattern: Pattern
    search: Search = Search()
    search_roi: tuple[int, int, int, int] | None = None


def save_pattern(path: str | Path, pattern: Pattern) -> None:
    """Save a trained model atomically, including its source geometry and mask."""
    _save_archive(path, pattern)


def save_recipe(path: str | Path, recipe: InspectionRecipe) -> None:
    """Save the pattern and search settings together in one atomic archive."""
    inspection = {"version": _INSPECTION_VERSION, "search": asdict(recipe.search), "search_roi": recipe.search_roi}
    _read_inspection(inspection, recipe.pattern)
    _save_archive(path, recipe.pattern, inspection)


def _save_archive(path: str | Path, pattern: Pattern, inspection: dict | None = None) -> None:
    target = Path(path)
    if not _numeric(pattern.input_scale) or not 0 < pattern.input_scale <= 1:
        raise ValueError("Invalid pattern input scale.")
    weighted = pattern.weights is not None or pattern.coarse_weights is not None
    scaled = pattern.input_scale != 1
    version = _SCALED_VERSION if scaled else _NATIVE_VERSION
    if weighted:
        version = _WEIGHTED_VERSION
    metadata = {
        "version": version,
        "training_roi": pattern.training_roi,
        "origin": pattern.origin,
        "factor": pattern.factor,
        "edge_threshold": pattern.edge_threshold,
        "fine_sigma": pattern.fine_sigma,
        "ignore_polarity": pattern.ignore_polarity,
    }
    if scaled or weighted:
        metadata["input_scale"] = pattern.input_scale
    if pattern.diagnostics is not None:
        metadata["diagnostics"] = asdict(pattern.diagnostics)
    if inspection is not None:
        metadata["inspection"] = inspection
    arrays = {name: getattr(pattern, name) for name in _ARRAY_NAMES}
    if weighted:
        for name, points in zip(_WEIGHT_NAMES, (pattern.coarse_points, pattern.points)):
            values = getattr(pattern, name)
            if values is None:
                raise ValueError("Weighted models require weights for both feature levels.")
            _validate_weights(values, len(points))
            arrays[name] = values
    mask = np.empty(0, dtype=np.uint8) if pattern.mask is None else pattern.mask
    temporary = NamedTemporaryFile(dir=target.parent, prefix=f".{target.name}.", suffix=".tmp", delete=False)
    try:
        with temporary:
            np.savez_compressed(temporary, metadata=np.array(json.dumps(metadata, allow_nan=False)), mask=mask, **arrays)
        os.replace(temporary.name, target)
    finally:
        Path(temporary.name).unlink(missing_ok=True)


def _numeric(value) -> bool:
    return type(value) in (int, float) and math.isfinite(value)


def _read_features(archive, points_name: str, normals_name: str, limit: int):
    points = archive[points_name]
    normals = archive[normals_name]
    if points.ndim != 2 or points.shape[1] != 2 or not 12 <= len(points) <= limit or normals.shape != points.shape:
        raise ValueError("Invalid feature array dimensions.")
    if any(values.dtype.kind != "f" or not np.isfinite(values).all() for values in (points, normals)):
        raise ValueError("Feature arrays require finite floating-point values.")
    if not np.allclose(np.linalg.norm(normals, axis=1), 1, atol=0.001, rtol=0):
        raise ValueError("Invalid feature normals.")
    return points, normals


def _read_level(data: dict, retained: int) -> FeatureDiagnostics:
    if not isinstance(data, dict):
        raise ValueError("Invalid training feature diagnostics.")
    detected, eligible, recorded = (data[key] for key in ("detected", "eligible", "retained"))
    weak = data["weak_dofs"]
    if any(type(value) is not int for value in (detected, eligible, recorded)) or not detected >= eligible >= recorded == retained:
        raise ValueError("Invalid diagnostic feature counts.")
    if not isinstance(weak, list) or len(weak) > len(_DOFS) or any(name not in _DOFS for name in weak):
        raise ValueError("Invalid diagnostic degrees of freedom.")
    return FeatureDiagnostics(detected, eligible, recorded, tuple(weak))


def _read_diagnostics(data: dict | None, coarse_count: int, fine_count: int) -> TrainingDiagnostics | None:
    if data is None:
        return None
    if not isinstance(data, dict):
        raise ValueError("Invalid training diagnostics.")
    flags = tuple(data[key] for key in ("auto_edge_threshold", "auto_coarse_factor", "auto_fine_sigma"))
    if any(type(flag) is not bool for flag in flags):
        raise ValueError("Invalid automatic training flags.")
    composite = data.get("composite")
    detail = None
    if composite is not None:
        if not isinstance(composite, dict):
            raise ValueError("Invalid composite training diagnostics.")
        images, fraction, required, tolerance = (composite[key] for key in
                                                 ("images", "min_occurrence", "required_images", "tolerance_px"))
        if (type(images) is not int or images < 2 or type(required) is not int
                or not _numeric(fraction) or not 0 < fraction <= 1 or required != math.ceil(fraction * images)
                or not _numeric(tolerance) or tolerance <= 0):
            raise ValueError("Invalid composite training diagnostics.")
        detail = CompositeDiagnostics(images, fraction, required, tolerance)
    return TrainingDiagnostics(*flags, _read_level(data["coarse"], coarse_count), _read_level(data["fine"], fine_count),
                               detail)


def _read_metadata(archive) -> dict:
    metadata = json.loads(archive["metadata"].item())
    if not isinstance(metadata, dict) or type(metadata.get("version")) is not int:
        raise ValueError("Unsupported model format version.")
    return metadata


def _read_pattern(archive, metadata: dict) -> Pattern:
    version = metadata["version"]
    if version not in (_NATIVE_VERSION, _SCALED_VERSION, _WEIGHTED_VERSION):
        raise ValueError("Unsupported model format version.")
    expected = {"metadata", "mask", *_ARRAY_NAMES}
    if version == _WEIGHTED_VERSION:
        expected.update(_WEIGHT_NAMES)
    if set(archive.files) != expected:
        raise ValueError("Missing or unexpected archive entries.")
    scale = metadata["input_scale"] if version >= _SCALED_VERSION else 1.0
    if not _numeric(scale) or not 0 < scale <= 1:
        raise ValueError("Invalid pattern input scale.")

    roi = metadata["training_roi"]
    if not isinstance(roi, list) or len(roi) != 4 or any(type(v) is not int for v in roi):
        raise ValueError("Invalid training ROI.")
    x, y, width, height = roi
    if min(x, y) < 0 or min(width, height) < 8:
        raise ValueError("Invalid training ROI.")
    origin = metadata["origin"]
    if not isinstance(origin, list) or len(origin) != 2 or not all(map(_numeric, origin)):
        raise ValueError("Invalid training origin.")

    factor = metadata["factor"]
    threshold, sigma = metadata["edge_threshold"], metadata["fine_sigma"]
    unsigned = metadata["ignore_polarity"]
    if type(factor) is not int or not 1 <= factor <= 8 or type(unsigned) is not bool:
        raise ValueError("Invalid coarse factor or polarity.")
    if not (_numeric(threshold) and threshold > 0 and _numeric(sigma) and 0.2 <= sigma <= 8):
        raise ValueError("Invalid edge threshold or fine sigma.")

    mask = archive["mask"]
    if mask.dtype != np.uint8 or mask.shape not in ((0,), (height, width)):
        raise ValueError("Invalid training mask shape or type.")
    if np.any((mask >= 128) & (mask < 192)):
        raise ValueError("Training mask contains reserved values.")
    coarse_points, coarse_normals = _read_features(archive, "coarse_points", "coarse_normals", 96)
    points, normals = _read_features(archive, "points", "normals", 480)
    coarse_weights = weights = None
    if version == _WEIGHTED_VERSION:
        coarse_weights, weights = (archive[name] for name in _WEIGHT_NAMES)
        _validate_weights(coarse_weights, len(coarse_points))
        _validate_weights(weights, len(points))
    anchor = (x + (width - 1) / 2, y + (height - 1) / 2)
    diagnostics = _read_diagnostics(metadata.get("diagnostics"), len(coarse_points), len(points))
    return Pattern(tuple(origin), anchor, tuple(roi), factor, coarse_points, coarse_normals,
                   points, normals, threshold, sigma, unsigned, mask if mask.size else None, diagnostics, scale,
                   coarse_weights, weights)


def load_pattern(path: str | Path) -> Pattern:
    """Load a saved model without the reference image or Python object decoding."""
    try:
        with np.load(Path(path), allow_pickle=False) as archive:
            return _read_pattern(archive, _read_metadata(archive))
    except _ARCHIVE_ERRORS as error:
        raise ValueError(f"Invalid pattern file {path}: {error}") from error


def _read_search_settings(values) -> Search:
    defaults = asdict(Search())
    if not isinstance(values, dict) or values.keys() != _INSPECTION_SEARCH_FIELDS:
        raise ValueError("Invalid inspection search fields.")
    options = {}
    for name, value in values.items():
        default = defaults[name]
        if isinstance(default, tuple):
            if not isinstance(value, (list, tuple)) or len(value) != len(default) or not all(map(_numeric, value)):
                raise ValueError(f"Invalid search range {name}.")
            value = tuple(value)
        elif name == "start_pose":
            if value is not None:
                if (not isinstance(value, dict) or value.keys() != {"x", "y", "angle_deg", "scale", "aspect"}
                        or not all(map(_numeric, value.values()))):
                    raise ValueError("Invalid inspection start pose.")
                value = Pose(**value)
        elif isinstance(default, bool) or name == "ignore_polarity":
            if type(value) is not bool and (name != "ignore_polarity" or value is not None):
                raise ValueError(f"Invalid search flag {name}.")
        elif not (name == "coarse_accept" and value is None) and not _numeric(value):
            raise ValueError(f"Invalid search value {name}.")
        options[name] = value
    return Search(**options)


def _read_inspection(inspection, pattern: Pattern) -> InspectionRecipe:
    if not isinstance(inspection, dict) or type(inspection.get("version")) is not int:
        raise ValueError("File does not contain an inspection recipe.")
    if inspection["version"] != _INSPECTION_VERSION:
        raise ValueError("Unsupported inspection recipe version.")
    search = _read_search_settings(inspection["search"])
    roi = inspection["search_roi"]
    if roi is not None:
        if (not isinstance(roi, (list, tuple)) or len(roi) != 4 or any(type(value) is not int for value in roi)
                or min(roi[:2]) < 0 or min(roi[2:]) < 8):
            raise ValueError("Search ROI requires nonnegative X and Y and width and height of at least 8.")
        roi = tuple(roi)
    _validate_search(search, pattern)
    if search.start_pose is not None:
        _seed_parameters(search.start_pose, pattern, search, (0, 0))
    return InspectionRecipe(pattern, search, roi)


def load_recipe(path: str | Path | BinaryIO) -> InspectionRecipe:
    """Load an inspection from a path or seekable binary snapshot.

    A binary stream lets integrations validate a content hash and decode exactly
    those bytes, independently of later changes to the file on disk.
    """
    source = path if hasattr(path, "read") else Path(path)
    label = getattr(path, "name", "<stream>") if hasattr(path, "read") else path
    try:
        with np.load(source, allow_pickle=False) as archive:
            metadata = _read_metadata(archive)
            pattern = _read_pattern(archive, metadata)
            return _read_inspection(metadata.get("inspection"), pattern)
    except _ARCHIVE_ERRORS as error:
        raise ValueError(f"Invalid inspection recipe {label}: {error}") from error
