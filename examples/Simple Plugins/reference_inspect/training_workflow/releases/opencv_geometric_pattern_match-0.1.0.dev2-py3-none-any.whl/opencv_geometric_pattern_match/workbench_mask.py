"""Paint a working training mask within the current training rectangle."""

import tkinter as tk
from tkinter import ttk

import cv2

from .training_draft import draw_training_mask
from .workbench_view import ImageView

_BANDS = {"Care (255)": 255, "Clutter only (64)": 64, "Ignore (0)": 0}


class MaskEditor(tk.Toplevel):
    def __init__(self, parent, image, initial_mask, apply):
        super().__init__(parent)
        self.title("Training mask")
        self.transient(parent)
        self.geometry("720x600")
        self.minsize(580, 400)
        self.image = image
        self.mask = initial_mask.copy()
        self.apply = apply
        self.previous = None
        self.last_point = None
        self.stroke = None
        self.band = tk.StringVar(self, "Ignore (0)")
        self.radius = tk.StringVar(self, "6")
        self.info = tk.StringVar(self, "Red ignores edges. Amber counts edges only as clutter.")

        toolbar = ttk.Frame(self, padding=8)
        toolbar.pack(fill="x")
        ttk.Combobox(toolbar, textvariable=self.band, values=tuple(_BANDS), state="readonly", width=18).pack(side="left")
        ttk.Label(toolbar, text="Brush radius").pack(side="left", padx=(10, 4))
        ttk.Spinbox(toolbar, from_=1, to=128, width=5, textvariable=self.radius).pack(side="left")
        ttk.Button(toolbar, text="Fill selected band", command=self.fill).pack(side="left", padx=8)
        self.undo_button = ttk.Button(toolbar, text="Undo", command=self.undo, state="disabled")
        self.undo_button.pack(side="left")
        footer = ttk.Frame(self, padding=8)
        footer.pack(side="bottom", fill="x")
        ttk.Button(footer, text="Apply mask", command=self.commit).pack(side="right")
        ttk.Button(footer, text="Cancel", command=self.destroy).pack(side="right", padx=6)
        ttk.Label(self, textvariable=self.info, padding=(8, 4)).pack(side="bottom", fill="x")
        self.view = ImageView(self)
        self.view.pack(fill="both", expand=True, padx=8)
        self.view.bind("<ButtonPress-1>", self.start_stroke)
        self.view.bind("<B1-Motion>", self.extend_stroke)
        self.view.bind("<ButtonRelease-1>", self.end_stroke)
        self.bind("<Escape>", lambda _: self.destroy())
        self.render()
        self.grab_set()

    def _snapshot(self):
        self.previous = self.mask.copy()
        self.undo_button.state(["!disabled"])

    def fill(self):
        self._snapshot()
        self.mask.fill(_BANDS[self.band.get()])
        self.render()

    def undo(self):
        if self.previous is not None:
            self.mask, self.previous = self.previous, None
            self.undo_button.state(["disabled"])
            self.render()

    def start_stroke(self, event):
        point = self.view.pixel_at(event.x, event.y)
        if point is None:
            return
        try:
            radius = int(self.radius.get())
            if not 1 <= radius <= 128:
                raise ValueError
        except ValueError:
            self.info.set("Enter a brush radius from 1 to 128 working pixels.")
            return
        self.info.set("Red ignores edges. Amber counts edges only as clutter.")
        self._snapshot()
        self.stroke = (radius, _BANDS[self.band.get()])
        self.last_point = point
        cv2.circle(self.mask, point, radius, self.stroke[1], thickness=-1)
        self.render()

    def extend_stroke(self, event):
        if self.stroke is None:
            return
        point = self.view.pixel_at(event.x, event.y, clamp=True)
        if point is None:
            return
        radius, value = self.stroke
        cv2.line(self.mask, self.last_point, point, value, thickness=2 * radius)
        self.last_point = point
        self.render()

    def end_stroke(self, event):
        self.extend_stroke(event)
        self.stroke = self.last_point = None

    def commit(self):
        self.apply(self.mask)
        self.destroy()

    def render(self):
        self.view.show(draw_training_mask(self.image, self.mask))
