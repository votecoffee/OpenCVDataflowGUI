"""Learn repeatable edge geometry from images registered to a common pixel frame."""

from __future__ import annotations

import math
from collections.abc import Iterable

import numpy as np

from .locator import (
    CompositeDiagnostics, FeatureDiagnostics, Pattern, TrainingDiagnostics, _auto_sigma, _auto_threshold, _bins,
    _coarse_factors, _crop, _crop_training_mask, _direction_lookup, _edges, _filter_edges, _nearest_edges, _subsample,
    _subsample_care, _validate_training_options, _weak_dofs,
)


def _unique_probes(pixels: np.ndarray, normals: np.ndarray, unsigned: bool) -> np.ndarray:
    keys = np.column_stack((pixels[:, 1], pixels[:, 0], _bins(normals, 6 if unsigned else 12)))
    return np.unique(keys, axis=0, return_index=True)[1]


def _consensus_level(images, threshold, sigma, care, unsigned, required, radius, limit):
    frame_edges = [_filter_edges(*_edges(image, threshold, sigma), care) for image in images]
    pixels, points, normals = (np.concatenate(values) for values in zip(*frame_edges))
    unique = _unique_probes(pixels, normals, unsigned)
    points, normals = points[unique], normals[unique]
    hits = np.zeros(len(points), dtype=int)
    point_sum = np.zeros_like(points)
    normal_sum = np.zeros_like(normals)
    for image, (frame_pixels, frame_points, frame_normals) in zip(images, frame_edges):
        if not len(frame_points):
            continue
        lookup = _direction_lookup(image.shape, frame_pixels, frame_normals, unsigned)
        edges = np.vstack((np.zeros((1, 4)), np.column_stack((frame_points, frame_normals))))
        for start in range(0, len(points), 8192):
            batch = slice(start, start + 8192)
            rows, matched, matched_normals, *_ = _nearest_edges(
                lookup, edges, points[batch], normals[batch], radius, unsigned)
            # Each seed gets at most one vote from this image.
            rows += start
            # Reorient unsigned normals to agree with the seed before averaging.
            if unsigned:
                reverse = np.sum(normals[rows] * matched_normals, axis=1) < 0
                matched_normals[reverse] *= -1
            hits[rows] += 1
            normal_sum[rows] += matched_normals
            point_sum[rows] += edges[matched, :2]

    accepted = np.flatnonzero(hits >= required)
    # A seed at each of two nearby pixels can vote for the same edge. Prefer stronger support.
    accepted = accepted[np.argsort(-hits[accepted], kind="stable")]
    points = point_sum[accepted] / hits[accepted, None]
    normals = normal_sum[accepted]
    normals /= np.linalg.norm(normals, axis=1)[:, None]
    pixels = np.rint(points).astype(int)
    if care is not None:
        x, y = pixels.T
        eligible = care[y, x]
        pixels, points, normals = pixels[eligible], points[eligible], normals[eligible]
    merged = _unique_probes(pixels, normals, unsigned)
    keep = merged[np.linspace(0, len(merged) - 1, min(limit, len(merged)), dtype=int)]
    points, normals = points[keep], normals[keep]
    weak = _weak_dofs(points, normals) if len(points) >= 12 else ()
    return points, normals, FeatureDiagnostics(len(unique), len(merged), len(keep), weak)


def train_composite(
    images: Iterable[np.ndarray],
    roi: tuple[int, int, int, int] | None = None,
    *,
    origin: tuple[float, float] | None = None,
    mask: np.ndarray | None = None,
    min_occurrence: float = 0.6,
    tolerance_px: float = 1.5,
    edge_threshold: float | None = 45.0,
    coarse_factor: int | None = None,
    fine_sigma: float | None = 0.85,
    ignore_polarity: bool = False,
) -> Pattern:
    """Train from repeatable edges in two or more already registered grayscale images."""
    if not 0 < min_occurrence <= 1:
        raise ValueError("Minimum occurrence must be greater than 0 and at most 1.")
    if not math.isfinite(tolerance_px) or tolerance_px <= 0:
        raise ValueError("Registration tolerance must be positive and finite.")
    _validate_training_options(edge_threshold, coarse_factor, fine_sigma, origin)
    sources = tuple(images)
    if len(sources) < 2:
        raise ValueError("Composite training requires at least two registered images.")
    source_shape = sources[0].shape
    if any(image.shape != source_shape for image in sources):
        raise ValueError("Registered training images must have the same dimensions.")
    frames = [_crop(image, roi)[0] for image in sources]
    x, y = (0, 0) if roi is None else roi[:2]
    height, width = frames[0].shape
    mask = _crop_training_mask(mask, source_shape, (x, y), frames[0].shape)
    care = None if mask is None else mask >= 192
    auto_threshold, auto_sigma = edge_threshold is None, fine_sigma is None
    if auto_sigma:
        fine_sigma = float(np.median([_auto_sigma(image, care) for image in frames]))
    if auto_threshold:
        edge_threshold = float(np.median([_auto_threshold(image, fine_sigma, care) for image in frames]))

    required = math.ceil(min_occurrence * len(frames))
    points, normals, fine = _consensus_level(
        frames, edge_threshold, fine_sigma, care, ignore_polarity, required, tolerance_px, 480)
    if fine.retained < 12:
        raise ValueError("Too few repeatable fine edges. Check image registration, occurrence, mask, and threshold.")
    chosen = None
    fewest_lost = math.inf
    for factor in _coarse_factors(width, height, coarse_factor):
        coarse_images = [_subsample(image, factor) for image in frames]
        coarse_care = _subsample_care(care, factor)
        cp, cn, coarse = _consensus_level(coarse_images, edge_threshold, 0.85, coarse_care, ignore_polarity,
                                         required, max(1.0, tolerance_px / factor), 96)
        if coarse.retained < 12:
            continue
        lost = len(set(coarse.weak_dofs) - set(fine.weak_dofs))
        if lost < fewest_lost:
            chosen = factor, cp, cn, coarse
            fewest_lost = lost
        if lost == 0:
            break
    if chosen is None:
        raise ValueError("Too few repeatable coarse edges. Choose a smaller coarse factor or check registration.")
    factor, coarse_points, coarse_normals, coarse = chosen
    center = np.array(((width - 1) / 2, (height - 1) / 2))
    anchor = (float(x + center[0]), float(y + center[1]))
    datum = anchor if origin is None else tuple(map(float, origin))
    detail = CompositeDiagnostics(len(frames), float(min_occurrence), required, float(tolerance_px))
    diagnostics = TrainingDiagnostics(auto_threshold, coarse_factor is None, auto_sigma, coarse, fine, detail)
    return Pattern(datum, anchor, (x, y, width, height), factor, (coarse_points + 0.5) * factor - 0.5 - center,
                   coarse_normals, points - center, normals, float(edge_threshold), float(fine_sigma),
                   bool(ignore_polarity), mask, diagnostics)
