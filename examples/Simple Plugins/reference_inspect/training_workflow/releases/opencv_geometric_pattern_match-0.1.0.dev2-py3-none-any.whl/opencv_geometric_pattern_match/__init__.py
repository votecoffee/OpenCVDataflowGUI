"""Edge-based two-dimensional pattern training and alignment."""

from .composite_training import train_composite
from .feature_weights import weight_pattern
from .locator import (
    CompositeDiagnostics, FeatureDiagnostics, Match, Pattern, Pose, RejectedCandidate, Search, SearchReview, TrainingDiagnostics,
    draw_match, draw_matches, draw_rejections, draw_training, locate, locate_all, review_search, train,
)
from .persistence import InspectionRecipe, load_pattern, load_recipe, save_pattern, save_recipe
from .runtime import SearchRuntime
from .shape_training import CircularArc, Line, train_shapes

__all__ = ["CircularArc", "CompositeDiagnostics", "FeatureDiagnostics", "InspectionRecipe", "Line", "Match", "Pattern", "Pose", "RejectedCandidate", "Search", "SearchReview",
           "SearchRuntime", "TrainingDiagnostics", "draw_match", "draw_matches", "draw_rejections", "draw_training",
           "load_pattern", "load_recipe", "locate", "locate_all", "review_search", "save_pattern", "save_recipe", "train", "train_composite", "train_shapes",
           "weight_pattern"]
