"""Image-file command line interface and synthetic demonstration."""

from __future__ import annotations

import argparse
import json
import sys
from concurrent.futures.process import BrokenProcessPool
from dataclasses import asdict, replace
from pathlib import Path
from time import perf_counter

import cv2
import numpy as np

from .composite_training import train_composite
from .feature_weights import weight_pattern
from .image_input import input_scale, prepare_image, read_gray, read_mask, working_to_source
from .locator import Pattern, Pose, Search, draw_matches, draw_training, locate_all, review_search, train
from .persistence import InspectionRecipe, load_pattern, load_recipe, save_pattern, save_recipe
from .runtime import SearchRuntime, _MAX_WORKERS
from .shape_training import _train_shape_file


def _demo_images():
    reference = np.full((144, 156), 40, np.uint8)
    outline = np.array([(20, 22), (109, 22), (135, 48), (135, 112), (96, 112),
                        (96, 128), (24, 128), (24, 91), (14, 91), (14, 51), (20, 51)])
    cv2.fillPoly(reference, [outline], 173, lineType=cv2.LINE_AA)
    cv2.circle(reference, (46, 53), 14, 47, thickness=-1, lineType=cv2.LINE_AA)
    cv2.circle(reference, (112, 85), 9, 47, thickness=-1, lineType=cv2.LINE_AA)
    cv2.rectangle(reference, (36, 91), (72, 106), 68, thickness=-1, lineType=cv2.LINE_AA)
    cv2.line(reference, (65, 43), (91, 65), 110, thickness=4, lineType=cv2.LINE_AA)
    truth = Pose(207.4, 137.7, 23.4, 1.09)
    transform = truth.matrix()
    transform[:, 2] -= transform[:, :2] @ [(reference.shape[1] - 1) / 2, (reference.shape[0] - 1) / 2]
    scene = cv2.warpAffine(reference, transform, (360, 280), borderValue=40)
    scene = np.clip(scene.astype(np.float32) * 0.76 + 33, 0, 255).astype(np.uint8)
    cv2.rectangle(scene, (228, 165), (271, 196), 100, thickness=-1)
    cv2.rectangle(scene, (25, 33), (89, 109), 152, thickness=3)
    cv2.circle(scene, (70, 192), 25, 145, thickness=4)
    cv2.line(scene, (289, 30), (334, 72), 182, thickness=4)
    return reference, scene, truth


def _auto_or_float(value: str) -> float | None:
    return None if value.lower() == "auto" else float(value)


def _training_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--max-side", type=int, metavar="PIXELS",
                        help="Downsample the reference to this longest side. Save the same scale for future scenes.")
    parser.add_argument("--train-roi", type=int, nargs=4, metavar=("X", "Y", "W", "H"), help="Train inside this rectangle in working image pixels.")
    parser.add_argument("--train-origin", type=float, nargs=2, metavar=("X", "Y"), help="Pattern datum in working reference pixels (default ROI center).")
    parser.add_argument("--train-mask", type=Path, help="Aligned grayscale mask with care and exclusion bands.")
    _feature_options(parser, image_training=True)


def _feature_options(parser: argparse.ArgumentParser, *, image_training: bool) -> None:
    number = _auto_or_float if image_training else float
    auto = " or 'auto'" if image_training else ""
    parser.add_argument("--edge-threshold", type=number, default=45.0,
                        help=f"High Canny threshold in Sobel gradient units{auto} (default 45).")
    parser.add_argument("--coarse-factor", type=int, help="Coarse subsampling factor 1 through 8 (default automatic).")
    parser.add_argument("--fine-sigma", type=number, default=0.85,
                        help=f"Fine Gaussian smoothing sigma in pixels{auto} (default 0.85).")
    parser.add_argument("--ignore-polarity", action="store_true", help="Train a pattern that allows opposite edge contrast.")
    parser.add_argument("--training-overlay", "--preview", type=Path, help="Save a PNG preview of the trained edges and origin.")
    parser.add_argument("--preview-level", choices=("coarse", "fine"), default="fine", help="Feature level shown in the training overlay.")


def _search_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--search-roi", type=int, nargs=4, metavar=("X", "Y", "W", "H"), help="Search inside this rectangle in working scene pixels.")
    parser.add_argument("--start-pose", type=float, nargs=4, metavar=("X", "Y", "DEG", "SCALE"),
                        help="Refine a nearby pose of the training origin in working scene pixels.")
    parser.add_argument("--start-aspect", type=float, help="Aspect ratio of --start-pose (default 1).")
    parser.add_argument("--start-window", type=float, default=Search.start_window,
                        help="Maximum search-anchor displacement per axis from the start pose in pixels (default 8).")
    parser.add_argument("--angle", type=float, nargs=3, default=Search.angle, metavar=("MIN", "MAX", "STEP"), help="Angle bounds and maximum coarse step in degrees.")
    parser.add_argument("--scale", type=float, nargs=3, default=Search.scale, metavar=("MIN", "MAX", "STEP"),
                        help="Geometric-mean scale bounds and maximum coarse step.")
    parser.add_argument("--aspect", type=float, nargs=2, default=Search.aspect, metavar=("MIN", "MAX"),
                        help="Ratio of pattern x scale to y scale during fine fitting (default 1 1).")
    parser.add_argument("--aspect-fallback", action="store_true",
                        help="Use the aspect range only after a similarity candidate fails acceptance.")
    parser.add_argument("--accept", type=float, default=Search.accept, help="Minimum match score from 0 to 1 (default 0.55).")
    parser.add_argument("--coarse-accept", type=float, help="Minimum coarse candidate score from 0 to 1 (default disabled).")
    parser.add_argument("--outside-region-threshold", type=float, default=Search.outside_region_threshold,
                        help="Maximum fraction of model edges outside the region to forgive in the final score (default 0).")
    parser.add_argument("--min-contrast", type=float, default=Search.min_contrast,
                        help="Minimum mean gray-level difference across matched edges (default 0).")
    parser.add_argument("--score-using-clutter", action="store_true",
                        help="Report clutter and reduce the final score for unexplained scene edges.")
    parser.add_argument("--max-results", type=int, default=Search.max_results, help="Maximum matches to return, from 1 to 100 (default 1).")
    parser.add_argument("--xy-overlap", type=float, default=Search.xy_overlap,
                        help="Maximum fraction of the smaller projected training rectangle that can overlap (default 0.8).")
    parser.add_argument("--angle-overlap", type=float, default=Search.angle_overlap_deg,
                        help="Largest angular difference in degrees for duplicate suppression (default 360).")
    parser.add_argument("--scale-overlap", type=float, default=Search.scale_overlap,
                        help="Largest ratio of the two scales for duplicate suppression (default 1.4).")


def _scene_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--search-mask", type=Path, help="Aligned 8-bit grayscale scene mask. Values below 128 exclude edges.")
    parser.add_argument("--overlay", type=Path, help="Save a PNG with pose axes and found and missing model edges.")
    parser.add_argument("--review", action="store_true", help="Include counts and sampled reasons for candidate rejections.")


def _prepare_reference(reference: np.ndarray, args: argparse.Namespace):
    scale = input_scale(reference.shape, args.max_side)
    working = prepare_image(reference, scale)
    mask = (read_mask(args.train_mask, reference.shape, working.shape, training=True)
            if args.train_mask is not None else None)
    return working, mask, scale


def _train_image(reference: np.ndarray, args: argparse.Namespace) -> Pattern:
    working, mask, scale = _prepare_reference(reference, args)
    pattern = train(working, args.train_roi, origin=args.train_origin, mask=mask,
                    edge_threshold=args.edge_threshold, coarse_factor=args.coarse_factor,
                    fine_sigma=args.fine_sigma, ignore_polarity=args.ignore_polarity)
    _write_training_preview(working, pattern, args)
    return replace(pattern, input_scale=scale)


def _train_composite_images(references: list[np.ndarray], args: argparse.Namespace) -> Pattern:
    if len(references) < 2:
        raise ValueError("Composite training requires at least two registered images.")
    if any(image.shape != references[0].shape for image in references[1:]):
        raise ValueError("Registered training images must have the same dimensions.")
    working, mask, scale = _prepare_reference(references[0], args)
    images = [working, *(prepare_image(image, scale) for image in references[1:])]
    pattern = train_composite(images, args.train_roi, origin=args.train_origin, mask=mask,
                              min_occurrence=args.min_occurrence, tolerance_px=args.tolerance_px,
                              edge_threshold=args.edge_threshold, coarse_factor=args.coarse_factor,
                              fine_sigma=args.fine_sigma, ignore_polarity=args.ignore_polarity)
    _write_training_preview(working, pattern, args)
    return replace(pattern, input_scale=scale)


def _write_training_preview(image: np.ndarray, pattern: Pattern, args: argparse.Namespace) -> None:
    if args.training_overlay:
        preview = draw_training(image, pattern, coarse=args.preview_level == "coarse")
        args.training_overlay.write_bytes(cv2.imencode(".png", preview)[1].tobytes())


def _training_report(pattern: Pattern) -> dict:
    return {"training_origin": pattern.origin, "training_roi": pattern.training_roi,
            "input_scale": pattern.input_scale,
            "coarse_factor": pattern.factor, "fine_sigma": pattern.fine_sigma,
            "edge_threshold": pattern.edge_threshold, "ignore_polarity": pattern.ignore_polarity,
            "has_training_mask": pattern.mask is not None,
            "has_feature_weights": pattern.weights is not None,
            "coarse_feature_count": len(pattern.coarse_points), "fine_feature_count": len(pattern.points),
            "training_diagnostics": asdict(pattern.diagnostics) if pattern.diagnostics is not None else None}


def _check_output_paths(inputs: tuple[Path | None, ...], outputs: tuple[Path | None, ...]) -> None:
    used = {path.resolve() for path in inputs if path is not None}
    for path in outputs:
        if path is None:
            continue
        resolved = path.resolve()
        if resolved in used:
            raise ValueError(f"Output path conflicts with another file argument: {path}")
        used.add(resolved)


def _result_report(result):
    payload = asdict(result)
    del payload["edge_matches"]
    del payload["outside_region_indices"]
    return payload


def _recipe_from_args(pattern: Pattern, args: argparse.Namespace) -> InspectionRecipe:
    if args.start_aspect is not None and args.start_pose is None:
        raise ValueError("--start-aspect requires --start-pose.")
    start_aspect = 1.0 if args.start_aspect is None else args.start_aspect
    seed = Pose(*args.start_pose, aspect=start_aspect) if args.start_pose is not None else None
    search = Search(tuple(args.angle), tuple(args.scale), args.accept,
                    start_pose=seed, start_window=args.start_window,
                    max_results=args.max_results, xy_overlap=args.xy_overlap,
                    angle_overlap_deg=args.angle_overlap, scale_overlap=args.scale_overlap,
                    coarse_accept=args.coarse_accept, min_contrast=args.min_contrast,
                    score_using_clutter=args.score_using_clutter, outside_region_threshold=args.outside_region_threshold,
                    aspect=tuple(args.aspect), aspect_fallback=args.aspect_fallback)
    return InspectionRecipe(pattern, search, tuple(args.search_roi) if args.search_roi is not None else None)


def _inspect_scene(scene: np.ndarray, recipe: InspectionRecipe, *, search_mask: Path | None,
                   overlay: Path | None, review_candidates: bool, runtime: SearchRuntime) -> dict:
    pattern, search, roi = recipe.pattern, recipe.search, recipe.search_roi
    working = prepare_image(scene, pattern.input_scale)
    mask = read_mask(search_mask, scene.shape, working.shape) if search_mask is not None else None
    start = perf_counter()
    options = {"roi": roi, "mask": mask, "capture_fit": overlay is not None, "runtime": runtime}
    review = review_search(working, pattern, search, **options) if review_candidates else None
    results = review.matches if review is not None else locate_all(working, pattern, search, **options)
    payload = _training_report(pattern)
    payload["search_mode"] = "refine_start_pose" if search.start_pose is not None else "search_image"
    payload["search"] = asdict(search)
    payload["search_roi"] = roi
    payload["has_search_mask"] = mask is not None
    payload["outside_region_threshold"] = search.outside_region_threshold
    payload["aspect_bounds"] = search.aspect
    payload["aspect_fallback"] = search.aspect_fallback
    payload["elapsed_ms"] = round((perf_counter() - start) * 1000, 2)
    payload["source_size"] = list(scene.shape[::-1])
    payload["working_size"] = list(working.shape[::-1])
    payload["working_to_source_scene"] = working_to_source(scene.shape, working.shape).tolist()
    payload["matches"] = [{**_result_report(result), "pattern_to_scene": result.pose.matrix().tolist()} for result in results]
    payload["match"] = _result_report(results[0]) if results else None
    if review is not None:
        payload["rejection_counts"] = review.rejection_counts
        payload["rejected_candidates"] = [_result_report(candidate) for candidate in review.rejected]
    if results:
        payload["pattern_to_scene"] = payload["matches"][0]["pattern_to_scene"]
        if overlay is not None:
            overlay.write_bytes(cv2.imencode(".png", draw_matches(working, pattern, results))[1].tobytes())
    return payload


def _run_scene(scene: np.ndarray, recipe: InspectionRecipe, args: argparse.Namespace, truth: Pose | None = None) -> int:
    with SearchRuntime(args.workers) as runtime:
        payload = _inspect_scene(scene, recipe, search_mask=args.search_mask, overlay=args.overlay,
                                 review_candidates=args.review, runtime=runtime)
    if truth is not None:
        payload["ground_truth"] = asdict(truth)
    print(json.dumps(payload, indent=2))
    return 0 if payload["matches"] else 1


def _batch_inputs(path: Path) -> list[tuple[str, Path, Path | None]]:
    manifest = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(manifest, dict) or manifest.keys() != {"scenes"}:
        raise ValueError("Batch manifest requires a scenes array.")
    entries = manifest["scenes"]
    if not isinstance(entries, list) or not entries:
        raise ValueError("Batch manifest requires at least one scene.")
    directory = path.resolve().parent
    seen = set()
    inputs = []
    for index, entry in enumerate(entries, 1):
        required = {"id", "image"}
        if (not isinstance(entry, dict) or not required <= entry.keys() <= required | {"mask"}
                or any(not isinstance(value, str) or not value.strip() for value in entry.values())):
            raise ValueError(f"Batch entry {index} needs a nonempty id and image, with an optional mask path.")
        scene_id = entry["id"]
        if scene_id in seen:
            raise ValueError(f"Duplicate batch scene ID {scene_id!r}.")
        seen.add(scene_id)
        inputs.append((scene_id, directory / entry["image"], directory / entry["mask"] if "mask" in entry else None))
    return inputs


def _run_batch(args: argparse.Namespace, runtime: SearchRuntime) -> int:
    recipe = load_recipe(args.recipe)
    inputs = _batch_inputs(args.manifest)
    overlays = [None] * len(inputs)
    if args.overlay_dir is not None:
        overlays = [args.overlay_dir / f"{index:04d}.png" for index in range(1, len(inputs) + 1)]
        protected = (args.recipe, args.manifest, *(path for _, image, mask in inputs for path in (image, mask)))
        _check_output_paths(protected, (args.overlay_dir, *overlays))
        args.overlay_dir.mkdir(parents=True)

    records = []
    summary = {"matched_scenes": 0, "no_match_scenes": 0, "error_scenes": 0, "matches": 0}
    for (scene_id, image, mask), overlay in zip(inputs, overlays):
        record = {"id": scene_id, "image": str(image), "mask": str(mask) if mask is not None else None}
        try:
            result = _inspect_scene(read_gray(image), recipe, search_mask=mask, overlay=overlay,
                                    review_candidates=args.review, runtime=runtime)
        except (OSError, ValueError, cv2.error, BrokenProcessPool) as error:
            record.update(status="error", error=str(error))
            summary["error_scenes"] += 1
        else:
            count = len(result["matches"])
            status = "matched" if count else "no_match"
            record.update(status=status, overlay=str(overlay) if overlay is not None and count else None, result=result)
            summary[f"{status}_scenes"] += 1
            summary["matches"] += count
        records.append(record)
    print(json.dumps({"recipe": str(args.recipe), "manifest": str(args.manifest), "summary": summary, "scenes": records},
                     indent=2))
    if summary["error_scenes"]:
        return 2
    return 1 if summary["no_match_scenes"] else 0


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv[:1] == ["workbench"]:
        parser = argparse.ArgumentParser(prog="ogpm workbench", description="Open the graphical training and inspection workbench.")
        parser.parse_args(argv[1:])
        try:
            from tkinter import TclError

            from .workbench import launch
        except ImportError as error:
            parser.error(f"The workbench requires Python with Tk installed. {error}")
        try:
            launch()
        except TclError as error:
            parser.error(str(error))
        return 0
    modes = ("train", "train-shapes", "train-composite", "weight-pattern", "run", "save-recipe", "run-recipe", "run-batch")
    mode = argv.pop(0) if argv and argv[0] in modes else None
    epilog = "Angles are counterclockwise in image coordinates. Exit status 1 means no accepted match."
    if mode is None:
        epilog += " Use train, train-shapes, or train-composite to save a model, weight-pattern to weight regions, and run to search."
        epilog += " Use save-recipe, run-recipe, and run-batch to reuse an inspection, or workbench for the GUI."
    if mode == "run-batch":
        epilog = "Exit status 0 means every scene matched, 1 means a scene had no match, and 2 means an error occurred."
    parser = argparse.ArgumentParser(prog=f"ogpm {mode}" if mode else "ogpm", description=__doc__, epilog=epilog)
    if mode == "train":
        parser.add_argument("reference", type=Path, help="Image containing the training pattern.")
        parser.add_argument("pattern", type=Path, help="Destination for the trained pattern archive.")
    elif mode == "train-shapes":
        parser.add_argument("geometry", type=Path, help="JSON frame, origin, and directed geometry.")
        parser.add_argument("pattern", type=Path, help="Destination for the trained pattern archive.")
        _feature_options(parser, image_training=False)
    elif mode == "train-composite":
        parser.add_argument("pattern", type=Path, help="Destination for the trained pattern archive.")
        parser.add_argument("references", nargs="+", type=Path, help="Registered training images in the same pixel frame.")
        parser.add_argument("--min-occurrence", type=float, default=0.6,
                            help="Minimum fraction of images supporting an edge (default 0.6).")
        parser.add_argument("--tolerance-px", type=float, default=1.5,
                            help="Maximum fine-edge displacement in working pixels (default 1.5).")
    elif mode == "weight-pattern":
        parser.add_argument("pattern", type=Path, help="Saved pattern archive.")
        parser.add_argument("output", type=Path, help="Destination for the weighted copy.")
        parser.add_argument("--region", type=float, nargs=5, action="append", required=True, metavar=("X", "Y", "W", "H", "WEIGHT"),
                            help="Set the weight within a rectangle in training ROI-relative working pixels. Repeat as needed.")
    elif mode == "run":
        parser.add_argument("pattern", type=Path, help="Saved pattern archive.")
        parser.add_argument("scene", type=Path, help="Image to search.")
    elif mode == "save-recipe":
        parser.add_argument("pattern", type=Path, help="Saved pattern archive.")
        parser.add_argument("recipe", type=Path, help="Destination for the pattern and search settings.")
    elif mode == "run-recipe":
        parser.add_argument("recipe", type=Path, help="Saved inspection recipe.")
        parser.add_argument("scene", type=Path, help="Image to search.")
    elif mode == "run-batch":
        parser.add_argument("recipe", type=Path, help="Saved inspection recipe for every scene.")
        parser.add_argument("manifest", type=Path, help="JSON list of scene IDs, image paths, and optional mask paths.")
        parser.add_argument("--overlay-dir", type=Path, help="New directory for numbered measured fit overlays.")
        parser.add_argument("--review", action="store_true", help="Include candidate rejection diagnostics per scene.")
    else:
        parser.add_argument("reference", type=Path, nargs="?", help="Image containing the training pattern.")
        parser.add_argument("scene", type=Path, nargs="?", help="Image to search.")
        parser.add_argument("--demo", action="store_true", help="Run on a synthetic bracket with a known pose.")
    if mode in (None, "train", "train-composite"):
        _training_options(parser)
    if mode in (None, "run", "save-recipe"):
        _search_options(parser)
    if mode in (None, "run", "run-recipe"):
        _scene_options(parser)
    if mode in (None, "run", "run-recipe", "run-batch"):
        parser.add_argument("--workers", type=int, choices=range(1, _MAX_WORKERS + 1), default=1,
                            help="Maximum fine-fit worker processes for large searches (default 1).")
    args = parser.parse_args(argv)
    try:
        if mode == "run-batch":
            with SearchRuntime(args.workers) as runtime:
                return _run_batch(args, runtime)
        if mode == "weight-pattern":
            _check_output_paths((args.pattern,), (args.output,))
            pattern = weight_pattern(load_pattern(args.pattern), args.region)
            save_pattern(args.output, pattern)
            print(json.dumps({"pattern": str(args.output), **_training_report(pattern)}, indent=2))
            return 0
        if mode == "run":
            _check_output_paths((args.pattern, args.scene, args.search_mask), (args.overlay,))
            return _run_scene(read_gray(args.scene), _recipe_from_args(load_pattern(args.pattern), args), args)
        if mode == "save-recipe":
            _check_output_paths((args.pattern,), (args.recipe,))
            recipe = _recipe_from_args(load_pattern(args.pattern), args)
            save_recipe(args.recipe, recipe)
            print(json.dumps({"recipe": str(args.recipe), "search": asdict(recipe.search),
                              "search_roi": recipe.search_roi, **_training_report(recipe.pattern)}, indent=2))
            return 0
        if mode == "run-recipe":
            _check_output_paths((args.recipe, args.scene, args.search_mask), (args.overlay,))
            return _run_scene(read_gray(args.scene), load_recipe(args.recipe), args)
        if mode == "train":
            _check_output_paths((args.reference, args.train_mask), (args.pattern, args.training_overlay))
            pattern = _train_image(read_gray(args.reference), args)
            save_pattern(args.pattern, pattern)
            print(json.dumps({"pattern": str(args.pattern), **_training_report(pattern)}, indent=2))
            return 0
        if mode == "train-composite":
            _check_output_paths((*args.references, args.train_mask), (args.pattern, args.training_overlay))
            pattern = _train_composite_images([read_gray(path) for path in args.references], args)
            save_pattern(args.pattern, pattern)
            print(json.dumps({"pattern": str(args.pattern), "train_mode": "composite", **_training_report(pattern)}, indent=2))
            return 0
        if mode == "train-shapes":
            _check_output_paths((args.geometry,), (args.pattern, args.training_overlay))
            pattern = _train_shape_file(args.geometry, edge_threshold=args.edge_threshold, coarse_factor=args.coarse_factor,
                                        fine_sigma=args.fine_sigma, ignore_polarity=args.ignore_polarity)
            if args.training_overlay:
                _, _, width, height = pattern.training_roi
                if width * height > 20_000_000:
                    raise ValueError("Shape frame is too large for a training preview.")
                _write_training_preview(np.full((height, width), 40, np.uint8), pattern, args)
            save_pattern(args.pattern, pattern)
            print(json.dumps({"pattern": str(args.pattern), "train_mode": "shapes", **_training_report(pattern)}, indent=2))
            return 0
        _check_output_paths((args.reference, args.scene, args.train_mask, args.search_mask),
                            (args.training_overlay, args.overlay))
        if args.demo:
            if args.reference or args.scene or args.train_roi or args.train_origin or args.max_side is not None:
                parser.error("--demo supplies its own reference, scene, region, origin, and image scale.")
            reference, scene, truth = _demo_images()
            return _run_scene(scene, _recipe_from_args(_train_image(reference, args), args), args, truth)
        if args.reference is None or args.scene is None:
            parser.error("Provide reference and scene images or use --demo.")
        pattern = _train_image(read_gray(args.reference), args)
        return _run_scene(read_gray(args.scene), _recipe_from_args(pattern, args), args)
    except (OSError, ValueError, cv2.error, BrokenProcessPool) as error:
        parser.error(str(error))
