"""Optional, Qt-free OpenCVDataflowGUI blocks for geometric recipes.

Importing this module requires the host's ``opencv_dataflow`` package. The core
matcher and archive codec have no dependency on that package or on a GUI toolkit.
"""

from __future__ import annotations

import hashlib
import io
import re
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path, PurePosixPath

import numpy as np

from opencv_dataflow.core import Block, Port, Result
from opencv_dataflow.features import overlay_image
from opencv_dataflow.graphics_layers import GraphicDrawing, draw_object, graphic_object
from opencv_dataflow.payloads import NO_VALUE, frame, metadata, require_same_frame
from opencv_dataflow.poses import make_pose
from opencv_dataflow.processing import gray_image
from opencv_dataflow.selection import SELECTION_INPUTS, selection_mask

from .image_input import input_scale, prepare_image, prepare_mask, working_to_source
from .completed_review import BINDING, CompletedMatchRecord, capture_completed
from .locator import Search, locate_all, review_search
from .persistence import InspectionRecipe, _INSPECTION_VERSION, _read_inspection, load_recipe
from .runtime import SearchRuntime, _MAX_WORKERS
from .training_draft import ImageSnapshot, TrainingDraft, _map_model_arrays, _snapshot_recipe


def _recipe_path(project_dir, relative_path):
    if project_dir is None:
        raise ValueError("Save the project before resolving its inspection recipe")
    if not isinstance(relative_path, str) or not relative_path.strip():
        raise ValueError("Select a project-relative inspection recipe")
    portable = PurePosixPath(relative_path)
    if (portable.is_absolute() or "\\" in relative_path or ":" in relative_path
            or ".." in portable.parts or portable.suffix.lower() != ".npz"):
        raise ValueError("Recipe path must be a project-relative .npz path using forward slashes")
    root = Path(project_dir).resolve()
    target = (root / relative_path).resolve()
    if not target.is_relative_to(root):
        raise ValueError("Recipe path resolves outside the project directory")
    return target


def _training_image_path(project_dir, relative_path, kind="reference"):
    target = _recipe_path(project_dir, relative_path).with_suffix(f".{kind}.png")
    if not target.resolve().is_relative_to(Path(project_dir).resolve()):
        raise ValueError("Training image resolves outside the project directory")
    return target


def recipe_reference(project_dir: str | Path, relative_path: str) -> dict[str, str]:
    """Validate an archive and return pinned parameters for a host matcher block."""
    content = _recipe_path(project_dir, relative_path).read_bytes()
    load_recipe(io.BytesIO(content))
    return {"recipe_path": relative_path, "recipe_sha256": hashlib.sha256(content).hexdigest()}


def _pinned_archive(project_dir, parameters):
    path = _recipe_path(project_dir, parameters["recipe_path"])
    content = path.read_bytes()
    digest = hashlib.sha256(content).hexdigest()
    if digest != parameters["recipe_sha256"].lower():
        raise ValueError("Recipe SHA-256 mismatch; validate and pin the intended recipe again")
    return content, digest


@dataclass(frozen=True, eq=False, init=False)
class GeometricRecipeModel:
    """A runtime recipe packet with private, read-only model buffers."""

    _recipe: InspectionRecipe = field(repr=False)
    model_id: str
    sha256: str | None

    def __init__(self, recipe: InspectionRecipe, *, sha256: str | None = None):
        object.__setattr__(self, "_recipe", _snapshot_recipe(recipe))
        object.__setattr__(self, "model_id", sha256 if sha256 is not None else uuid.uuid4().hex)
        object.__setattr__(self, "sha256", sha256)

    @property
    def recipe(self) -> InspectionRecipe:
        # Separate NumPy headers allow each caller to reshape a view without
        # changing the packet's geometry. Pixel and feature buffers stay shared.
        return _map_model_arrays(self._recipe, np.ndarray.view)

    def __deepcopy__(self, memo):
        return self

    def describe(self):
        return {
            "model": "ogpm_recipe_model_v1", "id": self.model_id, "recipe_sha256": self.sha256,
            "features": len(self._recipe.pattern.points),
            "input_scale": self._recipe.pattern.input_scale,
        }


def _homogeneous(matrix):
    return np.vstack((matrix, [0., 0., 1.]))


def _map(points, matrix):
    points = np.asarray(points, dtype=float).reshape(-1, 2)
    return np.c_[points, np.ones(len(points))] @ matrix[:2].T


def _record(result, pattern, to_input, image, model_id):
    """Use a datum pose and a separate ROI-local pattern-to-image transform."""
    datum_matrix = to_input @ _homogeneous(result.pose.matrix())
    x, y, width, height = pattern.training_roi
    patch_offset = np.eye(3)
    patch_offset[:2, 2] = np.subtract((x, y), pattern.origin)
    patch_matrix = datum_matrix @ patch_offset
    corners = _map(((0, 0), (width - 1, 0), (width - 1, height - 1), (0, height - 1)), patch_matrix)
    size, payload = [image.shape[1], image.shape[0]], metadata(image)
    record = {
        "score": result.score,
        "center": _map((((width - 1) / 2, (height - 1) / 2),), patch_matrix)[0].tolist(),
        "corners": corners.tolist(),
        "pose": make_pose(datum_matrix, size, payload),
        "transform": {
            "model": "image_pattern_pose_v1",
            "source_to_target": patch_matrix.tolist(),
            "source_size": [width, height],
            "target_size": size,
            "source_payload": {"spatial": frame([width, height], f"ogpm:{model_id}")},
            "target_payload": payload,
        },
        "coverage": result.coverage,
        "fit_error_working_px": result.fit_error_px,
        "coarse_score": result.coarse_score,
        "contrast": result.contrast,
        "clutter": result.clutter,
        "outside_region_fraction": result.outside_region_fraction,
        "measured_edge_count": len(result.edge_matches) if result.edge_matches is not None else None,
    }
    if hasattr(result, "reason"):
        record["reason"] = result.reason
    return record


def _dot(point, color):
    # A two-vertex zero-length polyline renders a small dot in the host renderer.
    return graphic_object("polyline", (point, point), color, thickness=2)


def _drawings(pattern, matches, rejected, to_input):
    layers = {name: [] for name in (
        "trained projections", "fit residuals", "missing edges", "outside or unmeasured edges",
        "found edges", "rejected candidates", "pose axes",
    )}
    relative = pattern.points + np.subtract(pattern.anchor, pattern.origin)
    for result in matches:
        matrix = to_input @ _homogeneous(result.pose.matrix())
        projected = _map(relative, matrix)
        layers["trained projections"].extend(_dot(point, (145, 145, 145)) for point in projected)
        found = {i for i, _, _ in result.edge_matches or ()}
        outside = set(result.outside_region_indices)
        for index, point in enumerate(projected):
            if index in found:
                continue
            unmeasured = result.edge_matches is None or index in outside
            name = "outside or unmeasured edges" if unmeasured else "missing edges"
            layers[name].append(_dot(point, (30, 185, 245) if unmeasured else (45, 45, 240)))
        for index, x, y in result.edge_matches or ():
            observed = _map(((x, y),), to_input)[0]
            layers["fit residuals"].append(graphic_object(
                "polyline", (projected[index], observed), (50, 150, 49), thickness=1,
            ))
            layers["found edges"].append(_dot(observed, (80, 235, 80)))
        origin, axis_x, axis_y = _map(((0, 0), (20, 0), (0, 13)), matrix)
        layers["pose axes"].extend((
            graphic_object("marker", (origin,), (21, 214, 255)),
            graphic_object("polyline", (origin, axis_x), (40, 40, 240)),
            graphic_object("polyline", (origin, axis_y), (40, 220, 40)),
            graphic_object("text", (axis_x,), (40, 40, 240), text="x"),
            graphic_object("text", (axis_y,), (40, 220, 40), text="y"),
        ))
    for result in rejected:
        matrix = to_input @ _homogeneous(result.pose.matrix())
        origin = _map(((0, 0),), matrix)[0]
        layers["rejected candidates"].extend((
            graphic_object("marker", (origin,), (30, 150, 245)),
            graphic_object("text", (origin,), (30, 150, 245), text=result.reason),
        ))
    return {name: GraphicDrawing(tuple(objects), source="image") for name, objects in layers.items() if objects}


_FILE_DEFAULTS = {"recipe_path": "", "recipe_sha256": ""}
_FILE_HELP = {
    "recipe_path": "Project-relative .npz inspection recipe, using forward slashes.",
    "recipe_sha256": "SHA-256 of the validated recipe bytes. Updating a recipe requires a new pin.",
}
_MATCH_DEFAULTS = {"review_rejections": True, "render_overlay": True, "match_workers": 1}
_MATCH_HELP = {
    "review_rejections": "Retain rejection counts and a bounded candidate sample for review.",
    "render_overlay": "Show the fit overlay in the result images and filmstrip. "
    "Turn off for timing or pose-only execution.",
    "match_workers": "Maximum fine-fit worker processes for large searches. One fits in the host process.",
}
_MATCH_OUTPUTS = (
    Port("matches", "data"), Port("count", "number"), Port("score", "number"),
    Port("transform", "data"), Port("pose", "data"), Port("points", "data"),
    Port("review", "data"), Port("overlay"),
)


class _PinnedRecipeBlock(Block):
    plugin_dialog_label = "Train geometric recipe…"
    plugin_dialog_modeless = True

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._verified_model = None

    def create_plugin_dialog(self, parent, parameters, context):
        from .qt_training import GeometricTrainingDialog

        return GeometricTrainingDialog(parent, parameters, context)

    def validate_parameters(self, parameters=None):
        super().validate_parameters(parameters)
        values = self.parameters if parameters is None else parameters
        digest = values["recipe_sha256"]
        if not isinstance(digest, str) or re.fullmatch(r"[0-9a-fA-F]{64}", digest) is None:
            raise ValueError("Recipe SHA-256 must contain exactly 64 hexadecimal characters")
        _recipe_path(self.project_dir, values["recipe_path"])

    def load_pinned_model(self):
        content, digest = _pinned_archive(self.project_dir, self.parameters)
        # Verify every read. A matching hash can reuse the decoded model, while
        # missing or changed assets still fail the current inspection.
        model = self._verified_model
        if model is None or model.sha256 != digest:
            model = GeometricRecipeModel(load_recipe(io.BytesIO(content)), sha256=digest)
            self._verified_model = model
        return model


def _inspect_model(block, inputs, model):
    recipe = model.recipe
    image = inputs["image"]
    native = gray_image(image, (np.uint8, np.uint16))
    working = prepare_image(native, recipe.pattern.input_scale)
    mask = selection_mask(inputs, native)
    if mask is not None:
        mask = prepare_mask(mask, native.shape, working.shape)
    render_overlay = block.parameters["render_overlay"]
    review_rejections = block.parameters["review_rejections"]
    generate_graphics = block.generate_graphics
    arguments = {
        "roi": recipe.search_roi, "mask": mask,
        "capture_fit": render_overlay or generate_graphics or review_rejections,
        "runtime": block.search_runtime(), "cancelled": getattr(block, "_cancelled", None),
    }
    if review_rejections:
        review = review_search(working, recipe.pattern, recipe.search, **arguments)
        matches, rejected, counts = review.matches, review.rejected, review.rejection_counts
    else:
        matches = locate_all(working, recipe.pattern, recipe.search, **arguments)
        rejected, counts = [], {}
    to_input = _homogeneous(working_to_source(native.shape, working.shape))
    records = [_record(match, recipe.pattern, to_input, image, model.model_id) for match in matches]
    score = records[0]["score"] if records else 0.
    drawings = {}
    if render_overlay or generate_graphics:
        drawings = _drawings(recipe.pattern, matches, rejected if generate_graphics else [], to_input)
    overlay = NO_VALUE
    if render_overlay:
        overlay = overlay_image(image)
        identity = np.eye(3)
        for name, drawing in drawings.items():
            if name == "rejected candidates":
                continue  # Rejections are a selectable layer, not painted over accepted fits.
            for obj in drawing.objects:
                draw_object(overlay, obj, identity)
    capture = None
    if block.run_profile.input_previews and block.run_profile.output_previews:
        capture = CompletedMatchRecord.create(
            uuid.uuid4().hex, model, matches, rejected, counts, working.shape[::-1],
            arguments["capture_fit"], review_rejections,
        )
    block._completed_review = capture
    return Result(
        outputs={
            "matches": {
                "model": "pattern_matches_v1", "pattern_id": model.model_id, "count": len(records), "items": records,
            },
            "count": len(records), "score": score,
            "transform": records[0]["transform"] if records else {},
            "pose": records[0]["pose"] if records else {},
            "points": [record["center"] for record in records],
            "review": {
                "model": "ogpm_search_review_v1", "recipe_sha256": model.sha256,
                "working_size": list(working.shape[::-1]), "working_to_input": to_input.tolist(),
                "rejection_counts": counts,
                "rejected": [_record(item, recipe.pattern, to_input, image, model.model_id) for item in rejected],
            },
            "overlay": overlay,
        },
        passed=bool(records), score=score, drawings=drawings if generate_graphics else {},
        # An explicit Set filmstrip image block has priority 0 or higher.
        event_data={"filmstrip_priority": -1} if render_overlay else {},
        message=f"{len(records)} geometric matches, best score {score:.3f}",
        payloads={"review": {BINDING: {"model": "ogpm_execution_binding_v1", "id": capture.identifier}}}
        if capture is not None else {},
    )


def _validate_match_options(values):
    for name in ("review_rejections", "render_overlay"):
        if type(values[name]) is not bool:
            raise ValueError(f"{name} must be boolean")
    workers = values["match_workers"]
    if type(workers) is not int or not 1 <= workers <= _MAX_WORKERS:
        raise ValueError(f"match_workers must be an integer from 1 to {_MAX_WORKERS}")


class _MatcherRuntime:
    composes_result_image = True
    _search_runtime = None
    _completed_review = None
    plugin_review_dialog_label = "Review completed pattern match…"

    def copy_runtime_from(self, other):
        super().copy_runtime_from(other)
        self._completed_review = other._completed_review

    def reset_runtime(self):
        super().reset_runtime()
        self._completed_review = None

    def capture_completed_review(self, context):
        snapshot = getattr(context, "snapshot_processed_execution", None)
        if snapshot is None:
            raise ValueError("Completed review needs the host's paired execution-snapshot API")
        bundle = snapshot(output_ports=("matches", "review"))
        return capture_completed(self._completed_review, bundle)

    def create_plugin_review_dialog(self, parent, context):
        from .qt_completed_review import CompletedPatternReviewDialog

        return CompletedPatternReviewDialog(parent, context, lambda: self.capture_completed_review(context))

    @property
    def filmstrip_output(self):
        return "overlay" if self.parameters["render_overlay"] else None

    def search_runtime(self):
        workers = self.parameters["match_workers"]
        if self._search_runtime is not None and self._search_runtime.workers != workers:
            self._search_runtime.close()
            self._search_runtime = None
        if workers > 1 and self._search_runtime is None:
            self._search_runtime = SearchRuntime(workers)
        return self._search_runtime

    def close(self):
        self._completed_review = None
        if self._search_runtime is not None:
            self._search_runtime.close()
            self._search_runtime = None
        super().close()


class GeometricRecipeMatcher(_MatcherRuntime, _PinnedRecipeBlock):
    """Single Python block using a saved recipe and the existing locator."""

    type_id = "pattern.ogpm_recipe"
    title, category = "Geometric inspection recipe", "Inspection"
    block_type, subtype = "Inspection", "Pattern matching"
    parallel_safe = True
    process_inputs_readonly = True
    inputs = SELECTION_INPUTS
    outputs = _MATCH_OUTPUTS
    defaults = {**_FILE_DEFAULTS, **_MATCH_DEFAULTS}
    parameter_help = {**_FILE_HELP, **_MATCH_HELP}

    def validate_parameters(self, parameters=None):
        super().validate_parameters(parameters)
        _validate_match_options(self.parameters if parameters is None else parameters)

    def process(self, inputs):
        return _inspect_model(self, inputs, self.load_pinned_model())


class LoadGeometricRecipe(_PinnedRecipeBlock):
    """Publish a pinned recipe on a model wire for a separate matcher block."""

    type_id = "pattern.ogpm_load_recipe"
    title, category = "Load geometric recipe", "Inspection"
    block_type, subtype = "Inspection", "Pattern matching"
    outputs = (Port("recipe", "any"),)
    defaults = _FILE_DEFAULTS
    parameter_help = _FILE_HELP

    def process(self, inputs):
        return Result({"recipe": self.load_pinned_model()})


class TrainGeometricRecipe(Block):
    """Train from a captured reference on a setup graph and publish its recipe."""

    type_id = "pattern.ogpm_train_recipe"
    title, category = "Train geometric recipe", "Inspection"
    block_type, subtype = "Inspection", "Pattern matching"
    inputs = (Port("image"), Port("mask", required=False))
    outputs = LoadGeometricRecipe.outputs
    defaults = {
        "max_side": 0, "training_roi": [], "origin": [], "edge_threshold": 45.0,
        "coarse_factor": 0, "fine_sigma": 0.85, "ignore_polarity": False,
        "search_options": {}, "search_roi": [],
    }
    parameter_help = {
        "max_side": "Maximum working side in pixels. Zero uses the source resolution.",
        "training_roi": "[x, y, width, height] in working pixels. Empty uses the full reference.",
        "origin": "[x, y] in working pixels. Empty uses the ROI center.",
        "edge_threshold": "High Canny threshold. Zero selects it automatically.",
        "coarse_factor": "Coarse subsampling factor. Zero selects it automatically.",
        "fine_sigma": "Fine smoothing sigma in pixels. Zero selects it automatically.",
        "search_options": "JSON overrides for the saved recipe's Search settings.",
        "search_roi": "[x, y, width, height] in working scene pixels. Empty uses the full scene.",
    }

    def process(self, inputs):
        values = self.parameters
        image = inputs["image"]
        raw = gray_image(image, (np.uint8, np.uint16))
        reference = ImageSnapshot(raw, input_scale(raw.shape, values["max_side"] or None))
        mask = inputs.get("mask")
        if mask is not None:
            require_same_frame((image, mask), message="Training mask and reference must use the same frame")
            mask = prepare_mask(mask, reference.source_shape, reference.pixels.shape, training=True)
        draft = TrainingDraft(
            reference, roi=values["training_roi"] or None, origin=values["origin"] or None, mask=mask,
            edge_threshold=values["edge_threshold"] or None, coarse_factor=values["coarse_factor"] or None,
            fine_sigma=values["fine_sigma"] or None, ignore_polarity=values["ignore_polarity"],
        )
        pattern = draft.train()
        search = {**asdict(Search()), **values["search_options"]}
        recipe = _read_inspection({
            "version": _INSPECTION_VERSION, "search": search, "search_roi": values["search_roi"] or None,
        }, pattern)
        return Result({"recipe": GeometricRecipeModel(recipe)})


class GeometricWiredMatcher(_MatcherRuntime, Block):
    """Execute the same locator using a typed recipe supplied on a wire."""

    type_id = "pattern.ogpm_match_model"
    title, category = "Match geometric recipe model", "Inspection"
    block_type, subtype = "Inspection", "Pattern matching"
    parallel_safe = True
    process_inputs_readonly = True
    inputs = (*SELECTION_INPUTS, Port("recipe", "any"))
    outputs = _MATCH_OUTPUTS
    defaults = _MATCH_DEFAULTS
    parameter_help = _MATCH_HELP

    def validate_parameters(self, parameters=None):
        super().validate_parameters(parameters)
        _validate_match_options(self.parameters if parameters is None else parameters)

    def process(self, inputs):
        model = inputs["recipe"]
        if not isinstance(model, GeometricRecipeModel):
            raise ValueError("Connect a trained or loaded geometric recipe model")
        return _inspect_model(self, inputs, model)


def register(registry):
    """OpenCVDataflowGUI trusted-plugin entry point."""
    for block_type in (GeometricRecipeMatcher, LoadGeometricRecipe, TrainGeometricRecipe, GeometricWiredMatcher):
        registry.register(block_type)
