"""Optional DataflowGUI training popup for the pinned recipe blocks."""

from __future__ import annotations

import io
import uuid
from concurrent.futures import CancelledError, ThreadPoolExecutor
from dataclasses import replace
from functools import partial
from pathlib import Path
from threading import Event

import cv2
import numpy as np
from PySide6.QtCore import QRectF, QSignalBlocker, Qt, QTimer, Signal
from PySide6.QtGui import QImage, QPixmap
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QScrollArea, QSpinBox, QStackedWidget, QTableWidget, QTableWidgetItem,
    QTabWidget, QVBoxLayout, QWidget,
)

from opencv_dataflow.images import preview_rgb
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from opencv_dataflow.payloads import ValuePacket, metadata, require_same_frame
from opencv_dataflow.processing import gray_image
from opencv_dataflow.region_editor import RegionCanvas

from .dataflow import _pinned_archive, _recipe_path, _training_image_path, recipe_reference
from .image_input import input_scale, prepare_mask, read_gray, read_mask
from .locator import DEFAULT_FIT_LAYERS, FIT_LAYERS, Pose, Search, draw_matches, draw_rejections, draw_training
from .result_review import candidate_bounds, candidate_report, save_candidate_review
from .persistence import InspectionRecipe, load_recipe, save_recipe
from .training_draft import (
    ImageSnapshot, InspectionPreview, TrainingDraft, draw_training_mask, draw_training_selection,
)


def _qimage(image):
    rgb = np.ascontiguousarray(preview_rgb(image))
    return QImage(rgb.data, rgb.shape[1], rgb.shape[0], rgb.strides[0], QImage.Format.Format_RGB888).copy()


class _ImageView(QWidget):
    def __init__(self, placeholder):
        super().__init__()
        self.image = QImage()
        self.placeholder = placeholder
        self.setMinimumSize(400, 280)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.stack = QStackedWidget()
        self.empty = QLabel(placeholder)
        self.empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.viewer = FilmstripImageView(self)
        self.stack.addWidget(self.empty)
        self.stack.addWidget(self.viewer)
        layout.addWidget(self.stack, 1)
        actions = QHBoxLayout()
        for title, callback in (("Fit", self.viewer.fit_image), ("100%", self.viewer.actual_size),
                                ("Zoom out", lambda: self.viewer.zoom(.8)),
                                ("Zoom in", lambda: self.viewer.zoom(1.25))):
            button = QPushButton(title)
            button.clicked.connect(callback)
            actions.addWidget(button)
        actions.addStretch()
        layout.addLayout(actions)
        self.setToolTip("Scroll to zoom; drag to pan. 100% shows the displayed pixel grid.")

    def set_image(self, pixels, *, reset_view=False):
        previous_size = self.image.size()
        self.image = QImage() if pixels is None else _qimage(pixels)
        if self.image.isNull():
            self.stack.setCurrentIndex(0)
            self.viewer.set_image(QPixmap())
            return
        self.stack.setCurrentIndex(1)
        value = QPixmap.fromImage(self.image)
        if not reset_view and previous_size == self.image.size():
            self.viewer.image_item.setPixmap(value)
        else:
            self.viewer.set_image(value)


class _TrainingCanvas(RegionCanvas):
    datum_picked = Signal(float, float)
    mask_changed = Signal()

    def __init__(self, reference, parent=None):
        height, width = reference.shape
        super().__init__(reference, {"shape": "rectangle", "rectangle": [0, 0, width, height]}, parent)
        self.tool = "Region"
        self.band = 0
        self.radius = 6
        self.mask = None
        self._brush_point = None

    def set_preview(self, image):
        self.image = _qimage(image)
        self.update()

    def _paint_mask(self, point):
        if self.mask is None:
            self.mask = np.full(self.image_shape, 255, np.uint8)
        if self._brush_point is None:
            cv2.circle(self.mask, tuple(point), self.radius, self.band, -1)
        else:
            cv2.line(self.mask, self._brush_point, tuple(point), self.band, 2 * self.radius)
        self._brush_point = tuple(point)
        self.mask_changed.emit()

    def mousePressEvent(self, event):
        if self.tool == "Region":
            super().mousePressEvent(event)
            return
        point = self.to_image(event.position())
        if event.button() != Qt.MouseButton.LeftButton or point is None:
            return
        if self.tool == "Mask":
            self._paint_mask(point)
        else:
            rect = self.image_rect()
            height, width = self.image_shape
            x = (event.position().x() - rect.left()) * width / rect.width() - 0.5
            y = (event.position().y() - rect.top()) * height / rect.height() - 0.5
            self.datum_picked.emit(min(max(x, 0), width - 1), min(max(y, 0), height - 1))

    def mouseMoveEvent(self, event):
        if self.tool == "Region":
            super().mouseMoveEvent(event)
        elif self.tool == "Mask" and self._brush_point is not None and event.buttons() & Qt.MouseButton.LeftButton:
            self._paint_mask(self.to_image(event.position(), clamp=True))

    def mouseReleaseEvent(self, event):
        if self.tool == "Region":
            super().mouseReleaseEvent(event)
        elif self.tool == "Mask" and self._brush_point is not None and event.button() == Qt.MouseButton.LeftButton:
            self._paint_mask(self.to_image(event.position(), clamp=True))
            self._brush_point = None


class GeometricTrainingDialog(QDialog):
    """Train and preview a recipe, then stage its pinned asset in the inspector."""

    def __init__(self, parent, parameters, context):
        super().__init__(parent)
        self.setWindowTitle("Geometric recipe trainer")
        self.resize(1120, 740)
        self._parameters, self._context = parameters, context
        self._reference = self._scene = self._scene_input = None
        self._reference_input = None
        self._refinement_input = None
        self._previous_refinement = None
        self._reference_payload = {}
        self._canvas = None
        self._review = None
        self._visible = []
        self._displayed_scene = None
        self.result_report = None
        self._revision = 0
        self._job = None
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="ogpm-training")
        self._cancelled = Event()
        self._timer = QTimer(self, interval=35)
        self._timer.timeout.connect(self._finish_job)
        # The host can call the base QDialog.reject and delete the popup while
        # a job is running. Workers own only snapshots and this event.
        executor, cancelled = self._executor, self._cancelled

        def close_jobs(*_):
            cancelled.set()
            executor.shutdown(wait=False, cancel_futures=True)

        self.finished.connect(close_jobs)
        self.finished.connect(self._timer.stop)
        self.destroyed.connect(close_jobs)

        initial, message = self._initial_recipe()
        self._pattern = initial.pattern if initial else None
        self._search_defaults = initial.search if initial else Search()
        self._fields = {}
        self.status = QLabel(message)
        self.status.setWordWrap(True)
        self._build(initial)
        if initial is not None:
            self._restore_reference()
            self._restore_refinement_scene()
        self._render_reference()
        self._perform(self.refresh_images)
        subscribe = getattr(context, "subscribe_outputs", None)
        if subscribe is not None:
            unsubscribe = subscribe(lambda _: self.refresh_images())
            self.finished.connect(unsubscribe)
            self.destroyed.connect(unsubscribe)
        self._publish_results()
        self._update_buttons()

    def _initial_recipe(self):
        if not self._parameters.get("recipe_path"):
            return None, "Capture a reference and a separate scene."
        try:
            content, _ = _pinned_archive(self._context.project_dir, self._parameters)
            return load_recipe(io.BytesIO(content)), "Saved edges shown. Capture or open a reference to retrain."
        except (OSError, ValueError) as exc:
            return None, f"Capture a reference to replace the saved recipe. {exc}"

    def _build(self, initial):
        layout = QVBoxLayout(self)
        capture = QHBoxLayout()
        self.source = QComboBox()
        self.source.setObjectName("image_output")
        capture.addWidget(self.source, 1)
        for title, action in (
            ("Refresh outputs", self.refresh_images),
            ("Capture reference", lambda: self.use_reference(*self._capture())),
            ("Capture scene", lambda: self.use_scene(*self._capture())),
        ):
            capture.addWidget(self._button(title, action))
        layout.addLayout(capture)

        body = QHBoxLayout()
        self.tabs = QTabWidget()
        self.tabs.setFixedWidth(390)
        self.tabs.addTab(self._scroll(self._train_form()), "Train")
        self.tabs.addTab(self._scroll(self._search_form(initial)), "Inspect")
        body.addWidget(self.tabs)
        views = QStackedWidget()
        reference_page = QWidget()
        self._reference_layout = QVBoxLayout(reference_page)
        self._saved_view = _ImageView("Capture or open a reference image")
        self._reference_layout.addWidget(self._saved_view, 1)
        self.features = QComboBox()
        self.features.addItems(("Fine", "Coarse"))
        self.features.currentIndexChanged.connect(self._render_reference)
        features_row = QHBoxLayout()
        features_row.addWidget(QLabel("Trained features"))
        features_row.addWidget(self.features)
        features_row.addStretch()
        self._reference_layout.addLayout(features_row)
        scene_page = QWidget()
        scene_layout = QVBoxLayout(scene_page)
        self.scene_view = _ImageView("Capture or open a preview scene")
        scene_layout.addWidget(self.scene_view, 1)
        results_row = QHBoxLayout()
        self.result_kind = QComboBox()
        self.result_kind.currentIndexChanged.connect(self._fill_candidates)
        results_row.addWidget(QLabel("Results"))
        results_row.addWidget(self.result_kind, 1)
        self.candidate = QComboBox()
        self.candidate.currentIndexChanged.connect(self._render_scene)
        results_row.addWidget(self.candidate, 1)
        self.refine_button = self._button("Refine selected match", self._refine)
        self.refine_button.setToolTip("Select one accepted or rejected candidate with measured fine edges.")
        results_row.addWidget(self.refine_button)
        scene_layout.addLayout(results_row)
        layers = QHBoxLayout()
        self.fit_layers = {}
        for name in FIT_LAYERS:
            check = QCheckBox(name.capitalize())
            check.setChecked(name in DEFAULT_FIT_LAYERS)
            check.toggled.connect(self._render_scene)
            self.fit_layers[name] = check
            layers.addWidget(check)
        self.focus_result = self._button("Focus selected", self._focus_result)
        layers.addWidget(self.focus_result)
        scene_layout.addLayout(layers)
        self.details = QLabel("Cyan pose axes · Green found · Red missing · Amber unmeasured")
        self.details.setWordWrap(True)
        scene_layout.addWidget(self.details)
        self.measurements = QTableWidget(0, 4)
        self.measurements.setHorizontalHeaderLabels(["Measurement", "Value", "Minimum", "Meaning"])
        self.measurements.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.measurements.setMaximumHeight(145)
        self.measurements.setMinimumHeight(100)
        self.measurements.horizontalHeader().setStretchLastSection(True)
        scene_layout.addWidget(self.measurements)
        self.export_result = self._button("Export selected review…", self._export_result)
        self.export_result.setToolTip("Save a new folder with a full working-grid fit, cropped assessment and JSON measurements.")
        scene_layout.addWidget(self.export_result)
        views.addWidget(reference_page)
        views.addWidget(scene_page)
        self.tabs.currentChanged.connect(views.setCurrentIndex)
        body.addWidget(views, 1)
        layout.addLayout(body, 1)
        layout.addWidget(self.status)
        footer = QHBoxLayout()
        self.train_button = self._button("Train pattern", self._train)
        self.preview_button = self._button("Run preview", self._preview)
        self.undo_refinement = self._button("Undo refinement", self._undo_refinement)
        self.cancel_work = self._button("Cancel work", self._cancel_job)
        self.stage = self._button("Stage recipe", self.accept)
        footer.addWidget(self.train_button)
        footer.addWidget(self.preview_button)
        footer.addWidget(self.undo_refinement)
        footer.addWidget(self.cancel_work)
        footer.addStretch()
        footer.addWidget(self.stage)
        footer.addWidget(self._button("Close", self.reject))
        layout.addLayout(footer)

    @staticmethod
    def _scroll(widget):
        scroll = QScrollArea(widgetResizable=True)
        scroll.setWidget(widget)
        return scroll

    def _button(self, text, action):
        button = QPushButton(text)
        button.clicked.connect(lambda: self._perform(action))
        return button

    def _perform(self, action):
        try:
            action()
        except (OSError, ValueError, TypeError, RuntimeError, cv2.error) as exc:
            self.status.setText(str(exc))

    def _field(self, form, name, title, value, *, training=False):
        field = QLineEdit(self._text(value))
        field.setObjectName(name)
        field.textChanged.connect(lambda: self._edited(training=training))
        self._fields[name] = field
        form.addRow(title, field)
        return field

    @staticmethod
    def _text(value):
        if isinstance(value, (tuple, list)):
            return " ".join(map(str, value))
        return "" if value is None else str(value)

    def _train_form(self):
        page = QWidget()
        form = QFormLayout(page)
        form.addRow(self._button("Open reference image…", lambda: self._open_image(self.use_reference)))
        self.reference_label = QLabel()
        self.reference_label.setWordWrap(True)
        form.addRow(self.reference_label)
        self.max_side = QSpinBox(minimum=0, maximum=16384, value=1024, specialValueText="Native")
        form.addRow("Max side on capture", self.max_side)
        self._draft_controls = QWidget()
        form.addRow(self._draft_controls)
        form = QFormLayout(self._draft_controls)
        form.setContentsMargins(0, 0, 0, 0)
        self._draft_controls.setVisible(self._pattern is None)
        self._field(form, "training_roi", "ROI  X Y W H", None, training=True)
        self._field(form, "origin", "Datum  X Y", None, training=True)
        self.tool = QComboBox()
        self.tool.addItems(("Region", "Datum", "Mask"))
        self.tool.currentTextChanged.connect(self._update_tool)
        form.addRow("Canvas tool", self.tool)
        form.addRow(self._button("Draw new ROI", self._draw_roi))
        self.mask_band = QComboBox()
        for text, value in (("Ignore", 0), ("Clutter only", 64), ("Care", 255)):
            self.mask_band.addItem(text, value)
        self.mask_band.currentIndexChanged.connect(self._update_tool)
        form.addRow("Mask brush", self.mask_band)
        self.brush_radius = QSpinBox(minimum=1, maximum=128, value=6)
        self.brush_radius.valueChanged.connect(self._update_tool)
        form.addRow("Brush radius", self.brush_radius)
        form.addRow(self._button("Open aligned mask…", self._open_mask))
        form.addRow(self._button("Capture selected output as mask", self._capture_mask))
        form.addRow(self._button("Clear mask", lambda: self._set_mask(None)))
        self._field(form, "edge_threshold", "Edge threshold", 45, training=True)
        self._field(form, "coarse_factor", "Coarse factor", "auto", training=True)
        self._field(form, "fine_sigma", "Fine smoothing", 0.85, training=True)
        self.ignore_polarity = QCheckBox("Ignore edge polarity")
        self.ignore_polarity.toggled.connect(lambda: self._edited(training=True))
        form.addRow(self.ignore_polarity)
        return page

    def _search_form(self, initial):
        page = QWidget()
        form = QFormLayout(page)
        form.addRow(self._button("Open scene image…", lambda: self._open_image(self.use_scene)))
        self.scene_label = QLabel()
        self.scene_label.setWordWrap(True)
        form.addRow(self.scene_label)
        search = self._search_defaults
        for name, title, value in (
            ("search_roi", "ROI  X Y W H", initial.search_roi if initial else None),
            ("angle", "Angle  MIN MAX STEP", search.angle),
            ("scale", "Scale  MIN MAX STEP", search.scale),
            ("aspect", "Aspect  MIN MAX", search.aspect),
            ("accept", "Accept score", search.accept),
            ("coarse_accept", "Coarse cutoff", search.coarse_accept),
            ("max_results", "Maximum results", search.max_results),
            ("xy_overlap", "Area overlap", search.xy_overlap),
            ("outside_region_threshold", "Outside allowance", search.outside_region_threshold),
            ("min_contrast", "Minimum contrast", search.min_contrast),
        ):
            self._field(form, name, title, value)
        start = search.start_pose
        self._field(form, "start_pose", "Seed  X Y DEG SCALE ASPECT",
                    None if start is None else (start.x, start.y, start.angle_deg, start.scale, start.aspect))
        self.aspect_fallback = QCheckBox("Aspect fallback only", checked=search.aspect_fallback)
        self.aspect_fallback.toggled.connect(lambda: self._edited())
        form.addRow(self.aspect_fallback)
        return page

    def refresh_images(self):
        current = self.source.currentData()
        self.source.clear()
        for output in self._context.refresh_images():
            for level in range(output.level_count):
                name = f"{output.block_name} / {output.port}"
                if output.level_count > 1:
                    name += f" / level {level}"
                self.source.addItem(name, (output.block_id, output.port, level))
        index = next((i for i in range(self.source.count()) if self.source.itemData(i) == current), 0)
        self.source.setCurrentIndex(index if self.source.count() else -1)
        self.source.setPlaceholderText("Run the graph to cache image outputs")

    def _capture(self):
        previous = self.source.currentData()
        self.refresh_images()
        selected = self.source.currentData()
        if selected is None:
            raise ValueError("Run the graph or open an image file first.")
        if previous is not None and previous != selected:
            raise ValueError("The selected output is no longer cached. Choose an available output.")
        block_id, port, level = selected
        packet = self._context.snapshot_image(block_id, port, level=level)
        return packet.value, self.source.currentText()

    def _open_image(self, action):
        name, _ = QFileDialog.getOpenFileName(self, "Open image", filter="Images (*.png *.bmp *.jpg *.tif *.tiff);;All files (*)")
        if name:
            action(read_gray(Path(name)), Path(name).name)

    @staticmethod
    def _gray(image):
        return gray_image(image, (np.uint8, np.uint16))

    def _restore_reference(self):
        pattern = self._pattern
        x, y, w, h = pattern.training_roi
        self.reference_label.setText(
            f"Saved geometry · ROI {x}, {y}, {w}, {h} · Datum {self._text(pattern.origin)}"
        )
        try:
            path = _training_image_path(self._context.project_dir, self._parameters["recipe_path"])
            if not path.is_file():
                return
            raw = read_gray(path)
            reference = ImageSnapshot(raw, pattern.input_scale)
            height, width = reference.pixels.shape
            if x + w > width or y + h > height:
                raise ValueError("The saved ROI does not fit the training reference.")
        except (OSError, ValueError, cv2.error) as exc:
            self.status.setText(f"Saved edges shown. Could not open the training reference. {exc}")
            return

        self._reference_input, self._reference = raw, reference
        self.reference_label.setText(self._image_label("Saved training reference", reference))
        diagnostics = pattern.diagnostics
        if pattern.weights is not None or (diagnostics and diagnostics.composite is not None):
            self.status.setText(
                "Saved reference and edges loaded. Capture or open a reference to train a replacement."
            )
            return
        self._set_reference_canvas()
        self._canvas.parameters["rectangle"] = list(pattern.training_roi)
        if pattern.mask is not None:
            self._canvas.mask = np.full(reference.pixels.shape, 255, np.uint8)
            self._canvas.mask[y:y + h, x:x + w] = pattern.mask
        values = {
            "training_roi": pattern.training_roi, "origin": pattern.origin,
            "edge_threshold": "auto" if diagnostics and diagnostics.auto_edge_threshold else pattern.edge_threshold,
            "coarse_factor": "auto" if diagnostics and diagnostics.auto_coarse_factor else pattern.factor,
            "fine_sigma": "auto" if diagnostics and diagnostics.auto_fine_sigma else pattern.fine_sigma,
        }
        for name, value in values.items():
            with QSignalBlocker(self._fields[name]):
                self._fields[name].setText(self._text(value))
        with QSignalBlocker(self.ignore_polarity):
            self.ignore_polarity.setChecked(pattern.ignore_polarity)
        self.max_side.setValue(0 if pattern.input_scale == 1 else max(reference.pixels.shape))
        self.status.setText("Saved training reference and edges loaded.")

    def _restore_refinement_scene(self):
        try:
            path = _training_image_path(self._context.project_dir, self._parameters["recipe_path"], "refinement")
            if path.is_file():
                message = self.status.text()
                self.use_scene(read_gray(path), "Last refinement image")
                self._refinement_input = self._scene_input
                self.tabs.setCurrentIndex(0)
                self.status.setText(f"{message} The last refinement image is ready in Inspect.")
        except (OSError, ValueError, cv2.error) as exc:
            self.status.setText(f"{self.status.text()} Could not open the last refinement image. {exc}")

    def _set_reference_canvas(self):
        if self._canvas is not None:
            self._reference_layout.removeWidget(self._canvas)
            self._canvas.deleteLater()
        self._saved_view.hide()
        self._draft_controls.show()
        self._canvas = _TrainingCanvas(self._reference.pixels)
        self._reference_layout.insertWidget(1, self._canvas, 1)
        self._canvas.changed.connect(self._canvas_roi_changed)
        self._canvas.datum_picked.connect(lambda x, y: self._fields["origin"].setText(f"{x:.6g} {y:.6g}"))
        self._canvas.mask_changed.connect(lambda: self._edited(training=True))
        self._update_tool()

    def use_reference(self, image, label):
        raw = self._gray(image)
        reference = ImageSnapshot(raw, input_scale(raw.shape, self.max_side.value() or None))
        scene = self._scene
        if self._scene_input is not None and scene.input_scale != reference.input_scale:
            scene = ImageSnapshot(self._scene_input, reference.input_scale)
        self._reference, self._scene = reference, scene
        self._reference_input = raw.copy()
        self._reference_payload = metadata(image)
        self.reference_label.setText(self._image_label(label, reference))
        if scene is not None:
            self.scene_label.setText(self._image_label(self._scene_name, scene))
        self._set_reference_canvas()
        for name in ("training_roi", "origin"):
            with QSignalBlocker(self._fields[name]):
                self._fields[name].clear()
        self.tabs.setCurrentIndex(0)
        self._edited(training=True)
        self._render_scene()
        self.status.setText("Draw the training ROI, set the datum, and train the pattern.")

    def use_scene(self, image, label):
        scale = self._reference.input_scale if self._reference is not None else (
            self._pattern.input_scale if self._pattern is not None else 1.0
        )
        raw = self._gray(image)
        self._scene = ImageSnapshot(raw, scale)
        self._scene_input = raw.copy()
        self._scene_name = label
        self.scene_label.setText(self._image_label(label, self._scene))
        self.tabs.setCurrentIndex(1)
        self._edited()
        self._render_scene()
        self.status.setText("Scene captured. Run preview when the pattern is ready.")

    @staticmethod
    def _image_label(label, snapshot):
        h, w = snapshot.pixels.shape
        return f"{label} · {w} × {h} working pixels"

    def _require_reference(self):
        if self._canvas is None:
            raise ValueError("Capture a reference image first.")
        return self._reference

    def _open_mask(self):
        reference = self._require_reference()
        name, _ = QFileDialog.getOpenFileName(self, "Open aligned training mask")
        if name:
            self._set_mask(read_mask(Path(name), reference.source_shape, reference.pixels.shape, training=True))

    def _capture_mask(self):
        reference = self._require_reference()
        image, _ = self._capture()
        require_same_frame(
            (ValuePacket(reference.pixels, self._reference_payload), image),
            message="Training mask and reference must use the same frame",
        )
        self._set_mask(prepare_mask(image, reference.source_shape, reference.pixels.shape, training=True))

    def _set_mask(self, mask):
        self._require_reference()
        self._canvas.mask = None if mask is None else np.array(mask, copy=True)
        self._edited(training=True)

    def _update_tool(self):
        if self._canvas is None:
            return
        if self.tool.currentText() != self._canvas.tool:
            self._canvas.cancel_gesture()
            self._canvas._brush_point = None
        self._canvas.tool = self.tool.currentText()
        self._canvas.band = self.mask_band.currentData()
        self._canvas.radius = self.brush_radius.value()

    def _draw_roi(self):
        self._require_reference()
        self.tool.setCurrentText("Region")
        self._canvas.new_shape()

    def _canvas_roi_changed(self):
        roi = self._canvas.parameters["rectangle"]
        field = self._fields["training_roi"]
        # A full-frame default can stay blank until the operator moves an edge.
        h, w = self._reference.pixels.shape
        if field.text() or roi != [0, 0, w, h]:
            field.setText(self._text(roi))

    def _value(self, name, convert, *, optional=False):
        value = self._fields[name].text().strip()
        return None if optional and not value else convert(value)

    def _numbers(self, name, length, convert, *, optional=False):
        values = self._value(name, lambda text: tuple(map(convert, text.split())), optional=optional)
        if values is not None and len(values) != length:
            raise ValueError(f"Enter {length} space-separated values for {name.replace('_', ' ')}.")
        return values

    def _draft(self):
        reference = self._require_reference()
        auto = lambda text: None if text.lower() == "auto" else float(text)
        return TrainingDraft(
            reference, roi=self._numbers("training_roi", 4, int, optional=True),
            origin=self._numbers("origin", 2, float, optional=True), mask=self._canvas.mask,
            edge_threshold=self._value("edge_threshold", auto),
            coarse_factor=self._value("coarse_factor", lambda text: None if text.lower() == "auto" else int(text)),
            fine_sigma=self._value("fine_sigma", auto), ignore_polarity=self.ignore_polarity.isChecked(),
        )

    def _recipe(self):
        if self._pattern is None:
            raise ValueError("Train or load a pattern first.")
        seed = self._numbers("start_pose", 5, float, optional=True)
        search = replace(
            self._search_defaults, angle=self._numbers("angle", 3, float), scale=self._numbers("scale", 3, float),
            aspect=self._numbers("aspect", 2, float), aspect_fallback=self.aspect_fallback.isChecked(),
            accept=self._value("accept", float), coarse_accept=self._value("coarse_accept", float, optional=True),
            max_results=self._value("max_results", int), xy_overlap=self._value("xy_overlap", float),
            outside_region_threshold=self._value("outside_region_threshold", float),
            min_contrast=self._value("min_contrast", float), start_pose=None if seed is None else Pose(*seed),
        )
        return InspectionRecipe(self._pattern, search, self._numbers("search_roi", 4, int, optional=True))

    def _train(self):
        self.tabs.setCurrentIndex(0)
        self._start_job("train", self._draft().train)

    def _preview(self):
        if self._scene is None:
            raise ValueError("Capture a scene first.")
        preview = InspectionPreview(self._recipe(), self._scene)
        self.tabs.setCurrentIndex(1)
        self._start_job("preview", preview.review)

    def _selected_candidate(self):
        index = self.candidate.currentData()
        return None if index is None else self._visible[index]

    def _refine(self):
        candidate = self._selected_candidate()
        if candidate is None or candidate.score is None or not candidate.edge_matches:
            raise ValueError("Select one preview candidate with a measured fine fit.")
        preview = InspectionPreview(self._recipe(), self._scene)
        self._start_job("refine", partial(preview.refine, candidate.pose))

    def _undo_refinement(self):
        self._pattern, self._refinement_input = self._previous_refinement
        self._previous_refinement = None
        self._review = None
        self._publish_results()
        self._render_reference()
        self.status.setText("Previous pattern restored. Run preview to check it.")
        self._update_buttons()

    def _start_job(self, kind, operation):
        if self._job is not None:
            return
        self._cancelled.clear()
        future = self._executor.submit(operation, cancelled=self._cancelled.is_set)
        self._job = (kind, self._revision, future)
        self.status.setText({
            "train": "Training features…", "preview": "Searching the scene…",
            "refine": "Refining fine edges at the selected pose…",
        }[kind])
        self._timer.start()
        self._update_buttons()

    def _cancel_job(self):
        if self._job is not None:
            self._cancelled.set()
            self.status.setText("Cancelling work…")
            self._update_buttons()

    def _finish_job(self):
        kind, revision, future = self._job
        if not future.done():
            return
        self._timer.stop()
        self._job = None
        try:
            result = future.result()
            if revision != self._revision or self._cancelled.is_set():
                raise CancelledError()
            if kind == "train":
                self._pattern = result
                self._refinement_input = self._previous_refinement = None
                self._review = None
                self._render_reference()
                self._publish_results()
                weak = ", ".join(result.diagnostics.fine.weak_dofs) or "none"
                self.status.setText(f"Trained {len(result.points)} fine and {len(result.coarse_points)} coarse edges. Weak axes: {weak}.")
            elif kind == "refine":
                self._previous_refinement = self._pattern, self._refinement_input
                self._pattern, self._refinement_input = result.pattern, self._scene_input
                self._review = None
                self._publish_results()
                self._render_reference()
                self.tabs.setCurrentIndex(0)
                self.status.setText(
                    f"Moved {result.moved} fine edges and reduced {result.downweighted} weights. "
                    f"Score at selected pose {result.before.score:.3f} → {result.after.score:.3f}. "
                    "Run preview to check the refined recipe before staging."
                )
            else:
                self._review = result
                self._publish_results()
                self.status.setText(f"{len(result.matches)} accepted matches.")
        except CancelledError:
            self.status.setText("Work cancelled. The current draft is ready.")
        except Exception as exc:
            self.status.setText(str(exc))
        self._update_buttons()

    def _edited(self, *, training=False):
        self._revision += 1
        if training:
            self._pattern = None
            self._refinement_input = self._previous_refinement = None
            self._render_reference()
        had_review = self._review is not None
        if had_review:
            self._review = None
            self._publish_results()
        if self._job is not None:
            self._cancel_job()
        elif training and self._reference is not None:
            self.status.setText("Training draft changed. Train to refresh the pattern.")
        elif had_review:
            self.status.setText("Search draft changed. Run preview to update results.")
        self._update_buttons()

    def _update_buttons(self):
        busy = self._job is not None
        self.train_button.setEnabled(self._canvas is not None and not busy)
        self.preview_button.setEnabled(self._scene is not None and self._pattern is not None and not busy)
        candidate = self._selected_candidate()
        self.refine_button.setEnabled(
            not busy and candidate is not None and candidate.score is not None and bool(candidate.edge_matches)
        )
        self.focus_result.setEnabled(candidate is not None and self._scene is not None)
        self.export_result.setEnabled(not busy and candidate is not None and self._scene is not None)
        self.undo_refinement.setEnabled(self._previous_refinement is not None and not busy)
        self.stage.setEnabled(self._pattern is not None and self._context.project_dir is not None and not busy)
        self.stage.setToolTip("" if self._context.project_dir is not None else "Save the project and reopen the trainer.")
        self.cancel_work.setEnabled(busy and not self._cancelled.is_set())

    def _render_reference(self):
        coarse = self.features.currentText() == "Coarse"
        if self._canvas is None:
            if self._pattern is not None:
                image = self._reference.pixels if self._reference is not None else None
                self._saved_view.set_image(draw_training(image, self._pattern, coarse=coarse))
            return
        image = self._reference.pixels
        if self._pattern is not None:
            image = draw_training(image, self._pattern, coarse=coarse)
        else:
            try:
                roi = self._numbers("training_roi", 4, int, optional=True)
                origin = self._numbers("origin", 2, float, optional=True)
                h, w = image.shape
                if roi is None or (min(roi[:2]) >= 0 and min(roi[2:]) >= 8 and roi[0] + roi[2] <= w and roi[1] + roi[3] <= h):
                    self._canvas.parameters["rectangle"] = list(roi or (0, 0, w, h))
                image = draw_training_selection(image, roi, origin)
            except ValueError:
                pass
        if self._canvas.mask is not None:
            image = draw_training_mask(image, self._canvas.mask)
        self._canvas.set_preview(image)

    def _publish_results(self):
        with QSignalBlocker(self.result_kind):
            self.result_kind.clear()
            self.result_kind.addItem("Accepted", ("accepted", None))
            if self._review is not None and self._review.rejected:
                self.result_kind.addItem("All rejected", ("rejected", None))
                for reason, count in sorted(self._review.rejection_counts.items()):
                    self.result_kind.addItem(f"{reason.replace('_', ' ')} ({count})", ("rejected", reason))
                if not self._review.matches:
                    self.result_kind.setCurrentIndex(1)
        self._fill_candidates()

    def _fill_candidates(self):
        self._visible = []
        if self._review is not None:
            kind, reason = self.result_kind.currentData()
            if kind == "accepted":
                self._visible = self._review.matches
            else:
                self._visible = [item for item in self._review.rejected if reason is None or item.reason == reason]
        with QSignalBlocker(self.candidate):
            self.candidate.clear()
            self.candidate.addItem(f"Show all ({len(self._visible)})", None)
            for index, item in enumerate(self._visible):
                score = f"{item.score:.3f}" if item.score is not None else "coarse only"
                self.candidate.addItem(f"{index + 1} · {score}", index)
        self._render_scene()

    def _render_scene(self):
        self._update_buttons()
        self.result_report = None
        self.measurements.setRowCount(0)
        if self._scene is None:
            self.scene_view.set_image(None)
            self._displayed_scene = None
            return
        image = self._scene.pixels
        message = "Cyan pose axes · Green found · Red missing · Amber unmeasured"
        if self._visible:
            index = self.candidate.currentData()
            results = self._visible if index is None else [self._visible[index]]
            kind, _ = self.result_kind.currentData()
            draw = draw_matches if kind == "accepted" else draw_rejections
            image = draw(image, self._pattern, results, layers=self._visible_layers())
            if index is not None:
                hit = results[0]
                x, y = self._scene.working_to_source() @ [hit.pose.x, hit.pose.y, 1]
                message += f"\nSource X {x:.2f} · Y {y:.2f} · {hit.pose.angle_deg:.2f}°"
                if hit.edge_matches is not None:
                    message += f" · Edges {len(hit.edge_matches)}/{len(self._pattern.points)}"
                if hit.fit_error_px is not None:
                    message += f" · Fit {hit.fit_error_px:.3f} working px"
                self.result_report = candidate_report(
                    self._pattern, hit, self._recipe().search,
                    working_to_source=self._scene.working_to_source(),
                )
                message += "\n" + self.result_report["explanation"]
                self.measurements.setRowCount(len(self.result_report["metrics"]))
                for row, metric in enumerate(self.result_report["metrics"]):
                    value = "not measured" if metric["value"] is None else f"{metric['value']:.4g}"
                    minimum = "—" if metric["minimum"] is None else f"{metric['minimum']:.4g}"
                    for column, text in enumerate((metric["name"], value, minimum, metric["status"])):
                        cell = QTableWidgetItem(text)
                        cell.setToolTip(metric["units"])
                        self.measurements.setItem(row, column, cell)
                self.measurements.resizeColumnsToContents()
        elif self._review is not None:
            message += "\nNo accepted matches or retained rejected candidates in this selection."
        self.details.setText(message)
        self.scene_view.set_image(image, reset_view=self._displayed_scene is not self._scene)
        self._displayed_scene = self._scene

    def _visible_layers(self):
        return tuple(name for name, check in self.fit_layers.items() if check.isChecked())

    def _focus_result(self):
        hit = self._selected_candidate()
        if hit is None or self._scene is None:
            return
        bounds = candidate_bounds(self._scene.pixels, self._pattern, hit)
        self.scene_view.viewer.fitInView(QRectF(*bounds), Qt.AspectRatioMode.KeepAspectRatio)
        self.scene_view.viewer._fitted = False

    def _export_result(self):
        hit = self._selected_candidate()
        if hit is None or self._scene is None:
            raise ValueError("Select one accepted or rejected candidate first.")
        directory = QFileDialog.getExistingDirectory(self, "Directory for a new result review folder")
        if directory:
            target = save_candidate_review(
                Path(directory) / f"pattern-review-{uuid.uuid4().hex[:12]}", self._scene.pixels,
                self._pattern, hit, self._recipe().search,
                working_to_source=self._scene.working_to_source(), layers=self._visible_layers(),
            )
            self.status.setText(f"Saved selected review to {target}. Matching recipe unchanged.")

    def accept(self):
        if self.stage.isEnabled():
            self._perform(self._stage_recipe)

    def _stage_recipe(self):
        recipe = self._recipe()
        project = self._context.project_dir
        relative = f"assets/ogpm/{uuid.uuid4().hex}/recipe.npz"
        target = _recipe_path(project, relative)
        images = {
            _training_image_path(project, relative, "reference"): self._reference_input,
            _training_image_path(project, relative, "refinement"): self._refinement_input,
        }
        target.parent.mkdir(parents=True, exist_ok=False)
        try:
            save_recipe(target, recipe)
            for path, image in images.items():
                if image is not None:
                    ok, png = cv2.imencode(".png", image)
                    if not ok:
                        raise ValueError(f"Could not encode {path.name}.")
                    path.write_bytes(png.tobytes())
            pinned = recipe_reference(project, relative)
        except (OSError, ValueError, cv2.error):
            for path in images:
                path.unlink(missing_ok=True)
            target.unlink(missing_ok=True)
            target.parent.rmdir()
            raise
        self._parameters.update(pinned)
        super().accept()
