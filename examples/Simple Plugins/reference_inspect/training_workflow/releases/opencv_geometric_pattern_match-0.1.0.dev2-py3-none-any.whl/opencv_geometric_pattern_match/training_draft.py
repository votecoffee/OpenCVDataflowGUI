"""Captured training and preview inputs shared by graphical editors."""

from __future__ import annotations

from dataclasses import dataclass, field, replace

import cv2
import numpy as np

from .image_input import prepare_image, prepare_mask, working_to_source
from .locator import CancelCheck, Pattern, Pose, SearchReview, review_search, train
from .persistence import InspectionRecipe
from .refinement import TrainingRefinement, _refine_training

_MODEL_ARRAYS = ("points", "normals", "coarse_points", "coarse_normals", "mask", "weights", "coarse_weights")


def _readonly_copy(array: np.ndarray) -> np.ndarray:
    # The bytes backing prevents a consumer from making the pixels writable.
    return np.frombuffer(array.tobytes(), dtype=array.dtype).reshape(array.shape)


def _map_model_arrays(recipe, convert):
    arrays = {}
    for name in _MODEL_ARRAYS:
        values = getattr(recipe.pattern, name)
        if values is not None:
            arrays[name] = convert(values)
    return replace(recipe, pattern=replace(recipe.pattern, **arrays))


def _snapshot_recipe(recipe: InspectionRecipe) -> InspectionRecipe:
    recipe = _map_model_arrays(recipe, _readonly_copy)
    search = recipe.search
    search = replace(search, angle=tuple(search.angle), scale=tuple(search.scale), aspect=tuple(search.aspect))
    roi = None if recipe.search_roi is None else tuple(recipe.search_roi)
    return replace(recipe, search=search, search_roi=roi)


@dataclass(frozen=True, eq=False, init=False)
class ImageSnapshot:
    """An owned working grayscale image and its source pixel grid."""

    pixels: np.ndarray = field(repr=False)
    source_shape: tuple[int, int]
    input_scale: float

    def __init__(self, image: np.ndarray, input_scale: float = 1.0):
        working = prepare_image(image, input_scale)
        object.__setattr__(self, "pixels", _readonly_copy(working))
        object.__setattr__(self, "source_shape", image.shape)
        object.__setattr__(self, "input_scale", float(input_scale))

    def working_to_source(self) -> np.ndarray:
        """Map working pixel centers into the captured source image."""
        return working_to_source(self.source_shape, self.pixels.shape)


@dataclass(frozen=True, eq=False)
class TrainingDraft:
    """Single-image training inputs in the reference snapshot's working pixels."""

    reference: ImageSnapshot
    roi: tuple[int, int, int, int] | None = None
    origin: tuple[float, float] | None = None
    mask: np.ndarray | None = field(default=None, repr=False)
    edge_threshold: float | None = 45.0
    coarse_factor: int | None = None
    fine_sigma: float | None = 0.85
    ignore_polarity: bool = False

    def __post_init__(self):
        if self.roi is not None:
            roi = tuple(self.roi)
            if len(roi) != 4 or any(
                not isinstance(value, (int, np.integer)) or isinstance(value, bool) for value in roi
            ):
                raise ValueError("Training ROI requires four whole working-pixel values.")
            object.__setattr__(self, "roi", tuple(map(int, roi)))
        if self.origin is not None:
            object.__setattr__(self, "origin", tuple(self.origin))
        if self.mask is not None:
            shape = self.reference.pixels.shape
            object.__setattr__(self, "mask", _readonly_copy(prepare_mask(self.mask, shape, shape, training=True)))

    def train(self, *, cancelled: CancelCheck = None) -> Pattern:
        """Fit the captured draft and attach the reference's input scale."""
        pattern = train(
            self.reference.pixels, self.roi, origin=self.origin, mask=self.mask,
            edge_threshold=self.edge_threshold, coarse_factor=self.coarse_factor,
            fine_sigma=self.fine_sigma, ignore_polarity=self.ignore_polarity, cancelled=cancelled,
        )
        return replace(pattern, input_scale=self.reference.input_scale)


@dataclass(frozen=True, eq=False)
class InspectionPreview:
    """A recipe and a separate scene snapshot for one inspection preview."""

    recipe: InspectionRecipe
    scene: ImageSnapshot
    mask: np.ndarray | None = field(default=None, repr=False)

    def __post_init__(self):
        if self.scene.input_scale != self.recipe.pattern.input_scale:
            raise ValueError("Preview scene must use the recipe's input scale.")
        object.__setattr__(self, "recipe", _snapshot_recipe(self.recipe))
        if self.mask is not None:
            shape = self.scene.pixels.shape
            object.__setattr__(self, "mask", _readonly_copy(prepare_mask(self.mask, shape, shape)))

    def review(self, *, cancelled: CancelCheck = None) -> SearchReview:
        """Return accepted and sampled rejected poses with measured edge correspondences."""
        return review_search(
            self.scene.pixels, self.recipe.pattern, self.recipe.search,
            roi=self.recipe.search_roi, mask=self.mask, capture_fit=True, cancelled=cancelled,
        )

    def refine(self, pose: Pose, *, cancelled: CancelCheck = None) -> TrainingRefinement:
        """Adapt the pattern at an operator-selected preview datum pose."""
        return _refine_training(
            self.scene.pixels, self.recipe.pattern, pose, self.recipe.search,
            self.recipe.search_roi, self.mask, cancelled=cancelled,
        )


def draw_training_selection(image: np.ndarray, roi: tuple[int, int, int, int] | None = None,
                            origin: tuple[float, float] | None = None) -> np.ndarray:
    """Show the draft ROI and datum before the pattern is trained."""
    overlay = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    height, width = image.shape
    x, y, w, h = roi or (0, 0, width, height)
    if x >= 0 and y >= 0 and w >= 8 and h >= 8 and x + w <= width and y + h <= height:
        cv2.rectangle(overlay, (x, y), (x + w - 1, y + h - 1), (215, 155, 45), 2)
        if origin is None:
            origin = (x + (w - 1) / 2, y + (h - 1) / 2)
    if origin is not None and 0 <= origin[0] < width and 0 <= origin[1] < height:
        cv2.drawMarker(overlay, tuple(round(p) for p in origin), (20, 215, 255), cv2.MARKER_CROSS, 18, 2)
    return overlay


def draw_training_mask(image: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """Tint ignored and clutter-only pixels in a grayscale or BGR preview."""
    overlay = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR) if image.ndim == 2 else image.copy()
    for region, color in ((mask < 64, (72, 70, 205)), ((mask >= 64) & (mask < 128), (18, 170, 240))):
        overlay[region] = 0.48 * overlay[region] + 0.52 * np.array(color)
    return overlay
