"""Immutable completed-fit evidence and exact consumed-frame review; never searches."""

from __future__ import annotations

import copy
import hashlib
import json
from dataclasses import dataclass, field, replace
from pathlib import Path

import cv2
import numpy as np

from .image_input import prepare_mask
from .locator import draw_matches
from .persistence import save_recipe
from .result_review import save_candidate_review
from .training_draft import ImageSnapshot, _readonly_copy

BINDING = "ogpm_completed_review"


def _candidate(value):
    return replace(
        value,
        edge_matches=None if value.edge_matches is None else tuple(map(tuple, value.edge_matches)),
        outside_region_indices=tuple(value.outside_region_indices),
    )


@dataclass(frozen=True)
class CompletedMatchRecord:
    """Only the last model/fit record; source pixels remain in the host input cache."""

    identifier: str
    model: object = field(repr=False)
    matches: tuple
    rejected: tuple
    rejection_counts: tuple
    working_size: tuple
    fit_captured: bool
    rejections_retained: bool

    @classmethod
    def create(cls, identifier, model, matches, rejected, counts, size, fit, rejections):
        return cls(
            identifier,
            model,
            tuple(map(_candidate, matches)),
            tuple(map(_candidate, rejected)),
            tuple(sorted(counts.items())),
            tuple(size),
            bool(fit),
            bool(rejections),
        )

    def __deepcopy__(self, memo):
        return self  # Model buffers and candidates are immutable; do not clone feature arrays.


@dataclass(frozen=True)
class CompletedMatchCapture:
    record: CompletedMatchRecord
    scene: ImageSnapshot
    source_pixels: np.ndarray = field(repr=False, compare=False)
    inspected: np.ndarray = field(repr=False, compare=False)
    source_format: str
    source_sha256: str
    _provenance: dict = field(repr=False, compare=False)

    @property
    def recipe(self):
        return self.record.model.recipe

    @property
    def provenance(self):
        return copy.deepcopy(self._provenance)

    def report(self):
        recipe = self.recipe
        return dict(
            model="ogpm_completed_execution_review_v1",
            execution_binding=self.record.identifier,
            executed_model=self.record.model.describe(),
            source_image=dict(
                shape=list(self.source_pixels.shape),
                dtype=self.source_pixels.dtype.str,
                format=self.source_format,
                sha256=self.source_sha256,
            ),
            working_size=list(self.record.working_size),
            working_to_input=np.vstack((self.scene.working_to_source(), [0.0, 0.0, 1.0])).tolist(),
            accepted=len(self.record.matches),
            retained_rejections=len(self.record.rejected),
            rejection_counts=dict(self.record.rejection_counts),
            correspondences_captured=self.record.fit_captured,
            rejection_diagnostics_retained=self.record.rejections_retained,
            inspected_pixels=int(np.count_nonzero(self.inspected)),
            working_pixels=int(self.inspected.size),
            search_roi=None if recipe.search_roi is None else list(recipe.search_roi),
            provenance=self.provenance,
            coordinate_scope="Exact consumed input grid; upstream spatial/pyramid metadata retained",
            identity_scope="Execution binding/snapshot IDs are not acquisition or exposure identities",
            search_reexecuted=False,
            recipe_reloaded=False,
            training_changed=False,
        )

    def inspected_image(self):
        image = cv2.cvtColor(self.scene.pixels, cv2.COLOR_GRAY2BGR)
        excluded = ~self.inspected
        image[excluded] = np.rint(image[excluded] * 0.35 + [15, 30, 50]).astype(np.uint8)
        return image

    def export(self, directory, candidate=None, *, layers=None):
        """Export a new immutable-frame review and re-encoded executed model snapshot."""
        recipe = self.recipe
        if candidate is not None and not any(
            candidate is value for value in self.record.matches + self.record.rejected
        ):
            raise ValueError("Select a candidate from this completed execution")
        if candidate is None:
            target = Path(directory)
            target.mkdir(parents=True, exist_ok=False)
            fit = draw_matches(
                self.scene.pixels, recipe.pattern, self.record.matches, layers=layers
            )
            _png(target / "fit.png", fit)
            report = dict(model="ogpm_completed_overview_v1", selected=None)
        else:
            target = save_candidate_review(
                directory,
                self.scene.pixels,
                recipe.pattern,
                candidate,
                recipe.search,
                working_to_source=self.scene.working_to_source(),
                layers=layers,
            )
            report = json.loads((target / "review.json").read_bytes())
        with (target / "consumed_input.npy").open("wb") as stream:
            np.save(stream, self.source_pixels, allow_pickle=False)
        _png(target / "working.png", self.scene.pixels)
        _png(target / "inspected_mask.png", self.inspected.astype(np.uint8) * 255)
        _png(target / "inspected.png", self.inspected_image())
        save_recipe(target / "executed_recipe.npz", recipe)
        details = self.report()
        details["exported_recipe"] = dict(
            file="executed_recipe.npz",
            sha256=hashlib.sha256((target / "executed_recipe.npz").read_bytes()).hexdigest(),
            scope="Re-encoded immutable executed model; archive bytes may differ from original pin",
        )
        report["completed_execution"] = details
        (target / "review.json").write_text(
            json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8"
        )
        return target


def _png(path, pixels):
    ok, encoded = cv2.imencode(".png", pixels)
    if not ok:
        raise ValueError("Could not encode completed review image")
    path.write_bytes(encoded.tobytes())


def capture_completed(record, bundle):
    """Bind a private atomic SDK input/output snapshot to its immutable model/fit cache."""
    from opencv_dataflow.images import image_format
    from opencv_dataflow.processing import gray_image
    from opencv_dataflow.selection import selection_mask

    if record is None:
        raise ValueError("No retained completed fit record; execute in Debug before reviewing")
    review, matches = bundle.outputs["review"], bundle.outputs["matches"]
    if review.payload.get(BINDING, {}).get("id") != record.identifier:
        raise ValueError("Completed execution changed during capture; capture the latest run again")
    if (
        review.value["recipe_sha256"] != record.model.sha256
        or matches.value["pattern_id"] != record.model.model_id
        or matches.value["count"] != len(record.matches)
        or tuple(review.value["working_size"]) != record.working_size
    ):
        raise ValueError("Completed model/result evidence does not match the retained fit record")
    image = bundle.inputs["image"].value
    native = gray_image(image, (np.uint8, np.uint16))
    recipe = record.model.recipe
    scene = ImageSnapshot(native, recipe.pattern.input_scale)
    mapping = np.vstack((scene.working_to_source(), [0.0, 0.0, 1.0]))
    if tuple(scene.pixels.shape[::-1]) != record.working_size or not np.array_equal(
        mapping, np.array(review.value["working_to_input"])
    ):
        raise ValueError("Completed image grid differs from its recorded model mapping")
    values = {name: packet.value for name, packet in bundle.inputs.items()}
    mask = selection_mask(values, native)
    inspected = np.ones(scene.pixels.shape, bool)
    if mask is not None:
        inspected &= prepare_mask(mask, native.shape, scene.pixels.shape) >= 128
    if recipe.search_roi is not None:
        x, y, width, height = recipe.search_roi
        region = np.zeros_like(inspected)
        region[y : y + height, x : x + width] = True
        inspected &= region
    source = _readonly_copy(np.asarray(image))
    provenance = dict(
        snapshot_id=bundle.snapshot_id,
        block_id=bundle.block_id,
        output_revision=bundle.output_revision,
        execution_count=bundle.execution_count,
        passed=bool(bundle.passed),
        score=bundle.score,
        message=bundle.message,
        inputs={name: copy.deepcopy(packet.payload) for name, packet in bundle.inputs.items()},
        outputs={name: copy.deepcopy(packet.payload) for name, packet in bundle.outputs.items()},
    )
    return CompletedMatchCapture(
        record,
        scene,
        source,
        _readonly_copy(inspected),
        image_format(image),
        hashlib.sha256(source.tobytes()).hexdigest(),
        provenance,
    )
