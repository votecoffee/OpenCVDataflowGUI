"""Reusable execution workers for independent fine fits on shared scene edges."""

from concurrent.futures import FIRST_EXCEPTION, ProcessPoolExecutor, wait
from concurrent.futures.process import BrokenProcessPool
from contextlib import ExitStack
from multiprocessing import get_context
from multiprocessing.shared_memory import SharedMemory
from shutil import disk_usage
from sys import platform
from threading import Lock

import cv2
import numpy as np

from .locator import _check_cancelled, _fit_starts


_MAX_WORKERS = 8
_MIN_SEEDS_PER_WORKER = 16
_MIN_INITIAL_PROBES = 65_536
_SHARED_ALLOCATION = Lock()


def _shared_copy(array, stack):
    memory = SharedMemory(create=True, size=array.nbytes)
    stack.callback(memory.unlink)
    stack.callback(memory.close)
    view = np.ndarray(array.shape, array.dtype, buffer=memory.buf)
    view[:] = array
    return (memory.name, array.shape, array.dtype), view


def _attach(spec, stack):
    name, shape, dtype = spec
    memory = SharedMemory(name=name)
    stack.callback(memory.close)
    view = np.ndarray(shape, dtype, buffer=memory.buf)
    view.flags.writeable = False
    return view


def _initialize_worker():
    # The host's OpenCV configuration belongs to the parent process.
    cv2.setNumThreads(1)


def _fit_shard(lookup_spec, edges_spec, stop_spec, args):
    with ExitStack() as shared:
        lookup = _attach(lookup_spec, shared)
        edges = _attach(edges_spec, shared)
        stop = _attach(stop_spec, shared)
        return list(_fit_starts(lookup, edges, *args, lambda: bool(stop[0])))


class SearchRuntime:
    """Own reusable fine-fit workers for calls to locate_all and review_search.

    The worker count is an execution limit and is separate from the recipe.
    Close the runtime when its inspection session ends. Scripts that enable
    workers should use the standard multiprocessing main guard.
    """

    def __init__(self, workers: int = 1):
        if type(workers) is not int or not 1 <= workers <= _MAX_WORKERS:
            raise ValueError(f"Search workers must be an integer from 1 to {_MAX_WORKERS}.")
        self._workers = workers
        self._lock = Lock()
        self._pool = None
        self._closed = False

    @property
    def workers(self):
        return self._workers

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def close(self):
        """Release worker processes after any submitted work completes."""
        with self._lock:
            self._closed = True
            pool, self._pool = self._pool, None
        if pool is not None:
            pool.shutdown()

    def _fit(self, lookup, edges, pattern, starts, search, first_search, xy_bounds, capture_fit, cancelled):
        partitions = min(self._workers, len(starts) // _MIN_SEEDS_PER_WORKER)
        with self._lock:
            if self._closed:
                raise RuntimeError("The search runtime is closed.")
        if partitions < 2 or len(starts) * len(pattern.points) < _MIN_INITIAL_PROBES:
            return _fit_starts(lookup, edges, pattern, starts, search, first_search, xy_bounds, capture_fit, cancelled)
        return self._fit_parallel(
            lookup, edges, pattern, starts, search, first_search, xy_bounds, capture_fit, cancelled, partitions,
        )

    def _fit_parallel(self, lookup, edges, pattern, starts, search, first_search, xy_bounds,
                      capture_fit, cancelled, partitions):
        if cancelled is not None:
            _check_cancelled(cancelled)
        with ExitStack() as shared:
            try:
                with _SHARED_ALLOCATION:
                    # Linux may allow creation past its tmpfs capacity and fault on write.
                    if platform == "linux" and lookup.nbytes + edges.nbytes + 4096 >= disk_usage("/dev/shm").free:
                        raise OSError("Insufficient space for shared scene edge maps.")
                    lookup_spec, _ = _shared_copy(lookup, shared)
                    edges_spec, _ = _shared_copy(edges, shared)
                    stop_spec, stop = _shared_copy(np.zeros(1, dtype=np.uint8), shared)
            except OSError:
                return _fit_starts(lookup, edges, pattern, starts, search, first_search, xy_bounds, capture_fit, cancelled)
            futures = []
            pool = None
            try:
                with self._lock:
                    if self._closed:
                        raise RuntimeError("The search runtime is closed.")
                    if self._pool is None:
                        self._pool = ProcessPoolExecutor(
                            self._workers, mp_context=get_context("spawn"), initializer=_initialize_worker,
                        )
                    pool = self._pool
                    for index in range(partitions):
                        args = (pattern, starts[index::partitions], search, first_search, xy_bounds, capture_fit)
                        futures.append(pool.submit(_fit_shard, lookup_spec, edges_spec, stop_spec, args))
                pending = set(futures)
                while pending:
                    if cancelled is not None:
                        _check_cancelled(cancelled)
                    done, pending = wait(pending, timeout=0.05 if cancelled is not None else None,
                                         return_when=FIRST_EXCEPTION)
                    for future in done:
                        future.result()
                # Keep original coarse order for tied scores, overlap and diagnostics.
                results = [None] * len(starts)
                for index, future in enumerate(futures):
                    results[index::partitions] = future.result()
                return results
            except BrokenProcessPool:
                with self._lock:
                    if self._pool is pool:
                        self._pool = None
                if pool is not None:
                    pool.shutdown()
                raise
            finally:
                # Workers may still hold mappings if a submit fails or the caller stops.
                stop[0] = 1
                for future in futures:
                    future.cancel()
                wait(futures)
