"""Score pose detections from multiple engines against the same labeled scenes."""

from __future__ import annotations

import argparse
import json
import math
from collections import Counter
from collections.abc import Iterable
from dataclasses import asdict, replace
from pathlib import Path

import cv2
import numpy as np

from .image_input import prepare_image, read_gray
from .locator import Pattern, Pose, Search, locate_all
from .persistence import load_pattern

_COUNTS = ("targets", "detections", "matched", "missed", "extra_pose", "pose_mismatch", "wrong_part", "background")


def _number(value):
    if type(value) not in (float, int) or not math.isfinite(value):
        raise ValueError("Pose labels and tolerances require finite numbers.")
    return float(value)


def _pose(item):
    pose = Pose(*(_number(item[name]) for name in ("x", "y", "angle_deg")),
                _number(item.get("scale", 1)), _number(item.get("aspect", 1)))
    if pose.scale <= 0 or pose.aspect <= 0:
        raise ValueError("Pose scale and aspect must be positive.")
    return pose


def _polygon(box, pose=None):
    x, y, width, height, angle = map(_number, box)
    if width <= 0 or height <= 0:
        raise ValueError("Footprint width and height must be positive.")
    corners = cv2.boxPoints(((x, y), (width, height), -angle))
    if pose is not None:
        matrix = pose.matrix()
        corners = (corners @ matrix[:, :2].T + matrix[:, 2]).astype(np.float32)
    if not np.isfinite(corners).all() or cv2.contourArea(corners) <= 0:
        raise ValueError("Footprint must have finite, nondegenerate corners.")
    return corners


def _overlap(first, second):
    area, _ = cv2.intersectConvexConvex(first, second)
    return float(np.clip(area / min(cv2.contourArea(first), cv2.contourArea(second)), 0, 1))


def _score_scene(scene, detections, model_box, center_limit, angle_limit, overlap_limit, assign):
    targets, distractors = scene["targets"], scene.get("distractors", [])
    labels = targets + distractors
    if len({label["id"] for label in labels}) != len(labels):
        raise ValueError("Instance IDs must be unique within a scene.")
    truth = [_pose(target["pose"]) for target in targets]
    poses = [_pose(item["pose"]) for item in detections]
    periods = [_number(target.get("angle_period_deg", 360)) for target in targets]
    if any(not 0 < period <= 360 for period in periods):
        raise ValueError("Angle period must be in (0, 360].")

    # Every detection can opt out at a cost larger than the sum of all valid pose costs.
    # This maximizes the number of valid pairs before minimizing their combined error.
    count, expected = len(poses), len(truth)
    miss_cost = 2 * count + 1
    costs = np.full((count, expected + count), float(miss_cost))
    errors = {}
    for i, pose in enumerate(poses):
        for j, (target, period) in enumerate(zip(truth, periods)):
            center = math.hypot(pose.x - target.x, pose.y - target.y)
            angle = abs(math.remainder(pose.angle_deg - target.angle_deg, period))
            if center <= center_limit and angle <= angle_limit:
                costs[i, j] = center / center_limit + angle / angle_limit
                errors[i, j] = (center, angle)
            else:
                costs[i, j] = 2 * miss_cost
    rows, cols = assign(costs)
    pairs = {}
    for i, j in zip(rows.tolist(), cols.tolist()):
        if j < expected:
            pairs[i] = j
    matched = set(pairs.values())
    missed = [target["id"] for j, target in enumerate(targets) if j not in matched]
    counts = Counter(targets=expected, detections=count, matched=len(matched), missed=len(missed))
    boxes = [_polygon(target["box"]) if "box" in target else _polygon(model_box, pose)
             for target, pose in zip(targets, truth)]
    boxes.extend(_polygon(label["box"]) for label in distractors)
    results = []
    for i, pose in enumerate(poses):
        if i in pairs:
            j = pairs[i]
            center, angle = errors[i, j]
            results.append({"detection": i, "kind": "matched", "instance": targets[j]["id"],
                            "center_error_px": center, "angle_error_deg": angle})
            continue
        footprint = _polygon(model_box, pose)
        overlap, j = max(((_overlap(footprint, box), j) for j, box in enumerate(boxes)),
                         key=lambda item: item[0], default=(0, None))
        kind, instance = "background", None
        if overlap >= overlap_limit:
            instance = labels[j]["id"]
            if j < expected:
                kind = "extra_pose" if j in matched else "pose_mismatch"
            else:
                kind = "wrong_part"
        counts[kind] += 1
        results.append({"detection": i, "kind": kind, "instance": instance, "footprint_overlap": overlap})
    return {"counts": {key: counts[key] for key in _COUNTS}, "missed_instances": missed, "results": results}


def score_detections(labels: dict, predictions: dict) -> dict:
    """Compare one prediction file to shared labels in working pixel coordinates."""
    from scipy.optimize import linear_sum_assignment

    if labels["scenes"].keys() != predictions["scenes"].keys():
        raise ValueError("Label and prediction files must have identical scene IDs, including empty scenes.")
    center, angle, overlap = (_number(labels[name]) for name in
                              ("center_tolerance_px", "angle_tolerance_deg", "overlap_threshold"))
    if center <= 0 or not 0 < angle <= 180 or not 0 < overlap <= 1:
        raise ValueError("Use positive tolerances, an angle tolerance up to 180, and overlap in (0, 1].")
    model_box = labels["model_box"]
    _polygon(model_box)
    scenes = {
        scene_id: _score_scene(scene, predictions["scenes"][scene_id], model_box, center, angle, overlap,
                               linear_sum_assignment)
        for scene_id, scene in labels["scenes"].items()
    }
    matched = [result for scene in scenes.values() for result in scene["results"] if result["kind"] == "matched"]
    pose_error = {}
    for metric in ("center_error_px", "angle_error_deg"):
        values = [result[metric] for result in matched]
        pose_error[metric] = {"median": float(np.median(values)), "max": max(values)} if values else None
    return {"counts": {key: sum(scene["counts"][key] for scene in scenes.values()) for key in _COUNTS},
            "pose_error": pose_error,
            "scenes": scenes}


def _grid(values):
    limits = sorted({_number(value) for value in values})
    if not limits or limits[0] < 0 or limits[-1] > 1:
        raise ValueError("Search grid axes require one or more values in [0, 1].")
    return limits


def score_search_grid(
    labels: dict, frames: Iterable[tuple[str, np.ndarray]], pattern: Pattern, search: Search, *,
    accept: Iterable[float], xy_overlap: Iterable[float], roi: tuple[int, int, int, int] | None = None,
) -> dict:
    """Measure acceptance and overlap sensitivity using labeled working images."""
    cutoffs, overlaps = _grid(accept), _grid(xy_overlap)
    run_cutoffs = cutoffs if search.aspect_fallback else cutoffs[:1]
    recipes = {(limit, cutoff): replace(search, accept=cutoff, xy_overlap=limit)
               for limit in overlaps for cutoff in run_cutoffs}
    runs = {key: {} for key in recipes}
    seen = set()
    for scene_id, image in frames:
        if scene_id in seen or scene_id not in labels["scenes"]:
            raise ValueError("Images and labels must have identical, unique scene IDs.")
        seen.add(scene_id)
        for key, recipe in recipes.items():
            matches = locate_all(image, pattern, recipe, roi=roi)
            runs[key][scene_id] = [asdict(hit) for hit in matches]
    if seen != labels["scenes"].keys():
        raise ValueError("Images and labels must have identical, unique scene IDs.")

    rows = []
    for limit in overlaps:
        for cutoff in cutoffs:
            # With fallback, the cutoff also selects the fit, so each cutoff needs its own run.
            scenes = runs[limit, cutoff if search.aspect_fallback else cutoffs[0]]
            predictions = {key: [hit for hit in hits if hit["score"] >= cutoff] for key, hits in scenes.items()}
            result = score_detections(labels, {"scenes": predictions})
            rows.append({"accept": cutoff, "xy_overlap": limit, "counts": result["counts"],
                         "pose_error": result["pose_error"]})
    return {"fixed_search": {key: value for key, value in asdict(search).items() if key not in ("accept", "xy_overlap")},
            "search_roi": roi, "rows": rows}


def _run_grid(labels: dict, recipe: dict, directory: Path) -> dict:
    pattern = load_pattern(directory / recipe["pattern"])
    options = recipe.get("search", {}).copy()
    if options.get("start_pose") is not None:
        options["start_pose"] = _pose(options["start_pose"])
    frames = ((scene, prepare_image(read_gray(directory / path), pattern.input_scale))
              for scene, path in recipe["scenes"].items())
    return score_search_grid(labels, frames, pattern, Search(**options), accept=recipe["accept"],
                             xy_overlap=recipe["xy_overlap"], roi=recipe.get("search_roi"))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("labels", type=Path)
    parser.add_argument("input", type=Path, help="Prediction JSON or a search recipe with --search-grid.")
    parser.add_argument("--search-grid", action="store_true", help="Run an OpenCV acceptance and overlap grid.")
    args = parser.parse_args(argv)
    try:
        labels = json.loads(args.labels.read_text(encoding="utf-8-sig"))
        inputs = json.loads(args.input.read_text(encoding="utf-8-sig"))
        report = (_run_grid(labels, inputs, args.input.resolve().parent) if args.search_grid
                  else score_detections(labels, inputs))
    except ModuleNotFoundError:
        parser.error("Install the benchmark extra with pip install .[benchmark].")
    except (OSError, ValueError, KeyError, TypeError, OverflowError, cv2.error) as error:
        parser.error(str(error))
    print(json.dumps(report, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
