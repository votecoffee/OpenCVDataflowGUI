"""Measurement definition editor with named datums, optional limits and picked probes."""

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
)

from .specs import LINE_KINDS, LineRegion, Measurement

KINDS = {"Signed step height": "step_height", "Plane angle": "plane_angle",
         "Surface residual range": "surface_range", "Point to plane": "point_plane_distance",
         "Minimum-zone flatness (all selected)": "minimum_zone_flatness",
         "Line separation (parallel)": "line_separation", "Line angle": "line_angle",
         "Point to line": "point_line_distance", "Observed line span": "line_span"}


def number(value=0):
    field = QDoubleSpinBox()
    field.setDecimals(9)
    field.setRange(-1e12, 1e12)
    field.setValue(value)
    return field


class MeasurementDialog(QDialog):
    def __init__(self, planes, units, *, spec=None, picked=None, parent=None, name="Measurement 1"):
        super().__init__(parent)
        self.setWindowTitle("Define 3D measurement")
        self.value, self.units, self.picked = None, units, picked
        self.regions = tuple(planes)
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.form = form
        layout.addLayout(form)
        self.name = QLineEdit(spec.name if spec else name)
        self.kind, self.plane, self.other = QComboBox(), QComboBox(), QComboBox()
        for label, kind in KINDS.items():
            self.kind.addItem(label, kind)
        for p in planes:
            self.plane.addItem(p.name)
            self.other.addItem(p.name)
        if len(planes) > 1:
            self.other.setCurrentIndex(1)
        if spec:
            self.kind.setCurrentIndex(self.kind.findData(spec.kind))
            self.plane.setCurrentText(spec.plane)
            self.other.setCurrentText(spec.other or "")
        else:
            count = sum(not isinstance(p, LineRegion) for p in planes)
            default = ("step_height" if count > 1 else "surface_range" if count else
                       "line_separation" if len(planes) > 1 else "line_span")
            self.kind.setCurrentIndex(self.kind.findData(default))
        form.addRow("Name", self.name)
        form.addRow("Measurement", self.kind)
        form.addRow("Datum / region", self.plane)
        form.addRow("Target region", self.other)
        point = spec.point if spec and spec.point else picked or (0, 0, 0)
        self.probe = [number(v) for v in point]
        probe_row = QHBoxLayout()
        for title, field in zip("XYZ", self.probe):
            probe_row.addWidget(QLabel(title))
            probe_row.addWidget(field)
        self.use_pick = QPushButton("Use picked point")
        self.use_pick.setEnabled(picked is not None)
        self.use_pick.clicked.connect(self._picked)
        probe_row.addWidget(self.use_pick)
        form.addRow(f"Probe ({units}, reference frame)", probe_row)
        self.angle = number(spec.max_angle_degrees if spec else 5)
        self.angle.setRange(0, 90)
        self.angle.setSuffix(" deg")
        form.addRow("Height / separation maximum angle", self.angle)
        self.zone_budget = QSpinBox()
        self.zone_budget.setRange(4, 1024)
        self.zone_budget.setValue(spec.zone_max_vertices if spec else 256)
        self.zone_budget.setToolTip("Maximum hull vertices. All selected points still count; "
                                   "exceeding the geometry budget makes flatness unavailable.")
        form.addRow("Flatness geometry budget", self.zone_budget)
        self.limits = []
        for title, val in (("Lower limit", spec.lower if spec else None),
                           ("Upper limit", spec.upper if spec else None)):
            enabled = QCheckBox(title)
            enabled.setChecked(val is not None)
            field = number(val or 0)
            enabled.toggled.connect(field.setEnabled)
            row = QHBoxLayout()
            row.addWidget(enabled)
            row.addWidget(field)
            form.addRow(row)
            self.limits.append((enabled, field))
        self.status = QLabel("No limits means a measured value without an acceptance criterion.")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                                   QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.kind.currentIndexChanged.connect(self._sync)
        self._sync()

    def _picked(self):
        for field, value in zip(self.probe, self.picked):
            field.setValue(value)

    def _sync(self, *_):
        kind = self.kind.currentData()
        names = [p.name for p in self.regions
                 if isinstance(p, LineRegion) == (kind in LINE_KINDS)]
        for index, combo in enumerate((self.plane, self.other)):
            current = combo.currentText()
            combo.clear()
            combo.addItems(names)
            if current in names:
                combo.setCurrentText(current)
            elif names:
                combo.setCurrentIndex(min(index, len(names) - 1))
        paired = kind in ("step_height", "plane_angle", "line_separation", "line_angle")
        is_probe = kind in ("point_plane_distance", "point_line_distance")
        self.other.setEnabled(paired)
        self.angle.setEnabled(kind in ("step_height", "line_separation"))
        self.form.setRowVisible(self.zone_budget, kind == "minimum_zone_flatness")
        for field in self.probe:
            field.setEnabled(is_probe)
        self.use_pick.setEnabled(is_probe and self.picked is not None)
        for check, field in self.limits:
            field.setEnabled(check.isChecked())
            field.setSuffix(" deg" if kind in ("plane_angle", "line_angle") else " " + self.units)

    def _accept(self):
        kind = self.kind.currentData()
        try:
            low, high = [field.value() if check.isChecked() else None
                         for check, field in self.limits]
            self.value = Measurement(
                self.name.text(), kind, self.plane.currentText(),
                other=(self.other.currentText() if kind in ("step_height", "plane_angle",
                                                           "line_separation", "line_angle")
                       else None),
                point=(tuple(f.value() for f in self.probe)
                       if kind in ("point_plane_distance", "point_line_distance") else None),
                lower=low, upper=high, max_angle_degrees=self.angle.value(),
                zone_max_vertices=(self.zone_budget.value()
                                   if kind == "minimum_zone_flatness" else 256))
        except ValueError as error:
            self.status.setText(str(error))
            return
        self.accept()
