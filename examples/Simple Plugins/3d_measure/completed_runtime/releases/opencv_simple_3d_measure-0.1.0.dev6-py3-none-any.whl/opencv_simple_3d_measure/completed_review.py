"""Frozen completed cloud, effective fixture and measurement/fit evidence."""

import copy
import hashlib
import json
from dataclasses import dataclass, field, is_dataclass
from pathlib import Path

import numpy as np
from opencv_dataflow.payloads import NO_VALUE
from opencv_dataflow.pointclouds import PointCloud

from .graphics import LAYERS, result_cloud
from .residuals import ResidualReview

BINDING = "measure_3d_completed_review"


def limits_text(item):
    lower, upper = item["lower"], item["upper"]
    if lower is None and upper is None:
        return "no acceptance limits configured"
    lower = "unbounded" if lower is None else f"{lower:g}"
    upper = "unbounded" if upper is None else f"{upper:g}"
    return f"limits [{lower}, {upper}] {item['units']}"


def _json(value):
    return json.dumps(value, sort_keys=True, allow_nan=False).encode("utf-8")


def _readonly(array):
    array = np.asarray(array)
    return np.frombuffer(array.tobytes(), dtype=array.dtype).reshape(array.shape)


def _freeze(value):
    if isinstance(value, np.ndarray):
        return _readonly(value)
    if is_dataclass(value):
        target = object.__new__(type(value))
        for name, item in vars(value).items():
            object.__setattr__(target, name, _freeze(item))
        return target
    if isinstance(value, dict):
        return {name: _freeze(item) for name, item in value.items()}
    if isinstance(value, (list, tuple)):
        return type(value)(_freeze(item) for item in value)
    return copy.deepcopy(value)


def _public_cloud(value):
    return PointCloud(
        value.points,
        value.units,
        value.frame,
        colors=value.colors,
        normals=value.normals,
        pixels=value.pixels,
        source_size=value.source_size,
        metadata=copy.deepcopy(value.metadata),
    )


def describe_cloud(value):
    return dict(
        units=value.units,
        frame=value.frame,
        source_size=value.source_size,
        metadata=copy.deepcopy(value.metadata),
        arrays={
            name: dict(
                shape=list(array.shape),
                dtype=array.dtype.str,
                sha256=hashlib.sha256(array.tobytes()).hexdigest(),
            )
            for name in ("points", "normals", "colors", "pixels")
            if (array := getattr(value, name)) is not None
        },
    )


@dataclass(frozen=True)
class CompletedMeasurementRecord:
    identifier: str
    report_json: bytes
    numeric_json: bytes
    parameters_json: bytes
    primary: str
    ports: tuple
    _result: object = field(repr=False, compare=False)
    _clouds: dict = field(repr=False, compare=False)

    @classmethod
    def create(cls, identifier, result, outputs, parameters, primary):
        emitted = {name: value for name, value in outputs.items() if value is not NO_VALUE}
        clouds = {name: value for name, value in emitted.items() if isinstance(value, PointCloud)}
        numeric = {name: value for name, value in emitted.items() if name not in clouds}
        return cls(
            identifier,
            _json(outputs["report"]),
            _json(numeric),
            _json(parameters),
            primary,
            tuple(emitted),
            result,
            clouds,
        )

    @property
    def report(self):
        return json.loads(self.report_json)

    @property
    def parameters(self):
        return json.loads(self.parameters_json)

    def __deepcopy__(self, memo):
        return self


@dataclass(frozen=True)
class CompletedMeasurementCapture:
    record: CompletedMeasurementRecord
    _result: object = field(repr=False, compare=False)
    _source: PointCloud = field(repr=False, compare=False)
    _fixture_input: object = field(repr=False, compare=False)
    _outputs: dict = field(repr=False, compare=False)
    _provenance: dict = field(repr=False, compare=False)
    _cache: dict = field(default_factory=dict, repr=False, compare=False)

    @property
    def provenance(self):
        return copy.deepcopy(self._provenance)

    @property
    def recipe_bytes(self):
        return getattr(self._result.recipe, "_source_bytes", None)

    def input_cloud(self):
        return _public_cloud(self._source)

    def measurement(self, name=None):
        name = self.record.primary if name is None else name
        for item in self.record.report["measurements"]:
            if item["name"] == name:
                return item
        raise ValueError("Choose a recorded measurement")

    def _region(self, name):
        if name is not None and name not in {r.name for r in self._result.recipe.regions}:
            raise ValueError("Choose a recorded fit region")

    def residual_review(self):
        if "residuals" not in self._cache:
            self._cache["residuals"] = ResidualReview(self._result)
        return self._cache["residuals"]

    def residual_report(self, region=None):
        self._region(region)
        return self.residual_review().report(region)

    def display_cloud(self, mode="fit", region=None, layers=LAYERS):
        self._region(region)
        if mode not in ("fit", "residuals", "input"):
            raise ValueError("Choose fit, residuals or input display")
        if isinstance(layers, str) or any(name not in LAYERS for name in layers):
            raise ValueError("Choose known graphic layers")
        if mode == "input":
            return self.input_cloud()
        if region is None and tuple(layers) == LAYERS and mode in self._outputs:
            return _public_cloud(self._outputs[mode])
        graphics = (
            result_cloud(self._result, plane=region, layers=layers)
            if mode == "fit"
            else self.residual_review().cloud(region=region, layers=layers)
        )
        return PointCloud(
            graphics.points,
            graphics.units,
            graphics.frame,
            colors=graphics.colors,
            metadata=copy.deepcopy(graphics.metadata),
        )

    def report(self, measurement=None, region=None, mode="fit", layers=LAYERS):
        self._region(region)
        return dict(
            model="simple_3d_measure_completed_review_v1",
            execution_binding=self.record.identifier,
            completed_result=self.record.report,
            executed_parameters=self.record.parameters,
            primary_measurement=self.record.primary,
            selected_measurement=self.measurement(measurement),
            selected_region=region,
            display_mode=mode,
            display_layers=list(layers),
            emitted_clouds=list(self._outputs),
            graphics_scope=(
                "Review graphics derive only from frozen fits; "
                "disabled runtime outputs remain absent"
            ),
            residual_semantics=(
                "Plane signed / line radial distance to current fit, "
                "not reference deviation or measurement uncertainty"
            ),
            residual_color_scale=(
                "Fixed at three taught fit bands; histogram tails retain values outside the range"
            ),
            effective_measurement_to_scene=self._result.fixture.tolist(),
            fixture_input=copy.deepcopy(self._fixture_input),
            source=describe_cloud(self._source),
            provenance=self.provenance,
            identity_scope=(
                "Software pairing and declared metadata do not prove physical synchronization"
            ),
            coordinate_scope=(
                "Fits/residual values use recipe units/frame; "
                "display geometry is mapped to the consumed scene frame"
            ),
            geometry_scope=(
                "Measured points remain separate from derived datum grids, ROI boxes, "
                "dimensions and minimum-zone support geometry"
            ),
            measurement_reexecuted=False,
            fit_reexecuted=False,
            recipe_reloaded=False,
            training_changed=False,
        )

    def export(
        self,
        directory,
        measurement=None,
        region=None,
        mode="fit",
        layers=LAYERS,
        *,
        yaw=25,
        pitch=-20,
    ):
        import cv2
        from opencv_dataflow.cloud_io import write_cloud

        document = self.report(measurement, region, mode, layers)
        cloud = self.display_cloud(mode, region, layers)
        target = Path(directory)
        target.mkdir(parents=True, exist_ok=False)
        if self.recipe_bytes is not None:
            (target / "executed_recipe.s3m").write_bytes(self.recipe_bytes)
            document["exported_recipe_sha256"] = hashlib.sha256(self.recipe_bytes).hexdigest()
        else:
            document["exported_recipe_sha256"] = None
        for name, value in {"consumed_scene": self._source, **self._outputs}.items():
            for member in ("points", "normals", "colors", "pixels"):
                array = getattr(value, member)
                if array is not None:
                    np.save(target / f"{name}_{member}.npy", array, allow_pickle=False)
            write_cloud(target / f"{name}.ply", value, binary=True)
        for name in ("scene", "local_points", "fixture"):
            np.save(
                target / f"measurement_{name}.npy", getattr(self._result, name), allow_pickle=False
            )
        regions = []
        for i, (spec, fit, rows) in enumerate(
            zip(self._result.recipe.regions, self._result.fits, self._result.selections)
        ):
            np.save(target / f"region_{i}_scene_rows.npy", rows, allow_pickle=False)
            for name in ("inliers", "residual"):
                array = getattr(fit, name)
                if array is not None:
                    np.save(target / f"region_{i}_{name}.npy", array, allow_pickle=False)
            regions.append(
                dict(name=spec.name, prefix=f"region_{i}", available=fit.valid, fit=fit.report())
            )
        document["exported_regions"] = regions
        self.residual_review().export(target / "all_residuals.npz")
        document["residual_review"] = self.residual_report(region)
        write_cloud(target / "selected_display.ply", cloud, binary=True)
        image = self.assessment(measurement, region, mode, layers, yaw=yaw, pitch=pitch)
        ok, png = cv2.imencode(".png", image)
        if not ok:
            raise ValueError("Could not encode measurement display")
        (target / "assessment.png").write_bytes(png.tobytes())
        document["projection"] = dict(
            yaw=yaw, pitch=pitch, scope="Display projection, not sensor pixels"
        )
        document["ply_scope"] = (
            "PLY retains XYZ/RGB/normals/units/frame; "
            "native NPY plus JSON retains source pixels and metadata"
        )
        (target / "review.json").write_text(
            json.dumps(document, indent=2, allow_nan=False) + "\n", encoding="utf-8"
        )
        return target

    def assessment(
        self, measurement=None, region=None, mode="fit", layers=LAYERS, *, yaw=25, pitch=-20
    ):
        import cv2
        from opencv_dataflow.pointclouds import render_cloud

        report = self.record.report
        item = self.measurement(measurement)
        cloud = self.display_cloud(mode, region, layers)
        image = np.full((900, 1280, 3), (30, 26, 22), np.uint8)
        image[80:720] = render_cloud(cloud, width=1280, height=640, yaw=yaw, pitch=pitch)
        value = "Unavailable" if item["value"] is None else f"{item['value']:.8g} {item['units']}"
        lines = [
            f"Simple3DMeasure | {'PASS' if report['passed'] else 'FAIL'} | frozen {mode} view",
            f"Recipe frame {report['measurement_frame']} -> scene {report['scene_frame']} | "
            f"{report['units']} | yaw {yaw}, pitch {pitch} | display projection",
            f"{item['name']}: {value} | {item['status']} | "
            f"{limits_text(item)}",
            f"{item['kind']} | {item.get('reason') or item.get('definition', '')}",
            f"Region: {region or 'all'} | primary: {self.record.primary} | "
            "no measurement or fit repeated",
            "Fit: green inliers, red exclusions, magenta unavailable; "
            "grids/axes/dimensions are derived.",
            "Residuals: fixed 3 taught bands, not measurement uncertainty. "
            "Exact raw input keeps source colors.",
        ]
        for text, y in zip(lines, (28, 57, 755, 782, 809, 842, 874)):
            text = text.encode("ascii", errors="replace").decode("ascii")[:170]
            while text and cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.53, 1)[0][0] > 1240:
                text = text[:-1]
            cv2.putText(
                image,
                text,
                (18, y),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.53,
                (230, 235, 240),
                1,
                cv2.LINE_AA,
            )
        return image


def capture_completed(record, bundle):
    if record is None:
        raise ValueError("No retained completed measurements; execute in Debug before reviewing")
    if any(
        bundle.outputs[name].payload.get(BINDING, {}).get("id") != record.identifier
        for name in record.ports
    ):
        raise ValueError("Completed model/result evidence changed; capture the latest run again")
    numeric = {
        name: packet.value for name, packet in bundle.outputs.items() if name not in record._clouds
    }
    if _json(numeric) != record.numeric_json:
        raise ValueError("Completed measurement values changed; capture the latest run again")
    for name, expected in record._clouds.items():
        value = bundle.outputs[name].value
        if (
            not isinstance(value, PointCloud)
            or value.units != expected.units
            or value.frame != expected.frame
        ):
            raise ValueError("Completed graphic cloud frame/units changed")
        if not np.array_equal(value.points, expected.points) or not np.array_equal(
            value.colors, expected.colors
        ):
            raise ValueError("Completed graphic cloud evidence changed")
    source = bundle.inputs["scene"].value
    if source.units != record._result.recipe.units or source.frame != record._result.frame:
        raise ValueError("Completed source frame/units disagree with measurements")
    provenance = dict(
        snapshot_id=bundle.snapshot_id,
        block_id=bundle.block_id,
        output_revision=bundle.output_revision,
        execution_count=bundle.execution_count,
        passed=bool(bundle.passed),
        score=bundle.score,
        message=bundle.message,
        inputs={name: copy.deepcopy(packet.payload) for name, packet in bundle.inputs.items()},
        outputs={name: copy.deepcopy(packet.payload) for name, packet in bundle.outputs.items()},
    )
    return CompletedMeasurementCapture(
        record,
        _freeze(record._result),
        _freeze(source),
        None if "fixture" not in bundle.inputs else copy.deepcopy(bundle.inputs["fixture"].value),
        {name: _freeze(bundle.outputs[name].value) for name in record._clouds},
        provenance,
    )
