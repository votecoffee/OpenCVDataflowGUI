"""Bounded, immutable reference appearance and descriptive capture evidence."""

import hashlib
import json
from dataclasses import dataclass

import numpy as np

from .specs import MAX_POINTS

MAX_METADATA_BYTES = 256 * 1024


def metadata_bytes(value):
    """Copy plain JSON without coercing arrays, numbers, objects or nonfinite values."""
    if not isinstance(value, dict):
        raise ValueError("Reference metadata must be a plain JSON object")
    remaining = 8192

    def check(item, depth=0):
        nonlocal remaining
        remaining -= 1
        if remaining < 0 or depth > 12:
            raise ValueError("Reference metadata exceeds its node/depth budget")
        if type(item) is dict:
            for key, child in item.items():
                if type(key) is not str or len(key) > 256:
                    raise ValueError("Reference metadata keys must be bounded strings")
                check(child, depth + 1)
        elif type(item) in (list, tuple):
            for child in item:
                check(child, depth + 1)
        elif item is None or type(item) is bool:
            pass
        elif type(item) is str:
            if len(item) > 32768:
                raise ValueError("Reference metadata string exceeds 32768 characters")
        elif type(item) is int:
            if item.bit_length() > 256:
                raise ValueError("Reference metadata integer exceeds 256 bits")
        elif type(item) is float and np.isfinite(item):
            pass
        else:
            raise ValueError("Reference metadata must contain only finite plain JSON values")

    check(value)
    raw = json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":"),
                     allow_nan=False).encode("utf-8")
    if len(raw) > MAX_METADATA_BYTES:
        raise ValueError("Reference metadata exceeds 256 KiB")
    return raw


@dataclass(frozen=True, init=False)
class ReferenceEvidence:
    count: int
    colors: np.ndarray | None
    pixels: np.ndarray | None
    source_size: tuple | None
    _metadata: bytes

    def __init__(self, count, *, colors=None, pixels=None, source_size=None, metadata=None):
        if type(count) is not int or not 0 <= count <= MAX_POINTS:
            raise ValueError("Reference evidence needs a bounded source row count")
        if source_size is not None:
            source_size = tuple(source_size)
            if (len(source_size) != 2 or
                    any(type(v) is not int or not 1 <= v <= 1000000 for v in source_size)):
                raise ValueError("Reference source size must be bounded integer width/height")
        object.__setattr__(self, "count", count)
        object.__setattr__(self, "source_size", source_size)
        object.__setattr__(self, "_metadata", metadata_bytes({} if metadata is None else metadata))
        for name, value, width, dtype in (("colors", colors, 3, np.uint8),
                                           ("pixels", pixels, 2, np.int32)):
            if value is not None:
                value = np.asarray(value)
                if (value.shape != (count, width) or value.dtype.kind not in "iuf"
                        or not np.isfinite(value).all() or np.any(value != np.rint(value))):
                    raise ValueError(f"Reference {name} require matching finite integer rows")
                if np.any(value < 0) or (name == "colors" and np.any(value > 255)):
                    raise ValueError("Reference colors/pixels are outside their range")
                if name == "pixels" and (source_size is None or np.any(value >= source_size)):
                    raise ValueError("Reference pixels must lie in the declared source image")
                value = np.array(value, dtype=dtype, order="C", copy=True)
                value.flags.writeable = False
            object.__setattr__(self, name, value)

    @property
    def metadata(self):
        return json.loads(self._metadata)

    @property
    def sha256(self):
        digest = hashlib.sha256(self._metadata)
        digest.update(json.dumps([self.count, self.source_size]).encode("ascii"))
        for name in ("colors", "pixels"):
            value = getattr(self, name)
            digest.update(name.encode("ascii") + (b"none" if value is None else value.tobytes()))
        return digest.hexdigest()

    def summary(self):
        return {"rows": self.count, "colors": self.colors is not None,
                "pixels": self.pixels is not None, "source_size": self.source_size,
                "sha256": self.sha256,
                "metadata_role": "descriptive_evidence_not_automatically_applied_calibration"}
