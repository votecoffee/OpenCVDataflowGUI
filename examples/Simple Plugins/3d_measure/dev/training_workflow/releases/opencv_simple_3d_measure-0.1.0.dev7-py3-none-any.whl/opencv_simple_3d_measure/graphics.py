"""Cached evidence to native RGB cloud graphics; no fitting while changing layers."""

from dataclasses import dataclass

import numpy as np

from .specs import LineRegion

LAYERS = ("scene", "inliers", "excluded", "unavailable", "planes", "lines", "regions",
          "measurements", "axes", "zones", "supports")
COLORS = {"scene": [110, 110, 110], "inliers": [45, 235, 100],
          "excluded": [245, 65, 65], "planes": [65, 175, 245],
          "regions": [135, 125, 175], "measurements": [255, 225, 40],
          "unavailable": [235, 50, 220], "zone_lower": [255, 165, 45],
          "zone_upper": [195, 130, 255]}


@dataclass(frozen=True)
class CloudGraphics:
    points: np.ndarray
    colors: np.ndarray
    units: str
    frame: str
    metadata: dict


def result_cloud(result, *, layers=LAYERS, plane=None):
    if any(layer not in LAYERS for layer in layers):
        raise ValueError("Choose known measurement graphic layers.")
    if plane is not None and plane not in {p.name for p in result.recipe.regions}:
        raise ValueError("Choose a defined plane region.")
    xyz, rgb, labels = [], [], []
    pose = result.fixture

    def add(data, color, *, local=True):
        data = np.asarray(data).reshape(-1, 3)
        if local:
            data = data @ pose[:3, :3].T + pose[:3, 3]
        xyz.append(data)
        rgb.append(np.tile(color, (len(data), 1)))

    def line(a, b, color, count=40):
        add(np.linspace(a, b, count), color)

    if "scene" in layers:
        ids = np.linspace(0, len(result.scene) - 1, min(6000, len(result.scene)), dtype=int)
        add(result.scene[ids], COLORS["scene"], local=False)
    axes_drawn = False
    for spec, fit, ids in zip(result.recipe.regions, result.fits, result.selections):
        if plane is not None and spec.name != plane:
            continue
        data = result.local_points[ids]
        if not fit.valid and "unavailable" in layers:
            chosen = np.linspace(0, len(data) - 1, min(2000, len(data)), dtype=int)
            add(data[chosen], COLORS["unavailable"])
        for name, selected in (("inliers", fit.inliers),
                               ("excluded", None if fit.inliers is None else ~fit.inliers)):
            if name in layers and fit.valid:
                selected = (np.ones(len(data), bool) if selected is None else selected)
                if name == "inliers" and fit.inliers is None:
                    continue
                chosen = np.flatnonzero(selected)
                chosen = chosen[np.linspace(0, len(chosen) - 1, min(2000, len(chosen)), dtype=int)]
                add(data[chosen], COLORS[name])
        if "regions" in layers:
            corners = np.array([[x, y, z] for x in (spec.minimum[0], spec.maximum[0])
                                for y in (spec.minimum[1], spec.maximum[1])
                                for z in (spec.minimum[2], spec.maximum[2])])
            for i in range(8):
                for bit in (1, 2, 4):
                    j = i ^ bit
                    if i < j:
                        line(corners[i], corners[j], COLORS["regions"], 16)
        if not fit.valid:
            continue
        if isinstance(spec, LineRegion):
            if "lines" in layers:
                line(*fit.endpoints, COLORS["planes"], 128)
            if "axes" in layers and not axes_drawn:
                u = fit.direction
                v = np.cross(u, np.eye(3)[np.argmin(abs(u))])
                v /= np.linalg.norm(v)
                length = max(np.ptp(fit.parameter_bounds) * .15, fit.tolerance)
                for i, direction in enumerate((u, v, np.cross(u, v))):
                    color = np.zeros(3, np.uint8)
                    color[i] = 255
                    line(fit.origin, fit.origin + length * direction, color)
                axes_drawn = True
            continue
        n = fit.normal
        u = np.cross(n, np.eye(3)[np.argmin(abs(n))])
        u /= np.linalg.norm(u)
        v = np.cross(n, u)
        support = data[fit.inliers] - fit.origin
        extent = np.array([[np.min(support @ u), np.max(support @ u)],
                           [np.min(support @ v), np.max(support @ v)]])
        length = max(np.linalg.norm(extent[:, 1] - extent[:, 0]) * .15, fit.tolerance)
        if "planes" in layers:
            for a in np.linspace(*extent[0], 5):
                line(fit.origin + a * u + extent[1, 0] * v,
                     fit.origin + a * u + extent[1, 1] * v, COLORS["planes"])
            for b in np.linspace(*extent[1], 5):
                line(fit.origin + extent[0, 0] * u + b * v,
                     fit.origin + extent[0, 1] * u + b * v, COLORS["planes"])
        if "axes" in layers and not axes_drawn:
            for axis, direction in enumerate((u, v, n)):
                color = np.zeros(3, np.uint8)
                color[axis] = 255
                line(fit.origin, fit.origin + length * direction, color)
            axes_drawn = True
    for measurement in result.measurements:
        zone = measurement.get("flatness")
        if (not ("zones" in layers or "supports" in layers) or
                zone is None or measurement["value"] is None or
                (plane is not None and measurement["plane"] != plane)):
            continue
        origin, normal = np.asarray(zone["origin"]), np.asarray(zone["normal"])
        u = np.cross(normal, np.eye(3)[np.argmin(abs(normal))])
        u /= np.linalg.norm(u)
        v = np.cross(normal, u)
        index = next(i for i, p in enumerate(result.recipe.regions)
                     if p.name == measurement["plane"])
        data = result.local_points[result.selections[index]] - origin
        extent = np.array([[np.min(data @ u), np.max(data @ u)],
                           [np.min(data @ v), np.max(data @ v)]])
        marker = max(np.linalg.norm(np.ptp(data, axis=0)) * .008, zone["numeric_resolution"])
        for side, offset in zip(("lower", "upper"), zone["offsets"]):
            color = COLORS["zone_" + side]
            base = origin + normal * offset
            if "zones" in layers:
                for x in np.linspace(*extent[0], 5):
                    line(base + u * x + v * extent[1, 0],
                         base + u * x + v * extent[1, 1], color)
                for y in np.linspace(*extent[1], 5):
                    line(base + v * y + u * extent[0, 0],
                         base + v * y + u * extent[0, 1], color)
            if "supports" in layers:
                for point in np.asarray(zone["support_" + side + "_points"]):
                    for axis in (u, v, normal):
                        line(point - marker * axis, point + marker * axis, color, 10)
    if "measurements" in layers:
        fits = {p.name: f for p, f in zip(result.recipe.regions, result.fits)}
        for measurement in result.measurements:
            if measurement["value"] is None or (plane is not None and
                    plane not in (measurement["plane"], measurement["other"])):
                continue
            fit = fits[measurement["plane"]]
            probe = measurement["probe_point"]
            if "dimension_endpoints" in measurement:
                a, b = np.asarray(measurement["dimension_endpoints"])
                line(a, b, COLORS["measurements"], 64)
                center = (a + b) / 2
            elif probe is not None:
                probe = np.asarray(probe)
                foot = probe - ((probe - fit.origin) @ fit.normal) * fit.normal
                line(foot, probe, COLORS["measurements"], 64)
                center = (foot + probe) / 2
            elif measurement["kind"] in ("plane_angle", "line_angle"):
                other = fits[measurement["other"]]
                is_line = measurement["kind"] == "line_angle"
                first = fit.direction if is_line else fit.normal
                second = other.direction if is_line else other.normal
                if first @ second < 0:
                    second = -second
                span = (np.ptp(fit.parameter_bounds) if is_line else
                        np.linalg.norm(fit.inlier_bounds[1] - fit.inlier_bounds[0]))
                radius = max(span * .15, fit.tolerance)
                theta = np.deg2rad(measurement["value"])
                t = np.linspace(0, 1, 48)
                curve = (np.tile(first, (len(t), 1)) if theta < 1e-8 else
                         (np.sin((1 - t) * theta)[:, None] * first
                          + np.sin(t * theta)[:, None] * second) / np.sin(theta))
                add(fit.origin + radius * curve, COLORS["measurements"])
                line(fit.origin, fit.origin + radius * first, COLORS["measurements"])
                line(fit.origin, fit.origin + radius * second, COLORS["measurements"])
                center = fit.origin + radius * curve[len(curve) // 2]
            elif measurement["kind"] == "surface_range":
                index = next(i for i, p in enumerate(result.recipe.planes)
                             if p.name == measurement["plane"])
                selected = result.local_points[result.selections[index]]
                low, high = selected[np.argmin(fit.residual)], selected[np.argmax(fit.residual)]
                projected_high = low + measurement["value"] * fit.normal
                line(low, projected_high, COLORS["measurements"], 64)
                line(projected_high, high, COLORS["measurements"], 32)
                center = (low + projected_high) / 2
            else:
                center = fit.origin
            labels.append({"name": measurement["name"], "value": measurement["value"],
                           "units": measurement["units"], "status": measurement["status"],
                           "position": (center @ pose[:3, :3].T + pose[:3, 3]).tolist()})
    cloud = np.ascontiguousarray(np.concatenate(xyz) if xyz else np.empty((0, 3)), np.float32)
    colors = np.ascontiguousarray(np.concatenate(rgb) if rgb else np.empty((0, 3)), np.uint8)
    cloud.flags.writeable = colors.flags.writeable = False
    return CloudGraphics(cloud, colors, result.recipe.units, result.frame,
                         {"tool": "Simple3DMeasure",
                          "legend": {k: list(v) for k, v in COLORS.items()},
                          "layers": list(layers), "measurement_annotations": labels,
                          "axes": ("plane datum Z is signed normal; line datum X is direction"
                                   if result.recipe.lines else
                                   "datum tangent axes RGB; blue is the signed normal"),
                          "plane_status": {p.name: f.status for p, f in
                                           zip(result.recipe.planes, result.fits)},
                          **({"line_status": {p.name: f.status for p, f in
                              zip(result.recipe.lines, result.fits[len(result.recipe.planes):])}}
                             if result.recipe.lines else {}),
                          **({"zone_status": {m["name"]: m["flatness"]["status"]
                              for m in result.measurements if "flatness" in m}}
                             if any("flatness" in m for m in result.measurements) else {}),
                          "note": "Plane grids, boxes and dimension lines are derived geometry."})
