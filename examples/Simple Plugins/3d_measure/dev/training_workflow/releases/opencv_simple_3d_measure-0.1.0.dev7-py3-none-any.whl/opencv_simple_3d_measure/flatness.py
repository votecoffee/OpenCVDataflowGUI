"""Minimum-width enclosing slab of every selected finite point, with bounded hull work."""

from dataclasses import dataclass

import numpy as np

from .specs import points, vector


@dataclass(frozen=True)
class FlatnessResult:
    status: str
    count: int
    value: float | None = None
    origin: np.ndarray | None = None
    normal: np.ndarray | None = None
    offsets: np.ndarray | None = None
    support_lower: tuple = ()
    support_upper: tuple = ()
    support_lower_count: int = 0
    support_upper_count: int = 0
    hull_vertices: int = 0
    difference_points: int = 0
    difference_facets: int = 0
    numeric_resolution: float = 0.
    max_hull_vertices: int = 256
    verification_gap: float | None = None
    candidate_upper_bound: float | None = None

    @property
    def valid(self):
        return self.status in ("resolved", "resolved_at_numeric_resolution")

    def report(self):
        return {"method": "convex_hull_minkowski_difference", "status": self.status,
                "selected_points": self.count, "hull_vertices": self.hull_vertices,
                "difference_points": self.difference_points,
                "difference_facets": self.difference_facets,
                "max_hull_vertices": self.max_hull_vertices,
                "max_difference_points": self.max_hull_vertices**2,
                "max_difference_facets": 131072,
                "numeric_resolution": self.numeric_resolution,
                "verification_gap": self.verification_gap,
                "candidate_upper_bound": self.candidate_upper_bound,
                "support_lower_count": self.support_lower_count,
                "support_upper_count": self.support_upper_count,
                "population": "all_selected_points_including_datum_fit_exclusions"}


def _oriented(normal, hint):
    direction = np.zeros(3) if hint is None else hint
    if abs(normal @ direction) <= 1e-12:
        direction = np.eye(3)[np.argmax(abs(normal))]
    return -normal if normal @ direction < 0 else normal


def minimum_zone_flatness(data, *, max_vertices=256, normal_hint=None):
    """Global finite-point minimum width; no random jitter, subsampling or discarded outliers.

    The centered difference body H-H is symmetric. Its closest supporting facet
    to the origin gives the minimum support width of H. Original selected points
    verify the final enclosure, and hull-vertex widths verify difference facets.
    Numeric resolution is an engineering roundoff estimate, not gauge uncertainty.
    """
    data = points(data)
    if type(max_vertices) is not int or not 4 <= max_vertices <= 1024:
        raise ValueError("Flatness geometry budget must be 4..1024 hull vertices.")
    hint = None if normal_hint is None else np.asarray(vector(normal_hint, "Normal hint"))
    if hint is not None and np.linalg.norm(hint) <= 1e-12:
        raise ValueError("Normal hint must be nonzero.")
    info = dict(count=len(data), max_hull_vertices=max_vertices)
    if len(data) < 3:
        return FlatnessResult("insufficient_points", **info)
    lo, hi = data.min(0), data.max(0)
    origin = (lo + hi) / 2
    scale = float(np.linalg.norm(hi - lo))
    resolution = max(scale * 1e-10, np.finfo(float).eps * max(float(abs(data).max()), scale) * 256)
    info["numeric_resolution"] = resolution
    if scale <= resolution:
        return FlatnessResult("degenerate_footprint", **info)
    local = (data - origin) / scale
    centered = local - local.mean(0)
    eigenvalues, vectors = np.linalg.eigh(centered.T @ centered)
    del centered
    if eigenvalues[1] <= max(eigenvalues[2] * 1e-16, (resolution / scale)**2):
        return FlatnessResult("degenerate_footprint", **info)
    normal = _oriented(vectors[:, 0].copy(), hint)
    projection = (data - origin) @ normal
    candidate = float(np.ptp(projection))
    info["candidate_upper_bound"] = candidate
    status = "resolved_at_numeric_resolution"
    if candidate > resolution:
        try:
            from scipy.spatial import ConvexHull, QhullError
        except ImportError:
            return FlatnessResult("dependency_missing", **info)
        try:
            hull = ConvexHull(local)
            vertices = local[hull.vertices]
            info["hull_vertices"] = len(vertices)
            if len(vertices) > max_vertices:
                return FlatnessResult("hull_budget_exceeded", **info)
            # For a polyhedron in R3 every minimum-width slab is represented by
            # a supporting facet of H-H, including the edge/edge contact case.
            difference = (vertices[:, None, :] - vertices[None, :, :]).reshape(-1, 3)
            info["difference_points"] = len(difference)
            body = ConvexHull(difference)
            info["difference_facets"] = len(body.equations)
            if len(body.equations) > 131072:
                return FlatnessResult("difference_budget_exceeded", **info)
            normals = body.equations[:, :3].copy()
            lengths = np.linalg.norm(normals, axis=1)
            if not np.isfinite(lengths).all() or np.any(lengths <= 1e-12):
                return FlatnessResult("hull_verification_failed", **info)
            normals /= lengths[:, None]
            distances = -body.equations[:, 3] / lengths
            margin = resolution / scale
            if not np.isfinite(distances).all() or np.any(distances < -margin):
                return FlatnessResult("hull_verification_failed", **info)
            # Verify every supporting facet against the full H-H vertex set
            # without multiplying facets by all original sensor points.
            for start in range(0, len(normals), 256):
                projected = vertices @ normals[start:start + 256].T
                widths = np.ptp(projected, axis=0)
                if np.max(abs(widths - distances[start:start + 256])) > margin:
                    return FlatnessResult("hull_verification_failed", **info)
            index = int(distances.argmin())
            normal = _oriented(normals[index].copy(), hint)
            projection = (data - origin) @ normal
            width = float(np.ptp(projection))
            gap = abs(width - float(distances[index]) * scale)
            info["verification_gap"] = gap
            if gap > resolution or width > candidate + resolution:
                return FlatnessResult("enclosure_verification_failed", **info)
            candidate = width
            status = "resolved"
        except QhullError:
            return FlatnessResult("qhull_failed", **info)
    offsets = np.array([projection.min(), projection.max()])
    lower = np.flatnonzero(projection <= offsets[0] + resolution)
    upper = np.flatnonzero(projection >= offsets[1] - resolution)
    for value in (origin, normal, offsets):
        value.flags.writeable = False
    return FlatnessResult(status, **info, value=candidate, origin=origin, normal=normal,
                          offsets=offsets, support_lower=tuple(int(i) for i in lower[:64]),
                          support_upper=tuple(int(i) for i in upper[:64]),
                          support_lower_count=len(lower), support_upper_count=len(upper))
