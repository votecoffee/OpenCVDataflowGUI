"""Physical-unit histogram from cached full-population counts, without another fit."""

import os
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont, QFontDatabase, QImage, QPainter, QPen, QRawFont
from PySide6.QtWidgets import QWidget

from .residuals import residual_colors

_FONT = None


def chart_font():
    global _FONT
    if _FONT is None:
        families = QFontDatabase.families()
        # Qt's Windows offscreen backend may start with no font database.
        # Use the machine's installed font; never bundle or redistribute it.
        if not families and os.name == "nt":
            path = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts/segoeui.ttf"
            if path.is_file():
                index = QFontDatabase.addApplicationFont(str(path))
                families = QFontDatabase.applicationFontFamilies(index)
        family = next((n for n in ("Segoe UI", "Arial", "DejaVu Sans") if n in families),
                      families[0] if families else "Sans Serif")
        _FONT = QFont(family, 10)
    return _FONT


class ResidualHistogram(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.row, self.name, self.units = None, None, ""
        self._font = chart_font()
        self.setMinimumHeight(155)
        self.setMaximumHeight(190)

    def set_region(self, row, name, units):
        self.row, self.name, self.units = row, name, units
        self.update()

    def save_image(self, path):
        font = QRawFont.fromFont(self._font)
        if not font.isValid() or not all(font.supportsCharacter(ord(c)) for c in "Az09-+."):
            raise ValueError("A usable system font is required for residual histogram labels")
        image = QImage(1200, 220, QImage.Format.Format_RGB32)
        painter = QPainter(image)
        self.draw(painter, image.width(), image.height())
        painter.end()
        if not image.save(str(path), "PNG"):
            raise OSError("Could not save the residual histogram")

    def paintEvent(self, event):
        painter = QPainter(self)
        self.draw(painter, self.width(), self.height())
        painter.end()

    def draw(self, painter, width, height):
        painter.setFont(self._font)
        painter.fillRect(0, 0, width, height, QColor(25, 29, 35))
        painter.setPen(QColor(230, 230, 230))
        if self.row is None:
            painter.drawText(15, 28, "Select a region for its histogram and physical scale.")
            return
        row, histogram = self.row, self.row["histogram"]
        painter.drawText(15, 20, f"{self.name}: {row['definition'].replace('_', ' ')}")
        if histogram is None:
            painter.setPen(QColor(235, 100, 220))
            painter.drawText(15, 48, f"Unavailable: {row['status']}; "
                             f"{row['selected_points']} selected points, no residual values.")
            return
        edges, counts = histogram["edges"], histogram["counts"]
        left, top, right, bottom = 65, 35, width - 30, height - 43
        plot_width, plot_height = max(1, right - left), max(1, bottom - top)
        maximum = max(max(counts), 1)
        colors = residual_colors([(a + b) / 2 for a, b in zip(edges, edges[1:])],
                                  row["fit_band"], signed=row["kind"] == "plane")
        painter.setPen(Qt.PenStyle.NoPen)
        for i, (count, color) in enumerate(zip(counts, colors)):
            painter.setBrush(QColor(*map(int, color)))
            x = left + i * plot_width / len(counts)
            bar_height = count / maximum * plot_height
            painter.drawRect(int(x), int(bottom - bar_height),
                             max(1, int(plot_width / len(counts)) - 1), int(bar_height))
        painter.setPen(QPen(QColor(180, 180, 180), 1))
        painter.drawLine(left, bottom, right, bottom)
        painter.drawText(8, top + 10, str(maximum))
        painter.drawText(8, bottom, "0")
        painter.drawText(left, height - 23, f"{edges[0]:.5g}")
        painter.drawText(right - 65, height - 23, f"{edges[-1]:.5g} {self.units}")
        for value in ((-row["fit_band"], row["fit_band"]) if row["kind"] == "plane"
                      else (row["fit_band"],)):
            x = round(left + (value - edges[0]) / (edges[-1] - edges[0]) * plot_width)
            painter.setPen(QPen(QColor(245, 245, 245), 1, Qt.PenStyle.DashLine))
            painter.drawLine(x, top, x, bottom)
            painter.drawText(x + 3, top + 11, f"{value:.4g}")
        painter.setPen(QColor(220, 220, 220))
        painter.drawText(15, height - 5,
            f"Counts; fit-band markers dashed. Outside color range: "
            f"{histogram['below_range']} below / {histogram['above_range']} above.")
