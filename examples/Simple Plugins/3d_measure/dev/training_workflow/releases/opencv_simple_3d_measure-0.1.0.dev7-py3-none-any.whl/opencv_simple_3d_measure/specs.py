"""Portable measurement configuration with explicit units and coordinate frames."""

from dataclasses import dataclass
from numbers import Real

import numpy as np

MAX_POINTS = 2_000_000


def finite(value, name):
    if isinstance(value, bool) or not isinstance(value, Real) or not np.isfinite(value):
        raise ValueError(f"{name} must be a finite number.")
    return float(value)


def label(value, name="Name"):
    if (not isinstance(value, str) or not value or len(value) > 64 or value != value.strip()
            or any(ord(c) < 32 for c in value)):
        raise ValueError(f"{name} must contain 1..64 characters without surrounding whitespace.")
    return value


def vector(value, name):
    data = np.asarray(value, float)
    if data.shape != (3,) or not np.isfinite(data).all() or np.any(abs(data) > 1e12):
        raise ValueError(f"{name} requires three finite coordinates.")
    return tuple(data.tolist())


def identity(units, frame):
    if units not in ("mm", "m"):
        raise ValueError("Measurements require declared mm or m units; convert upstream.")
    label(frame, "Coordinate frame")


def points(value):
    raw = np.asarray(value)
    if (raw.ndim != 2 or raw.shape[1] != 3 or len(raw) > MAX_POINTS
            or raw.dtype.kind not in "iuf"):
        raise ValueError("Supply 0..2,000,000 finite XYZ rows.")
    data = np.array(raw, dtype=float, order="C", copy=True)
    if not np.isfinite(data).all() or np.any(abs(data) > 1e12):
        raise ValueError("XYZ coordinates must be finite and within +/-1e12 declared units.")
    data.flags.writeable = False
    return data


def rigid(value):
    data = np.array(value, dtype=float, copy=True)
    if (data.shape != (4, 4) or not np.isfinite(data).all()
            or not np.allclose(data[3], [0, 0, 0, 1], atol=1e-8, rtol=0)
            or not np.allclose(data[:3, :3].T @ data[:3, :3], np.eye(3), atol=1e-5, rtol=0)
            or not np.isclose(np.linalg.det(data[:3, :3]), 1, atol=1e-5, rtol=0)):
        raise ValueError("Fixture must be a proper rigid measurement-to-scene 4x4 transform.")
    # Published/calibrated rotations can be rounded. Remove accepted roundoff,
    # so inverse transforms and physical distances use an actual rotation.
    u, _, vt = np.linalg.svd(data[:3, :3])
    data[:3, :3] = u @ vt
    data.flags.writeable = False
    return data


@dataclass(frozen=True)
class FitSettings:
    min_points: int = 30
    min_inlier_fraction: float = .5
    max_trials: int = 256
    fit_sample_limit: int = 20000
    seed: int = 0
    execution_workers: int = 1

    def __post_init__(self):
        for name, low, high in (("min_points", 3, 100000), ("max_trials", 16, 4096),
                                ("fit_sample_limit", 30, 100000), ("seed", 0, 2**32 - 1),
                                ("execution_workers", 1, 8)):
            value = getattr(self, name)
            if type(value) is not int or not low <= value <= high:
                raise ValueError(f"{name} must be an integer in [{low}, {high}].")
        if not .1 <= finite(self.min_inlier_fraction, "Minimum inlier fraction") <= 1:
            raise ValueError("Minimum inlier fraction must be in [.1, 1].")
        object.__setattr__(self, "min_inlier_fraction", float(self.min_inlier_fraction))
        if self.fit_sample_limit < self.min_points:
            raise ValueError("Fit sample limit must be at least min_points.")


@dataclass(frozen=True)
class PlaneRegion:
    name: str
    minimum: tuple
    maximum: tuple
    normal_hint: tuple | None = None
    tolerance: float | None = None

    def __post_init__(self):
        label(self.name)
        for key in ("minimum", "maximum"):
            object.__setattr__(self, key, vector(getattr(self, key), key))
        if np.any(np.asarray(self.maximum) <= self.minimum):
            raise ValueError("Region maximum must exceed minimum along all three axes.")
        if self.normal_hint is not None:
            normal = np.asarray(vector(self.normal_hint, "Normal hint"))
            size = np.linalg.norm(normal)
            if not np.isfinite(size) or size <= 1e-12:
                raise ValueError("Normal hint must have nonzero length.")
            object.__setattr__(self, "normal_hint", tuple((normal / size).tolist()))
        if self.tolerance is not None and finite(self.tolerance, "Plane tolerance") <= 0:
            raise ValueError("Plane tolerance must be positive, or null for reference learning.")
        if self.tolerance is not None:
            object.__setattr__(self, "tolerance", float(self.tolerance))

    def select(self, data):
        return np.all((data >= self.minimum) & (data <= self.maximum), axis=1)


@dataclass(frozen=True)
class LineRegion:
    name: str
    minimum: tuple
    maximum: tuple
    direction_hint: tuple | None = None
    tolerance: float | None = None

    def __post_init__(self):
        # Common spatial/tolerance contracts; the direction is an axial sign hint.
        checked = PlaneRegion(self.name, self.minimum, self.maximum,
                              normal_hint=self.direction_hint, tolerance=self.tolerance)
        for key in ("minimum", "maximum", "tolerance"):
            object.__setattr__(self, key, getattr(checked, key))
        object.__setattr__(self, "direction_hint", checked.normal_hint)

    def select(self, data):
        return np.all((data >= self.minimum) & (data <= self.maximum), axis=1)


LINE_KINDS = ("line_separation", "line_angle", "point_line_distance", "line_span")


@dataclass(frozen=True)
class Measurement:
    name: str
    kind: str
    plane: str
    other: str | None = None
    point: tuple | None = None
    lower: float | None = None
    upper: float | None = None
    max_angle_degrees: float = 5.0
    zone_max_vertices: int = 256

    def __post_init__(self):
        label(self.name)
        label(self.plane, "Plane name")
        if self.kind not in ("step_height", "plane_angle", "point_plane_distance",
                             "surface_range", "minimum_zone_flatness", *LINE_KINDS):
            raise ValueError("Unknown 3D measurement kind.")
        paired = self.kind in ("step_height", "plane_angle", "line_separation", "line_angle")
        if paired:
            label(self.other, "Other plane")
            if self.other == self.plane:
                raise ValueError("Choose two distinct plane regions.")
        elif self.other is not None:
            raise ValueError("This measurement does not use a second plane.")
        if self.kind in ("point_plane_distance", "point_line_distance"):
            object.__setattr__(self, "point", vector(self.point, "Probe point"))
        elif self.point is not None:
            raise ValueError("Only point-to-plane/line distance uses an explicit probe point.")
        for name in ("lower", "upper"):
            if getattr(self, name) is not None:
                object.__setattr__(self, name, finite(getattr(self, name), name))
        if self.lower is not None and self.upper is not None and self.lower > self.upper:
            raise ValueError("Lower measurement limit must not exceed upper limit.")
        if not 0 <= finite(self.max_angle_degrees, "Maximum plane angle") <= 90:
            raise ValueError("Maximum plane angle must be in [0,90] degrees.")
        object.__setattr__(self, "max_angle_degrees", float(self.max_angle_degrees))
        if type(self.zone_max_vertices) is not int or not 4 <= self.zone_max_vertices <= 1024:
            raise ValueError("Flatness geometry budget must be 4..1024 hull vertices.")
        if self.kind != "minimum_zone_flatness" and self.zone_max_vertices != 256:
            raise ValueError("Only minimum-zone flatness uses a custom geometry budget.")


def validate_measurements(regions, measurements):
    named = {p.name: p for p in regions}
    if len(named) != len(regions) or len({m.name for m in measurements}) != len(measurements):
        raise ValueError("Region and measurement names must each be unique.")
    for m in measurements:
        for name in (m.plane, m.other):
            if name is None:
                continue
            if name not in named:
                raise ValueError("Measurement references an undefined region.")
            if isinstance(named[name], LineRegion) != (m.kind in LINE_KINDS):
                raise ValueError("Measurement type requires matching plane or line regions.")


def definitions(planes, measurements, *, lines=()):
    planes, lines, measurements = tuple(planes), tuple(lines), tuple(measurements)
    if (not 1 <= len(planes) + len(lines) <= 16
            or not all(isinstance(p, PlaneRegion) for p in planes)
            or not all(isinstance(p, LineRegion) for p in lines)):
        raise ValueError("Define 1..16 plane or line regions.")
    if (not 1 <= len(measurements) <= 64
            or not all(isinstance(m, Measurement) for m in measurements)):
        raise ValueError("Define 1..64 measurements.")
    validate_measurements(planes + lines, measurements)
    return planes, measurements
