"""Atomic, full-precision XYZ region editing in the retained measurement frame."""

from dataclasses import replace

from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QGridLayout,
    QLabel,
    QLineEdit,
    QVBoxLayout,
)


class RegionBoundsDialog(QDialog):
    def __init__(self, region, units, frame, *, parent=None):
        super().__init__(parent)
        self.region, self.value = region, None
        self.setWindowTitle(f"XYZ bounds · {region.name}")
        layout = QVBoxLayout(self)
        identity = QLabel(f"{units} · measurement frame {frame}\n"
                          "Axis-aligned volume; includes hidden points. No unit conversion.")
        identity.setWordWrap(True)
        layout.addWidget(identity)
        grid = QGridLayout()
        layout.addLayout(grid)
        grid.addWidget(QLabel("Axis"), 0, 0)
        grid.addWidget(QLabel("Minimum"), 0, 1)
        grid.addWidget(QLabel("Maximum"), 0, 2)
        self.minimum, self.maximum = [], []
        for i, axis in enumerate("XYZ"):
            grid.addWidget(QLabel(axis), i + 1, 0)
            for column, values, fields in ((1, region.minimum, self.minimum),
                                           (2, region.maximum, self.maximum)):
                field = QLineEdit(repr(values[i]))
                field.setMinimumWidth(150)
                side = "minimum" if column == 1 else "maximum"
                field.setAccessibleName(f"{axis} {side} ({units})")
                fields.append(field)
                grid.addWidget(field, i + 1, column)
        self.status = QLabel("Update changes all bounds together. Cancel preserves the region.")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                                   QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Update region")
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _accept(self):
        try:
            # repr/float round-trips every untouched float; no spinbox rounding/clamping.
            self.value = replace(self.region,
                                 minimum=tuple(float(f.text()) for f in self.minimum),
                                 maximum=tuple(float(f.text()) for f in self.maximum))
        except ValueError as error:
            self.status.setText(str(error))
            return
        self.accept()
