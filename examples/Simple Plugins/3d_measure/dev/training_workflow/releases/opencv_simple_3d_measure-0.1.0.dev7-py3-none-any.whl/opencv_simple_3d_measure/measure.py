"""Retained-reference training and frame-aware 3D plane measurements."""

from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass, field, replace

import numpy as np

from .fitting import fit_plane, learn_tolerance
from .flatness import minimum_zone_flatness
from .line_fitting import fit_line, learn_line_tolerance
from .reference import ReferenceEvidence
from .specs import LINE_KINDS, FitSettings, LineRegion, definitions, finite, identity, points, rigid

MAX_SELECTED_POINTS = 4_000_000


@dataclass(frozen=True)
class Recipe:
    reference: np.ndarray
    planes: tuple
    measurements: tuple
    tolerances: tuple
    units: str
    frame: str
    settings: FitSettings
    lines: tuple = ()
    line_tolerances: tuple = ()
    reference_evidence: ReferenceEvidence | None = None
    _source_bytes: bytes | None = field(default=None, repr=False, compare=False)

    def __post_init__(self):
        identity(self.units, self.frame)
        lines = tuple(self.lines)
        planes, measurements = definitions(self.planes, self.measurements, lines=lines)
        if not isinstance(self.settings, FitSettings):
            raise ValueError("A measurement recipe requires FitSettings.")
        tolerances = tuple(finite(v, "Resolved plane tolerance") for v in self.tolerances)
        if len(tolerances) != len(planes) or any(v <= 0 for v in tolerances):
            raise ValueError("Store one positive resolved tolerance per plane.")
        if any(p.normal_hint is None for p in planes):
            raise ValueError("A trained plane requires its retained normal orientation.")
        line_tolerances = tuple(finite(v, "Resolved line tolerance") for v in self.line_tolerances)
        if len(line_tolerances) != len(lines) or any(v <= 0 for v in line_tolerances):
            raise ValueError("Store one positive resolved tolerance per line.")
        if any(p.direction_hint is None for p in lines):
            raise ValueError("A trained line requires its retained direction orientation.")
        reference = points(self.reference)
        if len(reference) < self.settings.min_points:
            raise ValueError("Retain at least min_points reference XYZ rows.")
        evidence = self.reference_evidence
        if evidence is not None and (not isinstance(evidence, ReferenceEvidence)
                                     or evidence.count != len(reference)):
            raise ValueError("Reference evidence must match the retained XYZ rows.")
        object.__setattr__(self, "reference", reference)
        object.__setattr__(self, "planes", planes)
        object.__setattr__(self, "measurements", measurements)
        object.__setattr__(self, "tolerances", tolerances)
        object.__setattr__(self, "lines", lines)
        object.__setattr__(self, "line_tolerances", line_tolerances)

    @property
    def regions(self):
        return self.planes + self.lines

    def configuration(self):
        measurements = []
        for m in self.measurements:
            value = asdict(m)
            if m.kind != "minimum_zone_flatness":
                value.pop("zone_max_vertices")
            measurements.append(value)
        return {"units": self.units, "frame": self.frame, "settings": asdict(self.settings),
                "planes": [asdict(p) for p in self.planes],
                "measurements": measurements,
                **({"lines": [asdict(p) for p in self.lines]} if self.lines else {})}


def _select(data, planes):
    selections, count = [], 0
    for plane in planes:
        ids = np.flatnonzero(plane.select(data))
        ids.flags.writeable = False
        count += len(ids)
        if count > MAX_SELECTED_POINTS:
            raise ValueError("Plane selections exceed four million rows; reduce overlap/ROIs.")
        selections.append(ids)
    return tuple(selections)


def train(reference, planes, measurements, *, units, frame="measurement", settings=None, lines=(),
          reference_evidence=None):
    """Retain references and learn automatic tolerances once, without test-scene tuning."""
    identity(units, frame)
    reference = points(reference)
    lines = tuple(lines)
    planes, measurements = definitions(planes, measurements, lines=lines)
    settings = FitSettings() if settings is None else settings
    if not isinstance(settings, FitSettings):
        raise ValueError("Supply FitSettings.")
    selections = _select(reference, planes + lines)
    taught, tolerances = [], []
    for plane, ids in zip(planes, selections):
        region = reference[ids]
        tolerance = (learn_tolerance(region, settings=settings, normal_hint=plane.normal_hint)
                     if plane.tolerance is None else plane.tolerance)
        fit = fit_plane(region, tolerance, settings=settings, normal_hint=plane.normal_hint)
        if not fit.valid:
            raise ValueError(f"Reference plane {plane.name}: {fit.status}.")
        taught.append(replace(plane, normal_hint=tuple(fit.normal.tolist())))
        tolerances.append(tolerance)
    taught_lines, line_tolerances = [], []
    for line, ids in zip(lines, selections[len(planes):]):
        region = reference[ids]
        tolerance = (learn_line_tolerance(region, settings=settings,
                                          direction_hint=line.direction_hint)
                     if line.tolerance is None else line.tolerance)
        fit = fit_line(region, tolerance, settings=settings, direction_hint=line.direction_hint)
        if not fit.valid:
            raise ValueError(f"Reference line {line.name}: {fit.status}.")
        taught_lines.append(replace(line, direction_hint=tuple(fit.direction.tolist())))
        line_tolerances.append(tolerance)
    return Recipe(reference, tuple(taught), measurements, tuple(tolerances), units, frame, settings,
                  tuple(taught_lines), tuple(line_tolerances), reference_evidence)


@dataclass(frozen=True)
class MeasurementResult:
    scene: np.ndarray
    local_points: np.ndarray
    fixture: np.ndarray
    frame: str
    recipe: Recipe
    fits: tuple
    selections: tuple
    measurements: tuple

    @property
    def passed(self):
        return all(m["status"] in ("measured", "within_limits") for m in self.measurements)

    def report(self):
        result = {
            "model": "simple_3d_measure_v1", "units": self.recipe.units,
            "measurement_frame": self.recipe.frame, "scene_frame": self.frame,
            "measurement_to_scene": self.fixture.tolist(), "scene_points": len(self.scene),
            "passed": self.passed, "measurements": list(self.measurements),
            "planes": {spec.name: {**fit.report(), "frame": self.recipe.frame,
                                    "units": self.recipe.units,
                                    "region_minimum": list(spec.minimum),
                                    "region_maximum": list(spec.maximum),
                                    "tolerance_source": "reference_noise" if spec.tolerance is None
                                                        else "explicit"}
                       for spec, fit in zip(self.recipe.planes, self.fits)},
            "settings": asdict(self.recipe.settings),
            "surface_range_definition": "max_minus_min_signed_distance_all_selected_points",
            "qualification": "fit_evidence_not_independent_dimensional_accuracy",
        }
        if self.recipe.lines:
            result["lines"] = {
                spec.name: {**fit.report(), "frame": self.recipe.frame, "units": self.recipe.units,
                            "region_minimum": list(spec.minimum),
                            "region_maximum": list(spec.maximum),
                            "tolerance_source": "reference_noise" if spec.tolerance is None
                                                else "explicit"}
                for spec, fit in zip(self.recipe.lines, self.fits[len(self.recipe.planes):])}
        return result


def _line_measurement(spec, first, second, record):
    if second is not None:
        angle = float(np.degrees(np.arccos(np.clip(abs(first.direction @ second.direction), 0, 1))))
        record["angle_degrees"] = angle
    if spec.kind == "line_angle":
        record["value"] = angle
        record["definition"] = "acute_angle_between_line_directions"
    elif spec.kind == "line_span":
        record["value"] = float(np.ptp(first.parameter_bounds))
        record["definition"] = "observed_inlier_axial_span_not_hidden_object_length"
        record["dimension_endpoints"] = first.endpoints.tolist()
    else:
        if spec.kind == "line_separation":
            if angle > spec.max_angle_degrees + 1e-9:
                record["reason"] = "lines_not_parallel"
                return
            probe = second.origin
            record["maximum_angle_degrees"] = spec.max_angle_degrees
            record["definition"] = "target_inlier_centroid_distance_to_datum_line"
        else:
            probe = np.asarray(spec.point)
            record["definition"] = "perpendicular_probe_distance_to_infinite_line"
        parameter = float((probe - first.origin) @ first.direction)
        foot = first.origin + parameter * first.direction
        record["value"] = float(np.linalg.norm(probe - foot))
        record["probe_point"] = probe.tolist()
        record["datum_projection"] = foot.tolist()
        record["dimension_endpoints"] = [foot.tolist(), probe.tolist()]
        record["datum_extrapolated"] = bool(parameter < first.parameter_bounds[0]
                                             or parameter > first.parameter_bounds[1])
        record["support_assessment"] = "observed_inlier_axial_interval_not_visibility"


def _flatness_measurement(spec, fit, zone, data, ids, record):
    record["definition"] = "minimum_width_two_parallel_planes_all_selected_points"
    record["flatness"] = {**zone.report(), "max_hull_vertices": spec.zone_max_vertices,
                          "datum_fit_residual_range": float(np.ptp(fit.residual))}
    if not zone.valid:
        record["reason"] = "flatness_solver: " + zone.status
        return record
    record["value"] = zone.value
    normal = zone.normal
    lower, upper = zone.support_lower, zone.support_upper
    record["flatness"].update(
        origin=zone.origin.tolist(), normal=normal.tolist(), offsets=zone.offsets.tolist(),
        datum_normal_angle_degrees=float(np.degrees(np.arccos(np.clip(abs(normal @ fit.normal),
                                                                      0, 1)))),
        support_lower_rows=[int(ids[i]) for i in lower],
        support_upper_rows=[int(ids[i]) for i in upper],
        support_lower_points=data[list(lower)].tolist(),
        support_upper_points=data[list(upper)].tolist())
    start = data[lower[0]]
    record["dimension_endpoints"] = [start.tolist(), (start + zone.value * normal).tolist()]
    return _limits(spec, record)


def _measurement(spec, fits, recipe, flatness=None):
    first, second = fits[spec.plane], fits.get(spec.other)
    unavailable = [name for name in (spec.plane, spec.other)
                   if name is not None and not fits[name].valid]
    record = {"name": spec.name, "kind": spec.kind, "plane": spec.plane,
              "other": spec.other, "value": None,
              "units": "deg" if spec.kind in ("plane_angle", "line_angle") else recipe.units,
              "lower": spec.lower, "upper": spec.upper, "status": "unavailable",
              "reason": None, "angle_degrees": None, "probe_point": spec.point}
    if unavailable:
        record["reason"] = ("line_unavailable: " if spec.kind in LINE_KINDS else
                            "plane_unavailable: ") + ", ".join(unavailable)
        return record
    if spec.kind in LINE_KINDS:
        _line_measurement(spec, first, second, record)
        if record["value"] is None:
            return record
        return _limits(spec, record)
    if spec.kind == "minimum_zone_flatness":
        zone, data, ids = flatness[(spec.plane, spec.zone_max_vertices)]
        return _flatness_measurement(spec, first, zone, data, ids, record)
    if second is not None:
        cosine = float(np.clip(abs(first.normal @ second.normal), 0, 1))
        angle = float(np.degrees(np.arccos(cosine)))
        record["angle_degrees"] = angle
    if spec.kind == "step_height":
        if angle > spec.max_angle_degrees + 1e-9:
            record["reason"] = "planes_not_parallel"
            return record
        value = float((second.origin - first.origin) @ first.normal)
        record["probe_point"] = second.origin.tolist()
        record["definition"] = "signed_target_inlier_centroid_distance_to_datum_plane"
        record["maximum_angle_degrees"] = spec.max_angle_degrees
    elif spec.kind == "plane_angle":
        value = angle
        record["definition"] = "acute_angle_between_plane_normals"
    elif spec.kind == "point_plane_distance":
        value = float((np.asarray(spec.point) - first.origin) @ first.normal)
        record["definition"] = "signed_probe_distance_along_datum_normal"
    else:
        # Fitting excludes outliers; assessment deliberately includes every selected point.
        value = float(np.ptp(first.residual))
        record["definition"] = "least_squares_plane_residual_range_all_selected_points"
    record["value"] = value
    probe = record["probe_point"]
    if probe is not None:
        probe = np.asarray(probe)
        foot = probe - ((probe - first.origin) @ first.normal) * first.normal
        record["datum_projection"] = foot.tolist()
        record["datum_extrapolated"] = bool(np.any(foot < first.inlier_bounds[0])
                                              or np.any(foot > first.inlier_bounds[1]))
        record["support_assessment"] = "inlier_axis_aligned_bounds_not_visibility"
    return _limits(spec, record)


def _limits(spec, record):
    value = record["value"]
    limited = spec.lower is not None or spec.upper is not None
    within = ((spec.lower is None or value >= spec.lower)
              and (spec.upper is None or value <= spec.upper))
    record["status"] = "measured" if not limited else "within_limits" if within else "out_of_limits"
    return record


class Measurer:
    def __init__(self, recipe):
        if not isinstance(recipe, Recipe):
            raise ValueError("Train or load a Recipe before measuring.")
        self.recipe = recipe

    def measure(self, scene, *, units, frame=None, fixture=None):
        recipe = self.recipe
        frame = recipe.frame if frame is None else frame
        identity(units, frame)
        if units != recipe.units:
            raise ValueError("Scene and recipe units must match; convert upstream.")
        if fixture is None and frame != recipe.frame:
            raise ValueError("Different scene/measurement frames require an explicit fixture pose.")
        pose = rigid(np.eye(4) if fixture is None else fixture)
        scene = points(scene)
        local = (scene if fixture is None else
                 points((scene - pose[:3, 3]) @ pose[:3, :3]))
        selections = _select(local, recipe.regions)

        def fit(index):
            plane = recipe.regions[index]
            if isinstance(plane, LineRegion):
                return fit_line(local[selections[index]],
                                recipe.line_tolerances[index - len(recipe.planes)],
                                settings=recipe.settings, direction_hint=plane.direction_hint)
            return fit_plane(local[selections[index]], recipe.tolerances[index],
                             settings=recipe.settings, normal_hint=plane.normal_hint)

        count = len(recipe.regions)
        workers = min(recipe.settings.execution_workers, count)
        if workers > 1:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                fits = tuple(pool.map(fit, range(count)))
        else:
            fits = tuple(fit(i) for i in range(count))
        named = {p.name: f for p, f in zip(recipe.regions, fits)}
        requested = dict.fromkeys((m.plane, m.zone_max_vertices) for m in recipe.measurements
                                  if m.kind == "minimum_zone_flatness" and named[m.plane].valid)

        def zone(key):
            name, budget = key
            index = next(i for i, p in enumerate(recipe.regions) if p.name == name)
            ids = selections[index]
            data = local[ids]
            return key, (minimum_zone_flatness(data, max_vertices=budget,
                                              normal_hint=fits[index].normal), data, ids)

        zone_workers = min(recipe.settings.execution_workers, len(requested))
        if zone_workers > 1:
            with ThreadPoolExecutor(max_workers=zone_workers) as pool:
                zones = dict(pool.map(zone, requested))
        else:
            zones = dict(zone(key) for key in requested)
        measurements = tuple(_measurement(m, named, recipe, zones) for m in recipe.measurements)
        return MeasurementResult(scene, local, pose, frame, recipe, fits, selections, measurements)
