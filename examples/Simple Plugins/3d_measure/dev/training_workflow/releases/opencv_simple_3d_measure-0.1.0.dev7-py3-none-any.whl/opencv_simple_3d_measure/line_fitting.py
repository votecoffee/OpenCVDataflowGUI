"""Bounded deterministic 3D line consensus with orthogonal radial residuals."""

from dataclasses import dataclass

import numpy as np

from .specs import FitSettings, finite, points, vector


@dataclass(frozen=True)
class LineFit:
    status: str
    count: int
    sampled_count: int
    tolerance: float
    origin: np.ndarray | None = None
    direction: np.ndarray | None = None
    residual: np.ndarray | None = None
    inliers: np.ndarray | None = None
    trials: int = 0
    parameter_bounds: np.ndarray | None = None
    endpoints: np.ndarray | None = None

    @property
    def valid(self):
        return self.status == "fit"

    def report(self):
        count = 0 if self.inliers is None else int(self.inliers.sum())
        return {"model": "fitted_line_3d_v1", "status": self.status,
                "selected_points": self.count, "fit_sample_points": self.sampled_count,
                "inlier_points": count, "excluded_fit_points": self.count - count,
                "inlier_fraction": count / self.count if self.count else 0.,
                "distance_tolerance": self.tolerance, "ransac_trials": self.trials,
                "origin": None if self.origin is None else self.origin.tolist(),
                "direction": None if self.direction is None else self.direction.tolist(),
                "parameter_bounds": (None if self.parameter_bounds is None else
                                     self.parameter_bounds.tolist()),
                "endpoints": None if self.endpoints is None else self.endpoints.tolist(),
                "observed_inlier_span": (None if self.parameter_bounds is None else
                                          float(np.ptp(self.parameter_bounds))),
                "orthogonal_rmse": (float(np.sqrt(np.mean(self.residual[self.inliers]**2)))
                                    if count else None),
                "all_selected_max_radial_residual": (float(self.residual.max())
                                                      if self.residual is not None else None)}


def radial(data, origin, direction):
    delta = data - origin
    return np.linalg.norm(delta - (delta @ direction)[:, None] * direction, axis=1)


def _tls(data, hint):
    origin = data.mean(0)
    _, singular, vectors = np.linalg.svd(data - origin, full_matrices=False)
    if (singular[0] <= 1e-12 or singular[1] >= singular[0] * (1 - 1e-6)):
        return None
    direction = vectors[0].copy()
    sign = np.zeros(3) if hint is None else hint
    if abs(direction @ sign) < 1e-12:
        sign = np.eye(3)[np.argmax(abs(direction))]
    if direction @ sign < 0:
        direction = -direction
    return origin, direction


def fit_line(data, tolerance, *, settings=None, direction_hint=None):
    data = points(data)
    settings = FitSettings() if settings is None else settings
    if not isinstance(settings, FitSettings):
        raise ValueError("Supply FitSettings.")
    tolerance = finite(tolerance, "Line tolerance")
    if tolerance <= 0:
        raise ValueError("Line tolerance must be positive.")
    hint = None if direction_hint is None else np.asarray(vector(direction_hint, "Direction hint"))
    if hint is not None and np.linalg.norm(hint) < 1e-12:
        raise ValueError("Direction hint must be nonzero.")
    sampled = data[np.linspace(0, len(data) - 1, min(len(data), settings.fit_sample_limit),
                                dtype=int)]
    info = dict(count=len(data), sampled_count=len(sampled), tolerance=tolerance)
    if len(data) < settings.min_points:
        return LineFit("insufficient_points", **info)
    center = sampled.mean(0)
    span = float(np.linalg.norm(np.ptp(sampled, axis=0)))
    if span <= 1e-12:
        return LineFit("degenerate", **info)
    sample = (sampled - center) / span
    distance = tolerance / span
    rng = np.random.default_rng(settings.seed)
    best, key, trials, required = None, (-1, -np.inf), 0, settings.max_trials
    while trials < min(required, settings.max_trials):
        a, b = sample[rng.choice(len(sample), 2, replace=False)]
        trials += 1
        direction = b - a
        size = np.linalg.norm(direction)
        if size <= 1e-10:
            continue
        residual = radial(sample, a, direction / size)
        selected = residual <= distance
        n = int(selected.sum())
        candidate = n, -float(residual[selected].mean()) if n else -np.inf
        if candidate > key:
            best, key = selected, candidate
            ratio = n / len(sample)
            if ratio >= 1:
                required = 16
            elif ratio > 0:
                required = min(required, max(16, int(np.ceil(
                    np.log(.001) / np.log1p(-ratio**2)))))
    if best is None or best.sum() < settings.min_points:
        return LineFit("degenerate" if best is None else "consensus_failed", trials=trials, **info)
    fitted = _tls(sample[best], hint)
    if fitted is None:
        return LineFit("degenerate", trials=trials, **info)
    origin, direction = center + fitted[0] * span, fitted[1]
    stable = False
    for _ in range(12):
        selected = radial(data, origin, direction) <= tolerance
        if selected.sum() < settings.min_points:
            break
        fitted = _tls((data[selected] - center) / span, hint)
        if fitted is None:
            return LineFit("degenerate", trials=trials, **info)
        origin, direction = center + fitted[0] * span, fitted[1]
        updated = radial(data, origin, direction) <= tolerance
        if np.array_equal(updated, selected):
            stable = True
            break
    residual = radial(data, origin, direction)
    selected = residual <= tolerance
    status = ("fit" if selected.sum() >= settings.min_points
              and selected.mean() >= settings.min_inlier_fraction else "consensus_failed")
    if status == "fit" and not stable:
        status = "refinement_not_stable"
    parameters = (data[selected] - origin) @ direction
    bounds = np.array([parameters.min(), parameters.max()]) if len(parameters) else None
    endpoints = None if bounds is None else origin + bounds[:, None] * direction
    for value in (origin, direction, residual, selected, bounds, endpoints):
        if value is not None:
            value.flags.writeable = False
    return LineFit(status, **info, origin=origin, direction=direction, residual=residual,
                   inliers=selected, trials=trials, parameter_bounds=bounds, endpoints=endpoints)


def learn_line_tolerance(data, *, settings, direction_hint=None):
    data = points(data)
    span = float(np.linalg.norm(np.ptp(data, axis=0))) if len(data) else 0.
    if len(data) < settings.min_points or span <= 1e-12:
        raise ValueError("Automatic line training needs a nondegenerate reference region.")
    coarse = fit_line(data, span * .02, settings=settings, direction_hint=direction_hint)
    if not coarse.valid:
        raise ValueError(f"Reference cannot establish a line: {coarse.status}.")
    # For isotropic transverse Gaussian noise, radial residuals are Rayleigh.
    # This is a fit-band heuristic, not a calibrated uncertainty/probability.
    sigma = np.median(coarse.residual[coarse.inliers]) / np.sqrt(2 * np.log(2))
    floor = max(span * 1e-6, np.finfo(float).eps * np.max(abs(data)) * 64)
    return float(max(3.5 * sigma, floor))
