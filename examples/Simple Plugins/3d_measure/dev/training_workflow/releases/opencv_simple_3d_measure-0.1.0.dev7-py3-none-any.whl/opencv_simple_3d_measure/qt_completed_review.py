"""Independent native fly-around review of completed measurements and residuals."""

import uuid
from pathlib import Path

from opencv_dataflow.cloud_viewer import CloudViewer
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QFileDialog,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
)

from .completed_review import limits_text
from .graphics import LAYERS
from .qt_residuals import ResidualHistogram


class CompletedMeasurementReviewDialog(CloudViewer):
    def __init__(self, parent, context, capture):
        super().__init__(None, parent)
        self.resize(1320, 1080)
        self.setWindowTitle("Completed 3D measurement review")
        self.snapshot = None
        self._capture = capture
        self._closed = False
        self.selected_measurement = None
        actions = QHBoxLayout()
        self.capture_button = QPushButton("Capture latest completed run")
        self.capture_button.clicked.connect(self.capture_latest)
        actions.addWidget(self.capture_button)
        focus = QPushButton("Focus measurement region")
        focus.clicked.connect(self.focus_region)
        actions.addWidget(focus)
        overview = QPushButton("Overview")
        overview.clicked.connect(self.overview)
        actions.addWidget(overview)
        self.export_button = QPushButton("Export frozen review…")
        self.export_button.setEnabled(False)
        self.export_button.clicked.connect(self.choose_export)
        actions.addWidget(self.export_button)
        close = QPushButton("Close review")
        close.clicked.connect(self.reject)
        actions.addWidget(close)
        self.layout().insertLayout(0, actions)
        self.identity, self.status, self.summary = (QLabel() for _ in range(3))
        for label in (self.identity, self.status, self.summary):
            label.setWordWrap(True)
            label.setTextFormat(Qt.TextFormat.PlainText)
        self.layout().insertWidget(1, self.identity)
        self.layout().insertWidget(2, self.status)
        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(
            ["Measurement", "Kind", "Value", "Units", "Lower", "Upper", "Status", "Reason"]
        )
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setMaximumHeight(155)
        self.table.itemSelectionChanged.connect(self.select_row)
        self.layout().insertWidget(3, self.table)
        controls = QHBoxLayout()
        self.mode = QComboBox()
        for title, value in (
            ("Fit / datums / dimensions", "fit"),
            ("Recorded fit residuals", "residuals"),
            ("Exact consumed cloud", "input"),
        ):
            self.mode.addItem(title, value)
        self.region = QComboBox()
        self.mode.currentIndexChanged.connect(self.show_selection)
        self.region.currentIndexChanged.connect(self.show_selection)
        controls.addWidget(self.mode)
        controls.addWidget(self.region, 1)
        self.layout().insertLayout(4, controls)
        grid = QGridLayout()
        self.layers = {}
        for i, name in enumerate(LAYERS):
            box = QCheckBox(name.replace("_", " ").capitalize())
            box.setChecked(True)
            box.toggled.connect(self.show_selection)
            self.layers[name] = box
            grid.addWidget(box, i // 6, i % 6)
        self.layout().insertLayout(5, grid)
        self.layout().insertWidget(6, self.summary)
        self.histogram = ResidualHistogram(self)
        self.histogram.hide()
        self.layout().insertWidget(7, self.histogram)
        self.legend = QLabel(
            "Fit: gray measured scene · green inliers · red fit exclusions · magenta unavailable · "
            "blue datum grids · purple ROI boxes · yellow dimensions · RGB datum axes. "
            "Residuals: plane signed blue/gray/red; line radial gray/red; "
            "fixed ±3/0..3 taught fit bands. "
            "Grids/axes/dimensions/zone supports are derived geometry, not extra sensor returns. "
            "Residuals are fit evidence, not reference deviation or measurement uncertainty."
        )
        self.legend.setWordWrap(True)
        self.layout().addWidget(self.legend)
        self.export_status = QLabel()
        self.export_status.setWordWrap(True)
        self.layout().addWidget(self.export_status)
        self.finished.connect(self.release_review)
        unsubscribe = context.subscribe_outputs(self.publication_changed)
        self.finished.connect(unsubscribe)
        self.destroyed.connect(unsubscribe)
        self.capture_latest()

    def release_review(self, *_):
        self._closed = True
        self.orbit_timer.stop()
        self.timer.stop()
        self.image.clear()
        self._rendered = None
        self.cloud = None
        self.histogram.row = None
        self.snapshot = None
        self._capture = None

    def publication_changed(self, revision):
        if self.snapshot is not None and not self._closed:
            self.status.setText(
                "Editor publication changed. This frozen review stays unchanged; "
                "capture latest explicitly."
            )

    def capture_latest(self):
        if self._closed:
            return
        try:
            snapshot = self._capture()
        except (ValueError, RuntimeError, KeyError) as error:
            self.status.setText(
                str(error)
                + (" Previous frozen frame remains displayed." if self.snapshot is not None else "")
            )
            return
        self.snapshot = snapshot
        report, p = snapshot.record.report, snapshot.provenance
        self.identity.setText(
            f"{p['block_id']} · completion {p['execution_count']} · "
            f"{'PASS' if report['passed'] else 'FAIL'} · "
            f"recipe {snapshot.record.parameters['sha256'][:16]} · "
            f"{report['scene_points']:,} points · {report['units']} · "
            f"measurement frame {report['measurement_frame']} → scene {report['scene_frame']}"
        )
        self.status.setText(
            "Frozen completed input, original recipe, effective fixture "
            "and measured fit/residual evidence. "
            "No refitting, measurement or recipe reload. Training is unchanged. "
            "Review graphics can be derived from frozen fits when runtime graphics were disabled."
        )
        self.region.blockSignals(True)
        self.region.clear()
        self.region.addItem("All recorded fit regions", None)
        for name, fit in {**report["planes"], **report.get("lines", {})}.items():
            self.region.addItem(f"{name} — {fit['status']}", name)
        self.region.blockSignals(False)
        self.table.blockSignals(True)
        self.table.setRowCount(len(report["measurements"]))
        for row, item in enumerate(report["measurements"]):
            for column, key in enumerate(
                ("name", "kind", "value", "units", "lower", "upper", "status", "reason")
            ):
                value = item.get(key)
                text = ("Unavailable" if key == "value" else "—") if value is None else str(value)
                cell = QTableWidgetItem(text)
                cell.setToolTip(text)
                self.table.setItem(row, column, cell)
        self.table.resizeColumnsToContents()
        self.table.blockSignals(False)
        self.export_button.setEnabled(True)
        self.select_measurement(snapshot.record.primary)

    def select_measurement(self, name):
        for row in range(self.table.rowCount()):
            if self.table.item(row, 0).text() == name:
                self.table.selectRow(row)
                self.select_row()
                return
        raise ValueError("Choose a recorded measurement")

    def select_row(self):
        row = self.table.currentRow()
        if self.snapshot is None or row < 0:
            return
        self.selected_measurement = self.table.item(row, 0).text()
        measurement = self.snapshot.measurement(self.selected_measurement)
        region = None if measurement.get("other") else measurement["plane"]
        self.region.setCurrentIndex(self.region.findData(region) if region is not None else 0)
        self.show_selection()

    def display_layers(self):
        return tuple(name for name in LAYERS if self.layers[name].isChecked())

    def show_selection(self, *_):
        if self.snapshot is None:
            return
        mode, region = self.mode.currentData(), self.region.currentData()
        for name, box in self.layers.items():
            box.setEnabled(
                mode != "input"
                and not (mode == "residuals" and name in ("inliers", "excluded", "unavailable"))
            )
        self.region.setEnabled(mode != "input")
        cloud = self.snapshot.display_cloud(mode, region, self.display_layers())
        item = self.snapshot.measurement(self.selected_measurement)
        value = "Unavailable" if item["value"] is None else f"{item['value']:.8g} {item['units']}"
        self.summary.setText(
            f"{item['name']}: {value} · {item['status']} · "
            f"{limits_text(item)} · "
            f"{item.get('reason') or item.get('definition', '')}"
        )
        self.histogram.setVisible(mode == "residuals")
        if mode == "residuals":
            report = self.snapshot.residual_report(region)
            self.histogram.set_region(
                None if region is None else report["regions"][region], region, report["units"]
            )
        self.set_cloud(cloud)

    def focus_region(self):
        if self.snapshot is None:
            return
        item = self.snapshot.measurement(self.selected_measurement)
        self.region.setCurrentIndex(self.region.findData(item.get("other") or item["plane"]))
        if self.mode.currentData() == "input":
            self.mode.setCurrentIndex(self.mode.findData("fit"))
        self.layers["scene"].setChecked(False)
        self.layers["measurements"].setChecked(False)
        self.show_selection()

    def overview(self):
        if self.snapshot is None:
            return
        self.region.setCurrentIndex(0)
        self.mode.setCurrentIndex(self.mode.findData("fit"))
        for box in self.layers.values():
            box.setChecked(True)
        self.show_selection()

    def export_to(self, directory):
        if self.snapshot is None:
            raise ValueError("Capture completed measurements before exporting")
        target = self.snapshot.export(
            directory,
            self.selected_measurement,
            self.region.currentData(),
            self.mode.currentData(),
            self.display_layers(),
            yaw=self.yaw.value(),
            pitch=self.pitch.value(),
        )
        if self.mode.currentData() == "residuals" and self.region.currentData() is not None:
            self.histogram.save_image(target / "histogram.png")
        self.export_status.setText(f"Exported frozen review: {target}")
        return target

    def choose_export(self):
        parent = QFileDialog.getExistingDirectory(
            self, "Choose parent folder for a new frozen review"
        )
        if parent:
            try:
                self.export_to(Path(parent) / f"measure3d-review-{uuid.uuid4().hex[:12]}")
            except (ValueError, OSError) as error:
                self.export_status.setText(str(error))
