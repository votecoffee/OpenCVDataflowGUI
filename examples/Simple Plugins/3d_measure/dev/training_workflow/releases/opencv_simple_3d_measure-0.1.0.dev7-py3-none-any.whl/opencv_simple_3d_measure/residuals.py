"""Cached all-selected residual evidence; display scales never change fit acceptance."""

import copy
import hashlib
import io
import json
from pathlib import Path

import numpy as np

from .graphics import COLORS, LAYERS, CloudGraphics, result_cloud
from .specs import LineRegion

RANGE_MULTIPLE = 3.
SIGNED_COLORS = [[45, 90, 240], [70, 190, 240], [215, 215, 215],
                 [255, 175, 45], [245, 50, 50]]


def residual_colors(values, tolerance, *, signed):
    knots = [-3, -1, 0, 1, 3] if signed else [0, 1, 3]
    palette = np.asarray(SIGNED_COLORS if signed else SIGNED_COLORS[2:])
    normalized = np.asarray(values) / tolerance
    return np.column_stack([np.interp(normalized, knots, palette[:, i])
                            for i in range(3)]).round().astype(np.uint8)


class ResidualReview:
    """Compute bounded regional distributions once from a frozen MeasurementResult."""

    def __init__(self, result):
        self.result = result
        self._summaries = {}
        for spec, fit, rows in zip(result.recipe.regions, result.fits, result.selections):
            signed = not isinstance(spec, LineRegion)
            summary = {"kind": "plane" if signed else "line", "status": fit.status,
                       "definition": ("signed_distance_to_current_fitted_plane" if signed else
                                      "unsigned_radial_distance_to_current_fitted_line"),
                       "population": "all_selected_points_including_fit_exclusions",
                       "selected_points": len(rows), "residual_points": 0,
                       "unavailable_points": len(rows), "fit_band": fit.tolerance,
                       "color_range": [-3 * fit.tolerance if signed else 0., 3 * fit.tolerance],
                       "histogram": None, "minimum": None, "median": None, "maximum": None,
                       "rmse": None, "absolute_p95": None,
                       "inlier_points": 0, "excluded_fit_points": len(rows)}
            if fit.valid:
                values = fit.residual
                lo, hi = summary["color_range"]
                edges = np.linspace(lo, hi, 25)
                counts, _ = np.histogram(values, edges)
                summary.update(residual_points=len(values), unavailable_points=0,
                    inlier_points=int(fit.inliers.sum()),
                    excluded_fit_points=int((~fit.inliers).sum()),
                    minimum=float(values.min()), median=float(np.median(values)),
                    maximum=float(values.max()), rmse=float(np.sqrt(np.mean(values**2))),
                    absolute_p95=float(np.quantile(abs(values), .95)),
                    origin=fit.origin.tolist(),
                    axis=(fit.normal if signed else fit.direction).tolist(),
                    histogram={"edges": edges.tolist(), "counts": counts.tolist(),
                               "below_range": int((values < lo).sum()),
                               "above_range": int((values > hi).sum()),
                               "scale": "counts_not_probability", "upper_edge_inclusive": True})
            self._summaries[spec.name] = summary

    def _names(self, region):
        if region is not None and region not in self._summaries:
            raise ValueError("Choose a defined residual region")
        return list(self._summaries) if region is None else [region]

    def report(self, region=None):
        return {"model": "simple_3d_residual_review_v1", "units": self.result.recipe.units,
                "measurement_frame": self.result.recipe.frame, "scene_frame": self.result.frame,
                "range_multiple": RANGE_MULTIPLE,
                "scale_source": "retained_fit_band_not_frame_minimum_maximum",
                "qualification": "fit_residual_not_reference_deviation_or_measurement_uncertainty",
                "regions": {name: copy.deepcopy(self._summaries[name])
                            for name in self._names(region)}}

    def cloud(self, *, region=None, layers=LAYERS, max_points=4000):
        names = self._names(region)
        if type(max_points) is not int or not 4 <= max_points <= 20000:
            raise ValueError("Residual display budget must be 4..20000 points per region")
        # Keep the original cached grids/axes/dimensions without duplicate fit point colors.
        layers = tuple(layers)
        if any(name not in LAYERS for name in layers):
            raise ValueError("Choose known measurement graphic layers")
        base = result_cloud(self.result, plane=region,
            layers=tuple(n for n in layers if n not in ("inliers", "excluded", "unavailable")))
        xyz, colors, displayed = [base.points], [base.colors], {}
        for spec, fit, rows in zip(self.result.recipe.regions, self.result.fits,
                                   self.result.selections):
            if spec.name not in names:
                continue
            if not len(rows):
                displayed[spec.name] = 0
                continue
            ids = np.linspace(0, len(rows) - 1, min(len(rows), max_points), dtype=int)
            if fit.valid:
                # Reserve part of the same budget for extreme residual evidence.
                extreme_count = min(128, max_points // 4, len(rows))
                extreme = np.argpartition(abs(fit.residual), len(rows) - extreme_count)[
                    -extreme_count:]
                uniform = np.linspace(0, len(rows) - 1,
                                      min(len(rows), max_points - extreme_count), dtype=int)
                ids = np.unique(np.r_[uniform, extreme, fit.residual.argmin(),
                                      fit.residual.argmax()])
                # Min/max can add two rows beyond the reservation; keep the limit explicit.
                if len(ids) > max_points:
                    anchors = np.unique([fit.residual.argmin(), fit.residual.argmax()])
                    ids = np.r_[anchors, np.setdiff1d(ids, anchors)[:max_points - len(anchors)]]
                rgb = residual_colors(fit.residual[ids], fit.tolerance,
                                      signed=not isinstance(spec, LineRegion))
            else:
                rgb = np.tile(COLORS["unavailable"], (len(ids), 1)).astype(np.uint8)
            xyz.append(self.result.scene[rows[ids]])
            colors.append(rgb)
            displayed[spec.name] = len(ids)
        points = np.ascontiguousarray(np.concatenate(xyz), np.float32)
        rgb = np.ascontiguousarray(np.concatenate(colors), np.uint8)
        points.flags.writeable = rgb.flags.writeable = False
        metadata = {**base.metadata, "view": "all_selected_fit_residuals",
                    "residual_review": self.report(region), "displayed_region_points": displayed,
                    "residual_legend": {"plane_band_knots": [-3, -1, 0, 1, 3],
                        "plane_colors": SIGNED_COLORS, "line_band_knots": [0, 1, 3],
                        "line_colors": SIGNED_COLORS[2:], "unavailable": COLORS["unavailable"],
                        "clipping": "endpoint_colors_saturate_beyond_range_counts_retained"}}
        return CloudGraphics(points, rgb, base.units, base.frame, metadata)

    def export(self, path, *, region=None):
        """Export full source-row IDs and physical residuals, independently of display sampling."""
        names = self._names(region)
        descriptor = self.report(region)
        descriptor["scene_xyz_sha256"] = hashlib.sha256(self.result.scene.tobytes()).hexdigest()
        descriptor["row_index_scope"] = "zero_based_rows_of_scene_xyz_sha256"
        arrays = {}
        for i, (spec, fit, rows) in enumerate(zip(self.result.recipe.regions, self.result.fits,
                                                 self.result.selections)):
            if spec.name not in names:
                continue
            key = f"region_{i}"
            arrays[key + "_rows"] = rows.astype(np.int32)
            if fit.valid:
                arrays[key + "_values"] = fit.residual
            descriptor["regions"][spec.name]["array_prefix"] = key
        arrays["manifest"] = np.asarray(json.dumps(descriptor, allow_nan=False))
        stream = io.BytesIO()
        np.savez_compressed(stream, **arrays)
        # Four million selected rows bound values+IDs to 48 MB plus small metadata.
        if len(stream.getbuffer()) > 64 * 1024 * 1024:
            raise ValueError("Residual export exceeds 64 MiB")
        with Path(path).open("xb") as destination:
            destination.write(stream.getvalue())
        return hashlib.sha256(stream.getvalue()).hexdigest()
