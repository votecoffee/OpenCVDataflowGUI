"""Transactional teaching state with bounded undo and stale training-job rejection."""

import hashlib
from dataclasses import dataclass, replace

import numpy as np

from .measure import Measurer, Recipe, train
from .reference import ReferenceEvidence
from .specs import (
    FitSettings,
    LineRegion,
    Measurement,
    PlaneRegion,
    definitions,
    identity,
    points,
    validate_measurements,
)


@dataclass(frozen=True)
class TrainingJob:
    revision: int
    reference: np.ndarray
    planes: tuple
    measurements: tuple
    settings: FitSettings
    units: str
    frame: str
    lines: tuple = ()
    reference_evidence: ReferenceEvidence | None = None

    def run(self):
        recipe = train(self.reference, self.planes, self.measurements, settings=self.settings,
                       units=self.units, frame=self.frame, lines=self.lines,
                       reference_evidence=self.reference_evidence)
        return recipe, Measurer(recipe).measure(self.reference, units=self.units, frame=self.frame)


class TeachingSession:
    def __init__(self, recipe=None):
        self.reference = None
        self.reference_evidence = None
        self.units, self.frame = "mm", "reference"
        self.planes, self.measurements, self.settings = (), (), FitSettings()
        self.lines = ()
        self.recipe = self.result = None
        self.revision, self.trained_revision = 0, -1
        self._undo, self._redo = [], []
        if recipe is not None:
            self.restore(recipe)

    @property
    def trained(self):
        return self.recipe is not None and self.revision == self.trained_revision

    @property
    def can_undo(self):
        return bool(self._undo)

    @property
    def can_redo(self):
        return bool(self._redo)

    @property
    def regions(self):
        return self.planes + self.lines

    @property
    def source_identity(self):
        if self.reference is None:
            return None
        evidence = self.reference_evidence
        return hashlib.sha256(self.reference.tobytes()
                              + (self.units + "\0" + self.frame).encode()
                              + (b"" if evidence is None else evidence.sha256.encode())).hexdigest()

    def restore(self, recipe):
        if not isinstance(recipe, Recipe):
            raise ValueError("Restore a trained measurement recipe")
        self.reference, self.units, self.frame = recipe.reference, recipe.units, recipe.frame
        self.reference_evidence = recipe.reference_evidence
        self.planes, self.measurements, self.settings = (recipe.planes, recipe.measurements,
                                                       recipe.settings)
        self.lines = recipe.lines
        self.revision += 1
        self.recipe, self.trained_revision = recipe, self.revision
        self.result = Measurer(recipe).measure(recipe.reference, units=recipe.units,
                                               frame=recipe.frame)
        self._undo.clear()
        self._redo.clear()

    def reference_cloud(self, xyz, *, units, frame, evidence=None):
        identity(units, frame)
        reference = points(xyz)
        if len(reference) < self.settings.min_points:
            raise ValueError("Reference needs at least the configured minimum number of points")
        if evidence is not None and (not isinstance(evidence, ReferenceEvidence)
                                     or evidence.count != len(reference)):
            raise ValueError("Reference evidence must match the retained XYZ rows")
        compatible = units == self.units and frame == self.frame
        self.reference, self.units, self.frame = reference, units, frame
        self.reference_evidence = evidence
        if not compatible:
            self.planes, self.lines, self.measurements = (), (), ()
        self.revision += 1
        self.recipe = self.result = None
        self.trained_revision = -1
        self._undo.clear()
        self._redo.clear()
        return compatible

    def _state(self):
        return self.regions, self.measurements, self.settings

    def _restore_state(self, state):
        regions, self.measurements, self.settings = state
        self.planes = tuple(p for p in regions if isinstance(p, PlaneRegion))
        self.lines = tuple(p for p in regions if isinstance(p, LineRegion))

    def _change(self, planes, measurements, settings=None):
        planes, measurements = tuple(planes), tuple(measurements)
        if len(planes) > 16 or len(measurements) > 64:
            raise ValueError("At most 16 regions and 64 measurements are supported")
        if len({p.name for p in planes}) != len(planes):
            raise ValueError("Region names must be unique")
        if len({m.name for m in measurements}) != len(measurements):
            raise ValueError("Measurement names must be unique")
        validate_measurements(planes, measurements)
        state = planes, measurements, self.settings if settings is None else settings
        if state != self._state():
            self._undo.append(self._state())
            self._undo = self._undo[-32:]
            self._redo.clear()
            self._restore_state(state)
            self.revision += 1

    def region(self, region, *, old_name=None):
        if not isinstance(region, (PlaneRegion, LineRegion)):
            raise ValueError("Expected a plane or line region")
        if old_name is None:
            self._change((*self.regions, region), self.measurements)
            return
        if old_name not in {p.name for p in self.regions}:
            raise ValueError("Choose an existing region")
        measurements = tuple(replace(m, plane=region.name if m.plane == old_name else m.plane,
                                     other=region.name if m.other == old_name else m.other)
                             for m in self.measurements)
        self._change(tuple(region if p.name == old_name else p for p in self.regions), measurements)

    def remove_region(self, name):
        self._change(tuple(p for p in self.regions if p.name != name),
                     tuple(m for m in self.measurements if name not in (m.plane, m.other)))

    def measurement(self, measurement, *, old_name=None):
        if not isinstance(measurement, Measurement):
            raise ValueError("Expected a measurement")
        values = ((*self.measurements, measurement) if old_name is None else
                  tuple(measurement if m.name == old_name else m for m in self.measurements))
        if old_name is not None and old_name not in {m.name for m in self.measurements}:
            raise ValueError("Choose an existing measurement")
        self._change(self.regions, values)

    def remove_measurement(self, name):
        self._change(self.regions, tuple(m for m in self.measurements if m.name != name))

    def undo(self):
        if self._undo:
            self._redo.append(self._state())
            self._restore_state(self._undo.pop())
            self.revision += 1

    def redo(self):
        if self._redo:
            self._undo.append(self._state())
            self._restore_state(self._redo.pop())
            self.revision += 1

    def job(self):
        if self.reference is None:
            raise ValueError("Load or capture a teaching reference first")
        definitions(self.planes, self.measurements, lines=self.lines)
        return TrainingJob(self.revision, self.reference, self.planes, self.measurements,
                           self.settings, self.units, self.frame, self.lines,
                           self.reference_evidence)

    def accept(self, job, output):
        if job.revision != self.revision or job.reference is not self.reference:
            return False
        self.recipe, self.result = output
        self.trained_revision = self.revision
        return True

    def staged_recipe(self):
        if not self.trained:
            raise ValueError("Train the current draft before staging; the previous fit is stale")
        return self.recipe
