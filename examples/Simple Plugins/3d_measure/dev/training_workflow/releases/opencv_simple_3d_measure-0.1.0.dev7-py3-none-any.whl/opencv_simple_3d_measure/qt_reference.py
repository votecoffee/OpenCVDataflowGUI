"""Read-only reference context, kept separate from calibration and measurement controls."""

import json

from PySide6.QtWidgets import QDialog, QDialogButtonBox, QLabel, QPlainTextEdit, QVBoxLayout


def show_reference_context(parent, evidence):
    if evidence is None:
        raise ValueError("This reference retains XYZ only; capture or import context to add it")
    dialog = QDialog(parent)
    dialog.setWindowTitle("Simple3DMeasure · retained reference context")
    dialog.resize(760, 620)
    layout = QVBoxLayout(dialog)
    label = QLabel("Frozen source context is descriptive evidence. Calibration and timestamps "
                   "are supplied upstream; these fields do not recalibrate points "
                   "or certify accuracy.")
    label.setWordWrap(True)
    layout.addWidget(label)
    text = QPlainTextEdit()
    text.setReadOnly(True)
    text.setPlainText(json.dumps({**evidence.summary(), "metadata": evidence.metadata}, indent=2))
    layout.addWidget(text)
    buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
    buttons.rejected.connect(dialog.reject)
    layout.addWidget(buttons)
    dialog.exec()
