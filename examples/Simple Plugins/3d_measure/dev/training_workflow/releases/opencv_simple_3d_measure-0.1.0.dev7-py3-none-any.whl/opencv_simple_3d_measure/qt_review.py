"""Retained recipe and completed-input review; graphical teaching is a later editor."""

import hashlib
import json
import uuid
from pathlib import Path

from opencv_dataflow.cloud_io import write_cloud
from opencv_dataflow.cloud_viewer import CloudViewer
from opencv_dataflow.pointclouds import PointCloud
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from . import Measurer, ReferenceEvidence, load_recipe, save_recipe
from .cli import write_npz
from .dataflow import fixture_matrix, recipe_path
from .graphics import LAYERS, result_cloud
from .persistence import MAX_BYTES
from .qt_residuals import ResidualHistogram
from .residuals import ResidualReview


class MeasurementReviewDialog(QDialog):
    def __init__(self, parent, parameters, context, *, review_only=False):
        super().__init__(parent)
        self.parameters, self.context = parameters, context
        self.review_only = review_only
        self.recipe = self.reference_result = self.completed_result = None
        self.digest, self.capture = None, None
        self.completed_evidence = None
        self._residual_reference = self._residual_completed = None
        self._unsubscribe = None
        self.setWindowTitle("Simple3DMeasure · recipe and result review")
        self.resize(1300, 900)
        layout = QVBoxLayout(self)
        actions = QHBoxLayout()
        for label, action in (("Import trained recipe…", self._import),
                              ("Capture completed run", self._capture),
                              ("Export visible review…", self._choose_export),
                              ("Stage recipe", self._stage)):
            if review_only and label in ("Import trained recipe…", "Stage recipe"):
                continue
            button = QPushButton(label)
            button.clicked.connect(lambda checked=False, f=action: self._run(f))
            actions.addWidget(button)
        layout.addLayout(actions)
        self.status = QLabel("Import a trained recipe, or open a block with a saved recipe.")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.choice = QComboBox()
        self.choice.addItem("Retained training reference")
        self.choice.addItem("Frozen completed run")
        self.choice.currentIndexChanged.connect(self.refresh)
        layout.addWidget(self.choice)
        row = QHBoxLayout()
        self.display = QComboBox()
        self.display.addItems(["Fit evidence", "Source appearance / measured points",
                               "Residuals / all selected"])
        self.display.currentIndexChanged.connect(self.refresh)
        row.addWidget(self.display)
        self.context_button = QPushButton("Source context…")
        self.context_button.clicked.connect(lambda: self._run(self._source_context))
        row.addWidget(self.context_button)
        self.source_status = QLabel()
        self.source_status.setWordWrap(True)
        row.addWidget(self.source_status, 1)
        layout.addLayout(row)
        row = QHBoxLayout()
        self.plane = QComboBox()
        self.plane.addItem("All regions", None)
        self.plane.currentIndexChanged.connect(self.refresh)
        row.addWidget(self.plane)
        self.layers = {}
        for name in LAYERS:
            box = QCheckBox(name.replace("_", " ").capitalize())
            box.setChecked(True)
            box.toggled.connect(self.refresh)
            self.layers[name] = box
            row.addWidget(box)
        layout.addLayout(row)
        legend = QLabel(
            "Gray: scene · Green: fit inliers · Red: excluded fitting points · Magenta: "
            "unavailable · Blue: fitted grids · Violet: trained ROI boxes · Yellow: dimensions · "
            "Orange/violet: lower/upper zone and support witnesses · RGB: datum axes."
        )
        legend.setWordWrap(True)
        layout.addWidget(legend)
        self.viewer = CloudViewer(None, self)
        self.viewer.setWindowFlags(Qt.WindowType.Widget)
        layout.addWidget(self.viewer, 1)
        self.histogram = ResidualHistogram()
        self.histogram.hide()
        layout.addWidget(self.histogram)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Measurement", "Value", "Units", "Status",
                                              "Evidence"])
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setMaximumHeight(190)
        self.table.cellDoubleClicked.connect(self._choose_residual_region)
        layout.addWidget(self.table)
        hint = QLabel(
            "Import a trained recipe to review its reference and completed runs. "
            "Stage prepares a revision; inspector Apply activates it."
        )
        hint.setWordWrap(True)
        layout.addWidget(hint)
        if parameters.get("recipe_path"):
            self._run(lambda: self.set_recipe(
                recipe_path(context.project_dir, parameters["recipe_path"]), parameters["sha256"]))
        if hasattr(context, "subscribe_outputs"):
            self._unsubscribe = context.subscribe_outputs(self._outputs_changed)

    def _run(self, action):
        try:
            action()
        except (ValueError, OSError, KeyError, TypeError, RuntimeError) as error:
            self.status.setText(str(error))

    def set_recipe(self, path, digest=None):
        path = Path(path)
        if path.stat().st_size > MAX_BYTES:
            raise ValueError("Recipe exceeds 64 MiB.")
        digest = digest or hashlib.sha256(path.read_bytes()).hexdigest()
        recipe = load_recipe(path, sha256=digest)
        self.set_trained_recipe(recipe, digest=digest)

    def set_trained_recipe(self, recipe, *, digest=None, reference_result=None):
        reference = reference_result
        if reference is not None and reference.recipe is not recipe:
            raise ValueError("Reference review must belong to this exact recipe")
        if reference is None:
            reference = Measurer(recipe).measure(recipe.reference, units=recipe.units,
                                                  frame=recipe.frame)
        self.recipe, self.reference_result, self.digest = recipe, reference, digest
        self.completed_result = self.capture = None
        self.completed_evidence = None
        self._residual_reference = self._residual_completed = None
        self.choice.blockSignals(True)
        self.choice.setCurrentIndex(0)
        self.choice.blockSignals(False)
        self.plane.blockSignals(True)
        self.plane.clear()
        self.plane.addItem("All regions", None)
        for p in recipe.regions:
            self.plane.addItem(p.name, p.name)
        self.plane.blockSignals(False)
        self.status.setText(
            f"Restored {len(recipe.reference):,} reference points; {len(recipe.regions)} regions. "
            "Fit bands are retained. Capture a completed run for independent review."
        )
        self.refresh()

    @property
    def current_result(self):
        return self.completed_result if self.choice.currentIndex() else self.reference_result

    @property
    def current_evidence(self):
        return (self.completed_evidence if self.choice.currentIndex() else
                None if self.recipe is None else self.recipe.reference_evidence)

    def _source_context(self):
        from .qt_reference import show_reference_context

        show_reference_context(self, self.current_evidence)

    def residual_review(self):
        name = "_residual_completed" if self.choice.currentIndex() else "_residual_reference"
        review = getattr(self, name)
        if review is None:
            if self.current_result is None:
                raise ValueError("Choose an available result before reviewing residuals")
            review = ResidualReview(self.current_result)
            setattr(self, name, review)
        return review

    def _choose_residual_region(self, row, column):
        if self.display.currentIndex() == 2 and self.table.item(row, 0) is not None:
            self.plane.setCurrentIndex(self.plane.findData(self.table.item(row, 0).text()))

    def refresh(self, *_):
        result = self.current_result
        if result is None:
            self.viewer.set_cloud(None)
            self.table.setRowCount(0)
            self.source_status.setText("No source for this review")
            self.context_button.setEnabled(False)
            self.histogram.hide()
            return
        evidence = self.current_evidence
        self.context_button.setEnabled(evidence is not None)
        self.source_status.setText("Source RGB retained" if evidence is not None and
                                   evidence.colors is not None else "No source RGB retained")
        source_mode = self.display.currentIndex() == 1
        residual_mode = self.display.currentIndex() == 2
        if residual_mode:
            self.source_status.setText("Planes: signed blue/gray/red; lines: radial gray/red. "
                                       "Range: three taught fit bands. Double-click a region row.")
        self.histogram.setVisible(residual_mode)
        for name, box in self.layers.items():
            box.setEnabled(not source_mode and
                           not (residual_mode and name in ("inliers", "excluded", "unavailable")))
        self.plane.setEnabled(not source_mode)
        if source_mode:
            self.viewer.set_cloud(PointCloud(result.scene, result.recipe.units, result.frame,
                colors=None if evidence is None else evidence.colors,
                pixels=None if evidence is None else evidence.pixels,
                source_size=None if evidence is None else evidence.source_size))
        else:
            layers = tuple(n for n, b in self.layers.items() if b.isChecked())
            region = self.plane.currentData()
            if residual_mode:
                review = self.residual_review()
                graphics = review.cloud(region=region, layers=layers)
                rows = review.report(region)["regions"]
                self.histogram.set_region(None if region is None else rows[region], region,
                                          result.recipe.units)
            else:
                graphics = result_cloud(result, plane=region, layers=layers)
            self.viewer.set_cloud(PointCloud(graphics.points, graphics.units, graphics.frame,
                                             colors=graphics.colors, metadata=graphics.metadata))
        if residual_mode:
            units = result.recipe.units
            self.table.setColumnCount(8)
            self.table.setHorizontalHeaderLabels(["Region", "State", "Valid / selected",
                f"Fit band ({units})", f"Min ({units})", f"Median ({units})", f"Max ({units})",
                f"|Residual| p95 ({units})"])
            self.table.setRowCount(len(rows))
            for i, (name, row) in enumerate(rows.items()):
                values = [name, row["status"],
                          f"{row['residual_points']} / {row['selected_points']}",
                          f"{row['fit_band']:.6g}"]
                values.extend("unavailable" if row[k] is None else f"{row[k]:.6g}"
                              for k in ("minimum", "median", "maximum", "absolute_p95"))
                for column, value in enumerate(values):
                    self.table.setItem(i, column, QTableWidgetItem(value))
            self.table.resizeColumnsToContents()
            return
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["Measurement", "Value", "Units", "Status",
                                              "Evidence"])
        self.table.setRowCount(len(result.measurements))
        for index, row in enumerate(result.measurements):
            evidence = row["reason"] or ("Datum projection outside inlier bounds"
                                        if row.get("datum_extrapolated") else "")
            values = (row["name"], "unavailable" if row["value"] is None else f"{row['value']:.6g}",
                      row["units"], row["status"], evidence)
            for column, value in enumerate(values):
                self.table.setItem(index, column, QTableWidgetItem(value))
        self.table.resizeColumnsToContents()

    def _import(self):
        path, _ = QFileDialog.getOpenFileName(self, "Import trained measurement recipe", "",
                                             "Measurement recipes (*.s3m)")
        if path:
            self.set_recipe(path)

    def _capture(self):
        if self.recipe is None:
            raise ValueError("Import a trained recipe before capturing a test run.")
        if not hasattr(self.context, "snapshot_processed_inputs"):
            raise ValueError("This host cannot capture completed inputs; use a newer host.")
        bundle = self.context.snapshot_processed_inputs()
        source = bundle.inputs["scene"].value
        if not isinstance(source, PointCloud):
            raise ValueError("Completed scene must be a declared point cloud.")
        packet = bundle.inputs.get("fixture")
        fixture = fixture_matrix(None if packet is None else packet.value, self.recipe, source)
        result = Measurer(self.recipe).measure(source.points, units=source.units,
                                                frame=source.frame, fixture=fixture)
        evidence = ReferenceEvidence(len(source.points), colors=source.colors,
            pixels=source.pixels, source_size=source.source_size,
            metadata={"cloud_metadata": source.metadata, "capture": {
                "kind": "completed_scene_fixture", "snapshot_id": bundle.snapshot_id,
                "block_id": bundle.block_id, "output_revision": bundle.output_revision,
                "execution_count": bundle.execution_count, "passed": bundle.passed,
                "scene_payload": bundle.inputs["scene"].payload,
                "fixture_payload": {} if packet is None else packet.payload,
                "reference_frame": self.recipe.frame, "source_frame": source.frame,
                "reference_to_source": result.fixture.tolist()}})
        self.completed_result, self.capture, self.completed_evidence = result, bundle, evidence
        self._residual_completed = None
        self.choice.setCurrentIndex(1)
        self.status.setText(
            f"Frozen inputs from completed run {bundle.execution_count}; "
            "acquisition timing comes from upstream."
        )
        self.refresh()

    def _outputs_changed(self, *_):
        if self.completed_result is not None:
            self.status.setText("New graph outputs are available. This review remains a frozen "
                                "completed run; capture again to review the new run.")

    def export(self, folder):
        result = self.current_result
        if result is None:
            raise ValueError("Select an available reference or completed result.")
        folder = Path(folder)
        folder.mkdir(parents=True, exist_ok=False)
        write_cloud(folder / "measurement_review.ply", self.viewer.cloud, binary=True)
        digest = save_recipe(folder / "measurement.s3m", result.recipe)
        evidence = self.current_evidence
        if evidence is not None:
            write_npz(folder / "source.npz", result.scene, units=result.recipe.units,
                       frame=result.frame, evidence=evidence)
        report = {**result.report(), "recipe_sha256": digest,
                  "source_recipe_sha256": self.digest,
                  "scene_xyz_sha256": hashlib.sha256(result.scene.tobytes()).hexdigest(),
                  "selected_plane": self.plane.currentData(),
                  "layers": [n for n, b in self.layers.items() if b.isChecked()],
                  "capture_id": (self.capture.snapshot_id if self.choice.currentIndex()
                                 and self.capture is not None else None)}
        if evidence is not None:
            report.update(source_context={**evidence.summary(), "metadata": evidence.metadata},
                          source_npz_sha256=hashlib.sha256(
                              (folder / "source.npz").read_bytes()).hexdigest(),
                          display=self.display.currentText())
        if self.display.currentIndex() == 2:
            review = self.residual_review()
            report.update(residual_review=review.report(self.plane.currentData()),
                          residual_npz_sha256=review.export(folder / "residuals.npz",
                                                           region=self.plane.currentData()))
            images = {}
            chart = ResidualHistogram(self)
            for i, (name, row) in enumerate(report["residual_review"]["regions"].items()):
                path = folder / f"residual_histogram_{i}.png"
                chart.set_region(row, name, result.recipe.units)
                chart.save_image(path)
                images[name] = {"file": path.name,
                                "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
            chart.deleteLater()
            report["residual_histograms"] = images
        (folder / "report.json").write_bytes(
            (json.dumps(report, indent=2, allow_nan=False) + "\n").encode("utf-8"))
        return folder

    def _choose_export(self):
        parent = QFileDialog.getExistingDirectory(self, "Parent for a fresh measurement export")
        if parent:
            self.export(Path(parent) / f"measurement_{uuid.uuid4().hex[:12]}")

    def _stage(self):
        if self.review_only:
            raise ValueError("Stage the current draft from the training window")
        if self.recipe is None:
            raise ValueError("Import a trained recipe before staging.")
        relative = f"assets/3d_measure/{uuid.uuid4().hex}.s3m"
        path = recipe_path(self.context.project_dir, relative)
        path.parent.mkdir(parents=True, exist_ok=True)
        digest = save_recipe(path, self.recipe)
        self.parameters.update(recipe_path=relative, sha256=digest)
        if (self.parameters.get("primary_measurement")
                not in {m.name for m in self.recipe.measurements}):
            self.parameters["primary_measurement"] = ""
        self.accept()

    def done(self, result):
        if self._unsubscribe is not None:
            self._unsubscribe()
            self._unsubscribe = None
        self.viewer.orbit_timer.stop()
        self.viewer.timer.stop()
        super().done(result)
