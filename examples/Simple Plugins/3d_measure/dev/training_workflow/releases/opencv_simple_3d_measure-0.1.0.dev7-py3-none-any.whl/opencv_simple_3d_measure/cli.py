"""Standalone bounded XYZ interchange, recipe training and measurement replay."""

import argparse
import io
import json
from pathlib import Path
from zipfile import BadZipFile, ZipFile

import numpy as np

from . import (
    FitSettings,
    LineRegion,
    Measurement,
    Measurer,
    PlaneRegion,
    ReferenceEvidence,
    load_recipe,
    save_recipe,
    train,
)
from .persistence import MAX_BYTES, read_array, read_xyz, strict_json
from .reference import MAX_METADATA_BYTES
from .specs import identity


def _scalar(raw, max_bytes=256):
    stream = io.BytesIO(raw)
    version = np.lib.format.read_magic(stream)
    if version not in ((1, 0), (2, 0)):
        raise ValueError("Unsupported scalar NPY version.")
    reader = (np.lib.format.read_array_header_1_0 if version == (1, 0)
              else np.lib.format.read_array_header_2_0)
    shape, _, dtype = reader(stream)
    if (shape != () or dtype.kind != "U" or dtype.itemsize > max_bytes
            or dtype.itemsize != len(raw) - stream.tell()):
        raise ValueError("Coordinate identity requires a bounded Unicode scalar.")
    return str(np.load(io.BytesIO(raw), allow_pickle=False).item())


def read_npz(path, *, with_evidence=False):
    path = Path(path)
    if path.stat().st_size > MAX_BYTES:
        raise ValueError("Cloud archive exceeds 64 MiB.")
    with ZipFile(path) as archive:
        names = archive.namelist()
        base = {"points.npy", "units.npy", "frame.npy"}
        if (not base.issubset(names) or len(names) != len(set(names))
                or set(names) - base - {"colors.npy", "pixels.npy", "evidence.npy"}
                or sum(i.file_size for i in archive.infolist()) > MAX_BYTES):
            raise ValueError("Cloud archive requires bounded points, units and frame entries.")
        data = read_xyz(archive.read("points.npy"))
        units, frame = [_scalar(archive.read(name + ".npy")) for name in ("units", "frame")]
        evidence = None
        if set(names) != base:
            descriptor = (strict_json(_scalar(archive.read("evidence.npy"),
                                              MAX_METADATA_BYTES * 4))
                          if "evidence.npy" in names else {})
            if not isinstance(descriptor, dict) or set(descriptor) - {"source_size", "metadata"}:
                raise ValueError("Cloud evidence requires source_size and/or metadata")
            arrays = {name: read_array(archive.read(name + ".npy"), width, dtypes)
                      for name, width, dtypes in (("colors", 3, ("|u1",)), ("pixels", 2, ("<i4",)))
                      if name + ".npy" in names}
            evidence = ReferenceEvidence(len(data), **arrays, **descriptor)
    identity(units, frame)
    return (data, units, frame, evidence) if with_evidence else (data, units, frame)


def write_npz(path, data, *, units, frame, evidence=None):
    """Create a portable cloud, including optional row-aligned source evidence."""
    from .specs import points

    identity(units, frame)
    data = points(data)
    if evidence is not None and (not isinstance(evidence, ReferenceEvidence)
                                 or evidence.count != len(data)):
        raise ValueError("Cloud evidence must match XYZ rows")
    arrays = {"points": data, "units": np.asarray(units), "frame": np.asarray(frame)}
    if evidence is not None:
        arrays.update({name: getattr(evidence, name) for name in ("colors", "pixels")
                       if getattr(evidence, name) is not None})
        arrays["evidence"] = np.asarray(json.dumps({"source_size": evidence.source_size,
                                                   "metadata": evidence.metadata}))
    if sum(value.nbytes + 256 for value in arrays.values()) > MAX_BYTES:
        raise ValueError("Cloud content exceeds 64 MiB; reduce the source upstream")
    stream = io.BytesIO()
    np.savez_compressed(stream, **arrays)
    if len(stream.getbuffer()) > MAX_BYTES:
        raise ValueError("Cloud archive exceeds 64 MiB")
    with Path(path).open("xb") as destination:
        destination.write(stream.getvalue())


def main(argv=None):
    parser = argparse.ArgumentParser(description="Train and run calibrated 3D measurements.")
    commands = parser.add_subparsers(dest="command", required=True)
    training = commands.add_parser("train")
    training.add_argument("cloud", type=Path)
    training.add_argument("configuration", type=Path)
    training.add_argument("recipe", type=Path)
    measuring = commands.add_parser("measure")
    measuring.add_argument("recipe", type=Path)
    measuring.add_argument("cloud", type=Path)
    measuring.add_argument("--fixture", type=Path, help="Measurement-to-scene 4x4 JSON matrix.")
    measuring.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    try:
        data, units, frame, evidence = read_npz(args.cloud, with_evidence=True)
        if args.command == "train":
            if args.configuration.stat().st_size > 1024 * 1024:
                raise ValueError("Configuration exceeds 1 MiB.")
            config = strict_json(args.configuration.read_bytes())
            if config["units"] != units or config["frame"] != frame:
                raise ValueError("Reference cloud and configuration identity must match.")
            recipe = train(data, [PlaneRegion(**p) for p in config.get("planes", [])],
                           [Measurement(**m) for m in config["measurements"]],
                           units=units, frame=frame,
                           settings=FitSettings(**config.get("settings", {})),
                           lines=[LineRegion(**p) for p in config.get("lines", [])],
                           reference_evidence=evidence)
            report = {"sha256": save_recipe(args.recipe, recipe),
                      "reference": Measurer(recipe).measure(data, units=units,
                                                            frame=frame).report()}
        else:
            fixture = None
            if args.fixture is not None:
                if args.fixture.stat().st_size > 65536:
                    raise ValueError("Fixture JSON exceeds 64 KiB.")
                fixture = strict_json(args.fixture.read_bytes())
            report = Measurer(load_recipe(args.recipe)).measure(data, units=units, frame=frame,
                                                                 fixture=fixture).report()
        text = json.dumps(report, indent=2, allow_nan=False) + "\n"
        if getattr(args, "output", None):
            args.output.write_bytes(text.encode("utf-8"))
        else:
            print(text, end="")
    except (ValueError, OSError, KeyError, TypeError, BadZipFile) as error:
        parser.exit(2, f"{error}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
