"""Retained, transactional 3D teaching using the host's native source-cloud editor."""

import hashlib
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from pathlib import Path

import numpy as np
from opencv_dataflow.cloud_io import read_cloud
from opencv_dataflow.cloud_teaching import CloudTeachingWidget
from opencv_dataflow.cloud_teaching_geometry import CloudBox
from opencv_dataflow.pointclouds import PointCloud
from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QMenu,
    QPushButton,
    QScrollArea,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from . import ReferenceEvidence, load_recipe, save_recipe
from .cli import read_npz
from .dataflow import fixture_matrix, recipe_path
from .persistence import MAX_BYTES
from .qt_bounds import RegionBoundsDialog
from .qt_measurement import KINDS, MeasurementDialog
from .specs import LineRegion, PlaneRegion
from .teaching import TeachingSession


class MeasurementTrainingDialog(QDialog):
    def __init__(self, parent, parameters, context):
        super().__init__(parent)
        self.parameters, self.context = parameters, context
        self.session = TeachingSession()
        self._future = self._job = self._unsubscribe = None
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="3d-teaching")
        self._children = []
        self._closed = False
        self.setWindowTitle("Simple3DMeasure · train measurements")
        available = self.screen().availableGeometry()
        self.resize(min(1380, available.width() - 40), min(940, available.height() - 40))
        layout = QVBoxLayout(self)
        actions = QHBoxLayout()
        footer = QHBoxLayout()
        self.buttons = {}
        for title, action in (("Import reference cloud…", self._import_reference),
                              ("Capture reference…", self._capture_reference),
                              ("Import recipe…", self._import_recipe),
                              ("Train / preview reference", self.start_training),
                              ("Review trained / completed run…", self._review),
                              ("Stage recipe", self._stage)):
            button = QPushButton(title)
            if title == "Capture reference…":
                menu = QMenu(button)
                for text, callback in (
                    ("Connected scene (uses scene frame)", self._capture_connected_reference),
                    ("Completed scene + fixture (keeps recipe frame)", self._capture_reference),
                ):
                    item = menu.addAction(text)
                    item.triggered.connect(lambda checked=False, f=callback: self._run(f))
                button.setMenu(menu)
            else:
                button.clicked.connect(lambda checked=False, f=action: self._run(f))
            (footer if title in ("Train / preview reference",
                "Review trained / completed run…", "Stage recipe") else actions).addWidget(button)
            self.buttons[title] = button
        layout.addLayout(actions)
        self.status = QLabel("Load a reference, draw regions, add measurements, then Train.")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.guidance = QLabel()
        self.guidance.setWordWrap(True)
        layout.addWidget(self.guidance)
        split = QSplitter(Qt.Orientation.Horizontal)
        self.split = split
        self.content_scroll = QScrollArea()
        self.content_scroll.setWidgetResizable(True)
        self.content_scroll.setWidget(split)
        layout.addWidget(self.content_scroll, 1)
        side = QWidget()
        controls = QVBoxLayout(side)
        identity = QFormLayout()
        self.units = QComboBox()
        self.units.addItems(["mm", "m"])
        self.frame = QLineEdit("reference")
        identity.addRow("Import fallback units", self.units)
        identity.addRow("Import fallback frame", self.frame)
        controls.addLayout(identity)
        self.identity = QLabel("No retained reference")
        self.identity.setWordWrap(True)
        controls.addWidget(self.identity)
        self.source_colors = QCheckBox("Show source RGB (keep regions and axes)")
        self.source_colors.toggled.connect(lambda *_: self._select())
        controls.addWidget(self.source_colors)
        self.context_button = QPushButton("Reference context…")
        self.context_button.clicked.connect(lambda: self._run(self._reference_context))
        controls.addWidget(self.context_button)
        controls.addWidget(QLabel("1. Draw a patch to seed an XYZ region; drag its face handles."))
        self.regions = QListWidget()
        self.regions.currentTextChanged.connect(self._select)
        controls.addWidget(self.regions)
        self.region_kind = QComboBox()
        self.region_kind.addItem("New plane region", "plane")
        self.region_kind.addItem("New line region", "line")
        controls.addWidget(self.region_kind)
        region_buttons = QHBoxLayout()
        for title, action in (("Draw region", self._draw), ("Delete region", self._remove_region),
                              ("Flip axis", self._flip)):
            b = QPushButton(title)
            b.clicked.connect(lambda checked=False, f=action: self._run(f))
            region_buttons.addWidget(b)
        controls.addLayout(region_buttons)
        form = QFormLayout()
        self.region_name = QLineEdit()
        self.region_name.editingFinished.connect(lambda: self._run(self._rename))
        form.addRow("Region name", self.region_name)
        self.bounds_button = QPushButton("Edit XYZ bounds…")
        self.bounds_button.clicked.connect(lambda: self._run(self._edit_bounds))
        form.addRow(self.bounds_button)
        self.region_summary = QLabel()
        self.region_summary.setWordWrap(True)
        form.addRow(self.region_summary)
        self.auto_band = QCheckBox("Learn fitting band from reference")
        self.auto_band.setChecked(True)
        self.band = QDoubleSpinBox()
        self.band.setDecimals(8)
        self.band.setRange(1e-9, 1e12)
        self.band.setValue(.1)
        self.auto_band.toggled.connect(lambda *_: self._run(self._band_changed))
        self.band.editingFinished.connect(lambda: self._run(self._band_changed))
        form.addRow(self.auto_band)
        form.addRow("Explicit fitting band", self.band)
        controls.addLayout(form)
        self.evidence = QLabel("Train to inspect selected/inlier counts, bands and signed normal.")
        self.evidence.setWordWrap(True)
        controls.addWidget(self.evidence)
        controls.addWidget(QLabel("2. Define measurements and optional acceptance limits."))
        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(["Name", "Type", "Reference value", "Status",
                                              "Datum / region", "Target / probe",
                                              "Acceptance limits"])
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.cellDoubleClicked.connect(lambda *_: self._run(lambda: self._measurement(True)))
        self.table.itemSelectionChanged.connect(self._select_measurement)
        controls.addWidget(self.table)
        self.measurement_summary = QLabel("Select a measurement to see its datums and limits.")
        self.measurement_summary.setWordWrap(True)
        controls.addWidget(self.measurement_summary)
        row = QHBoxLayout()
        for title, action in (("Add measurement…", lambda: self._measurement(False)),
                              ("Edit…", lambda: self._measurement(True)),
                              ("Delete", self._remove_measurement)):
            b = QPushButton(title)
            b.clicked.connect(lambda checked=False, f=action: self._run(f))
            row.addWidget(b)
        controls.addLayout(row)
        row = QHBoxLayout()
        self.undo_button, self.redo_button = QPushButton("Undo"), QPushButton("Redo")
        self.undo_button.clicked.connect(lambda: self._history(False))
        self.redo_button.clicked.connect(lambda: self._history(True))
        row.addWidget(self.undo_button)
        row.addWidget(self.redo_button)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        footer.addWidget(cancel)
        controls.addLayout(row)
        self.controls_scroll = QScrollArea()
        self.controls_scroll.setWidgetResizable(True)
        self.controls_scroll.setMinimumWidth(270)
        self.controls_scroll.setWidget(side)
        split.addWidget(self.controls_scroll)
        self.editor = CloudTeachingWidget()
        self.region_kind.currentIndexChanged.connect(lambda *_: self.refresh())
        self.editor.box_created.connect(lambda b: self._run(lambda: self._box(b, new=True)))
        self.editor.box_changed.connect(lambda b: self._run(lambda: self._box(b, new=False)))
        split.addWidget(self.editor)
        split.setSizes([470, 880])
        hint = QLabel("Source rows are frozen. Region boxes include all XYZ points inside their "
                      "volume, including points hidden in this view. The drawn patch only seeds "
                      "the box. Train explicitly after edits; Stage prepares a draft for Apply.")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        layout.addLayout(footer)
        self.timer = QTimer(self)
        self.timer.setInterval(40)
        self.timer.timeout.connect(self.poll_training)
        if parameters.get("recipe_path"):
            self._run(lambda: self.import_recipe(recipe_path(context.project_dir,
                                parameters["recipe_path"]), parameters["sha256"]))
        else:
            self.refresh()
        if hasattr(context, "subscribe_outputs"):
            self._unsubscribe = context.subscribe_outputs(self._outputs_changed)

    def _run(self, action):
        try:
            action()
        except (ValueError, OSError, RuntimeError, KeyError, TypeError) as error:
            self.status.setText(str(error))

    def import_recipe(self, path, digest=None):
        path = Path(path)
        if path.stat().st_size > MAX_BYTES:
            raise ValueError("Recipe exceeds 64 MiB")
        recipe = load_recipe(path, sha256=digest or hashlib.sha256(path.read_bytes()).hexdigest())
        self.session.restore(recipe)
        self._source_changed()
        self.status.setText("Restored retained reference, regions, measurements and fitting bands.")

    def load_reference(self, cloud, *, capture=None):
        metadata = {"cloud_metadata": cloud.metadata, **({"capture": capture} if capture else {})}
        evidence = ReferenceEvidence(len(cloud.points), colors=cloud.colors, pixels=cloud.pixels,
            source_size=cloud.source_size,
            metadata=metadata)
        compatible = self.session.reference_cloud(cloud.points, units=cloud.units,
                                                   frame=cloud.frame, evidence=evidence)
        self._source_changed()
        self.status.setText("Frozen teaching reference captured. Train after editing. "
                            + ("Existing regions remain in this frame." if compatible else
                               "New units/frame: previous region definitions were cleared."))

    def _source_changed(self):
        evidence = self.session.reference_evidence
        self.editor.set_cloud(PointCloud(self.session.reference, self.session.units,
            self.session.frame, colors=None if evidence is None else evidence.colors,
            pixels=None if evidence is None else evidence.pixels,
            source_size=None if evidence is None else evidence.source_size))
        self.refresh()

    def _reference_context(self):
        from .qt_reference import show_reference_context

        show_reference_context(self, self.session.reference_evidence)

    def _import_reference(self):
        path, _ = QFileDialog.getOpenFileName(self, "Import calibrated reference cloud", "",
                                             "Point clouds (*.ply *.pcd *.npz)")
        if path:
            if Path(path).suffix.lower() == ".npz":
                xyz, units, frame, evidence = read_npz(path, with_evidence=True)
                # Keep the NPZ's original metadata, not a nested re-import wrapper.
                self.session.reference_cloud(xyz, units=units, frame=frame, evidence=evidence)
                self._source_changed()
                self.status.setText("Frozen reference imported. Train the current draft.")
                return
            else:
                cloud = read_cloud(Path(path), units=self.units.currentText(),
                                   frame=self.frame.text())
            self.load_reference(cloud)

    def _capture_connected_reference(self):
        packet = self.context.snapshot_input_cloud("scene")
        self.load_reference(packet.value, capture={"kind": "connected_scene",
                                                  "payload": packet.payload})
        self.status.setText("Frozen connected scene captured in its own declared frame. "
                            "An execution fixture must match this frame or be disconnected.")

    def _capture_reference(self):
        if self.session.recipe is None:
            raise ValueError("Train or import a recipe before using its completed fixture capture")
        bundle = self.context.snapshot_processed_inputs()
        scene = bundle.inputs["scene"].value
        packet = bundle.inputs.get("fixture")
        fixture = fixture_matrix(None if packet is None else packet.value,
                                 self.session.recipe, scene)
        if fixture is None and scene.frame != self.session.frame:
            raise ValueError("Completed scene needs a fixture into the retained teaching frame")
        xyz = scene.points if fixture is None else (scene.points - fixture[:3, 3]) @ fixture[:3, :3]
        capture = {"kind": "completed_scene_fixture", "source_frame": scene.frame,
                   "reference_frame": self.session.frame,
                   "reference_to_source": (np.eye(4) if fixture is None else fixture).tolist(),
                   "scene_payload": bundle.inputs["scene"].payload,
                   "fixture_payload": {} if packet is None else packet.payload}
        for name in ("snapshot_id", "block_id", "output_revision", "execution_count", "passed"):
            if hasattr(bundle, name):
                capture[name] = getattr(bundle, name)
        self.load_reference(PointCloud(xyz, self.session.units, self.session.frame,
            colors=scene.colors, pixels=scene.pixels, source_size=scene.source_size,
            metadata=scene.metadata), capture=capture)
        self.status.setText("Frozen reference replaced from one completed scene/fixture bundle "
                            "in the retained measurement frame. Train this new reference.")

    def _import_recipe(self):
        path, _ = QFileDialog.getOpenFileName(self, "Import measurement recipe", "",
                                             "Recipes (*.s3m)")
        if path:
            self.import_recipe(path)

    def _draw(self):
        if self.session.reference is None:
            raise ValueError("Load or capture a reference first")
        self.editor.mode.setCurrentIndex(self.editor.mode.findData("draw"))
        self.status.setText("Draw a planar patch or narrow line samples; orbit to inspect its box. "
                            "Line fitting does not extract an edge from a wide surface patch.")

    def _box(self, box, *, new):
        old = next((p for p in self.session.regions if p.name == box.name), None)
        region_type = LineRegion if self.region_kind.currentData() == "line" else PlaneRegion
        region = (region_type(box.name, box.minimum, box.maximum) if new else
                  replace(old, minimum=box.minimum, maximum=box.maximum))
        self.session.region(region, old_name=None if new else box.name)
        self.refresh(box.name)
        self.status.setText("Region changed. Train the current draft to update fit evidence.")

    def _current_plane(self):
        name = self.regions.currentItem().text() if self.regions.currentItem() else None
        return next((p for p in self.session.regions if p.name == name), None)

    def _remove_region(self):
        plane = self._current_plane()
        if plane:
            self.session.remove_region(plane.name)
            self.refresh()
            self.status.setText("Region and dependent measurements removed. Undo restores them.")

    def _edit_bounds(self):
        region = self._current_plane()
        if region is None:
            raise ValueError("Select a region before editing its XYZ bounds")
        dialog = RegionBoundsDialog(region, self.session.units, self.session.frame, parent=self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.session.region(dialog.value, old_name=region.name)
            self.refresh(region.name)
            self.status.setText("XYZ bounds updated. Train to update fit evidence; Undo restores "
                                "the previous volume.")

    def _rename(self):
        plane = self._current_plane()
        if plane and plane.name != self.region_name.text():
            name = self.region_name.text()
            self.session.region(replace(plane, name=name), old_name=plane.name)
            self.refresh(name)

    def _band_changed(self):
        plane = self._current_plane()
        if plane:
            tolerance = None if self.auto_band.isChecked() else self.band.value()
            if (tolerance is not None and plane.tolerance is not None
                    and self.band.value() == self._band_displayed):
                tolerance = plane.tolerance
            self.session.region(replace(plane, tolerance=tolerance), old_name=plane.name)
            self.refresh(plane.name)

    def _flip(self):
        plane = self._current_plane()
        if plane is None or not self.session.trained:
            raise ValueError("Train and select a region before flipping its normal/direction")
        trained = next(p for p in self.session.recipe.regions if p.name == plane.name)
        hint = "direction_hint" if isinstance(plane, LineRegion) else "normal_hint"
        self.session.region(replace(plane, **{hint: tuple(-np.asarray(getattr(trained, hint)))}),
                            old_name=plane.name)
        self.refresh(plane.name)

    def _select(self, *_):
        plane = self._current_plane()
        self.region_name.setText(plane.name if plane else "")
        self.bounds_button.setEnabled(plane is not None)
        self.region_summary.setText(
            (f"{'Line' if isinstance(plane, LineRegion) else 'Plane'} volume in "
             f"{self.session.units} · frame {self.session.frame}\n"
             f"Min {plane.minimum}\nMax {plane.maximum}") if plane else "Select or draw a region.")
        self.auto_band.blockSignals(True)
        self.auto_band.setChecked(plane is None or plane.tolerance is None)
        self.auto_band.blockSignals(False)
        self.band.setEnabled(plane is not None and plane.tolerance is not None)
        if plane and plane.tolerance is not None:
            self.band.setValue(plane.tolerance)
        self._band_displayed = self.band.value()
        self.band.setSuffix(" " + self.session.units)
        boxes = (CloudBox(p.name, p.minimum, p.maximum) for p in self.session.regions)
        self.editor.set_boxes(boxes, plane.name if plane else None)
        self.editor.set_segments(())
        colors = None
        if plane is not None and self.session.reference is not None:
            colors = np.tile([120, 135, 145], (len(self.session.reference), 1)).astype(np.uint8)
            colors[plane.select(self.session.reference)] = [70, 190, 245]
        self.evidence.setText("Train this draft to update fit evidence and signed normal.")
        if plane and self.session.trained:
            index = next(i for i, p in enumerate(self.session.regions) if p.name == plane.name)
            fit = self.session.result.fits[index]
            if fit.valid:
                ids = self.session.result.selections[index]
                colors[ids[fit.inliers]] = [45, 235, 100]
                colors[ids[~fit.inliers]] = [245, 65, 65]
                if isinstance(plane, LineRegion):
                    self.editor.set_segments(((fit.endpoints[0], fit.endpoints[1], (65, 175, 245),
                                               "Observed fitted span"),
                                              (fit.origin, fit.endpoints[1], (255, 85, 70),
                                               "Line +X direction")))
                else:
                    length = np.linalg.norm(np.array(plane.maximum) - plane.minimum) * .2
                    self.editor.set_datum(fit.origin, fit.normal, length)
                self.evidence.setText(f"Reference: {fit.inliers.sum():,}/{fit.count:,} inliers; "
                                      f"band {fit.tolerance:.6g} {self.session.units}. "
                                      "Reference fit evidence is not dimensional qualification.")
            else:
                self.evidence.setText(f"Reference region unavailable: {fit.status}")
        evidence = self.session.reference_evidence
        has_colors = evidence is not None and evidence.colors is not None
        self.source_colors.setEnabled(has_colors)
        source_mode = has_colors and self.source_colors.isChecked()
        self.editor.set_point_colors(None if source_mode else colors)

    def refresh(self, selected=None):
        current = self._current_plane()
        selected = selected or (current.name if current else None)
        self.regions.blockSignals(True)
        self.regions.clear()
        self.regions.addItems([p.name for p in self.session.regions])
        names = [p.name for p in self.session.regions]
        if names:
            self.regions.setCurrentRow(names.index(selected) if selected in names else 0)
        self.regions.blockSignals(False)
        i = 1
        prefix = "Line" if self.region_kind.currentData() == "line" else "Plane"
        while f"{prefix} {i}" in names:
            i += 1
        self.editor.new_box_name = f"{prefix} {i}"
        self._select()
        self.undo_button.setEnabled(self.session.can_undo)
        self.redo_button.setEnabled(self.session.can_redo)
        self.buttons["Stage recipe"].setEnabled(self.session.trained)
        self.buttons["Review trained / completed run…"].setEnabled(self.session.trained)
        self.buttons["Train / preview reference"].setEnabled(self._future is None)
        row_index = self.table.currentRow()
        self.table.blockSignals(True)
        self.table.setRowCount(len(self.session.measurements))
        rows = self.session.result.measurements if self.session.trained else ()
        for i, m in enumerate(self.session.measurements):
            value = (f"{rows[i]['value']:.6g} {rows[i]['units']}" if rows and
                     rows[i]["value"] is not None else "Unavailable" if rows else "Train to update")
            status = rows[i]["status"] if rows else "Untrained / stale"
            target = m.other or (f"Probe {m.point}" if m.point is not None else "—")
            for column, text in enumerate((m.name, m.kind, value, status, m.plane, target,
                                            self._limits(m))):
                item = QTableWidgetItem(text)
                if rows:
                    item.setToolTip(rows[i]["reason"] or "")
                self.table.setItem(i, column, item)
        self.table.resizeColumnsToContents()
        if 0 <= row_index < len(self.session.measurements):
            self.table.selectRow(row_index)
        self.table.blockSignals(False)
        self._select_measurement(focus=False)
        self._guide()
        if self.session.reference is not None:
            evidence = self.session.reference_evidence
            context = ("XYZ only; no retained source context" if evidence is None else
                       "Source RGB retained" if evidence.colors is not None else "No source RGB")
            if evidence is not None and evidence.pixels is not None:
                context += " · source pixel rows retained"
            self.identity.setText(f"{len(self.session.reference):,} retained XYZ rows · "
                                  f"{self.session.units} · frame {self.session.frame}\n"
                                  + context + "\n"
                                  + ("Trained current draft" if self.session.trained else
                                     "Untrained / edited draft; Stage is disabled"))
        self.context_button.setEnabled(self.session.reference_evidence is not None)

    def _limits(self, measurement):
        unit = "deg" if measurement.kind in ("plane_angle", "line_angle") else self.session.units
        low, high = measurement.lower, measurement.upper
        if low is None and high is None:
            return "None (value only)"
        if low is None:
            return f"<= {high:.9g} {unit}"
        if high is None:
            return f">= {low:.9g} {unit}"
        return f"{low:.9g} .. {high:.9g} {unit}"

    def _select_measurement(self, *, focus=True):
        row = self.table.currentRow()
        if not 0 <= row < len(self.session.measurements):
            self.measurement_summary.setText("Select a measurement to see its datums and limits.")
            return
        spec = self.session.measurements[row]
        kind = next(label for label, value in KINDS.items() if value == spec.kind)
        target = (f" → target {spec.other}" if spec.other else
                  f" → probe {spec.point}" if spec.point is not None else "")
        self.measurement_summary.setText(
            f"{spec.name}: {kind}. Datum / region {spec.plane}{target}. "
            f"Limits: {self._limits(spec)}. Frame {self.session.frame}. "
            "Table values use the training reference; review an independent completed run.")
        if focus:
            names = [p.name for p in self.session.regions]
            self.regions.setCurrentRow(names.index(spec.plane))

    def _guide(self):
        if self.session.reference is None:
            text = "1 · Import or capture a calibrated reference with declared units and frame."
        elif not self.session.regions:
            text = "2 · Draw plane/line regions; inspect their XYZ volumes from several views."
        elif not self.session.measurements:
            text = "3 · Add measurements, choose their datums/targets and optional limits."
        elif self._future is not None:
            text = "4 · Training frozen draft. Further edits invalidate this job."
        elif not self.session.trained:
            text = ("4 · Definitions changed. Train to refresh fits and reference values "
                    "before Stage.")
        else:
            missing = sum(m["value"] is None for m in self.session.result.measurements)
            text = (f"5 · Current trained draft; {missing} unavailable reference measurements. "
                    "Review an independent completed run, then Stage → inspector Apply.")
        self.guidance.setText(text)

    def _history(self, redo):
        self.session.redo() if redo else self.session.undo()
        self.refresh()

    def _measurement(self, edit):
        if not self.session.regions:
            raise ValueError("Draw at least one plane region first")
        spec = None
        if edit:
            index = self.table.currentRow()
            if index < 0:
                raise ValueError("Select a measurement to edit")
            spec = self.session.measurements[index]
        pick = self.editor.last_pick
        picked = None
        if pick and pick["source_identity"] == self.editor.source.identity:
            picked = self.session.reference[pick["row"]].tolist()
        names = {m.name for m in self.session.measurements}
        i = 1
        while f"Measurement {i}" in names:
            i += 1
        dialog = MeasurementDialog(self.session.regions, self.session.units, spec=spec,
                                   picked=picked, parent=self, name=f"Measurement {i}")
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.session.measurement(dialog.value, old_name=spec.name if spec else None)
            self.refresh()

    def _remove_measurement(self):
        index = self.table.currentRow()
        if index >= 0:
            self.session.remove_measurement(self.session.measurements[index].name)
            self.refresh()

    def start_training(self):
        if self._future is not None:
            raise ValueError("A bounded training job is already running")
        self._job = self.session.job()
        self._future = self._executor.submit(self._job.run)
        self.status.setText("Training a frozen draft in the background. Edits invalidate this job.")
        self.timer.start()
        self.refresh()

    def poll_training(self):
        if self._closed or self._future is None or not self._future.done():
            return
        future, job = self._future, self._job
        self._future = self._job = None
        self.timer.stop()
        try:
            if job.revision != self.session.revision or job.reference is not self.session.reference:
                future.exception()
                accepted = False
            else:
                accepted = self.session.accept(job, future.result())
            if accepted:
                unavailable = sum(m["value"] is None for m in self.session.result.measurements)
                warning = (f"{unavailable} reference values unavailable; inspect their status. "
                           if unavailable else "")
                self.status.setText("Trained draft. " + warning
                                    + "Review independent runs before Stage / Apply.")
            else:
                self.status.setText("Discarded stale result; train current draft.")
        except Exception as error:
            self.status.setText(str(error))
        self.refresh()

    def _review(self):
        from .qt_review import MeasurementReviewDialog

        recipe = self.session.staged_recipe()
        dialog = MeasurementReviewDialog(self, {}, self.context, review_only=True)
        dialog.set_trained_recipe(recipe, reference_result=self.session.result)
        self._children.append(dialog)
        dialog.show()

    def _stage(self):
        recipe = self.session.staged_recipe()
        relative = f"assets/3d_measure/{uuid.uuid4().hex}.s3m"
        path = recipe_path(self.context.project_dir, relative)
        path.parent.mkdir(parents=True, exist_ok=True)
        digest = save_recipe(path, recipe)
        self.parameters.update(recipe_path=relative, sha256=digest)
        if self.parameters.get("primary_measurement") not in {m.name for m in recipe.measurements}:
            self.parameters["primary_measurement"] = ""
        self.accept()

    def _outputs_changed(self, *_):
        self.status.setText("New graph outputs are available. The teaching reference stays frozen; "
                            "capture explicitly to replace it.")

    def done(self, result):
        if not self._closed:
            self._closed = True
            self.timer.stop()
            for child in self._children:
                child.done(0)
            if self._unsubscribe is not None:
                self._unsubscribe()
                self._unsubscribe = None
            self._executor.shutdown(wait=False, cancel_futures=True)
        super().done(result)
