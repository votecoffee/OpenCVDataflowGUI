"""A cached single-block measurement adapter for OpenCVDataflowGUI."""

import re
from pathlib import Path, PurePosixPath
from uuid import uuid4

from opencv_dataflow.core import Port, Result
from opencv_dataflow.geometry3d_common import Tool3D
from opencv_dataflow.payloads import NO_VALUE
from opencv_dataflow.pointclouds import PointCloud

from . import Measurer, load_recipe
from .completed_review import BINDING, CompletedMeasurementRecord, capture_completed
from .graphics import result_cloud
from .residuals import ResidualReview
from .specs import rigid


def recipe_path(project_dir, relative):
    if project_dir is None:
        raise ValueError("Save the project before choosing a measurement recipe.")
    if not isinstance(relative, str) or not relative:
        raise ValueError("Choose a project-relative .s3m recipe.")
    path = PurePosixPath(relative)
    if (
        path.is_absolute()
        or "\\" in relative
        or ":" in relative
        or ".." in path.parts
        or path.suffix != ".s3m"
    ):
        raise ValueError("Recipe must be a project-relative .s3m path using forward slashes.")
    root = Path(project_dir).resolve()
    target = (root / relative).resolve()
    if not target.is_relative_to(root):
        raise ValueError("Recipe resolves outside the project directory.")
    return target


def fixture_matrix(value, recipe, scene):
    if value is None:
        return None
    if (
        not isinstance(value, dict)
        or value.get("model") != "pose_3d_v1"
        or value.get("units") != recipe.units
        or value.get("units") != scene.units
        or value.get("source_frame") != recipe.frame
        or value.get("target_frame") != scene.frame
    ):
        raise ValueError("Fixture must map the recipe frame to the scene frame in matching units.")
    return rigid(value.get("source_to_target"))


class Simple3DMeasure(Tool3D):
    type_id, title = "3d.simple_measure", "Simple3DMeasure"
    subtype = "Geometric measurement"
    process_inputs_readonly = True
    parallel_safe = True
    plugin_dialog_label = "Train 3D measurements…"
    plugin_dialog_modeless = True
    plugin_review_dialog_label = "Review completed 3D measurements…"
    inputs = (
        Port("scene", "cloud"),
        Port("fixture", "data", required=False, required_when_connected=True),
    )
    outputs = (
        Port("measurements", "data"),
        Port("planes", "data"),
        Port("report", "data"),
        Port("value", "number", required=False),
        Port("count", "number"),
        Port("fit", "cloud", required=False),
        Port("lines", "data"),
        Port("residuals", "cloud", required=False),
        Port("residual_report", "data", required=False),
    )
    defaults = {
        "recipe_path": "",
        "sha256": "",
        "primary_measurement": "",
        "render_graphics": True,
        "residual_graphics": False,
    }
    parameter_help = {
        "recipe_path": "Project-relative .s3m recipe retaining reference, regions and fit bands.",
        "sha256": "SHA-256 supplied when importing/staging the trained recipe.",
        "primary_measurement": "Measurement for value; empty selects the first trained name.",
        "render_graphics": "Compose the native RGB fit cloud; disable for numerical execution.",
        "residual_graphics": "Also compose all-selected residual colors and distributions. "
        "Opt-in review work; skipped when graphics are off.",
    }
    output_help = {
        "fit": "Native flyaround: inliers/exclusions, ROI boxes, grids, datum axes and dimensions.",
        "residuals": "Optional native residual colors; scale is fixed to each taught fit band.",
        "residual_report": "Optional all-selected distributions, tails and availability.",
        "value": "Selected measurement, absent when unavailable; units are in report.",
        "planes": "Fitted plane evidence in the recipe measurement frame with declared units.",
        "lines": "Fitted line axes, observed spans, radial residuals and support evidence.",
        "report": "Values/limits, availability, fit support, bands and scene/fixture identity.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.preview_output = "fit"
        self._verified = self._measurer = None
        self._completed_review = None

    def copy_runtime_from(self, other):
        super().copy_runtime_from(other)
        self._completed_review = other._completed_review

    def reset_runtime(self):
        super().reset_runtime()
        self._completed_review = None

    def capture_completed_review(self, context):
        snapshot = getattr(context, "snapshot_processed_execution", None)
        if snapshot is None:
            raise ValueError("Completed review needs the host's paired execution-snapshot API")
        record = self._completed_review
        ports = ("report",) if record is None else record.ports
        return capture_completed(record, snapshot(output_ports=ports))

    def create_plugin_review_dialog(self, parent, context):
        from .qt_completed_review import CompletedMeasurementReviewDialog

        return CompletedMeasurementReviewDialog(
            parent, context, lambda: self.capture_completed_review(context)
        )

    def validate_parameters(self, parameters=None):
        super().validate_parameters(parameters)
        p = self.parameters if parameters is None else parameters
        recipe_path(self.project_dir, p["recipe_path"])
        if not isinstance(p["sha256"], str) or re.fullmatch("[0-9a-f]{64}", p["sha256"]) is None:
            raise ValueError("Import/stage a recipe with its SHA-256.")
        if not isinstance(p["primary_measurement"], str):
            raise ValueError("Primary measurement must be a trained name or empty.")
        if type(p["render_graphics"]) is not bool:
            raise ValueError("render_graphics must be boolean.")
        if type(p["residual_graphics"]) is not bool:
            raise ValueError("residual_graphics must be boolean.")

    def process(self, inputs):
        self._completed_review = None
        p = self.parameters
        recipe = load_recipe(
            recipe_path(self.project_dir, p["recipe_path"]),
            sha256=p["sha256"],
            cached=self._verified,
        )
        if self._verified is None or self._verified[0] != p["sha256"]:
            self._measurer = Measurer(recipe)
        self._verified = p["sha256"], recipe
        name = p["primary_measurement"] or recipe.measurements[0].name
        if name not in {m.name for m in recipe.measurements}:
            raise ValueError("Primary measurement is not defined in this recipe.")
        source = inputs["scene"]
        if not isinstance(source, PointCloud):
            raise ValueError("Connect a point cloud with declared frame and mm/m units.")
        measured = self._measurer.measure(
            source.points,
            units=source.units,
            frame=source.frame,
            fixture=fixture_matrix(inputs.get("fixture"), recipe, source),
        )
        named = {m["name"]: m for m in measured.measurements}
        primary = named[name]
        report = measured.report()
        cloud = residuals = residual_report = NO_VALUE
        if p["render_graphics"] and self.generate_graphics:
            graphics = result_cloud(measured)
            cloud = PointCloud(
                graphics.points,
                graphics.units,
                graphics.frame,
                colors=graphics.colors,
                metadata=graphics.metadata,
            )
            if p["residual_graphics"]:
                review = ResidualReview(measured)
                residual_report = review.report()
                graphics = review.cloud()
                residuals = PointCloud(
                    graphics.points,
                    graphics.units,
                    graphics.frame,
                    colors=graphics.colors,
                    metadata=graphics.metadata,
                )
        count = sum(m["value"] is not None for m in measured.measurements)
        failures = [
            f"{m['name']}: {m['reason'] or m['status']}"
            for m in measured.measurements
            if m["status"] in ("unavailable", "out_of_limits")
        ]
        limited = any(m.lower is not None or m.upper is not None for m in recipe.measurements)
        outputs = {
            "measurements": list(measured.measurements),
            "planes": report["planes"],
            "report": report,
            "value": (NO_VALUE if primary["value"] is None else primary["value"]),
            "count": count,
            "fit": cloud,
            "lines": report.get("lines", {}),
            "residuals": residuals,
            "residual_report": residual_report,
        }
        payloads = {}
        if self.run_profile.input_previews and self.run_profile.output_previews:
            record = CompletedMeasurementRecord.create(uuid4().hex, measured, outputs, p, name)
            self._completed_review = record
            payloads = {port: {BINDING: {"id": record.identifier}} for port in record.ports}
        return Result(
            outputs,
            payloads=payloads,
            passed=measured.passed,
            fail_reasons=failures,
            message=f"{count}/{len(named)} measurements available; "
            + (
                (
                    "all configured limits satisfied"
                    if limited
                    else "valid measurements; no acceptance limits configured"
                )
                if measured.passed
                else "; ".join(failures[:3])
            ),
        )

    def create_plugin_dialog(self, parent, parameters, context):
        try:
            from .qt_training import MeasurementTrainingDialog
        except ModuleNotFoundError as error:
            if error.name not in (
                "opencv_dataflow.cloud_teaching",
                "opencv_dataflow.cloud_teaching_geometry",
            ):
                raise
            from .qt_review import MeasurementReviewDialog

            dialog = MeasurementReviewDialog(parent, parameters, context)
            dialog.status.setText(
                "Update the host for native 3D graphical teaching. "
                "This older host can review/import trained recipes."
            )
            return dialog
        return MeasurementTrainingDialog(parent, parameters, context)

    def close(self):
        self._verified = self._measurer = None
        self._completed_review = None
        super().close()


def register(registry):
    registry.register(Simple3DMeasure)
