"""Deterministic bounded RANSAC with orthogonal least-squares plane refinement."""

from dataclasses import dataclass

import numpy as np

from .specs import FitSettings, finite, points


@dataclass(frozen=True)
class PlaneFit:
    status: str
    count: int
    sampled_count: int
    tolerance: float
    origin: np.ndarray | None = None
    normal: np.ndarray | None = None
    residual: np.ndarray | None = None
    inliers: np.ndarray | None = None
    trials: int = 0
    inlier_bounds: np.ndarray | None = None

    @property
    def valid(self):
        return self.status == "fit"

    def report(self):
        count = 0 if self.inliers is None else int(self.inliers.sum())
        return {
            "status": self.status, "selected_points": self.count,
            "fit_sample_points": self.sampled_count, "inlier_points": count,
            "excluded_fit_points": self.count - count,
            "inlier_fraction": count / self.count if self.count else 0.0,
            "distance_tolerance": self.tolerance, "ransac_trials": self.trials,
            "origin": None if self.origin is None else self.origin.tolist(),
            "normal": None if self.normal is None else self.normal.tolist(),
            "inlier_bounds": None if self.inlier_bounds is None else self.inlier_bounds.tolist(),
            "orthogonal_rmse": (float(np.sqrt(np.mean(self.residual[self.inliers] ** 2)))
                                if count else None),
            "inlier_residual_range": (float(np.ptp(self.residual[self.inliers]))
                                      if count else None),
            "all_selected_residual_range": (float(np.ptp(self.residual))
                                            if self.residual is not None and self.count else None),
        }


def _tls(data, hint):
    origin = data.mean(axis=0)
    _, singular, vectors = np.linalg.svd(data - origin, full_matrices=False)
    if len(singular) < 3 or singular[1] <= max(singular[0] * 1e-8, 1e-12):
        return None
    normal = vectors[-1]
    direction = np.zeros(3) if hint is None else np.asarray(hint)
    if abs(normal @ direction) <= 1e-12:
        direction = np.eye(3)[np.argmax(abs(normal))]
    if normal @ direction < 0:
        normal = -normal
    return origin, normal


def fit_plane(data, tolerance, *, settings=None, normal_hint=None):
    """Fit on a bounded subset; classify and report every selected finite point."""
    data = points(data)
    settings = FitSettings() if settings is None else settings
    if not isinstance(settings, FitSettings):
        raise ValueError("Supply FitSettings.")
    tolerance = finite(tolerance, "Plane tolerance")
    if tolerance <= 0:
        raise ValueError("Plane tolerance must be positive.")
    if normal_hint is not None:
        normal_hint = np.asarray(normal_hint, float)
        if (normal_hint.shape != (3,) or not np.isfinite(normal_hint).all()
                or np.linalg.norm(normal_hint) < 1e-12):
            raise ValueError("Normal hint requires a finite nonzero vector.")
    count = len(data)
    sample_ids = np.linspace(0, count - 1, min(count, settings.fit_sample_limit), dtype=int)
    sampled = data[sample_ids]
    failure = dict(count=count, sampled_count=len(sampled), tolerance=tolerance)
    if count < settings.min_points:
        return PlaneFit("insufficient_points", **failure)
    center = sampled.mean(axis=0)
    span = np.linalg.norm(np.ptp(sampled, axis=0))
    if not np.isfinite(span) or span <= 1e-12:
        return PlaneFit("degenerate", **failure)
    normalized = (sampled - center) / span
    distance = tolerance / span
    rng = np.random.default_rng(settings.seed)
    best, best_key, trials = None, (-1, -np.inf), 0
    required_trials = settings.max_trials
    while trials < min(settings.max_trials, required_trials):
        picks = np.stack([rng.choice(len(sampled), 3, replace=False)
                          for _ in range(min(16, settings.max_trials - trials))])
        a, b, c = normalized[picks].transpose(1, 0, 2)
        normals = np.cross(b - a, c - a)
        lengths = np.linalg.norm(normals, axis=1)
        for first, normal, length in zip(a, normals, lengths):
            trials += 1
            if length <= 1e-10:
                continue
            normal = normal / length
            residual = abs((normalized - first) @ normal)
            inliers = residual <= distance
            n = int(inliers.sum())
            key = (n, -float(np.mean(residual[inliers])) if n else -np.inf)
            if key > best_key:
                best, best_key = inliers, key
                ratio = n / len(sampled)
                if ratio >= 1:
                    required_trials = 16
                elif ratio > 0:
                    required_trials = min(required_trials, max(16, int(np.ceil(
                        np.log(.001) / np.log1p(-ratio ** 3)))))
        if best is not None and best_key[0] >= settings.min_points:
            refined = _tls(normalized[best], normal_hint)
            if refined is not None:
                origin, normal = refined
                refined_mask = abs((normalized - origin) @ normal) <= distance
                if refined_mask.sum() >= best.sum():
                    best = refined_mask
                    best_key = (int(best.sum()), -float(np.mean(abs(
                        (normalized[best] - origin) @ normal))))
    if best is None or best.sum() < settings.min_points:
        return PlaneFit("degenerate" if best is None else "consensus_failed",
                        trials=trials, **failure)
    model = None
    for _ in range(4):
        model = _tls(normalized[best], normal_hint)
        if model is None:
            return PlaneFit("degenerate", trials=trials, **failure)
        origin, normal = model
        selected = abs((normalized - origin) @ normal) <= distance
        if selected.sum() < settings.min_points or np.array_equal(selected, best):
            break
        best = selected
    origin = center + model[0] * span
    normal = model[1].copy()
    # Resolve the final plane on all selected inliers, not just RANSAC samples.
    # This keeps its origin the actual target inlier centroid for step measurements.
    stable = False
    for _ in range(12):
        residual = (data - origin) @ normal
        inliers = abs(residual) <= tolerance
        if inliers.sum() < settings.min_points:
            break
        fitted = _tls((data[inliers] - center) / span, normal_hint)
        if fitted is None:
            return PlaneFit("degenerate", trials=trials, **failure)
        origin, normal = center + fitted[0] * span, fitted[1].copy()
        updated = abs((data - origin) @ normal) <= tolerance
        if np.array_equal(updated, inliers):
            stable = True
            break
    residual = (data - origin) @ normal
    inliers = abs(residual) <= tolerance
    status = ("fit" if inliers.sum() >= settings.min_points
              and inliers.mean() >= settings.min_inlier_fraction else "consensus_failed")
    if status == "fit" and not stable:
        status = "refinement_not_stable"
    bounds = np.array([data[inliers].min(0), data[inliers].max(0)]) if inliers.any() else None
    for value in (origin, normal, residual, inliers, bounds):
        if value is None:
            continue
        value.flags.writeable = False
    return PlaneFit(status, **failure, origin=origin, normal=normal, residual=residual,
                    inliers=inliers, trials=trials, inlier_bounds=bounds)


def learn_tolerance(data, *, settings, normal_hint=None):
    """Learn reference noise once; execution always uses the stored physical band."""
    data = points(data)
    span = np.linalg.norm(np.ptp(data, axis=0)) if len(data) else 0
    if len(data) < settings.min_points or span <= 1e-12:
        raise ValueError("Automatic plane training requires a nondegenerate reference region.")
    coarse = fit_plane(data, span * .02, settings=settings, normal_hint=normal_hint)
    if not coarse.valid:
        raise ValueError(f"Reference cannot establish a plane: {coarse.status}.")
    residual = coarse.residual[coarse.inliers]
    sigma = 1.4826 * np.median(abs(residual - np.median(residual)))
    floor = max(span * 1e-6, np.finfo(float).eps * np.max(abs(data)) * 64)
    return float(max(3 * sigma, floor))
