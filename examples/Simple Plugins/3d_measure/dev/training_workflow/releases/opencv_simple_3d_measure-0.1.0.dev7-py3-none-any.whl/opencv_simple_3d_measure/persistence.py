"""Self-contained, bounded, checksummed reference recipes; no pickle."""

import hashlib
import io
import json
import os
from pathlib import Path
from tempfile import NamedTemporaryFile
from zipfile import ZIP_DEFLATED, BadZipFile, ZipFile

import numpy as np

from .measure import Recipe
from .reference import ReferenceEvidence
from .specs import MAX_POINTS, FitSettings, LineRegion, Measurement, PlaneRegion

MAX_BYTES = 64 * 1024 * 1024


def strict_json(raw):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"Duplicate JSON key: {key}")
            result[key] = value
        return result

    def invalid(value):
        raise ValueError(f"Nonfinite JSON number: {value}")

    def number(value):
        parsed = float(value)
        if not np.isfinite(parsed):
            invalid(value)
        return parsed

    return json.loads(raw, object_pairs_hook=unique, parse_constant=invalid, parse_float=number)


def read_array(raw, width, dtypes):
    stream = io.BytesIO(raw)
    version = np.lib.format.read_magic(stream)
    if version not in ((1, 0), (2, 0)):
        raise ValueError("Use NPY version 1 or 2.")
    reader = (np.lib.format.read_array_header_1_0 if version == (1, 0)
              else np.lib.format.read_array_header_2_0)
    shape, _, dtype = reader(stream)
    if (len(shape) != 2 or shape[1] != width or not 0 <= shape[0] <= MAX_POINTS
            or dtype.str not in dtypes
            or shape[0] * width * dtype.itemsize != len(raw) - stream.tell()):
        raise ValueError("Expected a bounded array of the declared type with matching bytes.")
    return np.load(io.BytesIO(raw), allow_pickle=False)


def read_xyz(raw):
    return read_array(raw, 3, ("<f4", "<f8"))


def _array_bytes(value):
    stream = io.BytesIO()
    np.save(stream, value, allow_pickle=False)
    return stream.getvalue()


def save_recipe(path, recipe):
    if not isinstance(recipe, Recipe):
        raise ValueError("Save a trained Recipe.")
    array = _array_bytes(recipe.reference)
    entries = {"reference.npy": array}
    has_flatness = any(m.kind == "minimum_zone_flatness" for m in recipe.measurements)
    evidence = recipe.reference_evidence
    version = 4 if evidence is not None else 3 if has_flatness else 2 if recipe.lines else 1
    manifest = {"version": version, **recipe.configuration(),
                "resolved_tolerances": list(recipe.tolerances),
                "reference_sha256": hashlib.sha256(array).hexdigest()}
    if recipe.lines:
        manifest["resolved_line_tolerances"] = list(recipe.line_tolerances)
    if evidence is not None:
        arrays = {}
        for name in ("colors", "pixels"):
            value = getattr(evidence, name)
            if value is not None:
                entries[name + ".npy"] = _array_bytes(value)
                arrays[name] = hashlib.sha256(entries[name + ".npy"]).hexdigest()
        manifest["reference_evidence"] = {"arrays": arrays, "source_size": evidence.source_size,
                                          "metadata": evidence.metadata,
                                          "sha256": evidence.sha256}
    entries["recipe.json"] = json.dumps(manifest, allow_nan=False, indent=2).encode("utf-8")
    if sum(len(raw) for raw in entries.values()) > MAX_BYTES:
        raise ValueError("Recipe content exceeds 64 MiB; reduce the retained source upstream.")
    path = Path(path)
    with NamedTemporaryFile(dir=path.parent, prefix=f".{path.name}.", delete=False) as temp:
        temporary = Path(temp.name)
    try:
        with ZipFile(temporary, "w", compression=ZIP_DEFLATED) as data:
            for name, raw in entries.items():
                data.writestr(name, raw)
        if temporary.stat().st_size > MAX_BYTES:
            raise ValueError("Recipe archive exceeds 64 MiB.")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_recipe(path, *, sha256=None, cached=None):
    path = Path(path)
    if path.stat().st_size > MAX_BYTES:
        raise ValueError("Recipe exceeds 64 MiB.")
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if sha256 is not None and digest != sha256:
        raise ValueError("Recipe SHA-256 mismatch; stage the intended revision.")
    if cached is not None and cached[0] == digest:
        return cached[1]
    try:
        with ZipFile(io.BytesIO(raw)) as archive:
            names = archive.namelist()
            if (not {"recipe.json", "reference.npy"}.issubset(names)
                    or len(names) != len(set(names))
                    or set(names) - {"recipe.json", "reference.npy", "colors.npy", "pixels.npy"}
                    or sum(i.file_size for i in archive.infolist()) > MAX_BYTES
                    or archive.getinfo("recipe.json").file_size > 1024 * 1024):
                raise ValueError("Unexpected/duplicate entries or oversized recipe content.")
            manifest = strict_json(archive.read("recipe.json"))
            if type(manifest["version"]) is not int or manifest["version"] not in (1, 2, 3, 4):
                raise ValueError("Unsupported measurement recipe version.")
            descriptor = manifest.get("reference_evidence")
            expected = {"recipe.json", "reference.npy"}
            if manifest["version"] == 4:
                if (not isinstance(descriptor, dict) or
                        set(descriptor) != {"arrays", "source_size", "metadata", "sha256"} or
                        not isinstance(descriptor["arrays"], dict) or
                        set(descriptor["arrays"]) - {"colors", "pixels"}):
                    raise ValueError("Invalid reference evidence descriptor.")
                expected.update(name + ".npy" for name in descriptor["arrays"])
            elif "reference_evidence" in manifest:
                raise ValueError("Reference evidence requires archive version 4.")
            if set(names) != expected:
                raise ValueError("Unexpected or missing reference evidence entries.")
            if manifest["version"] == 1 and ("lines" in manifest or
                                               "resolved_line_tolerances" in manifest):
                raise ValueError("Line recipes require archive version 2.")
            if manifest["version"] < 3 and any(m.get("kind") == "minimum_zone_flatness"
                                               for m in manifest["measurements"]):
                raise ValueError("Minimum-zone flatness recipes require archive version 3.")
            array = archive.read("reference.npy")
            if hashlib.sha256(array).hexdigest() != manifest["reference_sha256"]:
                raise ValueError("Reference checksum mismatch.")
            reference = read_xyz(array)
            evidence = None
            if descriptor is not None:
                arrays = {}
                for name, digest in descriptor["arrays"].items():
                    raw_array = archive.read(name + ".npy")
                    if hashlib.sha256(raw_array).hexdigest() != digest:
                        raise ValueError(f"Reference {name} checksum mismatch.")
                    arrays[name] = read_array(raw_array, 3 if name == "colors" else 2,
                                              ("|u1",) if name == "colors" else ("<i4",))
                evidence = ReferenceEvidence(len(reference), **arrays,
                    source_size=descriptor["source_size"], metadata=descriptor["metadata"])
                if evidence.sha256 != descriptor["sha256"]:
                    raise ValueError("Reference evidence checksum mismatch.")
        return Recipe(reference, tuple(PlaneRegion(**p) for p in manifest["planes"]),
                      tuple(Measurement(**m) for m in manifest["measurements"]),
                      tuple(manifest["resolved_tolerances"]), manifest["units"], manifest["frame"],
                      FitSettings(**manifest["settings"]),
                      lines=tuple(LineRegion(**p) for p in (manifest["lines"] if
                          manifest["version"] == 2 else manifest.get("lines", []))),
                      line_tolerances=tuple(manifest["resolved_line_tolerances"]
                          if manifest["version"] == 2 else
                          manifest.get("resolved_line_tolerances", [])),
                      reference_evidence=evidence, _source_bytes=raw)
    except (BadZipFile, KeyError, TypeError, OSError) as error:
        raise ValueError(f"Invalid measurement recipe: {error}") from error
