"""Inspect declared reflected-pattern sequences before fitting."""

import numpy as np


def pattern_rows(sequence):
    return [
        {"axis": axis, "step": step, "id": identity, "shift_rad": shift}
        for axis in ("x", "y")
        for step, (identity, shift) in enumerate(
            zip(getattr(sequence, axis).frame_ids, getattr(sequence, axis).phase_angles), 1
        )
    ]


def unavailable_observations(image, mask, ceiling):
    finite = np.isfinite(image)
    return mask & ~finite, mask & finite & (image >= ceiling)


def audit_sequence(sequence, frames, mask, ceiling, *, cancelled):
    rows = pattern_rows(sequence)
    active = int(mask.sum())
    complete = {"x": mask.copy(), "y": mask.copy()}
    for row, plane in zip(rows, frames):
        if cancelled():
            raise RuntimeError("Source audit cancelled")
        missing, clipped = unavailable_observations(plane, mask, ceiling)
        row["nonfinite"], row["ceiling"] = int(missing.sum()), int(clipped.sum())
        row["available"] = active - row["nonfinite"] - row["ceiling"]
        complete[row["axis"]] &= ~(missing | clipped)
    return {
        "active_pixels": active,
        "complete_x": int(complete["x"].sum()),
        "complete_y": int(complete["y"].sum()),
        "complete_both": int((complete["x"] & complete["y"]).sum()),
        "ceiling": ceiling,
        "rows": rows,
    }


def setup_summary(sequence):
    def optional(value, unit):
        return "unknown" if value is None else f"{value:.6g} {unit}"

    axis_lines = []
    for axis in ("x", "y"):
        pattern = getattr(sequence, axis)
        redundancy = " · no fit redundancy" if len(pattern.phase_angles) == 3 else ""
        axis_lines.append(
            f"{axis.upper()} · {len(pattern.phase_angles)} shifts · "
            f"period {optional(pattern.period_px, 'px')} · "
            f"origin {optional(pattern.origin_rad, 'rad')} · direction {pattern.direction:+d}"
            + redundancy
        )
    response = (
        "Declared linear response" if sequence.response == "linear" else "Uncalibrated code values"
    )
    return "\n".join(
        [
            *axis_lines,
            f"{response} · exposure {optional(sequence.exposure_s, 's')}",
            "Wrapped phase in radians · whole-period changes can be invisible.",
            "Metric geometry unavailable here. Reflection normals require absolute screen U/V "
            "and known camera, screen and reference plane geometry.",
        ]
    )
