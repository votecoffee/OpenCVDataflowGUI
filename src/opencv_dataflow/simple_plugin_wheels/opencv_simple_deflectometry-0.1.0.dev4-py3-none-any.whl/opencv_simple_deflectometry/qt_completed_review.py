"""Independent source/reference/pixel and recorded circular-phase comparison review."""

import json
import uuid
from pathlib import Path

from opencv_dataflow.canvas import pixmap
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from opencv_dataflow.images import ImageArray
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
)


class PixelImageView(FilmstripImageView):
    pixel_chosen = Signal(int, int)

    def __init__(self, parent):
        super().__init__(parent)
        self.source_grid = True

    def mousePressEvent(self, event):
        if (
            self.source_grid
            and event.button() == Qt.MouseButton.LeftButton
            and event.modifiers() & Qt.KeyboardModifier.ShiftModifier
        ):
            point = self.mapToScene(event.position().toPoint())
            if self.sceneRect().contains(point):
                self.pixel_chosen.emit(int(point.x()), int(point.y()))
                event.accept()
                return
        super().mousePressEvent(event)


class CompletedDeflectReviewDialog(QDialog):
    def __init__(self, parent, context, capture):
        super().__init__(parent)
        self.setWindowTitle("Completed reflected-pattern and phase-change review")
        self.resize(1360, 960)
        self.snapshot, self.selected_pixel = None, None
        self._capture, self._closed = capture, False
        layout = QVBoxLayout(self)
        actions = QHBoxLayout()
        self.capture_button = QPushButton("Capture latest completed run")
        self.capture_button.clicked.connect(self.capture_latest)
        self.export_button = QPushButton("Export frozen review…")
        self.export_button.setEnabled(False)
        self.export_button.clicked.connect(self.choose_export)
        close = QPushButton("Close review")
        close.clicked.connect(self.reject)
        for button in (self.capture_button, self.export_button, close):
            actions.addWidget(button)
        layout.addLayout(actions)
        self.identity, self.status, self.summary = (QLabel() for _ in range(3))
        for label in (self.identity, self.status, self.summary):
            label.setWordWrap(True)
            label.setTextFormat(Qt.TextFormat.PlainText)
            layout.addWidget(label)
        row = QHBoxLayout()
        self.frame, self.source, self.map = QComboBox(), QComboBox(), QComboBox()
        self.component = QComboBox()
        self.component.addItem("X", 0)
        self.component.addItem("Y", 1)
        self.source.addItem("Consumed inspection source", "source")
        self.source.addItem("Executed training reference", "reference")
        for label, widget in (
            ("Observed pattern", self.frame),
            ("Left image", self.source),
            ("Completed map", self.map),
            ("Map axis", self.component),
        ):
            row.addWidget(QLabel(label))
            row.addWidget(widget)
            widget.currentIndexChanged.connect(self.show_views)
        layout.addLayout(row)
        pixel_row = QHBoxLayout()
        self.inspect = QCheckBox("Inspect original pixel")
        self.x, self.y = QSpinBox(), QSpinBox()
        for label, widget in (("X", self.x), ("Y", self.y)):
            pixel_row.addWidget(QLabel(label))
            pixel_row.addWidget(widget)
            widget.valueChanged.connect(self.select_from_fields)
        pixel_row.insertWidget(0, self.inspect)
        self.inspect.toggled.connect(self.select_from_fields)
        focus, overview = QPushButton("Focus pixel"), QPushButton("Overview")
        focus.clicked.connect(self.focus_pixel)
        overview.clicked.connect(self.overview)
        pixel_row.addWidget(focus)
        pixel_row.addWidget(overview)
        pixel_row.addStretch()
        layout.addLayout(pixel_row)
        split = QSplitter(Qt.Orientation.Horizontal)
        self.source_view, self.map_view = PixelImageView(self), PixelImageView(self)
        self.source_view.pixel_chosen.connect(self.select_pixel)
        self.map_view.pixel_chosen.connect(self.select_pixel)
        split.addWidget(self.source_view)
        self.tabs = QTabWidget()
        split.addWidget(self.tabs)
        self.tabs.addTab(self.map_view, "Source-aligned completed map")
        self.chart_view = FilmstripImageView(self)
        self.tabs.addTab(self.chart_view, "Recorded pattern codes / circular change")
        self.details = QPlainTextEdit()
        self.details.setReadOnly(True)
        self.tabs.addTab(self.details, "Capture / settings / pixel evidence")
        layout.addWidget(split, 1)
        self.view_note = QLabel()
        self.view_note.setWordWrap(True)
        layout.addWidget(self.view_note)
        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(
            [
                "Pattern",
                "Axis",
                "Phase shift [rad]",
                "Reference code",
                "Inspection code",
                "Reference flags",
                "Inspection flags",
            ]
        )
        self.table.setMaximumHeight(180)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.itemSelectionChanged.connect(self.select_frame_row)
        layout.addWidget(self.table)
        legend = QLabel(
            "Shift-click either source-grid image to select a pixel; wheel zoom / drag pan. "
            "Comparison reasons: green comparable · gray outside reference ROI · "
            "purple reference unavailable · orange inspection unavailable · blue both unavailable. "
            "Phase-fit reason names are listed per X/Y axis. All scales are display only. "
            "Whole-period ambiguity remains; no absolute screen coordinate, slope, height or cloud."
        )
        legend.setWordWrap(True)
        layout.addWidget(legend)
        self.export_status = QLabel()
        self.export_status.setWordWrap(True)
        layout.addWidget(self.export_status)
        unsubscribe = context.subscribe_outputs(self.publication_changed)
        self.finished.connect(self.release_review)
        self.finished.connect(unsubscribe)
        self.destroyed.connect(unsubscribe)
        self.capture_latest()

    def release_review(self, *_):
        self._closed = True
        for view in (self.source_view, self.map_view, self.chart_view):
            view.set_image(QPixmap())
        self.snapshot = self._capture = None

    def publication_changed(self, revision):
        if self.snapshot is not None and not self._closed:
            self.status.setText(
                "Editor publication changed. This frozen review stays unchanged; "
                "capture latest explicitly."
            )

    def capture_latest(self):
        if self._closed:
            return
        try:
            snapshot = self._capture()
        except (ValueError, RuntimeError, KeyError) as error:
            self.status.setText(
                str(error)
                + (" Previous frozen run remains displayed." if self.snapshot is not None else "")
            )
            return
        self.snapshot, self.selected_pixel = snapshot, None
        report, p = snapshot.record.report, snapshot.provenance
        self.identity.setText(
            f"{p['block_id']} · completion {p['execution_count']} · "
            f"capture {report['capture_id']} · grid {report['pixel_grid']} · "
            f"{report['comparable_pixels']}/{report['active_pixels']} comparable pixels "
            f"({report['coverage']:.1%}) · response {report['response']} · "
            f"exposure {report['exposure_s'] if report['exposure_s'] is not None else 'UNKNOWN'} s "
            f"{'PASS' if p['passed'] else 'FAIL'} configured criterion"
        )
        self.status.setText(
            "Frozen actual X/Y patterns, executed reference/sequence/radiometry/limits "
            "and stored phase/change maps. No source/model reload, phase fitting, unwrapping, "
            "reflection solving or calibration. Whole-period ambiguity remains. "
            "Caller identity does not prove registration/synchrony. Teaching stays independent."
        )
        self.frame.blockSignals(True)
        self.frame.clear()
        for i, (axis, local, name, _) in enumerate(snapshot.frame_entries):
            self.frame.addItem(f"{i}: {axis.upper()} {name} / step {local}", i)
        self.frame.blockSignals(False)
        self.map.blockSignals(True)
        self.map.clear()
        for name in snapshot.view_names:
            if name not in ("source", "reference"):
                self.map.addItem(name.replace("_", " "), name)
        default = "overlay" if snapshot.record._output["views"] else "change_rad"
        self.map.setCurrentIndex(self.map.findData(default))
        self.map.blockSignals(False)
        for widget, maximum in ((self.x, snapshot.shape[1] - 1), (self.y, snapshot.shape[0] - 1)):
            widget.blockSignals(True)
            widget.setRange(0, maximum)
            widget.blockSignals(False)
        self.export_button.setEnabled(True)
        self.overview()

    @staticmethod
    def update_image(view, image):
        transform, fitted = view.transform(), view._fitted
        center = view.mapToScene(view.viewport().rect().center())
        view.set_image(pixmap(ImageArray(image, "rgb")))
        if not fitted:
            view.setTransform(transform)
            view._fitted = False
            view.centerOn(center)

    def select_pixel(self, x, y):
        if self.snapshot is None or self._closed:
            return
        self.snapshot.pixel((x, y))
        self.selected_pixel = (x, y)
        for widget, value in ((self.x, x), (self.y, y), (self.inspect, True)):
            widget.blockSignals(True)
            widget.setChecked(value) if widget is self.inspect else widget.setValue(value)
            widget.blockSignals(False)
        self.show_views()

    def select_from_fields(self, *_):
        if self.inspect.isChecked():
            self.select_pixel(self.x.value(), self.y.value())
        else:
            self.selected_pixel = None
            self.show_views()

    def select_frame_row(self):
        rows = self.table.selectionModel().selectedRows()
        if rows:
            self.frame.setCurrentIndex(rows[0].row())

    def show_views(self, *_):
        if self.snapshot is None or self._closed:
            return
        frame, name, component = (
            self.frame.currentData(),
            self.map.currentData(),
            self.component.currentData(),
        )
        value = self.snapshot.record._output["maps"].get(name)
        self.component.setEnabled(value is not None and value.ndim == 3)
        self.map_view.source_grid = name != "overview"
        source, source_note = self.snapshot.view(
            self.source.currentData(), frame, selected=self.selected_pixel
        )
        image, note = self.snapshot.view(name, frame, component, self.selected_pixel)
        self.update_image(self.source_view, source)
        self.update_image(self.map_view, image)
        self.view_note.setText(
            source_note
            + " · "
            + note
            + (
                " · Overview panels are display coordinates; select on source."
                if name == "overview"
                else ""
            )
        )
        if self.selected_pixel is None:
            self.summary.setText(
                "Overview. Select an original source pixel for recorded X/Y fit/change and "
                "pattern-code evidence. Phase is wrapped; availability is not accuracy."
            )
            self.table.setRowCount(0)
            self.chart_view.set_image(QPixmap())
            self.details.setPlainText(
                json.dumps(
                    self.snapshot.report(frame=frame, view=name, component=component),
                    indent=2,
                    allow_nan=False,
                )
            )
            return
        pixel = self.snapshot.pixel(self.selected_pixel)
        self.summary.setText(
            f"Pixel {self.selected_pixel}: {pixel['reason_name']} · "
            f"reference X/Y {pixel['reference_reason_names']} · "
            f"inspection X/Y {pixel['test_reason_names']} · "
            f"circular X/Y {pixel['change_rad']} rad · magnitude {pixel['magnitude_rad']} rad · "
            f"configured exceedance {pixel['changed']} · whole-period ambiguity remains"
        )
        rows = self.snapshot.observations(self.selected_pixel)
        self.table.blockSignals(True)
        self.table.setRowCount(len(rows))
        keys = (
            "frame_id",
            "axis",
            "phase_angle_rad",
            "reference_code",
            "test_code",
            "reference_flags",
            "test_flags",
        )
        for row, item in enumerate(rows):
            for prefix in ("reference", "test"):
                item[prefix + "_flags"] = [
                    flag
                    for key, flag in (("nonfinite", "nonfinite"), ("ceiling", "at ceiling"))
                    if item[prefix + "_" + key]
                ]
            for column, key in enumerate(keys):
                value = item[key]
                text = "Unavailable" if value is None else str(value)
                cell = QTableWidgetItem(text)
                cell.setToolTip(text)
                self.table.setItem(row, column, cell)
        self.table.selectRow(frame)
        self.table.resizeColumnsToContents()
        self.table.blockSignals(False)
        self.update_image(self.chart_view, self.snapshot.chart(self.selected_pixel))
        self.details.setPlainText(
            json.dumps(
                self.snapshot.report(self.selected_pixel, frame, name, component),
                indent=2,
                allow_nan=False,
            )
        )

    def focus_pixel(self):
        if self.snapshot is None or self.selected_pixel is None:
            return
        if self.map.currentData() == "overview":
            self.map.setCurrentIndex(self.map.findData("change_rad"))
        self.tabs.setCurrentIndex(0)
        for view in (self.source_view, self.map_view):
            view.actual_size()
            view.zoom(4)
            view.centerOn(*self.selected_pixel)

    def overview(self):
        self.selected_pixel = None
        self.inspect.blockSignals(True)
        self.inspect.setChecked(False)
        self.inspect.blockSignals(False)
        self.show_views()
        for view in (self.source_view, self.map_view, self.chart_view):
            view.fit_image()

    def export_to(self, directory):
        if self.snapshot is None:
            raise ValueError("Capture a completed phase comparison before exporting")
        target = self.snapshot.export(
            directory,
            self.selected_pixel,
            self.frame.currentData(),
            self.map.currentData(),
            self.component.currentData(),
        )
        self.export_status.setText(f"Exported frozen review: {target}")
        return target

    def choose_export(self):
        parent = QFileDialog.getExistingDirectory(self, "Choose parent for a new frozen review")
        if parent:
            try:
                self.export_to(Path(parent) / f"deflect-review-{uuid.uuid4().hex[:12]}")
            except (ValueError, OSError) as error:
                self.export_status.setText(str(error))
