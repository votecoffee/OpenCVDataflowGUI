"""Bounded explicit capture manifests and preserved standalone phase comparison results."""

import argparse
import json
from pathlib import Path

import numpy as np
from opencv_simple_fringe_scan.cli import load_plane, strict_json
from opencv_simple_fringe_scan.phase import PhaseSettings
from PIL import Image

from .core import AxisSequence, Capture, CompiledReference, Sequence, positive


def read_capture(path, *, manifest_bytes=None):
    path = Path(path)
    if path.stat().st_size > 1024 * 1024:
        raise ValueError("Capture manifest exceeds 1 MiB")
    raw = path.read_bytes() if manifest_bytes is None else manifest_bytes
    if len(raw) > 1024 * 1024:
        raise ValueError("Capture manifest exceeds 1 MiB")
    data = strict_json(raw)
    if not isinstance(data, dict) or data.get("schema") != "simple_deflectometry_capture/v1":
        raise ValueError("Use an explicit simple_deflectometry_capture/v1 manifest")
    if data.get("source_encoding") not in ("linear", "srgb", "uncalibrated_codes"):
        raise ValueError("Declare linear/srgb encoding or uncalibrated-code diagnostics")
    scale = positive(data.get("input_scale"), 1e12, "source code scale")
    axes = data["sequence"]["axes"]
    if set(axes) != {"x", "y"}:
        raise ValueError("Declare exactly X and Y phase axes")
    sequence = Sequence(
        *(AxisSequence(**axes[key]) for key in ("x", "y")),
        **{key: data["sequence"][key] for key in ("setup_id", "pixel_grid", "exposure_s")},
        response=data["sequence"].get("response", "linear"),
    )
    if (data["source_encoding"] == "uncalibrated_codes") != (
        sequence.response == "uncalibrated_codes"
    ):
        raise ValueError("Uncalibrated codes need explicit matching sequence/encoding diagnostics")
    frames = data["frames"]
    if not isinstance(frames, list) or len(frames) != sum(
        len(getattr(sequence, key).frame_ids) for key in ("x", "y")
    ):
        raise ValueError("Provide every declared X/Y observation once in order")
    expected = [*sequence.x.frame_ids, *sequence.y.frame_ids]
    if [row.get("id") for row in frames] != expected:
        raise ValueError("Observed frame IDs/order differ from the declared X then Y sequence")
    planes, shape = [], None
    for row in frames:
        plane = load_plane(path.parent / row["image"], data.get("channel", "gray"))
        if shape is None:
            shape = plane.shape
            if plane.size * len(frames) > 16_000_000:
                raise ValueError("Capture exceeds 16 million total X/Y samples")
        elif plane.shape != shape:
            raise ValueError("Phase observations must share the declared source grid")
        codes = plane.astype(np.float32) / scale
        if np.any(np.isfinite(codes) & ((codes < 0) | (codes > 1))):
            raise ValueError("Source scale must produce normalized 0..1 codes")
        if data["source_encoding"] == "srgb":
            codes = np.where(codes <= 0.04045, codes / 12.92, ((codes + 0.055) / 1.055) ** 2.4)
        planes.append(codes)
    mask = load_plane(path.parent / data["mask"], "gray") if data.get("mask") else None
    n = len(sequence.x.frame_ids)
    capture = Capture(
        sequence, data["capture_id"], np.stack(planes[:n]), np.stack(planes[n:]), mask
    )
    return capture, data


def write_result(output, result, *, source_records=None):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    np.savez_compressed(output / "maps.npz", **result["maps"])
    report = dict(result["report"])
    if source_records is not None:
        report["source_records"] = source_records
    (output / "report.json").write_bytes(
        (json.dumps(report, indent=2, allow_nan=False) + "\n").encode()
    )
    for key, rgb in result["views"].items():
        Image.fromarray(rgb).save(output / (key + ".png"))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reference", type=Path)
    parser.add_argument("capture", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--minimum-coverage", type=float, default=0.95)
    parser.add_argument("--maximum-change-rad", type=float)
    parser.add_argument("--no-graphics", action="store_true")
    args = parser.parse_args(argv)
    if args.output.exists():
        raise FileExistsError(args.output)
    reference, ref_data = read_capture(args.reference)
    capture, test_data = read_capture(args.capture)
    settings = PhaseSettings(**ref_data.get("phase_settings", {}))
    result = CompiledReference(reference, phase=settings).compare(
        capture,
        minimum_coverage=args.minimum_coverage,
        maximum_change_rad=args.maximum_change_rad,
        graphics=not args.no_graphics,
    )
    write_result(
        args.output,
        result,
        source_records=dict(
            reference=ref_data.get("provenance", {}), test=test_data.get("provenance", {})
        ),
    )
    print(
        json.dumps(
            {
                key: result["report"][key]
                for key in ("capture_id", "comparable_pixels", "coverage", "passed")
            }
        )
    )
    return 0


if __name__ == "__main__":
    main()
