"""Private normalized teaching sources and bounded checksummed .sdef assets."""

import hashlib
import io
import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from tempfile import NamedTemporaryFile
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np
from opencv_simple_fringe_scan.cli import strict_json
from opencv_simple_fringe_scan.phase import PhaseSettings
from opencv_simple_fringe_scan.recipe import LIMIT, array_bytes, json_copy, read_array

from .cli import read_capture
from .core import AxisSequence, Capture, Sequence


def sequence_record(record):
    if not isinstance(record, dict) or set(record) != {
        "x",
        "y",
        "setup_id",
        "pixel_grid",
        "exposure_s",
        "response",
    }:
        raise ValueError("Declare the complete retained X/Y sequence and radiometry")
    return Sequence(
        **{**record, "x": AxisSequence(**record["x"]), "y": AxisSequence(**record["y"])}
    )


def limits(minimum_coverage, maximum_change_rad):
    if type(minimum_coverage) not in (int, float) or not (
        np.isfinite(minimum_coverage) and 0 <= minimum_coverage <= 1
    ):
        raise ValueError("Minimum comparable coverage must be in 0..1")
    if maximum_change_rad is not None and (
        type(maximum_change_rad) not in (int, float)
        or not np.isfinite(maximum_change_rad)
        or not 0 < maximum_change_rad <= np.sqrt(2) * np.pi
    ):
        raise ValueError("Bound the phase-change limit in radians, or disable it")


@dataclass(frozen=True, init=False)
class DeflectRecipe:
    reference: Capture = field(repr=False)
    phase: PhaseSettings
    minimum_coverage: float
    maximum_change_rad: float | None
    _notes: bytes = field(repr=False)
    _source_bytes: bytes | None = field(default=None, repr=False, compare=False)

    def __init__(
        self,
        reference,
        *,
        phase=None,
        minimum_coverage=0.95,
        maximum_change_rad=None,
        notes=None,
        _source_bytes=None,
    ):
        if not isinstance(reference, Capture) or not reference.mask.any():
            raise ValueError("Retain a source capture with a nonempty inspection region")
        if reference.x_images.dtype.str not in ("<f4", "<f8") or (
            reference.y_images.dtype.str not in ("<f4", "<f8")
        ):
            raise ValueError("Retain normalized float32/float64 X/Y source arrays")
        phase = PhaseSettings() if phase is None else phase
        if not isinstance(phase, PhaseSettings):
            raise ValueError("Use validated phase-fit settings")
        if notes is not None and not isinstance(notes, dict):
            raise ValueError("Retain a JSON metadata object")
        limits(minimum_coverage, maximum_change_rad)
        object.__setattr__(
            self,
            "reference",
            Capture(
                reference.sequence,
                reference.capture_id,
                reference.x_images,
                reference.y_images,
                reference.mask,
            ),
        )
        object.__setattr__(self, "phase", phase)
        object.__setattr__(self, "minimum_coverage", minimum_coverage)
        object.__setattr__(self, "maximum_change_rad", maximum_change_rad)
        object.__setattr__(self, "_source_bytes", _source_bytes)
        object.__setattr__(
            self, "_notes", json.dumps(json_copy(notes or {}), allow_nan=False).encode()
        )

    @property
    def notes(self):
        return strict_json(self._notes)


def import_reference(path, **settings):
    capture, data = read_capture(path)
    settings.setdefault("phase", PhaseSettings(**data.get("phase_settings", {})))
    notes = dict(
        source_provenance=data.get("provenance", {}),
        reference_import=dict(
            manifest_name=Path(path).name,
            source_encoding=data["source_encoding"],
            input_scale=data["input_scale"],
            source_names=[Path(row["image"]).name for row in data["frames"]],
        ),
    )
    return DeflectRecipe(capture, notes=notes, **settings)


def save_recipe(path, recipe):
    path = Path(path)
    if not isinstance(recipe, DeflectRecipe) or path.suffix != ".sdef":
        raise ValueError("Save a validated .sdef retained reference recipe")
    if path.exists():
        raise FileExistsError("Preserve existing training; choose a new recipe filename")
    members = {
        key + ".npy": array_bytes(getattr(recipe.reference, key))
        for key in ("x_images", "y_images", "mask")
    }
    document = dict(
        schema="simple_deflectometry_recipe/v1",
        sequence=asdict(recipe.reference.sequence),
        capture_id=recipe.reference.capture_id,
        shape=list(recipe.reference.mask.shape),
        phase=asdict(recipe.phase),
        minimum_coverage=recipe.minimum_coverage,
        maximum_change_rad=recipe.maximum_change_rad,
        notes=recipe.notes,
        sha256={key: hashlib.sha256(raw).hexdigest() for key, raw in members.items()},
    )
    members["recipe.json"] = (json.dumps(document, indent=2, allow_nan=False) + "\n").encode()
    if len(members["recipe.json"]) > 2 * 1024 * 1024 or sum(map(len, members.values())) > LIMIT:
        raise ValueError("Retained recipe exceeds its bounded metadata/160 MiB budget")
    with NamedTemporaryFile(dir=path.parent, prefix="." + path.name, delete=False) as stream:
        temporary = Path(stream.name)
    try:
        with ZipFile(temporary, "w", compression=ZIP_DEFLATED) as archive:
            for name, raw in members.items():
                archive.writestr(name, raw)
        if temporary.stat().st_size > LIMIT:
            raise ValueError("Retained recipe exceeds 160 MiB")
        os.link(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_recipe(path, *, sha256=None):
    path = Path(path)
    if path.stat().st_size > LIMIT:
        raise ValueError("Retained recipe exceeds 160 MiB")
    raw = path.read_bytes()
    if len(raw) > LIMIT or sha256 is not None and hashlib.sha256(raw).hexdigest() != sha256:
        raise ValueError("Recipe archive checksum/size differs")
    with ZipFile(io.BytesIO(raw)) as archive:
        infos = archive.infolist()
        names = [row.filename for row in infos]
        if set(names) != {"recipe.json", "x_images.npy", "y_images.npy", "mask.npy"} or (
            len(names) != 4
            or any(row.flag_bits & 1 for row in infos)
            or sum(row.file_size for row in infos) > LIMIT
            or archive.getinfo("recipe.json").file_size > 2 * 1024 * 1024
        ):
            raise ValueError("Invalid bounded retained recipe members")
        document = strict_json(archive.read("recipe.json"))
        if document.get("schema") != "simple_deflectometry_recipe/v1":
            raise ValueError("Unsupported deflectometry recipe schema")
        sequence = sequence_record(document["sequence"])
        shape = document["shape"]
        if (
            not isinstance(shape, list)
            or len(shape) != 2
            or any(type(v) is not int or not 2 <= v <= 16384 for v in shape)
            or (
                shape[0] * shape[1] * (len(sequence.x.frame_ids) + len(sequence.y.frame_ids))
                > 16_000_000
            )
        ):
            raise ValueError("Invalid bounded retained source dimensions")
        if set(document["sha256"]) != set(names) - {"recipe.json"}:
            raise ValueError("Retained array manifest differs")
        arrays = {}
        for key in ("x_images", "y_images", "mask"):
            body = archive.read(key + ".npy")
            if hashlib.sha256(body).hexdigest() != document["sha256"][key + ".npy"]:
                raise ValueError("Retained array checksum differs")
            array = read_array(body, stack=key != "mask")
            expected = (
                tuple(shape)
                if key == "mask"
                else (len(getattr(sequence, key[0]).frame_ids), *shape)
            )
            if array.shape != expected:
                raise ValueError("Retained array shape differs from its sequence")
            arrays[key] = array
    return DeflectRecipe(
        Capture(sequence, document["capture_id"], **arrays),
        phase=PhaseSettings(**document["phase"]),
        minimum_coverage=document["minimum_coverage"],
        maximum_change_rad=document["maximum_change_rad"],
        notes=document["notes"],
        _source_bytes=raw,
    )
