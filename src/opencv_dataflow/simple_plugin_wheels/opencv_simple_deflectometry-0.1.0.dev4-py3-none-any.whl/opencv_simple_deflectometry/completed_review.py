"""Exact completed reflected-pattern/reference evidence without fitting or reflection solving."""

import copy
import hashlib
import json
from dataclasses import asdict, dataclass, field
from functools import cached_property
from pathlib import Path
from uuid import uuid4

import cv2
import numpy as np
from opencv_dataflow.payloads import NO_VALUE
from opencv_simple_fringe_scan.completed_review import describe, finite, freeze, json_bytes, same
from opencv_simple_fringe_scan.phase import PHASE_REASONS
from opencv_simple_fringe_scan.render import COLORS, panel, scalar

from .core import REASONS
from .render import signed

BINDING = "deflect_completed_review"
CAPTURE_FIELDS = ("schema", "sequence", "capture_id", "x_images", "y_images", "mask", "metadata")


def consumed_fields(bundle):
    return {key: bundle.get(key) for key in CAPTURE_FIELDS}


@dataclass(frozen=True)
class CompletedDeflectRecord:
    identifier: str
    report_json: bytes
    parameters_json: bytes
    scalar_json: bytes
    ports: tuple
    ignored_fields: tuple
    _recipe: object = field(repr=False, compare=False)
    _capture: dict = field(repr=False, compare=False)
    _output: dict = field(repr=False, compare=False)
    _outputs: dict = field(repr=False, compare=False)
    _manifest: bytes | None = field(repr=False, compare=False)

    @property
    def report(self):
        return json.loads(self.report_json)

    @property
    def parameters(self):
        return json.loads(self.parameters_json)

    def __deepcopy__(self, memo):
        return self


def retain_completed(block, recipe, capture, output, outputs, manifest):
    if not (block.run_profile.input_previews and block.run_profile.output_previews):
        return {}
    emitted = {key: value for key, value in outputs.items() if value is not NO_VALUE}
    scalars = {
        key: value
        for key, value in emitted.items()
        if key in ("coverage", "count", "changed_pixels")
    }
    record = CompletedDeflectRecord(
        uuid4().hex,
        json_bytes(outputs["report"]),
        json_bytes(block.parameters),
        json_bytes(scalars),
        tuple(emitted),
        tuple(str(key) for key in capture if key not in CAPTURE_FIELDS),
        recipe,
        consumed_fields(capture),
        output,
        emitted,
        manifest,
    )
    block._completed_review = record
    return {key: {BINDING: {"id": record.identifier}} for key in record.ports}


class CompletedDeflectReview:
    plugin_review_dialog_label = "Review completed patterns and phase changes…"

    def copy_runtime_from(self, other):
        super().copy_runtime_from(other)
        self._completed_review = other._completed_review

    def reset_runtime(self):
        super().reset_runtime()
        self._completed_review = None

    def close(self):
        self._completed_review = None
        super().close()

    def capture_completed_review(self, context):
        snapshot = getattr(context, "snapshot_processed_execution", None)
        if snapshot is None:
            raise ValueError("Completed review needs the host's paired execution-snapshot API")
        record = self._completed_review
        inputs = (
            ()
            if record is None or record.parameters["source"] == "capture manifest"
            else ("capture",)
        )
        try:
            bundle = snapshot(
                input_ports=inputs, output_ports=("report",) if record is None else record.ports
            )
        except ValueError as error:
            if (
                record is not None
                and not inputs
                and "Processed inputs are unavailable" in str(error)
            ):
                raise ValueError(
                    "Update the host for empty paired-input selections; "
                    "this manifest run consumed no wired inputs"
                ) from error
            raise
        return capture_completed(record, bundle)

    def create_plugin_review_dialog(self, parent, context):
        from .qt_completed_review import CompletedDeflectReviewDialog

        return CompletedDeflectReviewDialog(
            parent, context, lambda: self.capture_completed_review(context)
        )


@dataclass(frozen=True)
class CompletedDeflectCapture:
    record: CompletedDeflectRecord
    _provenance: dict = field(repr=False, compare=False)

    @property
    def provenance(self):
        return copy.deepcopy(self._provenance)

    @property
    def recipe_bytes(self):
        return self.record._recipe._source_bytes

    @property
    def shape(self):
        return self.record._capture["x_images"].shape[1:]

    @cached_property
    def frame_entries(self):
        seq = self.record._recipe.reference.sequence
        return tuple(
            (axis, index, name, getattr(seq, axis).phase_angles[index])
            for axis in ("x", "y")
            for index, name in enumerate(getattr(seq, axis).frame_ids)
        )

    @property
    def frame_count(self):
        return len(self.frame_entries)

    def frame(self, index):
        if type(index) is not int or not 0 <= index < self.frame_count:
            raise ValueError("Choose a recorded observed-pattern frame")
        return self.frame_entries[index]

    @property
    def view_names(self):
        return ("source", "reference", *self.record._output["maps"], "overlay", "overview")

    @cached_property
    def _description(self):
        return describe(self.record._capture)

    @cached_property
    def _map_description(self):
        return describe(self.record._output["maps"])

    def pixel(self, selected):
        if (
            not isinstance(selected, tuple)
            or len(selected) != 2
            or any(type(v) is not int for v in selected)
        ):
            raise ValueError("Choose one original (x, y) source pixel")
        x, y = selected
        if not 0 <= y < self.shape[0] or not 0 <= x < self.shape[1]:
            raise ValueError("Choose a pixel inside the recorded source grid")
        maps = self.record._output["maps"]
        values = {key: finite(value[y, x]) for key, value in maps.items()}
        values["reason_name"] = REASONS[int(maps["reason"][y, x])]
        for prefix in ("reference", "test"):
            values[prefix + "_reason_names"] = [
                PHASE_REASONS[int(v)] for v in maps[prefix + "_reason"][y, x]
            ]
        return dict(x=x, y=y, whole_period_ambiguity=True, **values)

    def observations(self, selected):
        self.pixel(selected)
        x, y = selected
        recipe = self.record._recipe
        rows = []
        for index, (axis, local, name, angle) in enumerate(self.frame_entries):
            ref = float(getattr(recipe.reference, axis + "_images")[local, y, x])
            test = float(self.record._capture[axis + "_images"][local, y, x])
            rows.append(
                dict(
                    index=index,
                    axis=axis,
                    frame_id=name,
                    phase_angle_rad=angle,
                    reference_code=finite(ref),
                    test_code=finite(test),
                    reference_nonfinite=not np.isfinite(ref),
                    test_nonfinite=not np.isfinite(test),
                    reference_ceiling=bool(ref >= recipe.phase.input_ceiling),
                    test_ceiling=bool(test >= recipe.phase.input_ceiling),
                )
            )
        return rows

    def view(self, name, frame=0, component=0, selected=None):
        axis, local, identifier, _ = self.frame(frame)
        if name not in self.view_names:
            raise ValueError("Choose a recorded source or map view")
        if type(component) is not int or component not in (0, 1):
            raise ValueError("Choose X or Y map component")
        if selected is not None:
            self.pixel(selected)
        maps, views = self.record._output["maps"], self.record._output["views"]
        if name == "overview":
            if name in views:
                return np.array(
                    views[name], copy=True
                ), "Exact emitted overview; display coordinates"
            keys = ("source", "change_rad", "reason")
            return np.hstack(
                [
                    panel(
                        self.view(key, frame, component)[0],
                        key,
                        "Frozen evidence; display coordinates",
                    )
                    for key in keys
                ]
            ), "Review-only panels"
        if name in ("source", "reference"):
            raw = (
                self.record._capture[axis + "_images"]
                if name == "source"
                else getattr(self.record._recipe.reference, axis + "_images")
            )[local]
            gray = np.rint(np.clip(np.nan_to_num(raw, nan=0), 0, 1) * 255).astype(np.uint8)
            image = np.repeat(gray[:, :, None], 3, axis=2)
            image[~np.isfinite(raw)] = (75, 35, 85)
            contours, _ = cv2.findContours(
                self.record._recipe.reference.mask.astype(np.uint8),
                cv2.RETR_LIST,
                cv2.CHAIN_APPROX_SIMPLE,
            )
            cv2.drawContours(image, contours, -1, (30, 210, 230), 1)
            note = "Consumed inspection" if name == "source" else "Executed training reference"
            note += f" {identifier}; normalized code display 0..1; cyan reference ROI"
        elif name == "overlay":
            if name not in views:
                return np.full(
                    (*self.shape, 3), (65, 65, 70), np.uint8
                ), "Overlay was not emitted (graphics off)"
            image, note = (
                views[name],
                "Exact emitted overlay; mean source context / stored change/reasons",
            )
        else:
            value = maps[name]
            if value.ndim == 3:
                value = value[:, :, component]
            if name.endswith("reason"):
                image = COLORS[value]
                note = "Stored " + (
                    "comparison reasons" if name == "reason" else "phase-fit reasons"
                )
            elif name.endswith("valid"):
                image = np.full((*self.shape, 3), (75, 35, 85), np.uint8)
                image[value] = (40, 205, 95)
                note = "Stored availability: green valid / purple unavailable; not accuracy"
            elif name in ("changed", "near_wrap_boundary"):
                image = np.full((*self.shape, 3), (110, 110, 115), np.uint8)
                image[value] = (245, 55, 65) if name == "changed" else (255, 220, 20)
                image[~maps["valid"]] = (75, 35, 85)
                note = "Stored " + name + "; gray false / color true / purple unavailable"
                if name == "changed" and self.record.report["maximum_change_rad"] is None:
                    note += "; change criterion DISABLED"
            elif name == "change_rad":
                image, note = (
                    signed(value, np.pi),
                    "Stored signed circular change: blue -pi / white 0 / red +pi radians",
                )
            else:
                maximum = (
                    2 * np.pi
                    if name.endswith("wrapped")
                    else np.sqrt(2) * np.pi
                    if name == "magnitude_rad"
                    else 0.5
                    if name.endswith("amplitude")
                    else 0.3
                    if name.endswith("relative_rms")
                    else 1
                )
                image = scalar(value, maximum, cyclic=name.endswith("wrapped"))
                units = (
                    "rad"
                    if name.endswith("wrapped") or name == "magnitude_rad"
                    else "normalized / relative"
                )
                note = (
                    f"Stored {name}[{'XY'[component]}], {units}; "
                    f"fixed display 0..{maximum:.5g}; purple nonfinite"
                )
        image = np.array(image, copy=True)
        if selected is not None:
            cv2.drawMarker(image, selected, (255, 220, 20), cv2.MARKER_CROSS, 13, 1)
        return image, note

    def chart(self, selected):
        rows, pixel = self.observations(selected), self.pixel(selected)
        image = np.full((390, 1100, 3), 245, np.uint8)
        for row in rows:
            x = round(35 + (row["index"] + 0.5) * 680 / len(rows))
            for offset, key, color in (
                (-3, "reference_code", (40, 170, 80)),
                (3, "test_code", (45, 115, 230)),
            ):
                value = row[key]
                if value is None:
                    cv2.drawMarker(
                        image, (x + offset, 295), (150, 50, 180), cv2.MARKER_TILTED_CROSS, 7, 1
                    )
                else:
                    cv2.line(
                        image, (x + offset, 290), (x + offset, round(290 - 215 * value)), color, 3
                    )
            cv2.putText(
                image,
                str(row["index"]),
                (x - 5, 316),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.35,
                (25, 25, 25),
                1,
            )
        center, scale = np.array([915, 190]), 36.0
        for axis in np.eye(2):
            a, b = center - axis * np.pi * scale, center + axis * np.pi * scale
            cv2.line(image, tuple(a.astype(int)), tuple(b.astype(int)), (100, 100, 105), 1)
        limit = self.record.report["maximum_change_rad"]
        if limit is not None:
            cv2.circle(image, tuple(center), round(limit * scale), (170, 170, 175), 1)
        if pixel["valid"]:
            delta = np.asarray(pixel["change_rad"])
            end = center + delta * (scale, -scale)
            color = (240, 60, 65) if pixel["changed"] else (40, 170, 80)
            cv2.arrowedLine(
                image, tuple(center), tuple(np.rint(end).astype(int)), color, 2, tipLength=0.15
            )
            cv2.circle(image, tuple(np.rint(end).astype(int)), 3, color, -1)
        else:
            cv2.drawMarker(image, tuple(center), (150, 50, 180), cv2.MARKER_TILTED_CROSS, 17, 2)
        lines = (
            (12, 27, "Recorded codes: green reference / blue inspection; fixed display 0..1"),
            (760, 47, "Stored circular X/Y vector [rad]"),
            (760, 331, "Axes -pi..pi; gray configured limit"),
            (
                12,
                360,
                f"Pixel {selected}: {pixel['reason_name']}; magnitude {pixel['magnitude_rad']} rad",
            ),
            (
                12,
                382,
                "Whole-period ambiguity remains. No new fit, slope or height reconstruction.",
            ),
        )
        for x, y, text in lines:
            cv2.putText(
                image, text, (x, y), cv2.FONT_HERSHEY_SIMPLEX, 0.43, (25, 25, 25), 1, cv2.LINE_AA
            )
        return image

    def report(self, selected=None, frame=0, view="reason", component=0):
        self.frame(frame)
        recipe = self.record._recipe
        return dict(
            schema="simple_deflectometry_completed_review/v1",
            execution_binding=self.record.identifier,
            completed_result=self.record.report,
            executed_parameters=self.record.parameters,
            executed_configuration=dict(
                sequence=asdict(recipe.reference.sequence),
                reference_capture_id=recipe.reference.capture_id,
                reference_mask=describe(recipe.reference.mask),
                phase=asdict(recipe.phase),
                minimum_coverage=recipe.minimum_coverage,
                maximum_change_rad=recipe.maximum_change_rad,
                notes=recipe.notes,
            ),
            consumed_capture=copy.deepcopy(self._description),
            map_arrays=copy.deepcopy(self._map_description),
            ignored_capture_fields=list(self.record.ignored_fields),
            provenance=self.provenance,
            selected_pixel=None if selected is None else self.pixel(selected),
            selected_observations=[] if selected is None else self.observations(selected),
            selected_frame=frame,
            selected_view=view,
            selected_component=component,
            emitted_views=list(self.record._output["views"]),
            manifest_sha256=None
            if self.record._manifest is None
            else hashlib.sha256(self.record._manifest).hexdigest(),
            geometry_scope=(
                "Wrapped phase/reference comparison only; "
                "no absolute screen U/V, normal, slope, height or cloud"
            ),
            source_scope=(
                "Exact normalized consumed native arrays; "
                "original encoded camera-image bytes unavailable"
            ),
            identity_scope=(
                "Caller setup/grid/sequence/radiometry/tickets do not prove "
                "registration, synchrony or physical accuracy"
            ),
            diagnostic_scope="Stored diagnostics only; no per-frame fitted prediction/residual",
            whole_period_ambiguity=True,
            phase_fitting_reexecuted=False,
            unwrapping_reexecuted=False,
            reflection_solving_reexecuted=False,
            calibration_changed=False,
            capture_reloaded=False,
            recipe_reloaded=False,
            training_changed=False,
        )

    def export(self, directory, selected=None, frame=0, view="reason", component=0):
        document = self.report(selected, frame, view, component)
        chosen, note = self.view(view, frame, component, selected)
        if self.recipe_bytes is None:
            raise ValueError("Original executed recipe bytes are unavailable")
        target = Path(directory)
        target.mkdir(parents=True, exist_ok=False)
        (target / "executed_recipe.sdef").write_bytes(self.recipe_bytes)
        document["exported_recipe_sha256"] = hashlib.sha256(self.recipe_bytes).hexdigest()
        if self.record._manifest is not None:
            (target / "consumed_manifest.json").write_bytes(self.record._manifest)
        declarations = []

        def native(value):
            if isinstance(value, np.ndarray):
                name = f"capture_array_{len(declarations):03d}.npy"
                np.save(target / name, value, allow_pickle=False)
                declarations.append(name)
                return dict(array_file=name, **describe(value))
            if isinstance(value, dict):
                return {key: native(item) for key, item in value.items()}
            if isinstance(value, (list, tuple)):
                return [native(item) for item in value]
            return describe(value)

        (target / "capture_data.json").write_bytes(
            json.dumps(native(self.record._capture), indent=2, allow_nan=False).encode() + b"\n"
        )
        for axis in ("x", "y"):
            np.save(
                target / f"reference_{axis}_images.npy",
                getattr(self.record._recipe.reference, axis + "_images"),
                allow_pickle=False,
            )
        np.save(
            target / "reference_mask.npy", self.record._recipe.reference.mask, allow_pickle=False
        )
        for name, value in self.record._output["maps"].items():
            np.save(target / f"map_{name}.npy", value, allow_pickle=False)
        for name, value in self.record._output["views"].items():
            np.save(target / f"emitted_{name}.npy", value, allow_pickle=False)
        images = dict(
            source=self.view("source", frame, selected=selected)[0],
            reference=self.view("reference", frame, selected=selected)[0],
            selected_view=chosen,
            overview=self.view("overview", frame)[0],
        )
        if selected is not None:
            images["observations"] = self.chart(selected)
        assessment = np.hstack(
            (
                panel(images["source"], "Consumed pattern", "Source grid / cyan reference ROI"),
                panel(chosen, view, note),
                panel(
                    self.view("reason")[0],
                    "Recorded comparability",
                    "Unknown reference/test stays unavailable",
                ),
            )
        )
        report = self.record.report
        banner = np.full((76, assessment.shape[1], 3), 28, np.uint8)
        exposure = report["exposure_s"] if report["exposure_s"] is not None else "UNKNOWN"
        texts = (
            f"{'PASS' if report['passed'] else 'FAIL'} configured criterion | "
            f"{report['capture_id']} | {report['comparable_pixels']}/{report['active_pixels']} "
            f"comparable | pixel {selected}",
            f"Response {report['response']} | exposure {exposure} s | "
            f"change limit {report['maximum_change_rad']} rad | "
            f"stored exceeded pixels {report['changed_pixels']}",
            "WRAPPED PHASE ONLY: whole-period ambiguity; no physical slope/height/cloud",
        )
        for i, text in enumerate(texts):
            cv2.putText(
                banner,
                text.encode("ascii", errors="replace").decode()[:175],
                (10, 21 + 22 * i),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.45,
                (235, 235, 235),
                1,
                cv2.LINE_AA,
            )
        legend = np.full((30, assessment.shape[1], 3), 28, np.uint8)
        for i, label in enumerate(REASONS):
            x = 10 + i * 275
            cv2.rectangle(legend, (x, 8), (x + 10, 19), COLORS[i].tolist(), -1)
            cv2.putText(
                legend,
                label.replace("_", " "),
                (x + 15, 18),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.34,
                (225, 225, 225),
                1,
            )
        images["assessment"] = np.vstack((banner, assessment, legend))
        for name, image in images.items():
            okay, png = cv2.imencode(".png", image[:, :, ::-1])
            if not okay:
                raise ValueError("Cannot encode frozen deflectometry review")
            (target / f"{name}.png").write_bytes(png.tobytes())
        (target / "review.json").write_bytes(
            json.dumps(document, indent=2, allow_nan=False).encode() + b"\n"
        )
        return target


def capture_completed(record, bundle):
    if record is None:
        raise ValueError(
            "No retained completed phase comparison; execute in Debug before reviewing"
        )
    if set(bundle.outputs) != set(record.ports) or any(
        bundle.outputs[key].payload.get(BINDING, {}).get("id") != record.identifier
        for key in record.ports
    ):
        raise ValueError("Completed capture/model/result changed; capture latest explicitly")
    if json_bytes(bundle.outputs["report"].value) != record.report_json:
        raise ValueError("Completed report changed")
    scalars = {
        key: packet.value
        for key, packet in bundle.outputs.items()
        if key in ("coverage", "count", "changed_pixels")
    }
    if json_bytes(scalars) != record.scalar_json:
        raise ValueError("Completed coverage/count/change criterion changed")
    for key in ("image", "maps", "overlay", "overview"):
        if key in record.ports and not same(record._outputs[key], bundle.outputs[key].value):
            raise ValueError("Completed raw map/image evidence changed")
    if record.parameters["source"] == "connected capture":
        if not same(record._capture, consumed_fields(bundle.inputs["capture"].value)):
            raise ValueError("Completed connected capture changed")
    provenance = dict(
        snapshot_id=bundle.snapshot_id,
        block_id=bundle.block_id,
        execution_count=bundle.execution_count,
        output_revision=bundle.output_revision,
        passed=bool(bundle.passed),
        score=bundle.score,
        message=bundle.message,
        inputs={key: copy.deepcopy(packet.payload) for key, packet in bundle.inputs.items()},
        outputs={key: copy.deepcopy(packet.payload) for key, packet in bundle.outputs.items()},
    )
    return CompletedDeflectCapture(freeze(record), provenance)
