"""Frozen jaw teaching captures and revision-bound previews, independent of Qt."""

import copy
from dataclasses import dataclass, field, replace

import numpy as np

from .jaw import JawPlanner, corners, tool_boxes, transform
from .jaw_specs import JawRecipe, PartInstance, acquisition_id, frozen
from .specs import Camera, depth_array, rigid

REFERENCE = "jaw_training_preview_v1"


def instance_record(instance, recipe):
    result = dict(
        model="part_instance_v1",
        id=instance.identifier,
        accepted=instance.accepted,
        capture_id=instance.capture_id,
        pose=dict(
            model="pose_3d_v1",
            units="m",
            source_frame=recipe.part.frame,
            target_frame=recipe.bin.camera.frame,
            source_to_target=instance.camera_from_part.tolist(),
        ),
    )
    if instance.label_id is not None:
        result["label_id"] = instance.label_id
    return result


@dataclass(frozen=True)
class JawCapture:
    depth: np.ndarray = field(repr=False, compare=False)
    instances: tuple
    capture_id: str
    bin_to_camera: np.ndarray = field(repr=False, compare=False)
    labels: np.ndarray | None = field(default=None, repr=False, compare=False)
    identity: dict = field(default_factory=dict, compare=False)

    def __post_init__(self):
        acquisition_id(self.capture_id)
        instances = tuple(self.instances)
        if (
            not 1 <= len(instances) <= 32
            or any(not isinstance(i, PartInstance) for i in instances)
            or any(i.capture_id != self.capture_id for i in instances)
            or len({i.identifier for i in instances}) != len(instances)
        ):
            raise ValueError("Preview needs 1..32 unique current accepted/rejected part poses")
        depth = np.asarray(self.depth)
        if depth.ndim != 2 or depth.size > 2_000_000 or depth.dtype.kind not in "uf":
            raise ValueError("Freeze a bounded numeric axial-depth plane")
        object.__setattr__(self, "depth", frozen(depth))
        object.__setattr__(self, "instances", instances)
        object.__setattr__(self, "bin_to_camera", rigid(self.bin_to_camera))
        object.__setattr__(self, "identity", copy.deepcopy(self.identity))
        if self.labels is not None:
            labels = np.asarray(self.labels)
            if (
                labels.shape != depth.shape
                or labels.dtype.kind not in "iu"
                or np.any(labels < 0)
                or np.any(labels > 2**31 - 1)
            ):
                raise ValueError("Preview labels must be matching nonnegative integer IDs")
            labels = np.array(labels, dtype=np.int32, copy=True)
            labels.flags.writeable = False
            object.__setattr__(self, "labels", labels)


def freeze_inputs(recipe, inputs, *, identity=None):
    camera = inputs.get("camera")
    if camera is not None and Camera.from_record(camera) != recipe.bin.camera:
        raise ValueError("Preview camera differs from the retained setup; import its calibration")
    depth = inputs["depth"]
    if hasattr(depth, "units") and (depth.units != "m" or recipe.bin.depth_scale != 1):
        raise ValueError("Unit-bearing depth must be meters with retained scale 1")
    records = inputs["part_instances"]
    if not isinstance(records, list) or not 1 <= len(records) <= 32:
        raise ValueError("Preview needs 1..32 explicit part_instance_v1 records")
    instances = tuple(
        PartInstance.from_record(
            item, part_frame=recipe.part.frame, camera_frame=recipe.bin.camera.frame
        )
        for item in records
    )
    pose = inputs.get("bin_pose")
    if pose is None:
        pose = recipe.bin.bin_to_camera
    else:
        if (
            not isinstance(pose, dict)
            or pose.get("model") != "pose_3d_v1"
            or pose.get("units") != "m"
            or pose.get("source_frame") != recipe.bin.frame
            or pose.get("target_frame") != recipe.bin.camera.frame
        ):
            raise ValueError("Preview bin pose must map the retained bin frame to camera in m")
        pose = pose["source_to_target"]
    return JawCapture(
        depth_array(depth, recipe.bin.camera),
        instances,
        inputs["capture_id"],
        pose,
        inputs.get("instances"),
        identity or {},
    )


def retain_reference(recipe, capture):
    notes = copy.deepcopy(recipe.notes)
    notes[REFERENCE] = dict(
        capture_id=capture.capture_id,
        part_instances=[instance_record(i, recipe) for i in capture.instances],
        identity=copy.deepcopy(capture.identity),
        scope="Frozen teaching capture; publication identity does not prove exposure synchrony",
    )
    return replace(
        recipe,
        bin=replace(
            recipe.bin,
            reference_depth=capture.depth,
            reference_instances=capture.labels,
            reference_rgb=None,
            bin_to_camera=capture.bin_to_camera,
        ),
        notes=notes,
    )


def reference_capture(recipe):
    record = recipe.notes.get(REFERENCE)
    if record is None:
        return None
    return freeze_inputs(
        recipe,
        dict(
            depth=recipe.bin.reference_depth,
            part_instances=record["part_instances"],
            capture_id=record["capture_id"],
            instances=recipe.bin.reference_instances,
        ),
        identity=record.get("identity", {}),
    )


class JawTeachingSession:
    def __init__(self):
        self.recipe = self.result = None
        self.revision, self.preview_revision = 0, -1
        self._undo = []

    @property
    def ready(self):
        return self.recipe is not None and self.preview_revision == self.revision

    def load(self, recipe):
        if not isinstance(recipe, JawRecipe):
            raise TypeError("Load a validated JawRecipe")
        self.recipe, self.result = recipe, None
        self.revision += 1
        self.preview_revision = -1
        self._undo.clear()

    def change(self, **values):
        if self.recipe is None:
            raise ValueError("Import a retained jaw setup first")
        candidate = replace(self.recipe, **values)
        self._undo.append(self.recipe)
        self._undo = self._undo[-32:]
        self.recipe = candidate
        self.revision += 1

    def undo(self):
        if self._undo:
            self.recipe = self._undo.pop()
            self.revision += 1

    def job(self, capture):
        if self.recipe is None or not isinstance(capture, JawCapture):
            raise ValueError("Retain CAD geometry and freeze a depth/pose capture first")
        return self.revision, self.recipe, capture

    def accept(self, job, result):
        if job[0] != self.revision or job[1] is not self.recipe:
            return False
        self.result, self.preview_revision = result, self.revision
        return True

    def staged(self):
        if not self.ready:
            raise ValueError("Preview the current draft before Stage; prior results are stale")
        return self.recipe


def run_preview(job, cancelled=lambda: False):
    capture = job[2]
    return JawPlanner(job[1]).plan(
        capture.depth,
        capture.instances,
        capture_id=capture.capture_id,
        bin_to_camera=capture.bin_to_camera,
        instance_labels=capture.labels,
        cancelled=cancelled,
    )


def grasp_segments(recipe, grasp, *, sweeps=True):
    """Derived overlays in the canonical CAD frame; never added to picked source rows."""
    s, frame = recipe.settings, grasp.part_from_grasp
    segments = []

    def box(lo, hi, color):
        pts = transform(corners(lo, hi), frame)
        for i in range(8):
            for bit in (1, 2, 4):
                if i < i ^ bit:
                    segments.append((pts[i], pts[i ^ bit], color, ""))

    if sweeps:
        opening = max(s.minimum_opening, grasp.span + 2 * s.opening_margin)
        for _, lo, hi in tool_boxes(grasp.span, opening, s):
            box(lo, hi, (75, 150, 240))
    z = s.finger_length - s.pad_height / 2
    for sign in (-1, 1):
        x = sorted((sign * grasp.span / 2, sign * (grasp.span / 2 + s.finger_thickness)))
        box(
            [x[0], -s.finger_width / 2, -s.pad_height / 2],
            [x[1], s.finger_width / 2, z],
            (80, 240, 110),
        )
    box(
        [-s.palm_width / 2, -s.palm_depth / 2, z],
        [s.palm_width / 2, s.palm_depth / 2, z + s.palm_height],
        (80, 240, 110),
    )
    tcp = frame @ recipe.grasp_from_tcp
    for axis, color in enumerate(((255, 85, 70), (80, 245, 100), (75, 160, 255))):
        segments.append(
            (tcp[:3, 3], tcp[:3, 3] + tcp[:3, axis] * 0.012, color, "TCP " + "XYZ"[axis])
        )
    center = frame[:3, 3]
    segments.append(
        (center, center + frame[:3, 2] * s.pregrasp_distance, (245, 210, 60), "+Z retract")
    )
    contacts = transform(np.array([[-grasp.span / 2, 0, 0], [grasp.span / 2, 0, 0]]), frame)
    segments.append((*contacts, (245, 210, 60), "Taught contacts"))
    for point in contacts:
        for axis in np.eye(3):
            segments.append((point - axis * 0.0008, point + axis * 0.0008, (255, 210, 60), ""))
    return segments
