"""Read-only physical setup guidance and atomic bin-volume editing."""

import numpy as np
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QGridLayout,
    QLabel,
    QLineEdit,
    QVBoxLayout,
)

from .specs import vector


def bin_summary(recipe):
    valid = (np.isfinite(recipe.reference_depth) & (recipe.reference_depth > 0)
             & (recipe.reference_depth <= 1e9 / recipe.depth_scale))
    source = f"{np.count_nonzero(valid):,}/{valid.size:,} valid reference depth pixels"
    size = tuple(float(b - a) for a, b in zip(recipe.minimum, recipe.maximum))
    origin = tuple(float(v) for v in recipe.bin_to_camera[:3, 3])
    up = tuple(float(v) for v in recipe.bin_to_camera[:3, 2])
    return (
        f"{recipe.units} · bin frame {recipe.frame} → camera {recipe.camera.frame}\n"
        f"{source}; missing pixels stay unknown. "
        f"Depth scale {recipe.depth_scale:.12g} {recipe.units}/stored sample.\n"
        f"Camera {recipe.camera.image_size[0]}×{recipe.camera.image_size[1]}; "
        f"fx/fy {recipe.camera.matrix[0][0]:.9g}/{recipe.camera.matrix[1][1]:.9g} px. "
        f"Bin origin in camera {origin} {recipe.units}; "
        f"bin +Z in camera {up}.\n"
        f"Bin min {recipe.minimum}; max {recipe.maximum}; size {size} {recipe.units}. "
        "Floor is minimum Z, +Z is up and the top is open.\n"
        "The retained bin-to-camera transform defines this frame; setup does not "
        "estimate camera calibration, validate a robot workcell or qualify a grasp."
    )


class BinBoundsDialog(QDialog):
    def __init__(self, recipe, *, parent=None):
        super().__init__(parent)
        self.value = None
        self.setWindowTitle("Edit bin XYZ bounds")
        layout = QVBoxLayout(self)
        identity = QLabel(f"{recipe.units} · bin frame {recipe.frame}\n"
                          "Floor = minimum Z; top is open. Coordinates do not change the frame.")
        identity.setWordWrap(True)
        layout.addWidget(identity)
        grid = QGridLayout()
        layout.addLayout(grid)
        grid.addWidget(QLabel("Axis"), 0, 0)
        grid.addWidget(QLabel("Minimum"), 0, 1)
        grid.addWidget(QLabel("Maximum"), 0, 2)
        self.minimum, self.maximum = [], []
        for i, axis in enumerate("XYZ"):
            grid.addWidget(QLabel(axis), i + 1, 0)
            for column, values, fields in ((1, recipe.minimum, self.minimum),
                                           (2, recipe.maximum, self.maximum)):
                field = QLineEdit(repr(values[i]))
                field.setMinimumWidth(150)
                fields.append(field)
                grid.addWidget(field, i + 1, column)
        self.status = QLabel("All six bounds update together. Cancel preserves the old volume.")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                                   QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Update bin")
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _accept(self):
        try:
            low = vector(tuple(float(field.text()) for field in self.minimum))
            high = vector(tuple(float(field.text()) for field in self.maximum))
            if np.any(np.asarray(high) <= low):
                raise ValueError("Bin maximum must exceed minimum on each axis; +Z is up")
        except ValueError as error:
            self.status.setText(str(error))
            return
        self.value = low, high
        self.accept()
