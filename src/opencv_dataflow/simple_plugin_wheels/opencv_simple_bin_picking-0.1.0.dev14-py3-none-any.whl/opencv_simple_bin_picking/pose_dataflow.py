"""Small explicit report converter; provider ML/CAD dependencies are not imported."""

from opencv_dataflow.core import Port, Result
from opencv_dataflow.geometry3d_common import Tool3D
from opencv_dataflow.parameter_validation import ValidationError

from .pose_instances import adapt_instances
from .specs import label


class SimplePartInstances(Tool3D):
    type_id, title, subtype = (
        "3d.simple_part_instances",
        "Simple locator → part instances",
        "Bin picking",
    )
    process_inputs_readonly = parallel_safe = preview_safe = True
    inputs = (
        Port("locator_report", "data"),
        Port("capture_id", "text"),
        Port("locator_capture_id", "text", required=False, required_when_connected=True),
        Port("label_ids", "data", required=False, required_when_connected=True),
    )
    outputs = (Port("part_instances", "data"), Port("count", "integer"), Port("report", "data"))
    defaults = dict(
        part_frame="part", camera_frame="camera", instance_prefix="part", allow_legacy_capture=False
    )
    parameter_help = {
        "part_frame": "Exact original CAD frame retained by the locator and jaw recipe.",
        "camera_frame": "Locator target must already be this calibrated depth-camera frame.",
        "instance_prefix": "Current-acquisition names; GDRNPP appends detection IDs.",
        "allow_legacy_capture": "Enable an explicit source capture input for reports without IDs.",
    }
    input_help = {
        "locator_report": "Supported locator report; raw cohort scores cannot accept a pose.",
        "capture_id": "Current depth acquisition identity; must match the locator capture.",
        "locator_capture_id": "Explicit legacy locator acquisition identity, not inferred here.",
        "label_ids": "Optional mapping of every emitted instance name to a label-image ID.",
    }
    output_help = {
        "part_instances": "Accepted poses in m; one part for a FoundationPose masked instance.",
        "report": "Conversion decisions; empty conversion means no accepted part.",
    }

    def validate_parameters(self, parameters=None):
        super().validate_parameters(parameters)
        values = self.parameters if parameters is None else parameters
        for name in ("part_frame", "camera_frame", "instance_prefix"):
            try:
                label(values[name])
                if name == "instance_prefix":
                    label(values[name] + "-32")
            except ValueError as error:
                raise ValidationError(str(error), name) from error
        if type(values["allow_legacy_capture"]) is not bool:
            raise ValidationError("Legacy capture binding must be boolean", "allow_legacy_capture")

    def process(self, inputs):
        records, report = adapt_instances(
            inputs["locator_report"],
            capture_id=inputs["capture_id"],
            **self.parameters,
            locator_capture_id=inputs.get("locator_capture_id"),
            label_ids=inputs.get("label_ids"),
        )
        return Result(
            dict(part_instances=records, count=len(records), report=report),
            passed=True,
            message=f"Converted {len(records)} accepted proposals; no grasp qualification",
        )


def register(registry):
    registry.register(SimplePartInstances)
