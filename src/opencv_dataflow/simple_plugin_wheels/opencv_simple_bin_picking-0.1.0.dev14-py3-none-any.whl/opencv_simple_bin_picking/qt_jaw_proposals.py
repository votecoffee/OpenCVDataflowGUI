"""Bounded worker and native cloud review before explicitly adding CAD suggestions."""

from concurrent.futures import CancelledError, ThreadPoolExecutor
from threading import Event

from opencv_dataflow.cloud_viewer import CloudViewer
from opencv_dataflow.pointclouds import PointCloud
from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from .jaw_proposals import proposal_cloud, propose_contacts


class ContactProposalDialog(QDialog):
    def __init__(self, parent, recipe, retract):
        super().__init__(parent)
        self.recipe, self.retract = recipe, retract
        self.result, self.selected = None, ()
        self._closed, self._future = False, None
        self._cancel = Event()
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="jaw-contacts")
        self.setWindowTitle("Suggest CAD contacts · review before adding")
        self.resize(1350, 850)
        layout = QVBoxLayout(self)
        self.status = QLabel(
            "Searching opposing CAD patches with current gripper settings. "
            "Model checks only; current pose and measured scene are not checked."
        )
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        split = QSplitter()
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["Suggestion", "Model status", "Left pad", "Right pad", "Span mm", "Reasons"]
        )
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.itemSelectionChanged.connect(self.review)
        split.addWidget(self.table)
        self.viewer = CloudViewer(None, self)
        self.viewer.setWindowFlags(Qt.WindowType.Widget)
        self.viewer.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, False)
        split.addWidget(self.viewer)
        layout.addWidget(split, 1)
        layout.addWidget(
            QLabel(
                "Gray: CAD · yellow: source contacts · green/red: supported/missing pad tests · "
                "magenta: CAD collisions · blue: sweeps · RGB: TCP axes"
            )
        )
        actions = QHBoxLayout()
        self.add_button = QPushButton("Add selected to training draft")
        self.add_button.setEnabled(False)
        self.add_button.clicked.connect(self.choose)
        actions.addWidget(self.add_button)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        actions.addWidget(cancel)
        layout.addLayout(actions)
        self.timer = QTimer(self)
        self.timer.setInterval(30)
        self.timer.timeout.connect(self.poll)
        self._future = self.pool.submit(
            propose_contacts, recipe, retract, cancelled=self._cancel.is_set
        )
        self.timer.start()

    def poll(self):
        if self._closed or self._future is None or not self._future.done():
            return
        future, self._future = self._future, None
        self.timer.stop()
        try:
            result = future.result()
            if self._cancel.is_set():
                raise CancelledError()
            self.result = result
            self.table.blockSignals(True)
            self.table.setRowCount(len(result.proposals))
            for row, p in enumerate(result.proposals):
                values = (
                    p.grasp.name,
                    "Reviewable" if p.reviewable else "Rejected",
                    f"{p.contact_sides[0]:.1%}",
                    f"{p.contact_sides[1]:.1%}",
                    f"{p.grasp.span * 1000:.3f}",
                    ", ".join(p.reasons),
                )
                for column, value in enumerate(values):
                    self.table.setItem(row, column, QTableWidgetItem(value))
            self.table.blockSignals(False)
            self.table.resizeColumnsToContents()
            self.status.setText(
                f"{sum(p.reviewable for p in result.proposals)} reviewable / "
                f"{len(result.proposals)} displayed; {result.verified} bounded model checks. "
                "Select rows to inspect and explicitly add. These are not accepted runtime grasps."
            )
            if result.proposals:
                self.table.selectRow(0)
            else:
                self.status.setText(
                    "No opposing CAD contact pair was found for this retract preference. "
                    "Review the surface normals, gripper dimensions and taught retract direction."
                )
        except CancelledError:
            self.status.setText("Cancelled; no suggestions added.")
        except Exception as error:
            self.status.setText(str(error))

    def review(self):
        rows = sorted({index.row() for index in self.table.selectionModel().selectedRows()})
        if self.result is None or not rows:
            self.add_button.setEnabled(False)
            return
        proposals = self.result.proposals
        self.add_button.setEnabled(
            all(proposals[i].reviewable for i in rows) and len(self.recipe.grasps) + len(rows) <= 32
        )
        graphic = proposal_cloud(self.recipe, proposals[rows[0]])
        self.viewer.set_cloud(
            PointCloud(
                graphic.points, "m", graphic.frame, colors=graphic.colors, metadata=graphic.metadata
            )
        )

    def choose(self):
        if not self.add_button.isEnabled():
            return
        rows = sorted({index.row() for index in self.table.selectionModel().selectedRows()})
        self.selected = tuple(self.result.proposals[i] for i in rows)
        self.accept()

    def done(self, result):
        if not self._closed:
            self._closed = True
            self._cancel.set()
            self.timer.stop()
            self.pool.shutdown(wait=False, cancel_futures=True)
            self.viewer.orbit_timer.stop()
            self.viewer.timer.stop()
        super().done(result)
