"""Independent native fly-around review of finished suction and CAD-jaw evidence."""

import json
import uuid
from pathlib import Path

import numpy as np
from opencv_dataflow.canvas import pixmap
from opencv_dataflow.cloud_viewer import CloudViewer
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from opencv_dataflow.images import ImageArray
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
)


class CompletedPickingReviewDialog(CloudViewer):
    def __init__(self, parent, context, capture):
        super().__init__(None, parent)
        self.resize(1320, 1040)
        self.setWindowTitle("Completed bin-picking evidence")
        self.snapshot = None
        self._capture, self._closed = capture, False
        self.selected_candidate = None
        self.input_dialogs = []
        actions = QHBoxLayout()
        self.capture_button = QPushButton("Capture latest completed run")
        self.capture_button.clicked.connect(self.capture_latest)
        self.export_button = QPushButton("Export frozen review…")
        self.export_button.setEnabled(False)
        self.export_button.clicked.connect(self.choose_export)
        self.inputs_button = QPushButton("Review captured images…")
        self.inputs_button.clicked.connect(self.show_inputs)
        focus, overview, close = (
            QPushButton(text) for text in ("Focus candidate", "Overview", "Close review")
        )
        focus.clicked.connect(self.focus_candidate)
        overview.clicked.connect(self.overview)
        close.clicked.connect(self.reject)
        for button in (
            self.capture_button,
            self.inputs_button,
            focus,
            overview,
            self.export_button,
            close,
        ):
            actions.addWidget(button)
        self.layout().insertLayout(0, actions)
        self.identity, self.status, self.summary = (QLabel() for _ in range(3))
        for label in (self.identity, self.status, self.summary):
            label.setWordWrap(True)
            label.setTextFormat(Qt.TextFormat.PlainText)
        self.layout().insertWidget(1, self.identity)
        self.layout().insertWidget(2, self.status)
        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(
            [
                "Candidate",
                "Decision",
                "Geometric score",
                "Contact fraction",
                "Clearance",
                "Collision points",
                "Unknown samples",
                "Reasons",
            ]
        )
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setMaximumHeight(145)
        self.table.itemSelectionChanged.connect(self.select_row)
        self.layout().insertWidget(3, self.table)
        self.mode = QComboBox()
        self.mode.currentIndexChanged.connect(self.show_selection)
        self.layout().insertWidget(4, self.mode)
        self.layer_grid = QGridLayout()
        self.layers = {}
        self.layout().insertLayout(5, self.layer_grid)
        self.layout().insertWidget(6, self.summary)
        details_toggle = QCheckBox("Show recorded candidate, limits and evidence details")
        self.details = QPlainTextEdit()
        self.details.setReadOnly(True)
        self.details.setMaximumHeight(150)
        self.details.hide()
        details_toggle.toggled.connect(self.details.setVisible)
        self.layout().insertWidget(7, details_toggle)
        self.layout().insertWidget(8, self.details)
        legend = QLabel(
            "Plan: green eligible · red rejected · orange unknown · magenta measured/CAD collision "
            "witnesses · RGB TCP axes; selected cup is yellow. Fit samples: green supported · "
            "magenta contradiction · blue occluded · orange unknown · yellow ambiguous · purple "
            "label mismatch. Tool/CAD/TCP/fit/sweeps are derived geometry; unknown queries are not "
            "free-space observations. Overview limits drawing; the table keeps every candidate. "
            "Geometric scores are not success probabilities or physical/robot qualification."
        )
        legend.setWordWrap(True)
        self.layout().addWidget(legend)
        self.export_status = QLabel()
        self.export_status.setWordWrap(True)
        self.layout().addWidget(self.export_status)
        self.finished.connect(self.release_review)
        unsubscribe = context.subscribe_outputs(self.publication_changed)
        self.finished.connect(unsubscribe)
        self.destroyed.connect(unsubscribe)
        self.capture_latest()

    def release_review(self, *_):
        self._closed = True
        self.orbit_timer.stop()
        self.timer.stop()
        for dialog in self.input_dialogs:
            dialog.close()
        self.input_dialogs.clear()
        self.image.clear()
        self._rendered = self.cloud = self.snapshot = self._capture = None

    def publication_changed(self, revision):
        if self.snapshot is not None and not self._closed:
            self.status.setText(
                "Editor publication changed. This frozen review stays unchanged; "
                "capture latest explicitly."
            )

    def capture_latest(self):
        if self._closed:
            return
        try:
            snapshot = self._capture()
        except (ValueError, RuntimeError, KeyError) as error:
            self.status.setText(
                str(error)
                + (" Previous frozen run remains displayed." if self.snapshot is not None else "")
            )
            return
        self.snapshot, self.selected_candidate = snapshot, None
        p, report = snapshot.provenance, snapshot.record.report
        self.identity.setText(
            f"{snapshot.record.kind} · {p['block_id']} · completion {p['execution_count']} · "
            f"{report['units']} / {report['frame']} · "
            f"recipe {snapshot.record.parameters['sha256'][:16]} · "
            f"declared capture {report.get('capture_id', 'not supplied')}"
        )
        diagnostic = snapshot.report()["diagnostic_arrays"]
        self.status.setText(
            "Frozen completed inputs, executed recipe and candidate decisions. No planning, "
            "collision checks, depth projection or recipe reload. Training stays unchanged. "
            f"Retained pose-fit groups: {diagnostic['pose_fit']}; mesh-fit groups: "
            f"{diagnostic['mesh_fit']}. Missing diagnostic arrays remain unavailable."
        )
        self.mode.blockSignals(True)
        self.mode.clear()
        self.mode.addItem("Candidate / contact / clearance evidence", "plan")
        self.mode.addItem("All retained measured first returns", "observations")
        for name in ("pose_fit", "mesh_fit"):
            if diagnostic[name]:
                self.mode.addItem(f"Retained {name.replace('_', ' ')} diagnostics", name)
        self.mode.blockSignals(False)
        for box in self.layers.values():
            self.layer_grid.removeWidget(box)
            box.deleteLater()
        self.layers = {}
        for i, name in enumerate(snapshot.layers):
            box = QCheckBox(name.replace("_", " ").capitalize())
            box.setChecked(True)
            box.toggled.connect(self.show_selection)
            self.layers[name] = box
            self.layer_grid.addWidget(box, i // 6, i % 6)
        self.table.blockSignals(True)
        self.table.clearSelection()
        self.table.setRowCount(len(report["candidates"]))
        for row, item in enumerate(report["candidates"]):
            values = (
                item["id"],
                item["status"],
                f"{item['score']:.5g}",
                item.get("contact_fraction"),
                item.get("clearance_status"),
                item.get("collision_points", len(item.get("collision_rows", []))),
                item.get("unknown_sample_count", len(item.get("unknown_samples", []))),
                ", ".join(item["reasons"]),
            )
            for column, value in enumerate(values):
                cell = QTableWidgetItem("Unavailable" if value is None else str(value))
                cell.setToolTip(cell.text())
                cell.setData(Qt.ItemDataRole.UserRole, item["id"])
                self.table.setItem(row, column, cell)
        self.table.resizeColumnsToContents()
        self.table.blockSignals(False)
        self.export_button.setEnabled(True)
        self.inputs_button.setEnabled(bool(snapshot.input_names))
        self.show_selection()

    def select_candidate(self, identity):
        if identity is None:
            self.table.clearSelection()
            self.selected_candidate = None
            self.show_selection()
            return
        self.snapshot.candidate(identity)
        for row in range(self.table.rowCount()):
            if self.table.item(row, 0).data(Qt.ItemDataRole.UserRole) == identity:
                self.table.selectRow(row)
                self.select_row()
                return

    def select_row(self):
        if self.snapshot is None:
            return
        rows = self.table.selectionModel().selectedRows()
        self.selected_candidate = (
            self.table.item(rows[0].row(), 0).data(Qt.ItemDataRole.UserRole) if rows else None
        )
        self.show_selection()

    def display_layers(self):
        return tuple(name for name, box in self.layers.items() if box.isChecked())

    def show_selection(self, *_):
        if self.snapshot is None or self._closed:
            return
        mode = self.mode.currentData()
        for name, box in self.layers.items():
            available = name not in ("pose_fit", "mesh_fit") or bool(
                self.snapshot.report()["diagnostic_arrays"][name]
            )
            box.setEnabled(mode == "plan" and available)
        candidate = self.snapshot.candidate(self.selected_candidate)
        self.summary.setText(
            f"{len(self.snapshot.record.report['candidates'])} recorded candidates · "
            f"{len(self.snapshot._result.picks)} eligible alternatives"
            if candidate is None
            else f"Candidate {candidate['id']} · {candidate['status']} · geometric score "
            f"{candidate['score']:.5g} · " + (", ".join(candidate["reasons"]) or "eligible")
        )
        self.details.setPlainText(
            json.dumps(
                dict(
                    candidate=candidate,
                    executed_configuration=self.snapshot.recipe.configuration(),
                    evidence_scope=self.snapshot.report()["unknown_scope"],
                ),
                indent=2,
                allow_nan=False,
            )
        )
        self.set_cloud(
            self.snapshot.display_cloud(self.selected_candidate, self.display_layers(), mode)
        )

    def focus_candidate(self):
        if self.snapshot is None:
            return
        if self.selected_candidate is None:
            self.status.setText("Select a recorded candidate to focus its retained geometry.")
            return
        self.mode.setCurrentIndex(0)
        for name in ("scene", "bin"):
            self.layers[name].setChecked(False)
        self.show_selection()

    def overview(self):
        if self.snapshot is None:
            return
        self.mode.setCurrentIndex(0)
        for box in self.layers.values():
            box.setChecked(True)
        self.select_candidate(None)

    def export_to(self, directory):
        if self.snapshot is None:
            raise ValueError("Capture a completed run before exporting")
        target = self.snapshot.export(
            directory,
            self.selected_candidate,
            self.display_layers(),
            self.mode.currentData(),
            yaw=self.yaw.value(),
            pitch=self.pitch.value(),
        )
        self.export_status.setText(f"Exported frozen review: {target}")
        return target

    def choose_export(self):
        parent = QFileDialog.getExistingDirectory(self, "Choose parent for a new frozen review")
        if parent:
            try:
                self.export_to(Path(parent) / f"bin-review-{uuid.uuid4().hex[:12]}")
            except (ValueError, OSError) as error:
                self.export_status.setText(str(error))

    def show_inputs(self):
        if self.snapshot is None:
            return
        dialog = QDialog(self)
        dialog.resize(950, 850)
        dialog.setWindowTitle(
            f"Captured inputs — completion {self.snapshot.provenance['execution_count']}"
        )
        layout = QVBoxLayout(dialog)
        note = QLabel(
            "Read-only captured arrays. Wheel zoom / drag pan. Depth contrast is for "
            "display only; original dtype, invalid depths and metadata are exported. "
            "Appearance input is not assumed registered to depth."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        tabs = QTabWidget()
        layout.addWidget(tabs)
        for name in self.snapshot.input_names:
            array = self.snapshot.input_array(name)
            description = self.snapshot.input_description(name)
            if array.ndim not in (2, 3):
                continue
            if array.ndim == 2:
                valid = np.isfinite(array) & (array > 0)
                display = np.zeros(array.shape, np.uint8)
                if valid.any():
                    low, high = np.percentile(array[valid], [1, 99])
                    display[valid] = np.clip(
                        (array[valid] - low) * 255 / max(high - low, 1e-12), 0, 255
                    )
                image = ImageArray(display, "GRAY")
            else:
                image = ImageArray(array, description["attributes"].get("color_format", "BGR"))
            view = FilmstripImageView(dialog)
            view.set_image(pixmap(image))
            tabs.addTab(view, f"{name} — {array.dtype}")
        self.input_dialogs.append(dialog)
        dialog.show()
