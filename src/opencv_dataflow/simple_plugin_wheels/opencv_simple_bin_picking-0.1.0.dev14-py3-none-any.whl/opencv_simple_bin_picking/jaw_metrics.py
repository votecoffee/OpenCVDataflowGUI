"""Explicit diagnostic denominators; no pose, contact or clearance acceptance policy."""

import numpy as np

from .jaw_fit import STATES


def ray_statistics(states, weights=None):
    """Summarize identical ray states with uniform or positive finite weights.

    Only supported, contradictory and label-mismatched rays test the predicted
    surface. Foreground occlusion, unknown depth and ambiguous neighborhoods
    cannot establish its presence or absence. A conditional support ratio must
    always be read alongside the testable fraction and absolute population.
    """
    states = np.asarray(states)
    if (
        states.ndim != 1
        or states.dtype.kind not in "ui"
        or np.any(states < 0)
        or np.any(states >= len(STATES))
    ):
        raise ValueError("Use a one-dimensional array of declared evidence state codes")
    weights = np.ones(len(states)) if weights is None else np.asarray(weights, np.float64)
    if weights.shape != states.shape or not np.isfinite(weights).all() or np.any(weights <= 0):
        raise ValueError("Ray weights must be matching finite positive values")
    total = float(weights.sum())
    if not np.isfinite(total):
        raise ValueError("Total ray weight must remain finite")
    mass = {name: float(weights[states == code].sum()) for code, name in enumerate(STATES)}
    testable = sum(mass[name] for name in ("supported", "contradiction", "label_mismatch"))

    def fraction(numerator, denominator=total):
        return float(numerator / denominator) if denominator > 0 else None

    return dict(
        rays=len(states),
        expected_mass=total,
        testable_mass=testable,
        state_mass=mass,
        observed_fraction=fraction(total - mass["unknown"]),
        testable_fraction=fraction(testable),
        supported_expected_fraction=fraction(mass["supported"]),
        support_testable_fraction=fraction(mass["supported"], testable),
        contradiction_testable_fraction=fraction(mass["contradiction"], testable),
        label_mismatch_testable_fraction=fraction(mass["label_mismatch"], testable),
        occluded_fraction=fraction(mass["occluded"]),
        unknown_fraction=fraction(mass["unknown"]),
        ambiguous_fraction=fraction(mass["ambiguous"]),
    )


def mesh_statistics(states, z, incidence, camera, stride):
    """Pixel count versus visible-area midpoint quadrature on the same mesh rays.

    For ray r=((u-cx)/fx,(v-cy)/fy,1) and outward unit normal n,
    dA/du/dv = z**2 / (fx*fy*abs(dot(n,r))). Grid stride scales the
    quadrature cell area. Silhouette/partial cells and grazing incidence make
    this an estimate, not exact visible CAD area or sensor uncertainty.
    """
    pixel = dict(status="available", units="rays", **ray_statistics(states))
    z, incidence = np.asarray(z, np.float64), np.asarray(incidence, np.float64)
    if z.shape != np.asarray(states).shape or incidence.shape != z.shape:
        raise ValueError("Depth and incidence must match the classified rays")
    if type(stride) is not int or stride < 1:
        raise ValueError("Use the positive integer renderer grid stride")
    k = np.asarray(camera.matrix)
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        weights = (z / k[0, 0]) * (z / k[1, 1]) * stride**2 / incidence
        total = weights.sum()
    invalid = (~np.isfinite(weights)) | (weights <= 0) | (z <= 0) | (incidence <= 0)
    area = dict(status="unavailable", units="m2", invalid_weight_rays=int(invalid.sum()))
    if not invalid.any() and np.isfinite(total):
        area.update(status="available", **ray_statistics(states, weights))
    return dict(
        model="mesh_ray_weighting_diagnostics_v1",
        pixel=pixel,
        visible_area=area,
        acceptance_applied=False,
        testable_states=["supported", "contradiction", "label_mismatch"],
        excluded_from_conditional_support=["occluded", "unknown", "ambiguous"],
        scope="Same first-surface rays; pixel count versus visible-area midpoint quadrature",
        interpretation=(
            "Conditional support requires testable fraction and absolute evidence; "
            "neither weighting is a probability, calibrated confidence or acceptance gate"
        ),
    )
