"""Offline training-label filmstrips and camera-visible cloud reviews; no Torch."""

import hashlib
import html
import json
import re
from pathlib import Path
from types import SimpleNamespace

import cv2
import numpy as np

from .geometry import render_xyz
from .training_data import check_dataset, image, load_definition, load_model, project, read_file
from .wire import strict_json


def save_json(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + "\n")


def save_image(path, bgr):
    ok, encoded = cv2.imencode(".png", bgr)
    if not ok:
        raise ValueError("Cannot encode training-data review image")
    with path.open("xb") as stream:
        stream.write(encoded.tobytes())


def cloud_arrays(rgb, depth, camera, xyz, visible_mask, pose, axis_length, limit=20000):
    """Measured scene and one first-return CAD surface, never a filled CAD cloud."""
    y, x = np.nonzero(depth > 0)
    ids = np.linspace(0, len(y) - 1, min(limit, len(y)), dtype=int) if len(y) else []
    x, y = x[ids], y[ids]
    z = depth[y, x]
    points = np.c_[(x - camera[0, 2]) * z / camera[0, 0], (y - camera[1, 2]) * z / camera[1, 1], z]
    colors = rgb[y, x, ::-1].copy()
    surface = xyz[(xyz[:, :, 2] > 0) & visible_mask]
    if len(surface):
        ids = np.linspace(0, len(surface) - 1, min(10000, len(surface)), dtype=int)
        points = np.r_[points, surface[ids]]
        colors = np.r_[colors, np.tile([255, 200, 0], (len(ids), 1)).astype(np.uint8)]
    for axis, color in enumerate(np.eye(3, dtype=np.uint8) * 255):
        line = pose[:3, 3] + np.linspace(0, axis_length, 31)[:, None] * pose[:3, axis]
        points = np.r_[points, line]
        colors = np.r_[colors, np.tile(color, (len(line), 1))]
    return points.astype(np.float32), colors


def save_cloud(path, points, colors):
    with path.open("x", encoding="ascii", newline="\n") as stream:
        stream.write(
            f"ply\nformat ascii 1.0\ncomment units m\nelement vertex {len(points)}\n"
            "property float x\nproperty float y\nproperty float z\n"
            "property uchar red\nproperty uchar green\nproperty uchar blue\nend_header\n"
        )
        for point, color in zip(points, colors):
            stream.write(
                " ".join([*(f"{v:.9g}" for v in point), *(str(int(v)) for v in color)]) + "\n"
            )


def render_sample(root, row, mesh, hashes):
    rgb = image(root, row["rgb_path"], hashes)
    depth = image(root, row["depth_path"], hashes).astype(np.float32) * row["depth_scale_to_m"]
    mask = image(root, row["visible_mask_path"], hashes) != 0
    pose, camera = np.array(row["model_to_camera_m"]), np.array(row["camera_matrix"])
    overlay = rgb.copy()
    camera_vertices = mesh.vertices @ pose[:3, :3].T + pose[:3, 3]
    supported = bool(camera_vertices[:, 2].min() >= 0.1)
    xyz = (
        render_xyz(mesh, pose, camera, shape=depth.shape)
        if supported
        else np.zeros((*depth.shape, 3), np.float32)
    )
    rendered = xyz[:, :, 2] > 0
    for selection, color in ((rendered, (0, 200, 255)), (mask, (255, 230, 0))):
        contours, _ = cv2.findContours(
            selection.astype(np.uint8), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE
        )
        cv2.drawContours(overlay, contours, -1, color, 1, cv2.LINE_AA)
    if mask.any():
        overlay[mask] = np.clip(
            0.85 * overlay[mask] + 0.15 * np.array([255, 230, 0]), 0, 255
        ).astype(np.uint8)
    length = float(np.linalg.norm(np.ptp(mesh.vertices, axis=0)) * 0.18)
    axes = project(np.r_[np.zeros((1, 3)), np.eye(3) * length], pose, camera)
    axes = np.rint(axes).clip(-1000000, 1000000).astype(int)
    for endpoint, color, label in zip(
        axes[1:], ((20, 30, 245), (20, 210, 40), (240, 80, 20)), "XYZ"
    ):
        cv2.line(overlay, tuple(axes[0]), tuple(endpoint), color, 2, cv2.LINE_AA)
        cv2.putText(
            overlay, label, tuple(endpoint), cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1, cv2.LINE_AA
        )
    cv2.drawMarker(overlay, tuple(axes[0]), (255, 255, 255), cv2.MARKER_CROSS, 9, 1)
    common = mask & rendered & (depth > 0)
    diagnostic = dict(
        cad_surface_rendered=supported,
        visible_label_on_cad_fraction=float(np.count_nonzero(mask & rendered) / mask.sum())
        if mask.any() and supported
        else None,
        median_abs_depth_difference_mm=float(
            np.median(np.abs(xyz[:, :, 2][common] - depth[common])) * 1000
        )
        if common.any()
        else None,
        scope="Label/geometry diagnostic, no depth acceptance gate or predicted pose",
    )
    if not supported:
        diagnostic["note"] = "CAD surface preview currently requires all vertices beyond 100 mm"
    return rgb, overlay, xyz, depth, diagnostic


def export_training_review(
    definition_path, output, *, dataset_root=None, max_previews=64, cancelled=lambda: False
):
    if (
        isinstance(max_previews, bool)
        or not isinstance(max_previews, int)
        or not 1 <= max_previews <= 512
    ):
        raise ValueError("Bound label previews to 1..512")
    output = Path(output)
    if output.exists():
        raise FileExistsError("Choose a new training-data review folder")
    report = check_dataset(definition_path, dataset_root=dataset_root, cancelled=cancelled)
    definition, root = load_definition(definition_path, dataset_root)
    if (
        hashlib.sha256(Path(definition_path).read_bytes()).hexdigest()
        != report["definition_sha256"]
    ):
        raise ValueError("Dataset definition changed before review")
    model_dir = definition["models_dir"]
    meshes, hashes = {}, dict(report["source_sha256"])
    info = strict_json(read_file(root, model_dir + "/models_info.json", hashes))
    for object_id in definition["object_ids"]:
        vertices, faces = load_model(root, model_dir, object_id, info[str(object_id)], hashes)
        meshes[object_id] = SimpleNamespace(vertices=vertices, faces=faces, center=np.zeros(3))
    output.mkdir(parents=True, exist_ok=False)
    previews, clouds, panels = [], set(), []
    for ordinal, row in enumerate(report["samples"][:max_previews]):
        if cancelled():
            raise RuntimeError("Training-data review cancelled; incomplete folder retained")
        rgb, overlay, xyz, depth, diagnostic = render_sample(
            root, row, meshes[row["object_id"]], hashes
        )
        stem = f"label_{ordinal:05d}"
        save_image(output / (stem + ".png"), overlay)
        save_image(output / (stem + "_source.png"), rgb)
        box = np.array(row["bbox_visible_xywh"], np.float64)
        if not row["usable"]:
            corners = np.array(row["cad_bounds_pixels"])
            box = np.r_[corners.min(axis=0), np.ptp(corners, axis=0)]
        padding = max(16, 0.3 * max(box[2:]))
        low = np.maximum([0, 0], np.floor(box[:2] - padding)).astype(int)
        high = np.minimum(
            [rgb.shape[1], rgb.shape[0]], np.ceil(box[:2] + box[2:] + padding)
        ).astype(int)
        cropped = overlay[low[1] : high[1], low[0] : high[0]] if np.all(high > low) else overlay
        save_image(output / (stem + "_thumbnail.png"), cropped)
        entry = dict(
            id=row["id"],
            object_id=row["object_id"],
            role=row["role"],
            usable=row["usable"],
            overlay=stem + ".png",
            source=stem + "_source.png",
            thumbnail=stem + "_thumbnail.png",
            focus_xywh=box.tolist(),
            visible_fraction=row["visible_fraction"],
            valid_depth_fraction=row["valid_depth_fraction"],
            **diagnostic,
        )
        key = row["role"], row["object_id"]
        if row["usable"] and key not in clouds and len(clouds) < 8:
            visible = image(root, row["visible_mask_path"], hashes) != 0
            points, colors = cloud_arrays(
                rgb,
                depth,
                np.array(row["camera_matrix"]),
                xyz,
                visible,
                np.array(row["model_to_camera_m"]),
                float(np.linalg.norm(np.ptp(meshes[row["object_id"]].vertices, axis=0)) * 0.18),
            )
            save_cloud(output / (stem + ".ply"), points, colors)
            entry["cloud"] = stem + ".ply"
            entry["cloud_points"] = len(points)
            clouds.add(key)
        previews.append(entry)
        tile = np.full((288, 320, 3), 248, np.uint8)
        scale = min(316 / cropped.shape[1], 236 / cropped.shape[0])
        small = cv2.resize(
            cropped, (round(cropped.shape[1] * scale), round(cropped.shape[0] * scale))
        )
        left = (320 - small.shape[1]) // 2
        tile[44 : 44 + small.shape[0], left : left + small.shape[1]] = small
        for line, text in enumerate(
            (
                f"{row['role']} | object {row['object_id']} | {ordinal + 1}",
                f"visible {row['visible_fraction']:.0%} | "
                f"depth valid {row['valid_depth_fraction']:.0%}",
            )
        ):
            cv2.putText(
                tile,
                text,
                (8, 17 + line * 18),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.43,
                (30, 30, 30),
                1,
                cv2.LINE_AA,
            )
        panels.append(tile)
    if cancelled():
        raise RuntimeError("Training-data review cancelled; incomplete folder retained")
    if (
        hashlib.sha256(Path(definition_path).read_bytes()).hexdigest()
        != report["definition_sha256"]
    ):
        raise ValueError("Dataset definition changed during review")
    save_json(output / "report.json", report)
    save_json(output / "previews.json", previews)
    if panels:
        panels += [np.full_like(panels[0], 248)] * ((-len(panels)) % 3)
        save_image(
            output / "overview.png",
            np.vstack([np.hstack(panels[i : i + 3]) for i in range(0, len(panels), 3)]),
        )
    (output / "review.html").write_text(page(report, previews), encoding="utf-8", newline="\n")
    return report, previews


def page(report, previews):
    credit = report["source_credit"]
    values = {
        "TITLE": html.escape(report["name"]),
        "STATUS": html.escape(report["status"]),
        "SHOWN": str(len(previews)),
        "TOTAL": str(len(report["samples"])),
        "OBJECTS": "".join(f"<option>{i}</option>" for i in report["object_ids"]),
        "MESSAGES": "".join(
            "<li>" + html.escape(e["message"]) + "</li>"
            for e in report["errors"] + report["warnings"]
        ),
        "CREDIT": html.escape(
            credit["authors"]
            + " - "
            + credit["title"]
            + " - "
            + credit["license"]
            + " - "
            + credit["source_url"]
        ),
        "DATA": json.dumps(previews, allow_nan=False).replace("<", "\\u003c"),
    }
    template = Path(__file__).with_suffix(".html").read_text(encoding="utf-8")
    return re.sub(r"@@([A-Z]+)@@", lambda m: values[m[1]], template)
