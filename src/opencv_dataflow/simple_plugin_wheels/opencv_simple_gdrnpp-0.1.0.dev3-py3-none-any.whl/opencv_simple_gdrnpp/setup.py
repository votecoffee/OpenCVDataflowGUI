"""Portable object setup, retained RGB-D references and explicit external model binding.

Uses the sibling package's original bounded geometry/array utilities only;
neither Torch nor a FoundationPose neural runtime is imported during setup.
"""

import hashlib
import io
import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from tempfile import NamedTemporaryFile
from zipfile import ZIP_DEFLATED, BadZipFile, ZipFile, ZipInfo

import numpy as np
from opencv_simple_foundation_pose.persistence import LIMIT, bounded_array, strict_json
from opencv_simple_foundation_pose.specs import Frame, Mesh, Settings, frame_name, frozen, rigid

from .estimate import Detection
from .preprocess import validate_box
from .runtime import (
    CHECKPOINT_BYTES,
    CHECKPOINT_SHA256,
    SOURCE_COMMIT,
    SOURCE_CONFIG,
    validate_extents,
)

GEOMETRY_SHA256 = "7f93f2e6abe6582a80aab6aa2effd42c4886d44c4092710de44be0913b270efa"
ARRAY_NAMES = {
    name + ".npy" for name in ("vertices", "faces", "colors", "rgb", "depth", "mask", "symmetries")
}


def binding():
    return dict(
        provider="GDRNPP",
        dataset="T-LESS",
        object_id=6,
        source_commit=SOURCE_COMMIT,
        source_config=SOURCE_CONFIG,
        checkpoint_sha256=CHECKPOINT_SHA256,
        checkpoint_bytes=CHECKPOINT_BYTES,
        metric_geometry_sha256=GEOMETRY_SHA256,
    )


def geometry_digest(mesh):
    return hashlib.sha256(
        mesh.vertices.astype("<f8").tobytes() + mesh.faces.astype("<i4").tobytes()
    ).hexdigest()


def plain_label(value):
    if (
        not isinstance(value, str)
        or value != value.strip()
        or not 1 <= len(value) <= 128
        or any(ord(c) < 32 for c in value)
    ):
        raise ValueError("Use a nonempty plain name of at most 128 characters")
    return value


@dataclass(frozen=True)
class Capture:
    frame: Frame
    detections: tuple[Detection, ...]
    capture_id: str
    model_frame: str = "tless_object6"

    def __post_init__(self):
        if not isinstance(self.frame, Frame):
            raise TypeError("Retain a validated RGB-D frame")
        plain_label(self.capture_id)
        frame_name(self.model_frame)
        if self.model_frame == self.frame.frame:
            raise ValueError("Model and camera physical frames must differ")
        detections = tuple(self.detections)
        if (
            len(detections) > 64
            or any(not isinstance(d, Detection) for d in detections)
            or len({d.identifier for d in detections}) != len(detections)
        ):
            raise ValueError("Use up to 64 uniquely identified detections")
        for detection in detections:
            validate_box(
                detection.box, width=self.frame.rgb.shape[1], height=self.frame.rgb.shape[0]
            )
        object.__setattr__(self, "detections", detections)


@dataclass(frozen=True)
class ExecutionSettings:
    threads: int = 4
    batch_size: int = 1
    distance_tolerance_m: float = 0.005
    minimum_coverage: float = 0.7
    maximum_contradiction: float = 0.1
    depth_refine: bool = False
    maximum_correction_m: float = 0.02
    depth_refinement: str = "median_translation"
    maximum_overlap: float = 1.0

    def __post_init__(self):
        for name, maximum in (("threads", 32), ("batch_size", 8)):
            if type(getattr(self, name)) is not int or not 1 <= getattr(self, name) <= maximum:
                raise ValueError(f"{name} must be an integer in 1..{maximum}")
        if type(self.depth_refine) is not bool:
            raise ValueError("depth_refine must be boolean")
        if (
            isinstance(self.maximum_overlap, bool)
            or not isinstance(self.maximum_overlap, (int, float))
            or not np.isfinite(self.maximum_overlap)
            or not 0 <= self.maximum_overlap <= 1
        ):
            raise ValueError("Maximum overlap must be a finite fraction in [0, 1]")
        if self.depth_refinement not in ("median_translation", "projective_icp_v1"):
            raise ValueError("Choose median_translation or projective_icp_v1")
        if (
            isinstance(self.maximum_correction_m, bool)
            or not np.isfinite(self.maximum_correction_m)
            or not 0 < self.maximum_correction_m <= 0.1
        ):
            raise ValueError("Bound depth correction to (0, .1] meters")
        if self.depth_refinement == "projective_icp_v1" and self.maximum_correction_m < 1e-5:
            raise ValueError("Projective ICP needs a translation bound of at least 0.01 mm")
        self.fit_settings()

    def fit_settings(self):
        return Settings(
            distance_tolerance=self.distance_tolerance_m,
            minimum_coverage=self.minimum_coverage,
            maximum_contradiction=self.maximum_contradiction,
        )


@dataclass(frozen=True)
class SourceCredit:
    dataset: str = ""
    license: str = ""
    url: str = ""
    attribution: str = ""
    modifications: str = ""

    def __post_init__(self):
        if any(not isinstance(value, str) or len(value) > 8192 for value in asdict(self).values()):
            raise ValueError("Use bounded source/attribution strings")


@dataclass(frozen=True)
class Recipe:
    name: str
    mesh: Mesh
    reference: Capture
    symmetries: np.ndarray = field(repr=False)
    settings: ExecutionSettings = field(default_factory=ExecutionSettings)
    credit: SourceCredit = field(default_factory=SourceCredit)
    content_sha256: str = field(init=False)
    _source_bytes: bytes | None = field(default=None, repr=False, compare=False, kw_only=True)

    def __post_init__(self):
        plain_label(self.name)
        if (
            not isinstance(self.mesh, Mesh)
            or not isinstance(self.reference, Capture)
            or not isinstance(self.settings, ExecutionSettings)
            or not isinstance(self.credit, SourceCredit)
        ):
            raise TypeError("Retain validated model, capture, settings and source credit")
        if not self.reference.detections:
            raise ValueError("Select at least one instance in the retained reference")
        frame_name(self.mesh.frame)
        if self.mesh.frame != self.reference.model_frame:
            raise ValueError("Reference and CAD physical model frames differ")
        validate_extents(np.ptp(self.mesh.vertices, axis=0))
        if geometry_digest(self.mesh) != GEOMETRY_SHA256:
            raise ValueError(
                "This checkpoint requires the original metric T-LESS CAD-6 geometry/origin"
            )
        symmetries = np.asarray(self.symmetries, np.float64)
        if (
            symmetries.ndim != 3
            or symmetries.shape[1:] != (4, 4)
            or not 1 <= len(symmetries) <= 128
        ):
            raise ValueError("Retain 1..128 discrete metric object symmetries including identity")
        for symmetry in symmetries:
            rigid(symmetry)
        if not np.any(np.all(np.isclose(symmetries, np.eye(4), atol=1e-9, rtol=0), axis=(1, 2))):
            raise ValueError("Retain the identity object symmetry")
        object.__setattr__(self, "symmetries", frozen(symmetries, np.float64))
        manifest, _ = _entries(self)
        object.__setattr__(self, "content_sha256", hashlib.sha256(manifest).hexdigest())


def _entries(recipe):
    arrays = dict(
        vertices=recipe.mesh.vertices,
        faces=recipe.mesh.faces,
        colors=recipe.mesh.colors,
        rgb=recipe.reference.frame.rgb,
        depth=recipe.reference.frame.depth,
        mask=recipe.reference.frame.mask.astype(np.uint8),
        symmetries=recipe.symmetries,
    )
    entries = {}
    for name, value in arrays.items():
        stream = io.BytesIO()
        np.save(stream, value, allow_pickle=False)
        entries[name + ".npy"] = stream.getvalue()
    settings = asdict(recipe.settings)
    if settings["maximum_overlap"] == 1:
        settings.pop("maximum_overlap")
    if settings["depth_refinement"] == "median_translation":
        # Preserve original archive/content identity when loading legacy default recipes.
        settings.pop("depth_refinement")
    manifest = dict(
        schema="simple_gdrnpp_recipe/v1",
        name=recipe.name,
        units="m",
        binding=binding(),
        mesh_frame=recipe.mesh.frame,
        camera_frame=recipe.reference.frame.frame,
        camera_matrix=recipe.reference.frame.camera.tolist(),
        reference_capture_id=recipe.reference.capture_id,
        reference_detections=[asdict(d) for d in recipe.reference.detections],
        settings=settings,
        credit=asdict(recipe.credit),
        arrays={n: hashlib.sha256(raw).hexdigest() for n, raw in entries.items()},
    )
    raw = (json.dumps(manifest, sort_keys=True, indent=2, allow_nan=False) + "\n").encode("utf-8")
    if len(raw) > 1024 * 1024 or sum(map(len, entries.values())) + len(raw) > LIMIT:
        raise ValueError("Retained setup exceeds its 64 MiB limit")
    return raw, entries


def save_recipe(path, recipe):
    """Create a complete new archive atomically; never replace an existing recipe."""
    if not isinstance(recipe, Recipe):
        raise TypeError("Save a validated Recipe")
    path = Path(path)
    if path.exists():
        raise FileExistsError("Choose a new recipe filename")
    manifest, entries = _entries(recipe)
    with NamedTemporaryFile(dir=path.parent, prefix=".gdrnpp-", delete=False) as stream:
        pending = Path(stream.name)
    try:
        with ZipFile(pending, "w") as archive:
            for name, raw in {"recipe.json": manifest, **entries}.items():
                info = ZipInfo(name, (1980, 1, 1, 0, 0, 0))
                info.compress_type, info.create_system = ZIP_DEFLATED, 0
                archive.writestr(info, raw)
        if pending.stat().st_size > LIMIT:
            raise ValueError("Retained setup archive exceeds 64 MiB")
        # Same-directory hard link publishes the complete file without clobbering a racing writer.
        os.link(pending, path)
    finally:
        pending.unlink(missing_ok=True)
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_recipe(path, *, sha256=None):
    path = Path(path)
    if path.stat().st_size > LIMIT:
        raise ValueError("Retained setup archive exceeds 64 MiB")
    raw = path.read_bytes()
    if sha256 is not None and hashlib.sha256(raw).hexdigest() != sha256:
        raise ValueError("Recipe SHA-256 differs")
    try:
        with ZipFile(io.BytesIO(raw)) as archive:
            names = archive.namelist()
            if (
                set(names) != ARRAY_NAMES | {"recipe.json"}
                or len(names) != len(set(names))
                or sum(i.file_size for i in archive.infolist()) > LIMIT
                or archive.getinfo("recipe.json").file_size > 1024 * 1024
            ):
                raise ValueError("Unexpected/duplicate/oversized retained setup entries")
            manifest = strict_json(archive.read("recipe.json"))
            expected = {
                "schema",
                "name",
                "units",
                "binding",
                "mesh_frame",
                "camera_frame",
                "camera_matrix",
                "reference_capture_id",
                "reference_detections",
                "settings",
                "credit",
                "arrays",
            }
            if (
                set(manifest) != expected
                or manifest["schema"] != "simple_gdrnpp_recipe/v1"
                or manifest["units"] != "m"
                or manifest["binding"] != binding()
                or not isinstance(manifest["arrays"], dict)
                or set(manifest["arrays"]) != ARRAY_NAMES
            ):
                raise ValueError("Unsupported retained setup/model binding")
            arrays = {}
            for name, digest in manifest["arrays"].items():
                value = archive.read(name)
                if hashlib.sha256(value).hexdigest() != digest:
                    raise ValueError("Retained array checksum differs")
                arrays[name[:-4]] = bounded_array(value)
        return Recipe(
            manifest["name"],
            Mesh(arrays["vertices"], arrays["faces"], arrays["colors"], manifest["mesh_frame"]),
            Capture(
                Frame(
                    arrays["rgb"],
                    arrays["depth"],
                    manifest["camera_matrix"],
                    arrays["mask"],
                    manifest["camera_frame"],
                ),
                tuple(Detection(**d) for d in manifest["reference_detections"]),
                manifest["reference_capture_id"],
                manifest["mesh_frame"],
            ),
            arrays["symmetries"],
            ExecutionSettings(**manifest["settings"]),
            SourceCredit(**manifest["credit"]),
            _source_bytes=raw,
        )
    except (BadZipFile, KeyError, TypeError, OSError) as error:
        raise ValueError(f"Invalid retained GDRNPP setup: {error}") from error


def describe(recipe):
    return dict(
        schema="simple_gdrnpp_setup_summary/v1",
        name=recipe.name,
        content_sha256=recipe.content_sha256,
        binding=binding(),
        units="m",
        model_frame=recipe.mesh.frame,
        camera_frame=recipe.reference.frame.frame,
        reference_capture_id=recipe.reference.capture_id,
        image_size=list(recipe.reference.frame.depth.shape[::-1]),
        reference_detections=[asdict(d) for d in recipe.reference.detections],
        symmetry_count=len(recipe.symmetries),
        settings=asdict(recipe.settings),
        credit=asdict(recipe.credit),
        weights_bundled=False,
        network_training=False,
    )
