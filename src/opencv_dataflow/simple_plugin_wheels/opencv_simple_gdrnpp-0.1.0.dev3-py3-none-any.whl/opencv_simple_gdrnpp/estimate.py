"""Bounded multi-instance RGB inference, preserving provider and assistance semantics."""

import time
from dataclasses import dataclass

import numpy as np

from .preprocess import frame_signature, prepare_frame, validate_frame
from .rotation import decode_pose
from .runtime import validate_extents


@dataclass(frozen=True)
class Detection:
    identifier: str
    box: tuple
    object_id: int = 6
    score: float | None = None
    source: str = "external_box"

    def __post_init__(self):
        bounds = np.asarray(self.box, np.float64)
        if (
            bounds.shape != (4,)
            or not np.isfinite(bounds).all()
            or np.any(bounds[:2] < 0)
            or np.any(bounds[2:] - bounds[:2] < 1)
        ):
            raise ValueError("Use a finite nonempty source-image XYXY rectangle")
        object.__setattr__(self, "box", tuple(bounds.tolist()))
        for field in ("identifier", "source"):
            value = getattr(self, field)
            if not isinstance(value, str) or not value.strip() or len(value) > 128:
                raise ValueError("Use nonempty bounded detection identities and source labels")
        if type(self.object_id) is not int or self.object_id != 6:
            raise ValueError("This checkpoint is trained for T-LESS object 6 only")
        if self.score is not None and (
            isinstance(self.score, bool) or not np.isfinite(self.score) or not 0 <= self.score <= 1
        ):
            raise ValueError("External detector score must be absent or finite in [0,1]")


class Estimator:
    def __init__(self, model, *, batch_size=1):
        if type(batch_size) is not int or not 1 <= batch_size <= 8:
            raise ValueError("Use bounded instance batches of 1..8")
        self.model, self.batch_size = model, batch_size

    def predict(
        self,
        rgb,
        camera,
        detections,
        extents,
        *,
        capture_id,
        source_frame="tless_object6",
        camera_frame="camera",
        cancelled=lambda: False,
    ):
        for label in (capture_id, source_frame, camera_frame):
            if not isinstance(label, str) or not label.strip() or len(label) > 128:
                raise ValueError("Name the capture and physical source/target frames")
        if source_frame == camera_frame:
            raise ValueError("Model and camera frame names must differ")
        detections = tuple(detections)
        extents = validate_extents(extents)
        rgb, camera = validate_frame(rgb, camera)
        if len(detections) > 64 or any(not isinstance(d, Detection) for d in detections):
            raise ValueError("Provide up to 64 explicitly identified detections")
        if len({d.identifier for d in detections}) != len(detections):
            raise ValueError("Detection identities must be unique within a capture")
        start = time.perf_counter()
        if cancelled():
            raise RuntimeError("Inference cancelled; no current poses published")
        prepared_frame = prepare_frame(rgb, camera) if detections else None
        crops = tuple(prepared_frame.crop(d.box) for d in detections)
        # Crops own their small buffers; release full-frame work before inference.
        del prepared_frame
        prepared = time.perf_counter()
        candidates, fields = [], []
        group_sizes = []
        network_seconds = 0.0
        for index in range(0, len(crops), self.batch_size):
            if cancelled():
                raise RuntimeError("Inference cancelled; no current poses published")
            group = crops[index : index + self.batch_size]
            rotations, translations, geometry, elapsed = self.model.infer(group, extents)
            group_sizes.append(len(group))
            network_seconds += elapsed
            if (
                rotations.shape != (len(group), 6)
                or translations.shape != (len(group), 3)
                or geometry.shape != (len(group), 70, 64, 64)
                or not np.isfinite(geometry).all()
            ):
                raise ValueError("Learned outputs do not match the selected model interface")
            for j, crop in enumerate(group):
                detection = detections[index + j]
                pose = decode_pose(rotations[j], translations[j], crop)
                candidates.append(
                    dict(
                        id=detection.identifier,
                        object_id=6,
                        capture_id=capture_id,
                        pose=dict(
                            model="pose_3d_v1",
                            source_to_target=pose.tolist(),
                            units="m",
                            source_frame=source_frame,
                            target_frame=camera_frame,
                        ),
                        detection_source=detection.source,
                        detection_score=detection.score,
                        network_score=None,
                        qualification="network_pose_only",
                        fit=None,
                        raw_rotation6d=rotations[j].tolist(),
                        raw_centroid_z=translations[j].tolist(),
                        crop=dict(
                            source_xyxy=list(crop.source_box),
                            source_size=list(crop.source_size),
                            working_size=list(crop.working_size),
                            padded_scale=crop.scale,
                            source_from_input=crop.source_from_input.tolist(),
                            source_from_output=crop.source_from_output.tolist(),
                        ),
                    )
                )
                fields.append(geometry[j].copy())
        if cancelled():
            raise RuntimeError("Inference cancelled; no current poses published")
        report = dict(
            model="simple_gdrnpp_result_v1",
            capture_id=capture_id,
            units="m",
            source_frame=source_frame,
            target_frame=camera_frame,
            candidates=candidates,
            best_pose=None,
            accepted_candidates=0,
            provider=dict(self.model.provenance),
            input=frame_signature(rgb, camera),
            score_semantics=(
                "GDRNPP pose head has no scalar confidence; external detector score is separate"
            ),
            qualification="RGB network proposals require independent geometry/task qualification",
            seconds=dict(
                preprocess=prepared - start,
                network=network_seconds,
                total=time.perf_counter() - start,
            ),
            batch_size=self.batch_size,
            batch_execution=dict(
                requested_size=self.batch_size,
                instance_count=len(candidates),
                group_sizes=group_sizes,
                forward_calls=len(group_sizes),
            ),
            ground_truth_pose_used=False,
        )
        return report, tuple(fields)
