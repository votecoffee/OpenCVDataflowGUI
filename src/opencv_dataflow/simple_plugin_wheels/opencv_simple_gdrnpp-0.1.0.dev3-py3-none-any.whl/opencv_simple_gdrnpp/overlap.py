"""Optional final selection using shared, measured first-return surfaces."""

import math

import numpy as np

from .geometry import render_xyz
from .review import _instance_frame, _validate_context

SUPPORT_PIXEL_BUDGET = 8_000_000  # At most 64 MB of retained int32/float32 support.


def _supported_surface(mesh, frame, candidate, tolerance, cancelled):
    pose = np.array(candidate["pose"]["source_to_target"], dtype=np.float64)
    pose[:3, 3] += pose[:3, :3] @ mesh.center
    z = render_xyz(mesh, pose, frame.camera, shape=frame.depth.shape, cancelled=cancelled)[..., 2]
    supported = (
        (z > 0)
        & (frame.depth > 0)
        & _instance_frame(frame, candidate).mask
        & (np.abs(z - frame.depth) <= tolerance)
    )
    pixels = np.flatnonzero(supported).astype(np.int32)
    return pixels, z.ravel()[pixels].copy()


def _shared_fraction(first, second, tolerance):
    denominator = min(len(first[0]), len(second[0]))
    if not denominator:
        return 0.0
    _, a, b = np.intersect1d(first[0], second[0], assume_unique=True, return_indices=True)
    return float(np.count_nonzero(np.abs(first[1][a] - second[1][b]) <= tolerance) / denominator)


def suppress_overlaps(mesh, frame, report, maximum_overlap=1.0, *, cancelled=lambda: False):
    """Keep stronger depth-accepted proposals; disabled at 1.0, stable on ties.

    Work and sparse surfaces are call-local. Publish the selection atomically,
    retaining original depth evidence separately from final acceptance. Older
    adapters filtering fit.status also exclude suppressed poses safely.
    """
    if (
        isinstance(maximum_overlap, bool)
        or not isinstance(maximum_overlap, (int, float))
        or not math.isfinite(maximum_overlap)
        or not 0 <= maximum_overlap <= 1
    ):
        raise ValueError("Maximum overlap must be a finite fraction in [0, 1]")
    if "overlap_selection" in report:
        raise ValueError("Select overlaps once; start a new prediction to retry")
    if maximum_overlap == 1:
        return report
    _validate_context(mesh, frame, report)
    candidates = report["candidates"]
    if any((c.get("fit") or {}).get("status") not in ("accepted", "rejected") for c in candidates):
        raise ValueError("Verify measured depth before overlap selection")
    tolerance = report["fit_settings"]["distance_tolerance_m"]
    accepted = sorted(
        (i for i, c in enumerate(candidates) if c["fit"]["status"] == "accepted"),
        key=lambda i: -candidates[i]["fit"]["coverage"],
    )
    decisions = [dict(status="depth_rejected") for _ in candidates]
    surfaces, retained, comparisons, stored_pixels = {}, [], 0, 0
    for index in accepted:
        if cancelled():
            raise RuntimeError("Overlap selection cancelled; no result published")
        if len(accepted) > 1:
            surface = _supported_surface(mesh, frame, candidates[index], tolerance, cancelled)
            for winner in retained:
                if cancelled():
                    raise RuntimeError("Overlap selection cancelled; no result published")
                comparisons += 1
                overlap = _shared_fraction(surface, surfaces[winner], tolerance)
                if overlap > maximum_overlap:
                    decisions[index] = dict(
                        status="overlap_suppressed",
                        retained_by=candidates[winner]["id"],
                        retained_by_index=winner,
                        overlap=overlap,
                    )
                    break
            else:
                stored_pixels += len(surface[0])
                if stored_pixels > SUPPORT_PIXEL_BUDGET:
                    raise ValueError("Overlap support budget exceeded; reduce input proposal count")
                surfaces[index] = surface
        if decisions[index]["status"] != "overlap_suppressed":
            decisions[index] = dict(status="retained")
            retained.append(index)
    if cancelled():
        raise RuntimeError("Overlap selection cancelled; no result published")
    for candidate, decision in zip(candidates, decisions, strict=True):
        candidate["depth_fit"] = dict(candidate["fit"])
        candidate["selection"] = decision
        candidate["qualification"] = "measured_depth_and_overlap_selection"
        if decision["status"] == "overlap_suppressed":
            candidate["fit"] = dict(
                candidate["fit"], status="rejected", reason="overlap_suppressed"
            )
    report["depth_accepted_candidates"] = len(accepted)
    report["accepted_candidates"] = len(retained)
    report["best_pose"] = candidates[retained[0]]["pose"] if retained else None
    report["overlap_selection"] = dict(
        maximum_overlap=maximum_overlap,
        metric="shared_supported_first_return_pixels_over_smaller_support",
        distance_tolerance_m=tolerance,
        ranking="measured_support_descending_then_input_order",
        depth_accepted=len(accepted),
        retained=len(retained),
        suppressed=len(accepted) - len(retained),
        surface_renders=len(accepted) if len(accepted) > 1 else 0,
        comparisons=comparisons,
        retained_support_pixels=stored_pixels,
    )
    return report
