"""Explicit persistent CPU model; strict state loading and no automatic asset fetch."""

import hashlib
import json
import time
from pathlib import Path

import numpy as np

CHECKPOINT_SHA256 = "b1dc54a1a6572e4db560f28a05a0821ed4dc05b18c07052f651f890753d8e606"
CHECKPOINT_BYTES = 410204745
SOURCE_COMMIT = "990003d2c13d4a06fec98e27d980595a9831ccc7"
SOURCE_CONFIG = "configs/gdrn/tlessPbrSO/convnext_AugCosyAAEGray_DMask_amodalClipBox_tless/6.py"
MODEL_EXTENTS_M = np.array([0.0894, 0.0500, 0.0555], np.float32)


def validate_extents(extents):
    extents = np.asarray(extents, np.float32)
    if (
        extents.shape != (3,)
        or not np.isfinite(extents).all()
        or not np.allclose(extents, MODEL_EXTENTS_M, atol=1e-6, rtol=0)
    ):
        raise ValueError("This checkpoint requires the original T-LESS CAD-6 extents in meters")
    return extents


class TorchModel:
    def __init__(self, model_directory, *, threads=4):
        initialization_start = time.perf_counter()
        if type(threads) is not int or not 1 <= threads <= 32:
            raise ValueError("Use 1..32 explicit CPU worker threads")
        directory = Path(model_directory).resolve(strict=True)
        manifest = json.loads((directory / "checkpoint.json").read_text(encoding="utf-8"))
        if (
            manifest.get("schema") != "simple_gdrnpp_checkpoint/v1"
            or manifest.get("sha256") != CHECKPOINT_SHA256
            or manifest.get("bytes") != CHECKPOINT_BYTES
            or manifest.get("source_commit") != SOURCE_COMMIT
            or manifest.get("object_id") != 6
            or manifest.get("config") != SOURCE_CONFIG
        ):
            raise ValueError("Select the verified T-LESS object-6 PBR checkpoint/config pair")
        path = (directory / manifest["model_path"]).resolve(strict=True)
        if not path.is_relative_to(directory) or path.stat().st_size != CHECKPOINT_BYTES:
            raise ValueError("Checkpoint path/size does not match its selected model directory")
        with path.open("rb") as stream:
            digest = hashlib.file_digest(stream, "sha256").hexdigest()
        if digest != CHECKPOINT_SHA256:
            raise ValueError("Checkpoint checksum differs")
        import timm
        import torch

        from .network import Network

        start = time.perf_counter()
        torch.set_num_threads(threads)
        state = torch.load(path, map_location="cpu", weights_only=True)
        if (
            not isinstance(state, dict)
            or not state
            or any(not torch.is_tensor(v) for v in state.values())
        ):
            raise ValueError("Checkpoint must contain only a tensor state dictionary")
        for key, value in state.items():
            if ".norm." in key and key.startswith("geo_head_net."):
                alias = key.replace(".norm.", ".gn.")
                if alias not in state or not torch.equal(value, state[alias]):
                    raise ValueError("Publisher normalization aliases disagree")
        self.network = Network().eval()
        self.network.load_state_dict(state, strict=True)
        self.manifest = manifest
        self.provenance = dict(
            provider="GDRNPP",
            architecture="convnext_base_double_mask_64_regions",
            source_commit=SOURCE_COMMIT,
            checkpoint_sha256=digest,
            object_id=6,
            device="cpu",
            torch=torch.__version__,
            timm=timm.__version__,
            threads=threads,
            parameter_keys=len(state),
            load_seconds=time.perf_counter() - start,
            initialization_seconds=time.perf_counter() - initialization_start,
            source_config=SOURCE_CONFIG,
            adapted_inference_only=True,
            upstream_training_runtime_parity_qualified=False,
        )

    def infer(self, crops, extents):
        import torch

        crops = tuple(crops)
        if not 1 <= len(crops) <= 8:
            raise ValueError("Use bounded batches of 1..8 cropped instances")
        extents = validate_extents(extents)
        if torch.get_num_threads() != self.provenance["threads"]:
            raise RuntimeError("CPU thread policy changed; run the model in its isolated worker")
        images = torch.from_numpy(np.stack([c.image for c in crops]))
        coordinates = torch.from_numpy(np.stack([c.coordinates for c in crops]))
        sizes = torch.from_numpy(np.tile(extents, (len(crops), 1)))
        start = time.perf_counter()
        with torch.inference_mode():
            rotation, translation, geometry = self.network(images, coordinates, sizes)
        elapsed = time.perf_counter() - start
        return (
            rotation.numpy().copy(),
            translation.numpy().copy(),
            geometry.numpy().copy(),
            elapsed,
        )
