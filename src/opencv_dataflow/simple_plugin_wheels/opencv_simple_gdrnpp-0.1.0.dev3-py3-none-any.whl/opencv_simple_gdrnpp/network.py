"""Inference-only topology for the published ConvNeXt single-object checkpoint.

Adapted from GDRNPP 990003d GDRN_double_mask.py, ConvPnPNet,
TopDownDoubleMaskXyzRegionHead and ConvModule (Apache-2.0). Changes remove
training/loss/optimizer/registry/CUDA-extension dependencies and make the one
supported architecture explicit. Parameter names, normalization aliases,
bilinear align-corners behavior and extent normalization are preserved.
"""

import timm
import torch
from torch import nn


class ConvNormAct(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Conv2d(256, 256, 3, padding=1, bias=False)
        self.norm = nn.GroupNorm(32, 256)
        # The publisher registers the same normalization module under both names.
        self.gn = self.norm
        self.activate = nn.GELU()

    def forward(self, x):
        return self.activate(self.norm(self.conv(x)))


class GeometryHead(nn.Module):
    def __init__(self):
        super().__init__()
        self.features = nn.ModuleList(
            [
                nn.ConvTranspose2d(1024, 256, 3, stride=2, padding=1, output_padding=1, bias=False),
                nn.GroupNorm(32, 256),
                nn.GELU(),
                ConvNormAct(),
                ConvNormAct(),
                nn.UpsamplingBilinear2d(scale_factor=2),
                ConvNormAct(),
                ConvNormAct(),
                nn.UpsamplingBilinear2d(scale_factor=2),
                ConvNormAct(),
                ConvNormAct(),
            ]
        )
        self.out_layer = nn.Conv2d(256, 70, 1)

    def forward(self, x):
        if isinstance(x, (tuple, list)):
            if len(x) != 1:
                raise ValueError("Expected one final-stage ConvNeXt feature map")
            x = x[0]
        for layer in self.features:
            x = layer(x)
        return self.out_layer(x)


class PoseHead(nn.Module):
    def __init__(self):
        super().__init__()
        self.features = nn.ModuleList()
        for channels in (69, 128, 128):
            self.features.extend(
                [
                    nn.Conv2d(channels, 128, 3, stride=2, padding=1, bias=False),
                    nn.GroupNorm(32, 128),
                    nn.GELU(),
                ]
            )
        self.fc1 = nn.Linear(128 * 8 * 8, 1024)
        self.fc2 = nn.Linear(1024, 256)
        self.fc_r = nn.Linear(256, 6)
        self.fc_t = nn.Linear(256, 3)
        self.act = nn.GELU()

    def forward(self, x):
        for layer in self.features:
            x = layer(x)
        x = self.act(self.fc1(x.flatten(1)))
        x = self.act(self.fc2(x))
        return self.fc_r(x), self.fc_t(x)


class Network(nn.Module):
    def __init__(self):
        super().__init__()
        self.backbone = timm.create_model(
            "convnext_base", pretrained=False, features_only=True, out_indices=(3,)
        )
        self.geo_head_net = GeometryHead()
        self.pnp_net = PoseHead()

    def forward(self, image, coordinates, extents):
        geometry = self.geo_head_net(self.backbone(image))
        xyz = (geometry[:, 2:5] - 0.5) * extents[:, :, None, None]
        regions = torch.softmax(geometry[:, 6:], dim=1)
        # 0: visible mask, 1: full mask, 2..4: XYZ, 5: region background.
        rotation, translation = self.pnp_net(torch.cat([xyz, coordinates, regions], dim=1))
        return rotation, translation, geometry
