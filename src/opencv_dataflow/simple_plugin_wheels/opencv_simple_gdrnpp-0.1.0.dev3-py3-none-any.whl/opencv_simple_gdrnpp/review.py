"""Optional shared metric verification and source-aligned pose/first-return review.

This uses the sibling package's original geometry utilities only. No
FoundationPose network, ONNX weights or inference is involved.
"""

import json
from pathlib import Path

import cv2
import numpy as np

from .geometry import BACKEND, render_xyz, visible_fit
from .preprocess import frame_signature
from .runtime import validate_extents
from .selection import candidate_status


def _validate_context(mesh, frame, report):
    from opencv_simple_foundation_pose.specs import rigid

    validate_extents(np.ptp(mesh.vertices, axis=0))
    if (
        report.get("units") != "m"
        or report.get("source_frame") != mesh.frame
        or report.get("target_frame") != frame.frame
        or report.get("input") != frame_signature(frame.rgb, frame.camera)
    ):
        raise ValueError(
            "Review needs the original RGB/calibration and matching metric model/frames"
        )
    for candidate in report["candidates"]:
        pose = candidate["pose"]
        if (
            candidate.get("capture_id") != report["capture_id"]
            or pose.get("units") != "m"
            or pose.get("source_frame") != mesh.frame
            or pose.get("target_frame") != frame.frame
        ):
            raise ValueError("Candidate capture/physical frames differ from this review")
        rigid(pose["source_to_target"])


def _instance_frame(frame, candidate):
    """A neighboring detection must not supply this candidate's target support."""
    from opencv_simple_foundation_pose.specs import Frame

    bounds = candidate.get("crop", {}).get("source_xyxy")
    if bounds is None:
        return frame
    x0, y0, x1, y1 = bounds
    height, width = frame.depth.shape
    mask = (
        frame.mask
        & (np.arange(width)[None, :] >= x0)
        & (np.arange(width)[None, :] < x1)
        & (np.arange(height)[:, None] >= y0)
        & (np.arange(height)[:, None] < y1)
    )
    return Frame(frame.rgb, frame.depth, frame.camera, mask, frame.frame)


def verify(mesh, frame, report, settings=None, *, cancelled=None, retained=None):
    from opencv_simple_foundation_pose.specs import Settings

    _validate_context(mesh, frame, report)
    if "overlap_selection" in report:
        raise ValueError("Start a new prediction before reverifying overlap-selected poses")
    settings = settings or Settings()
    report["best_pose"], report["accepted_candidates"] = None, 0
    for candidate in report["candidates"]:
        if cancelled is not None and cancelled():
            raise RuntimeError("Depth verification cancelled; no current result published")
        pose = np.array(candidate["pose"]["source_to_target"])
        centered = pose.copy()
        centered[:3, 3] += centered[:3, :3] @ mesh.center
        arguments = dict(cancelled=cancelled) if cancelled is not None else {}
        if retained is not None:
            arguments["retained"] = retained.setdefault(candidate["id"], {})
        candidate["fit"] = visible_fit(
            mesh, _instance_frame(frame, candidate), centered, settings, **arguments
        )
        candidate["qualification"] = "measured_depth_gates"
    if cancelled is not None and cancelled():
        raise RuntimeError("Depth verification cancelled; no current result published")
    accepted = [c for c in report["candidates"] if c["fit"]["status"] == "accepted"]
    accepted.sort(key=lambda c: -c["fit"]["coverage"])
    report["best_pose"] = accepted[0]["pose"] if accepted else None
    report["accepted_candidates"] = len(accepted)
    report["fit_settings"] = dict(
        distance_tolerance_m=settings.distance_tolerance,
        minimum_coverage=settings.minimum_coverage,
        maximum_contradiction=settings.maximum_contradiction,
    )
    report["fit_semantics"] = (
        "Original measured axial depth; first-return CAD surfaces are predictions"
    )
    report["verification_backend"] = (
        "Original metric assessment with batched geometry; no FoundationPose neural inference"
    )
    report["geometry_execution_backend"] = BACKEND
    return report


def refine_depth(
    mesh,
    frame,
    report,
    *,
    maximum_correction_m=0.02,
    method="median_translation",
    fit_settings=None,
    cancelled=lambda: False,
):
    """Optional bounded local depth alignment, separate from RGB pose inference."""
    _validate_context(mesh, frame, report)
    if "overlap_selection" in report:
        raise ValueError("Start a new prediction before refining overlap-selected poses")
    if method not in ("median_translation", "projective_icp_v1"):
        raise ValueError("Choose a supported depth refinement method")
    if not 0 < maximum_correction_m <= 0.1:
        raise ValueError("Bound the metric depth correction to (0, .1] m")
    if any("depth_refinement" in c for c in report["candidates"]):
        raise ValueError("Refine each RGB proposal once; start a new prediction to retry")
    report["best_pose"], report["accepted_candidates"] = None, 0
    for candidate in report["candidates"]:
        candidate["fit"] = None
        candidate["qualification"] = "requires_depth_reverification"
    for candidate in report["candidates"]:
        if cancelled():
            raise RuntimeError("Depth refinement cancelled; no current result published")
        pose = np.array(candidate["pose"]["source_to_target"])
        if method == "projective_icp_v1":
            from .refinement import RefinementSettings, refine_pose

            refined, detail = refine_pose(
                mesh,
                _instance_frame(frame, candidate),
                pose,
                RefinementSettings(maximum_translation_m=maximum_correction_m),
                fit_settings=fit_settings,
                cancelled=cancelled,
            )
            candidate["depth_refinement"] = detail
            if detail["status"] == "applied":
                candidate["unrefined_pose"] = candidate["pose"]
                candidate["pose"] = {**candidate["pose"], "source_to_target": refined.tolist()}
            continue
        centered = pose.copy()
        centered[:3, 3] += pose[:3, :3] @ mesh.center
        xyz = render_xyz(mesh, centered, frame.camera, shape=frame.depth.shape, cancelled=cancelled)
        predicted = xyz[..., 2]
        interior = cv2.erode((predicted > 0).astype(np.uint8), np.ones((3, 3), np.uint8)) > 0
        valid = interior & _instance_frame(frame, candidate).mask & (frame.depth > 0)
        if valid.sum() < 50:
            candidate["depth_refinement"] = dict(
                status="unavailable", reason="insufficient_measured_surface"
            )
            continue
        correction = float(np.median(frame.depth[valid] - predicted[valid]))
        if abs(correction) > maximum_correction_m:
            candidate["depth_refinement"] = dict(
                status="rejected", reason="correction_exceeds_bound", axial_correction_m=correction
            )
            continue
        refined = pose.copy()
        refined[:3, 3] *= 1 + correction / pose[2, 3]
        candidate["unrefined_pose"] = candidate["pose"]
        candidate["pose"] = {**candidate["pose"], "source_to_target": refined.tolist()}
        candidate["depth_refinement"] = dict(
            status="applied",
            method="median_axial_translation",
            axial_correction_m=correction,
            measured_samples=int(valid.sum()),
            maximum_correction_m=maximum_correction_m,
            rotation_refined=False,
        )
    report["depth_refinement"] = method
    report["depth_refinement_scope"] = "Local CPU alignment; not the publisher CUDA refiner"
    report["same_depth_used_for_refinement_and_verification"] = True
    return report


def overlay(mesh, frame, report, index=0, *, _rendered=None):
    _validate_context(mesh, frame, report)
    image = frame.rgb.copy()
    if not report["candidates"]:
        cv2.putText(
            image, "No candidate boxes", (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 190, 40), 2
        )
        return image
    candidate = report["candidates"][index]
    pose = np.array(candidate["pose"]["source_to_target"])
    centered = pose.copy()
    centered[:3, 3] += pose[:3, :3] @ mesh.center
    xyz = (
        _rendered
        if _rendered is not None
        else render_xyz(mesh, centered, frame.camera, shape=frame.depth.shape)
    )
    z = xyz[..., 2]
    edge = cv2.Canny((z > 0).astype(np.uint8) * 255, 100, 200) > 0
    # Include model surface pixels to make the fit visible on textureless parts.
    selected = edge | ((z > 0) & (np.indices(z.shape).sum(axis=0) % 7 == 0))
    known = (frame.depth > 0) & _instance_frame(frame, candidate).mask
    tolerance = report.get("fit_settings", {}).get("distance_tolerance_m", 0.005)
    delta = z - frame.depth
    color = np.zeros((*z.shape, 3), np.uint8)
    color[:] = [255, 165, 30]
    color[known & (np.abs(delta) <= tolerance)] = [40, 240, 80]
    color[known & (delta < -tolerance)] = [255, 50, 70]
    color[known & (delta > tolerance)] = [150, 100, 250]
    image[selected] = color[selected]
    rv = cv2.Rodrigues(pose[:3, :3])[0]
    # Draw axes with RGB colors in the source RGB array.
    axis = np.r_[np.zeros((1, 3)), np.eye(3) * mesh.diameter / 3]
    pixels = cv2.projectPoints(axis, rv, pose[:3, 3], frame.camera, None)[0].reshape(-1, 2)
    uv = np.rint(pixels).astype(int)
    for i, color in enumerate(([255, 0, 0], [0, 255, 0], [50, 120, 255])):
        cv2.arrowedLine(
            image, tuple(uv[0]), tuple(uv[i + 1]), color, 2, cv2.LINE_AA, tipLength=0.15
        )
    fit = candidate.get("fit") or {}
    label = (
        f"{candidate_status(candidate)} | support {fit.get('coverage', 0):.1%}"
        f" | contrad. {fit.get('contradiction', 0):.1%}"
    )
    settings = report.get("fit_settings", {})
    gates = (
        f"Gates: support >= {settings.get('minimum_coverage', 0.7):.0%}; "
        f"contradiction <= {settings.get('maximum_contradiction', 0.1):.0%}"
    )
    if candidate_status(candidate) == "overlap_suppressed":
        selected = candidate["selection"]
        gates = f"Duplicate of {selected['retained_by'][:30]} | overlap {selected['overlap']:.1%}"
    cv2.rectangle(image, (0, 0), (image.shape[1], 61), (15, 15, 15), -1)
    cv2.putText(image, label, (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 220, 40), 1)
    cv2.putText(image, gates, (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (230, 230, 230), 1)
    cv2.rectangle(
        image, (0, image.shape[0] - 30), (image.shape[1], image.shape[0]), (15, 15, 15), -1
    )
    for x, text, rgb in [
        (8, "Supported", (40, 240, 80)),
        (140, "Contradicted", (255, 50, 70)),
        (305, "Behind depth", (150, 100, 250)),
        (480, "Unknown/outside", (255, 165, 30)),
    ]:
        cv2.putText(image, text, (x, image.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.48, rgb, 1)
    return image


def result_cloud(mesh, frame, report, *, index=0, _rendered=None, retained=None):
    """Measured scene plus only the camera-visible predicted CAD surface and pose axes."""
    _validate_context(mesh, frame, report)
    y, x = np.where(frame.depth > 0)
    ids = np.linspace(0, len(x) - 1, min(len(x), 30_000), dtype=int)
    y, x = y[ids], x[ids]
    z = frame.depth[y, x]
    points = [
        np.c_[
            (x - frame.camera[0, 2]) * z / frame.camera[0, 0],
            (y - frame.camera[1, 2]) * z / frame.camera[1, 1],
            z,
        ]
    ]
    colors = [frame.rgb[y, x]]
    if retained is not None:
        retained.update(scene_points=points[0], scene_colors=colors[0], scene_x=x, scene_y=y)
    if report["candidates"]:
        candidate = report["candidates"][index]
        pose = np.array(candidate["pose"]["source_to_target"])
        centered = pose.copy()
        centered[:3, 3] += pose[:3, :3] @ mesh.center
        xyz = (
            _rendered
            if _rendered is not None
            else render_xyz(mesh, centered, frame.camera, shape=frame.depth.shape)
        )
        y, x = np.where(xyz[..., 2] > 0)
        ids = np.linspace(0, len(x) - 1, min(len(x), 15_000), dtype=int)
        y, x = y[ids], x[ids]
        surface = xyz[y, x]
        delta = surface[:, 2] - frame.depth[y, x]
        known = (frame.depth[y, x] > 0) & _instance_frame(frame, candidate).mask[y, x]
        tolerance = report.get("fit_settings", {}).get("distance_tolerance_m", 0.005)
        rgb = np.tile([255, 165, 30], (len(x), 1))
        rgb[known & (np.abs(delta) <= tolerance)] = [40, 240, 80]
        rgb[known & (delta < -tolerance)] = [255, 50, 70]
        rgb[known & (delta > tolerance)] = [150, 100, 250]
        points.append(surface)
        colors.append(rgb)
        for axis in range(3):
            points.append(
                np.linspace(pose[:3, 3], pose[:3, 3] + pose[:3, axis] * mesh.diameter / 3, 100)
            )
            rgb = np.zeros(3, np.uint8)
            rgb[axis] = 255
            colors.append(np.tile(rgb, (100, 1)))
    return np.concatenate(points).astype(np.float32), np.concatenate(colors).astype(np.uint8)


def review_arrays(mesh, frame, report, index=0, *, image=True, cloud=True, retained=None):
    """Compose selected graphics with one call-local surface, never a cross-capture cache."""
    _validate_context(mesh, frame, report)
    xyz = None
    if (image or cloud) and report["candidates"]:
        pose = np.array(report["candidates"][index]["pose"]["source_to_target"])
        centered = pose.copy()
        centered[:3, 3] += pose[:3, :3] @ mesh.center
        xyz = render_xyz(mesh, centered, frame.camera, shape=frame.depth.shape)
    arrays = {}
    if image:
        arrays["overlay"] = overlay(mesh, frame, report, index, _rendered=xyz)
    if cloud:
        arrays["points"], arrays["colors"] = result_cloud(
            mesh, frame, report, index=index, _rendered=xyz, retained=retained
        )
    return arrays


def candidate_gallery(mesh, frame, report, selected_index=None, selected_overlay=None):
    """Bounded opt-in contact sheet; source-aligned overlays remain separate outputs."""
    _validate_context(mesh, frame, report)
    count = len(report["candidates"])
    if not 0 <= count <= 64:
        raise ValueError("Review up to 64 candidate proposals")
    columns = min(4, max(1, int(np.ceil(np.sqrt(count)))))
    rows = (max(1, count) + columns - 1) // columns
    width, height, header = 360, 270, 48
    image = np.full((rows * (height + header), columns * width, 3), 245, np.uint8)
    for i in range(max(1, count)):
        tile = (
            selected_overlay
            if i == selected_index and selected_overlay is not None
            else overlay(mesh, frame, report, i)
        )
        y, x = (i // columns) * (height + header), (i % columns) * width
        resized = cv2.resize(tile, (width, height), interpolation=cv2.INTER_AREA)
        image[y + header : y + header + height, x : x + width] = resized
        if count:
            candidate = report["candidates"][i]
            fit = candidate.get("fit") or {}
            status = candidate_status(candidate)
            color = (
                (15, 120, 55)
                if status == "accepted"
                else (155, 100, 5)
                if status == "overlap_suppressed"
                else (180, 40, 55)
            )
            label = f"{i + 1}: {candidate['id'][:30]}" + (" *" if i == selected_index else "")
            detail = f"{status} | support {fit.get('coverage', 0):.1%}"
        else:
            label, detail, color = "No candidates", "No pose accepted", (100, 70, 10)
        cv2.putText(image, label, (x + 7, y + 18), cv2.FONT_HERSHEY_SIMPLEX, 0.43, (25, 40, 50), 1)
        cv2.putText(image, detail, (x + 7, y + 38), cv2.FONT_HERSHEY_SIMPLEX, 0.43, color, 1)
    return image


def write_cloud(path, points, colors, frame_name):
    header = (
        "ply\nformat binary_little_endian 1.0\ncomment units=m frame="
        + frame_name
        + f"\nelement vertex {len(points)}\nproperty float x\nproperty float y\nproperty float z\n"
        + "property uchar red\nproperty uchar green\nproperty uchar blue\nend_header\n"
    )
    data = np.empty(len(points), dtype=[("xyz", "<f4", (3,)), ("rgb", "u1", (3,))])
    data["xyz"], data["rgb"] = points, colors
    Path(path).write_bytes(header.encode("utf-8") + data.tobytes())


def export_review(output, mesh, frame, report, fields=()):
    _validate_context(mesh, frame, report)
    output = Path(output)
    if output.exists():
        raise FileExistsError("Choose a new result directory")
    output.mkdir(parents=True)
    report["candidate_reviews"] = []
    for index in range(max(1, len(report["candidates"]))):
        suffix = "" if index == 0 else f"_{index:03d}"
        image_path, cloud_path = f"overlay{suffix}.png", f"fit{suffix}.ply"
        if not cv2.imwrite(
            str(output / image_path), overlay(mesh, frame, report, index)[..., ::-1]
        ):
            raise OSError("Could not write result overlay")
        points, colors = result_cloud(mesh, frame, report, index=index)
        write_cloud(output / cloud_path, points, colors, frame.frame)
        report["candidate_reviews"].append(
            dict(
                candidate_id=report["candidates"][index]["id"] if report["candidates"] else None,
                image=image_path,
                cloud=cloud_path,
            )
        )
    np.savez_compressed(
        output / "capture.npz",
        rgb=frame.rgb,
        depth=frame.depth,
        camera=frame.camera,
        mask=frame.mask,
        frame=np.array(frame.frame),
        units=np.array("m"),
    )
    if fields:
        np.savez_compressed(output / "learned_fields.npz", geometry=np.stack(fields))
    (output / "report.json").write_text(
        json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8", newline="\n"
    )
    return output
