"""Published allocentric 6D rotation / centroid-relative-Z pose decoding.

Adapted from GDRNPP 990003d rot_reps.py, pose_from_pred_centroid_z.py and
core/utils/utils.py (Apache-2.0). Modifications: NumPy output, explicit metric
and positive-depth checks, no training/autograd or dataset dependencies.
"""

import cv2
import numpy as np


def decode_pose(rotation6d, translation3, crop):
    rotation6d = np.asarray(rotation6d, np.float64)
    translation3 = np.asarray(translation3, np.float64)
    if (
        rotation6d.shape != (6,)
        or translation3.shape != (3,)
        or not np.isfinite(np.r_[rotation6d, translation3]).all()
    ):
        raise ValueError("Network must emit finite six-rotation / three-translation values")
    x = rotation6d[:3]
    if np.linalg.norm(x) < 1e-10:
        raise ValueError("Degenerate learned rotation")
    x = x / np.linalg.norm(x)
    z = np.cross(x, rotation6d[3:])
    if np.linalg.norm(z) < 1e-10:
        raise ValueError("Collinear learned rotation axes")
    z /= np.linalg.norm(z)
    allo = np.stack([x, np.cross(z, x), z], axis=1)
    center = translation3[:2] * crop.box_size + crop.center
    depth = translation3[2] * 64 / crop.scale
    if not 0.01 <= depth <= 100:
        raise ValueError("Learned translation is outside positive metric depth bounds")
    translation = np.linalg.solve(crop.camera, [*center, 1]) * depth
    ray = translation / np.linalg.norm(translation)
    axis = np.cross([0.0, 0.0, 1.0], ray)
    length = np.linalg.norm(axis)
    ego = (
        np.eye(3)
        if length < 1e-12
        else cv2.Rodrigues(axis / length * np.arctan2(length, ray[2]))[0]
    )
    pose = np.eye(4)
    pose[:3, :3] = ego @ allo
    pose[:3, 3] = translation
    return pose
