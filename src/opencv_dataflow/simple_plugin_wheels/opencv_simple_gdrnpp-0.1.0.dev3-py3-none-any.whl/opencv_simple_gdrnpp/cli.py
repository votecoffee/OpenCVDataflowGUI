"""Offline explicit-worker CLI; saved requests cannot choose executable code."""

import argparse
import json
from pathlib import Path

import cv2
import numpy as np

from .estimate import Detection, Estimator


def infer(request_path, model_directory, output, *, threads=4, batch_size=1):
    from .runtime import TorchModel

    request_path, output = Path(request_path), Path(output)
    if output.exists():
        raise FileExistsError("Choose a new result directory")
    request = json.loads(request_path.read_text(encoding="utf-8"))
    if request.get("schema") != "simple_gdrnpp_request/v1":
        raise ValueError("Expected a simple_gdrnpp_request/v1 file")
    path = (request_path.parent / request["rgb_path"]).resolve(strict=True)
    if path.stat().st_size > 50 * 1024 * 1024:
        raise ValueError("RGB file exceeds 50 MiB")
    bgr = cv2.imdecode(np.frombuffer(path.read_bytes(), np.uint8), cv2.IMREAD_UNCHANGED)
    if bgr is None or bgr.dtype != np.uint8 or bgr.ndim != 3 or bgr.shape[2] != 3:
        raise ValueError("Use an unambiguous uint8 three-channel RGB source file")
    if request.get("distortion", []) not in ([], [0, 0, 0, 0], [0, 0, 0, 0, 0]):
        raise ValueError("Rectify the image and supply its matching pinhole intrinsics first")
    detections = [Detection(**d) for d in request["detections"]]
    model = TorchModel(model_directory, threads=threads)
    report, fields = Estimator(model, batch_size=batch_size).predict(
        bgr[..., ::-1],
        request["camera_matrix"],
        detections,
        request["extents_m"],
        capture_id=request["capture_id"],
        source_frame=request.get("model_frame", "tless_object6"),
        camera_frame=request.get("camera_frame", "camera"),
    )
    output.mkdir(parents=True)
    (output / "report.json").write_text(
        json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8", newline="\n"
    )
    if fields:
        np.savez_compressed(output / "learned_fields.npz", geometry=np.stack(fields))
    return report


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    commands = p.add_subparsers(dest="command", required=True)
    run = commands.add_parser("infer")
    run.add_argument("request", type=Path)
    run.add_argument("--models", type=Path, required=True)
    run.add_argument("--output", type=Path, required=True)
    run.add_argument("--threads", type=int, default=4)
    run.add_argument("--batch-size", type=int, default=1)
    commands.add_parser("info")
    data = commands.add_parser(
        "check-data", help="Review calibrated training labels; no model training"
    )
    data.add_argument("definition", type=Path)
    data.add_argument("--output", type=Path, required=True)
    data.add_argument("--dataset-root", type=Path)
    data.add_argument("--max-previews", type=int, default=64)
    setup = commands.add_parser("setup", help="Retain object/reference assets; no network training")
    setup.add_argument("definition", type=Path)
    setup.add_argument("--recipe", type=Path, required=True, help="New portable recipe filename")
    inspect = commands.add_parser("inspect", help="Reopen setup without loading model weights")
    inspect.add_argument("recipe", type=Path)
    inspect.add_argument("--sha256")
    inspect.add_argument("--export-reference", type=Path)
    execute = commands.add_parser(
        "run", help="Run retained reference or explicit new RGB-D capture"
    )
    execute.add_argument("recipe", type=Path)
    execute.add_argument("--sha256")
    execute.add_argument("--models", type=Path, required=True)
    execute.add_argument("--output", type=Path, required=True)
    execute.add_argument("--capture", type=Path)
    a = p.parse_args(argv)
    if a.command == "check-data":
        from .training_review import export_training_review

        report, previews = export_training_review(
            a.definition, a.output, dataset_root=a.dataset_root, max_previews=a.max_previews
        )
        print(
            json.dumps(
                dict(
                    status=report["status"],
                    structurally_valid=report["structurally_valid"],
                    counts=report["counts"],
                    previews=len(previews),
                    review=str(a.output / "review.html"),
                    model_training_performed=False,
                )
            )
        )
        if not report["structurally_valid"]:
            raise SystemExit(2)
        return
    if a.command == "info":
        print(
            json.dumps(
                dict(
                    tool="SimpleGDRNPP",
                    version="0.1.0.dev0",
                    supported_object="T-LESS 6",
                    provider="published ConvNeXt GDRNPP PBR-only model",
                    training=False,
                    device="explicit CPU worker",
                    weights_bundled=False,
                    host_plugin=True,
                    native_setup=True,
                    retained_setup=True,
                )
            )
        )
    elif a.command == "infer":
        result = infer(a.request, a.models, a.output, threads=a.threads, batch_size=a.batch_size)
        print(
            json.dumps(
                dict(
                    candidates=len(result["candidates"]),
                    accepted=result["accepted_candidates"],
                    seconds=result["seconds"],
                ),
                indent=2,
            )
        )
    else:
        from .setup import describe, load_recipe, save_recipe
        from .workflow import create_setup, export_reference, load_capture, run_recipe

        if a.command == "setup":
            recipe = create_setup(a.definition)
            digest = save_recipe(a.recipe, recipe)
            print(json.dumps(dict(recipe_sha256=digest, **describe(recipe)), indent=2))
        elif a.command == "inspect":
            recipe = load_recipe(a.recipe, sha256=a.sha256)
            if a.export_reference:
                export_reference(recipe, a.export_reference)
            print(json.dumps(describe(recipe), indent=2))
        else:
            from .review import export_review
            from .runtime import TorchModel

            if a.output.exists():
                raise FileExistsError("Choose a new review directory")
            recipe = load_recipe(a.recipe, sha256=a.sha256)
            capture = load_capture(a.capture) if a.capture else None
            model = TorchModel(a.models, threads=recipe.settings.threads)
            report, fields = run_recipe(recipe, model, capture=capture)
            frame = (capture or recipe.reference).frame
            export_review(a.output, recipe.mesh, frame, report, fields)
            passed = report["accepted_candidates"] > 0
            print(
                json.dumps(
                    dict(
                        passed=passed,
                        candidates=len(report["candidates"]),
                        accepted=report["accepted_candidates"],
                        setup=report["setup"],
                        seconds=report["seconds"],
                    ),
                    indent=2,
                )
            )
            return 0 if passed else 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
