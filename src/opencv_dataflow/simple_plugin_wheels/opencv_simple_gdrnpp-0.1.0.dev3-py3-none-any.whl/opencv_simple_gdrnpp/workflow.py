"""Retained setup import and repeatable RGB-D preview/run, independent of the GUI."""

import json
import time
from pathlib import Path

import cv2
import numpy as np
from opencv_simple_foundation_pose.specs import Frame, Mesh

from .estimate import Detection, Estimator
from .execution import CandidateStages, execution_plan
from .overlap import suppress_overlaps
from .review import refine_depth, verify
from .runtime import CHECKPOINT_SHA256, SOURCE_COMMIT, SOURCE_CONFIG, validate_extents
from .setup import Capture, ExecutionSettings, Recipe, SourceCredit, strict_json


def read_json(path):
    path = Path(path)
    if path.stat().st_size > 1024 * 1024:
        raise ValueError("Setup/capture JSON exceeds 1 MiB")
    return strict_json(path.read_bytes())


def read_image(base, name):
    if not isinstance(name, str) or not name or "://" in name:
        raise ValueError("Select an explicit local image file")
    path = (Path(base) / name).resolve(strict=True)
    if not path.is_file() or path.stat().st_size > 50 * 1024 * 1024:
        raise ValueError("Reference image exceeds 50 MiB or is not a file")
    image = cv2.imdecode(np.frombuffer(path.read_bytes(), np.uint8), cv2.IMREAD_UNCHANGED)
    if image is None:
        raise ValueError("Cannot decode the selected image")
    return image


def capture_from_request(request, base):
    expected = {
        "schema",
        "capture_id",
        "rgb_path",
        "depth_path",
        "depth_scale_to_m",
        "camera_matrix",
        "model_frame",
        "camera_frame",
        "extents_m",
        "detections",
        "distortion",
    }
    if not isinstance(request, dict) or set(request) != expected:
        raise ValueError("Use the exact RGB-D capture request fields; do not include pose labels")
    if request["schema"] != "simple_gdrnpp_request/v1":
        raise ValueError("Expected a simple_gdrnpp_request/v1 capture")
    validate_extents(request["extents_m"])
    if request["distortion"] not in ([], [0, 0, 0, 0], [0, 0, 0, 0, 0]):
        raise ValueError("Rectify RGB/depth and supply the matching pinhole intrinsics")
    scale = request["depth_scale_to_m"]
    if isinstance(scale, bool) or not np.isfinite(scale) or not 1e-12 <= scale <= 1:
        raise ValueError("Declare stored axial-depth units to meters")
    rgb = read_image(base, request["rgb_path"])
    if rgb.dtype != np.uint8 or rgb.ndim != 3 or rgb.shape[2] != 3:
        raise ValueError("Retain an unambiguous uint8 three-channel source image")
    raw = read_image(base, request["depth_path"])
    if raw.ndim != 2 or raw.dtype not in (np.uint16, np.float32, np.float64):
        raise ValueError("Stored axial depth must be single-channel uint16 or float, not uint8")
    if not isinstance(request["detections"], list) or len(request["detections"]) > 64:
        raise ValueError("Provide up to 64 external detection records")
    detections = tuple(Detection(**d) for d in request["detections"])
    frame = Frame(
        rgb[..., ::-1],
        raw.astype(np.float32) * scale,
        request["camera_matrix"],
        np.ones(raw.shape, np.uint8),
        request["camera_frame"],
    )
    return Capture(frame, detections, request["capture_id"], request["model_frame"])


def load_capture(path):
    return capture_from_request(read_json(path), Path(path).parent)


def create_setup(path):
    path = Path(path)
    request = read_json(path)
    expected = {
        "schema",
        "name",
        "mesh_path",
        "mesh_scale_to_m",
        "reference",
        "symmetries_m",
        "settings",
        "credit",
    }
    if (
        not isinstance(request, dict)
        or set(request) != expected
        or request["schema"] != "simple_gdrnpp_setup/v1"
    ):
        raise ValueError("Expected an explicit simple_gdrnpp_setup/v1 definition")
    reference = capture_from_request(request["reference"], path.parent)
    mesh = Mesh.read(
        path.parent / request["mesh_path"],
        scale=request["mesh_scale_to_m"],
        frame=reference.model_frame,
    )
    return Recipe(
        request["name"],
        mesh,
        reference,
        request["symmetries_m"],
        ExecutionSettings(**request["settings"]),
        SourceCredit(**request["credit"]),
    )


def run_recipe(
    recipe, model, *, capture=None, cancelled=lambda: False, geometry_workers=None, retained=None
):
    if not isinstance(recipe, Recipe):
        raise TypeError("Run a validated retained recipe")
    current = recipe.reference if capture is None else capture
    if not isinstance(current, Capture) or current.model_frame != recipe.mesh.frame:
        raise ValueError("Current capture must identify this retained model's physical frame")
    plan = execution_plan(
        len(current.detections), current.frame.depth.size, recipe.settings.threads, geometry_workers
    )
    expected = dict(
        checkpoint_sha256=CHECKPOINT_SHA256,
        source_commit=SOURCE_COMMIT,
        source_config=SOURCE_CONFIG,
        object_id=6,
        threads=recipe.settings.threads,
    )
    if any(model.provenance.get(k) != v for k, v in expected.items()):
        raise ValueError("Worker model/thread policy differs from the retained setup")
    start = time.perf_counter()
    report, fields = Estimator(model, batch_size=recipe.settings.batch_size).predict(
        current.frame.rgb,
        current.frame.camera,
        current.detections,
        np.ptp(recipe.mesh.vertices, axis=0),
        capture_id=current.capture_id,
        source_frame=recipe.mesh.frame,
        camera_frame=current.frame.frame,
        cancelled=cancelled,
    )
    with CandidateStages(plan, cancelled=cancelled) as stages:
        if recipe.settings.depth_refine:
            tick = time.perf_counter()
            stages.run(
                "depth_refinement",
                report,
                lambda r, stop: refine_depth(
                    recipe.mesh,
                    current.frame,
                    r,
                    maximum_correction_m=recipe.settings.maximum_correction_m,
                    method=recipe.settings.depth_refinement,
                    fit_settings=recipe.settings.fit_settings(),
                    cancelled=stop,
                ),
                (
                    "best_pose",
                    "accepted_candidates",
                    "depth_refinement",
                    "depth_refinement_scope",
                    "same_depth_used_for_refinement_and_verification",
                ),
            )
            report["seconds"]["depth_refinement"] = time.perf_counter() - tick
        tick = time.perf_counter()
        stages.run(
            "depth_verification",
            report,
            lambda r, stop: verify(
                recipe.mesh,
                current.frame,
                r,
                recipe.settings.fit_settings(),
                cancelled=stop,
                **({"retained": retained} if retained is not None else {}),
            ),
            ("fit_settings", "fit_semantics", "verification_backend", "geometry_execution_backend"),
        )
        report["seconds"]["depth_verification"] = time.perf_counter() - tick
    report["candidate_execution"] = plan
    report["seconds"]["through_depth_verification"] = time.perf_counter() - start
    if recipe.settings.maximum_overlap < 1:
        tick = time.perf_counter()
        suppress_overlaps(
            recipe.mesh,
            current.frame,
            report,
            recipe.settings.maximum_overlap,
            cancelled=cancelled,
        )
        report["seconds"]["overlap_selection"] = time.perf_counter() - tick
        report["seconds"]["through_overlap_selection"] = time.perf_counter() - start
    report["setup"] = dict(
        name=recipe.name,
        content_sha256=recipe.content_sha256,
        retained_reference_capture=recipe.reference.capture_id,
        ran_retained_reference=capture is None,
        network_training=False,
    )
    report["assistance"] = (
        "Explicit external instance rectangles; no automatic detector or pose labels"
    )
    return report, fields


def export_reference(recipe, output):
    """Show what setup retained without loading or running any neural network."""
    from .preprocess import frame_signature
    from .review import result_cloud, write_cloud
    from .setup import describe

    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    frame = recipe.reference.frame
    image = frame.rgb.copy()
    for detection in recipe.reference.detections:
        x0, y0, x1, y1 = np.rint(detection.box).astype(int)
        cv2.rectangle(image, (x0, y0), (x1 - 1, y1 - 1), (40, 240, 80), 2)
        cv2.putText(
            image,
            detection.identifier,
            (x0, max(20, y0 - 8)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (255, 220, 40),
            1,
        )
    cv2.rectangle(image, (0, 0), (image.shape[1], 35), (15, 15, 15), -1)
    cv2.putText(
        image,
        "Retained reference | external boxes | no pose inference",
        (8, 24),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.5,
        (240, 240, 240),
        1,
    )
    if not cv2.imwrite(str(output / "reference.png"), image[..., ::-1]):
        raise OSError("Cannot write retained reference preview")
    report = dict(
        units="m",
        source_frame=recipe.mesh.frame,
        target_frame=frame.frame,
        input=frame_signature(frame.rgb, frame.camera),
        candidates=[],
    )
    xyz, rgb = result_cloud(recipe.mesh, frame, report)
    write_cloud(output / "reference_cloud.ply", xyz, rgb, frame.frame)
    (output / "setup.json").write_text(
        json.dumps(describe(recipe), indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    return output
