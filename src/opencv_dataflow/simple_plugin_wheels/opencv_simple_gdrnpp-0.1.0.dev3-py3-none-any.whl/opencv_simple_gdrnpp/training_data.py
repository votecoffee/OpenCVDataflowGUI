"""Calibrated BOP training-data checks; never call inference or alter a recipe.

Original implementation of the documented BOP scenewise file contract. Poses
retain the original CAD origin. The only unit conversion is millimeters to
meters, including the per-image depth scale. No model is trained by this module.
"""

import hashlib
import io
import itertools
import re
from pathlib import Path

import cv2
import numpy as np

from .wire import strict_json

SCHEMA = "simple_gdrnpp_training_dataset/v1"
ROLES = ("train", "validation", "test")
MAX_FILE = 50 * 1024 * 1024


def relative_path(root, value):
    if (
        not isinstance(value, str)
        or not value
        or "\\" in value
        or ":" in value
        or value.startswith("/")
        or ".." in Path(value).parts
    ):
        raise ValueError("Use a contained dataset-relative path")
    path = (root / value).resolve(strict=True)
    if not path.is_relative_to(root.resolve()):
        raise ValueError("A dataset path resolves outside its root")
    return path


def read_file(root, relative, hashes):
    path = relative_path(root, relative)
    if not path.is_file() or path.stat().st_size > MAX_FILE:
        raise ValueError("Dataset member exceeds its file bound")
    raw = path.read_bytes()
    if len(raw) > MAX_FILE:
        raise ValueError("Dataset member grew past its file bound")
    digest = hashlib.sha256(raw).hexdigest()
    if relative in hashes and hashes[relative] != digest:
        raise ValueError("Dataset member changed during checking")
    hashes[relative] = digest
    return raw


def image(root, relative, hashes):
    raw = read_file(root, relative, hashes)
    # Inspect the header before decoding to bound the expanded image, not just
    # its compressed bytes. BOP PNG/JPEG inputs are handled by the image reader.
    from PIL import Image

    with Image.open(io.BytesIO(raw)) as header:
        if min(header.size) < 2 or header.width * header.height > 2_000_000:
            raise ValueError("Bound dataset images to 2..2 million pixels")
    result = cv2.imdecode(np.frombuffer(raw, np.uint8), cv2.IMREAD_UNCHANGED)
    if result is None:
        raise ValueError("Cannot decode dataset image")
    return result


def integer(value, label, minimum=0):
    if isinstance(value, bool) or not isinstance(value, int) or not minimum <= value <= 999999:
        raise ValueError("Invalid " + label)
    return value


def numbers(value, shape, label):
    raw = np.asarray(value)
    if raw.dtype.kind not in "iuf" or raw.size != int(np.prod(shape)):
        raise ValueError("Invalid numeric " + label)
    result = raw.astype(np.float64).reshape(shape)
    if not np.isfinite(result).all():
        raise ValueError("Nonfinite " + label)
    return result


def camera_record(record):
    camera = numbers(record["cam_K"], (3, 3), "camera")
    if (
        min(camera[0, 0], camera[1, 1]) <= 0
        or np.max(np.abs(camera)) > 1e7
        or abs(camera[0, 1]) > 1e-9
        or abs(camera[1, 0]) > 1e-9
        or not np.allclose(camera[2], [0, 0, 1], atol=1e-9, rtol=0)
    ):
        raise ValueError("Use rectified pinhole camera intrinsics")
    scale = numbers([record["depth_scale"]], (1,), "depth scale")[0] * 0.001
    if not 0 < scale <= 1:
        raise ValueError("Invalid millimeter depth scale")
    return camera, float(scale)


def pose_record(record):
    rotation = numbers(record["cam_R_m2c"], (3, 3), "model-to-camera rotation")
    translation = numbers(record["cam_t_m2c"], (3,), "model-to-camera translation") * 0.001
    if (
        not np.allclose(rotation.T @ rotation, np.eye(3), rtol=0, atol=1e-4)
        or not np.isclose(np.linalg.det(rotation), 1, rtol=0, atol=1e-4)
        or np.max(np.abs(translation)) > 100
        or translation[2] <= 0
    ):
        raise ValueError("Use a proper camera pose with positive axial distance in meters")
    result = np.eye(4)
    result[:3, :3], result[:3, 3] = rotation, translation
    return result


def model_corners(info):
    low = numbers([info["min_" + axis] for axis in "xyz"], (3,), "CAD origin bounds") * 0.001
    size = numbers([info["size_" + axis] for axis in "xyz"], (3,), "CAD extents") * 0.001
    if np.any(size <= 0) or not 1e-5 <= np.linalg.norm(size) <= 10:
        raise ValueError("Verify millimeter CAD extents")
    return np.array(list(itertools.product(*zip(low, low + size))))


def project(points, pose, camera):
    xyz = np.asarray(points) @ pose[:3, :3].T + pose[:3, 3]
    if np.any(xyz[:, 2] <= 0):
        raise ValueError("Annotated CAD extends behind the camera")
    pixels = xyz @ camera.T
    return pixels[:, :2] / pixels[:, 2:3]


def _box(value):
    box = numbers(value, (4,), "visible bounding box")
    if np.any(box[2:] < 0):
        raise ValueError("Visible annotation has a negative bounding box")
    return box


def load_definition(path, dataset_root=None):
    path = Path(path).resolve(strict=True)
    if path.stat().st_size > 4 * 1024 * 1024:
        raise ValueError("Dataset definition exceeds 4 MiB")
    definition = strict_json(path.read_bytes())
    if not isinstance(definition, dict) or definition.get("schema") != SCHEMA:
        raise ValueError("Use a " + SCHEMA + " definition")
    if definition.get("model_units") != "mm":
        raise ValueError("This BOP importer requires explicit millimeter model units")
    ids = definition.get("object_ids")
    if not isinstance(ids, list) or not 1 <= len(ids) <= 64:
        raise ValueError("Choose 1..64 distinct object IDs")
    for object_id in ids:
        integer(object_id, "object ID", 1)
    if len(set(ids)) != len(ids):
        raise ValueError("Choose distinct object IDs")
    if not isinstance(definition.get("models_dir"), str):
        raise ValueError("Choose a relative BOP models directory")
    captures = definition.get("captures")
    if not isinstance(captures, list) or not 1 <= len(captures) <= 10000:
        raise ValueError("Choose 1..10000 explicitly selected captures")
    credit = definition.get("source_credit", {})
    if not all(
        isinstance(credit.get(k), str) and credit[k].strip()
        for k in ("title", "authors", "license", "source_url")
    ):
        raise ValueError("Retain dataset title, authors, license and source URL")
    root = (
        Path(dataset_root).resolve(strict=True)
        if dataset_root is not None
        else relative_path(path.parent, definition.get("root"))
    )
    if not root.is_dir():
        raise ValueError("Choose a dataset directory")
    return definition, root


def _capture(definition, root, selection, models, hashes):
    role = selection["role"]
    if role not in ROLES:
        raise ValueError("Choose train, validation or test explicitly")
    partition, group = selection["partition"], selection["group_id"]
    if not isinstance(partition, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", partition):
        raise ValueError("Invalid BOP partition name")
    if not isinstance(group, str) or not group.strip() or len(group) > 128:
        raise ValueError("Retain a capture group identity")
    if partition.startswith("test") and role != "test":
        raise ValueError("Benchmark test captures cannot become training or validation data")
    scene = integer(selection["scene_id"], "scene ID")
    frame = integer(selection["image_id"], "image ID")
    base = f"{partition}/{scene:06d}"
    metadata = {
        name: strict_json(read_file(root, base + "/" + name + ".json", hashes))
        for name in ("scene_camera", "scene_gt", "scene_gt_info")
    }
    camera, scale = camera_record(metadata["scene_camera"][str(frame)])
    labels, infos = metadata["scene_gt"][str(frame)], metadata["scene_gt_info"][str(frame)]
    if not isinstance(labels, list) or len(labels) != len(infos) or len(labels) > 1000:
        raise ValueError("Ground-truth poses and info must have matching instance indices")
    rgb_path = base + f"/rgb/{frame:06d}.png"
    try:
        relative_path(root, rgb_path)
    except FileNotFoundError:
        rgb_path = base + f"/rgb/{frame:06d}.jpg"
    rgb = image(root, rgb_path, hashes)
    depth_path = base + f"/depth/{frame:06d}.png"
    depth = image(root, depth_path, hashes)
    if rgb.dtype != np.uint8 or rgb.ndim != 3 or rgb.shape[2] != 3:
        raise ValueError("Use uint8 three-channel RGB images")
    if depth.dtype != np.uint16 or depth.shape != rgb.shape[:2]:
        raise ValueError("Use registered uint16 axial depth matching the RGB dimensions")
    if np.max(depth) * scale > 100:
        raise ValueError("Depth exceeds 100 m; verify its millimeter scale")
    identity = f"{partition}/{scene:06d}/{frame:06d}"
    rows = []
    for index, (label, info) in enumerate(zip(labels, infos)):
        object_id = integer(label["obj_id"], "ground-truth object ID", 1)
        if object_id not in definition["object_ids"]:
            continue
        pose = pose_record(label)
        mask_path = base + f"/mask_visib/{frame:06d}_{index:06d}.png"
        mask = image(root, mask_path, hashes)
        if (
            mask.dtype != np.uint8
            or mask.shape != depth.shape
            or not set(np.unique(mask)) <= {0, 255}
        ):
            raise ValueError("Use matching binary visible-instance masks with values 0/255")
        selected = mask != 0
        visible = int(np.count_nonzero(selected))
        count = info["px_count_visib"]
        if isinstance(count, bool) or not isinstance(count, int) or not 0 <= count <= mask.size:
            raise ValueError("Invalid visible pixel count")
        if visible != count:
            raise ValueError("Visible mask and ground-truth pixel count differ")
        fraction = float(numbers([info["visib_fract"]], (1,), "visible fraction")[0])
        if not 0 <= fraction <= 1:
            raise ValueError("Visible fraction must be in [0, 1]")
        source_box = (
            _box(info["bbox_visib"])
            if visible
            else numbers(info["bbox_visib"], (4,), "hidden bounding-box sentinel")
        )
        box = source_box.copy() if visible else np.zeros(4)
        if visible:
            y, x = np.nonzero(selected)
            actual = [
                int(x.min()),
                int(y.min()),
                int(x.max() - x.min() + 1),
                int(y.max() - y.min() + 1),
            ]
            # BOP stores max-min spans, including zero for a single pixel.
            # Preserve them and explicitly publish the max-min+1 crop size.
            expected = [actual[0], actual[1], actual[2] - 1, actual[3] - 1]
            if not np.array_equal(expected, source_box):
                raise ValueError("Visible mask and BOP bounding-box spans differ")
            box = np.asarray(actual, np.float64)
        corners = project(model_corners(models[str(object_id)]), pose, camera)
        if visible and (
            np.any(corners.max(axis=0) < box[:2]) or np.any(corners.min(axis=0) > box[:2] + box[2:])
        ):
            raise ValueError("Projected CAD bounds do not overlap the annotated part")
        rows.append(
            dict(
                id=identity + f"/{index:06d}",
                capture_id=identity,
                role=role,
                group_id=group,
                object_id=object_id,
                instance_index=index,
                rgb_path=rgb_path,
                depth_path=depth_path,
                visible_mask_path=mask_path,
                image_size=[int(rgb.shape[1]), int(rgb.shape[0])],
                camera_matrix=camera.tolist(),
                depth_scale_to_m=scale,
                model_to_camera_m=pose.tolist(),
                model_origin="Original BOP CAD origin; no recentering",
                bbox_visible_xywh=box.tolist(),
                bbox_visible_bop_xywh=source_box.tolist(),
                cad_bounds_pixels=corners.tolist(),
                visible_fraction=fraction,
                visible_pixels=visible,
                valid_depth_fraction=(
                    float(np.count_nonzero(selected & (depth > 0))) / visible if visible else 0.0
                ),
                usable=bool(visible),
                rgb_sha256=hashes[rgb_path],
            )
        )
    return identity, (partition, scene), group, rows


def load_model(root, model_dir, object_id, info, hashes):
    """Validate raw PLY before parsing; keep the publisher's original origin."""
    import trimesh

    raw = read_file(root, model_dir + f"/obj_{object_id:06d}.ply", hashes)
    header = raw[:65536].split(b"end_header", 1)
    if len(header) != 2 or not (raw.startswith(b"ply\n") or raw.startswith(b"ply\r\n")):
        raise ValueError("Use a bounded PLY model with an explicit header")
    for kind, limit in ((b"vertex", 250000), (b"face", 500000)):
        match = re.search(rb"(?m)^element\s+" + kind + rb"\s+(\d+)\s*$", header[0])
        if not match or not 4 <= int(match[1]) <= limit:
            raise ValueError("Verify bounded CAD vertex/triangle counts")
    mesh = trimesh.load(io.BytesIO(raw), file_type="ply", process=False)
    vertices, faces = np.asarray(mesh.vertices, np.float64) * 0.001, np.asarray(mesh.faces)
    if (
        vertices.ndim != 2
        or vertices.shape[1:] != (3,)
        or not np.isfinite(vertices).all()
        or faces.ndim != 2
        or faces.shape[1:] != (3,)
        or faces.dtype.kind not in "ui"
        or faces.min() < 0
        or faces.max() >= len(vertices)
    ):
        raise ValueError("Use finite CAD vertices and indexed triangles")
    corners = model_corners(info)
    if not np.allclose(
        [vertices.min(axis=0), vertices.max(axis=0)],
        [corners.min(axis=0), corners.max(axis=0)],
        atol=1e-5,
        rtol=0,
    ):
        raise ValueError("CAD geometry and declared millimeter bounds differ")
    return vertices, faces.astype(np.int32)


def check_dataset(path, *, dataset_root=None, cancelled=lambda: False):
    definition_hash = hashlib.sha256(Path(path).read_bytes()).hexdigest()
    definition, root = load_definition(path, dataset_root)
    if cancelled():
        raise RuntimeError("Training-data check cancelled; no dataset published")
    hashes, errors, warnings, samples = {}, [], [], []
    model_dir = definition["models_dir"]
    models = strict_json(read_file(root, model_dir + "/models_info.json", hashes))
    for object_id in definition["object_ids"]:
        model_corners(models[str(object_id)])
        load_model(root, model_dir, object_id, models[str(object_id)], hashes)
    groups, scenes, seen, exposures = {}, {}, {}, {}
    for ordinal, selection in enumerate(definition["captures"]):
        if cancelled():
            raise RuntimeError("Training-data check cancelled; no dataset published")
        try:
            identity, scene, group, rows = _capture(definition, root, selection, models, hashes)
            role = selection["role"]
            if identity in seen:
                raise ValueError("A capture occurs more than once in the split definition")
            if group in groups and groups[group] != role:
                raise ValueError("A capture group crosses training/validation/test roles")
            if scene in scenes and scenes[scene] != role:
                raise ValueError("One BOP acquisition scene crosses dataset roles")
            seen[identity], groups[group], scenes[scene] = role, role, role
            for row in rows:
                digest = row["rgb_sha256"]
                if digest in exposures and exposures[digest] != role:
                    raise ValueError("An identical RGB exposure crosses dataset roles")
                exposures[digest] = role
            if len(samples) + len(rows) > 100000:
                raise ValueError("Bound this preflight to 100000 instance labels")
            samples.extend(rows)
        except (ValueError, KeyError, TypeError, OSError) as error:
            errors.append(
                dict(
                    capture_index=ordinal,
                    code=type(error).__name__,
                    message=str(error)
                    if isinstance(error, ValueError)
                    else "Missing, unreadable or malformed dataset member",
                )
            )
    counts = {
        role: {
            str(i): sum(r["role"] == role and r["object_id"] == i and r["usable"] for r in samples)
            for i in definition["object_ids"]
        }
        for role in ROLES
    }
    for role in ("train", "validation"):
        for object_id, count in counts[role].items():
            if count == 0:
                errors.append(
                    dict(
                        code="missing_split_class",
                        role=role,
                        object_id=int(object_id),
                        message="Each object needs usable training and validation labels",
                    )
                )
            elif count < 20:
                warnings.append(
                    dict(
                        code="small_split_class",
                        role=role,
                        object_id=int(object_id),
                        message=(
                            "Fewer than 20 instances: a small workflow sample, "
                            "not training qualification"
                        ),
                    )
                )
    if any(not r["usable"] for r in samples):
        warnings.append(
            dict(
                code="invisible_instances",
                message="Fully hidden instances are retained but marked unusable",
            )
        )
    coverage = {}
    for object_id in definition["object_ids"]:
        coverage[str(object_id)] = {}
        for role in ROLES:
            selected = [
                r
                for r in samples
                if r["object_id"] == object_id and r["role"] == role and r["usable"]
            ]
            bins = [0] * 8
            distances = []
            for row in selected:
                pose = np.array(row["model_to_camera_m"])
                direction = -pose[:3, :3].T @ pose[:3, 3]
                bins[int(np.dot(direction >= 0, [1, 2, 4]))] += 1
                distances.append(float(np.linalg.norm(pose[:3, 3])))
            coverage[str(object_id)][role] = dict(
                camera_direction_octants=bins,
                occupied_octants=sum(n > 0 for n in bins),
                capture_groups=sorted({r["group_id"] for r in selected}),
                distance_range_m=[min(distances), max(distances)] if distances else None,
                visible_fraction_range=(
                    [
                        min(r["visible_fraction"] for r in selected),
                        max(r["visible_fraction"] for r in selected),
                    ]
                    if selected
                    else None
                ),
                scope="Raw camera-direction coverage; not symmetry-aware or an accuracy score",
            )
    if cancelled():
        raise RuntimeError("Training-data check cancelled; no dataset published")
    if hashlib.sha256(Path(path).read_bytes()).hexdigest() != definition_hash:
        raise ValueError("Dataset definition changed during checking")
    for relative in list(hashes):
        if cancelled():
            raise RuntimeError("Training-data check cancelled; no dataset published")
        read_file(root, relative, hashes)  # Final content check, not just timestamps.
    return dict(
        schema="simple_gdrnpp_training_check/v1",
        name=definition.get("name", "Training data"),
        object_ids=definition["object_ids"],
        class_mapping={str(i): n for n, i in enumerate(definition["object_ids"])},
        source_credit=definition["source_credit"],
        definition_sha256=definition_hash,
        units="m",
        pose_direction="Original CAD model to camera",
        structurally_valid=not errors,
        status="blocked" if errors else "needs_review" if warnings else "structure_checked",
        errors=errors,
        warnings=warnings,
        counts=counts,
        coverage=coverage,
        samples=samples,
        source_sha256=hashes,
        model_training_performed=False,
        model_accuracy_score=None,
        scope="Data/label readiness only; no optimizer, checkpoint, inference or inspection result",
    )
