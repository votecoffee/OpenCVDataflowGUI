"""Bounded call-local depth stages; ordered results and all-or-error publication."""

import copy
import threading
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait

PLANNING_BYTES = 512 * 1024 * 1024
AUTOMATIC_WORKERS = 4


def execution_plan(candidate_count, pixel_count, cpu_budget, requested=None):
    if requested is not None and (type(requested) is not int or not 1 <= requested <= 4):
        raise ValueError("Geometry workers must be None (automatic) or an integer in 1..4")
    if (
        type(candidate_count) is not int
        or not 0 <= candidate_count <= 64
        or type(pixel_count) is not int
        or not 1 <= pixel_count <= 2_000_000
        or type(cpu_budget) is not int
        or not 1 <= cpu_budget <= 32
    ):
        raise ValueError("Use validated candidate, pixel and CPU budgets")
    # Conservative concurrency estimate, not a measured peak/RSS guarantee.
    per_candidate = pixel_count * 96 + 32 * 1024 * 1024
    workers = min(
        requested or AUTOMATIC_WORKERS,
        cpu_budget,
        max(1, candidate_count),
        max(1, PLANNING_BYTES // per_candidate),
    )
    return dict(
        policy="bounded_depth_stages_v1",
        mode="automatic" if requested is None else "explicit",
        candidate_count=candidate_count,
        cpu_budget=cpu_budget,
        effective_workers=workers,
        estimated_bytes_per_active_candidate=per_candidate,
        planning_memory_budget_bytes=PLANNING_BYTES,
        stages=[],
    )


class CandidateStages:
    """One pool per inspection, no neural calls or cross-capture result cache."""

    def __init__(self, plan, *, cancelled=lambda: False):
        self.plan, self.cancelled = plan, cancelled
        self.stop = threading.Event()
        self.pool = None

    def __enter__(self):
        if self.plan["effective_workers"] > 1:
            self.pool = ThreadPoolExecutor(
                max_workers=self.plan["effective_workers"], thread_name_prefix="gdrnpp-depth"
            )
        return self

    def __exit__(self, *_):
        self.stop.set()
        if self.pool:
            self.pool.shutdown(wait=True, cancel_futures=True)

    def _check(self):
        if self.stop.is_set() or self.cancelled():
            self.stop.set()
            raise RuntimeError("Depth stage cancelled; no current result published")

    def run(self, name, report, function, common_keys):
        self._check()
        if self.pool is None:
            function(report, self.cancelled)
            self._check()
            self.plan["stages"].append(
                dict(
                    name=name,
                    tasks=len(report["candidates"]),
                    peak_in_flight=1 if report["candidates"] else 0,
                )
            )
            return
        candidates = report["candidates"]
        results, pending = [None] * len(candidates), {}
        cursor, peak = 0, 0

        def task(candidate):
            if self.stop.is_set():
                raise RuntimeError("Depth stage cancelled; no current result published")
            private = dict(report, candidates=[copy.deepcopy(candidate)])
            function(private, self.stop.is_set)
            return private

        try:
            while cursor < len(candidates) or pending:
                self._check()
                while cursor < len(candidates) and len(pending) < self.plan["effective_workers"]:
                    pending[self.pool.submit(task, candidates[cursor])] = cursor
                    cursor += 1
                peak = max(peak, len(pending))
                done, _ = wait(pending, timeout=0.02, return_when=FIRST_COMPLETED)
                for future in done:
                    index = pending.pop(future)
                    results[index] = future.result()
            self._check()
            # Compute everything before publishing any candidates/common stage fields.
            completed = []
            for original, result in zip(candidates, results, strict=True):
                values = result["candidates"]
                if len(values) != 1 or values[0]["id"] != original["id"]:
                    raise ValueError("Depth task changed its candidate identity")
                completed.append(values[0])
            shared = {key: results[0][key] for key in common_keys} if results else {}
            if name == "depth_verification":
                accepted = [c for c in completed if c["fit"]["status"] == "accepted"]
                accepted.sort(key=lambda c: -c["fit"]["coverage"])
                shared.update(
                    best_pose=accepted[0]["pose"] if accepted else None,
                    accepted_candidates=len(accepted),
                )
            for original, result in zip(candidates, completed, strict=True):
                original.clear()
                original.update(result)
            report.update(shared)
            self.plan["stages"].append(dict(name=name, tasks=len(candidates), peak_in_flight=peak))
        except BaseException:
            self.stop.set()
            for future in pending:
                future.cancel()
            raise
