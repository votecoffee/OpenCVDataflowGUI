"""Bounded robust projective point-to-plane alignment of first-return CAD to raw depth.

Original NumPy/OpenCV implementation. No pose labels, confidence fabrication,
scene completion, hidden CAD surfaces or publisher CUDA refiner are used.
"""

from dataclasses import asdict, dataclass

import cv2
import numpy as np
from opencv_simple_foundation_pose.specs import Frame, Mesh, Settings, rigid

from .geometry import BACKEND, render_xyz, visible_fit


@dataclass(frozen=True)
class RefinementSettings:
    strides: tuple = (4, 2, 1)
    iterations_per_level: int = 4
    maximum_correspondence_m: float = 0.02
    maximum_translation_m: float = 0.02
    maximum_rotation_degrees: float = 15.0
    minimum_correspondences: int = 50

    def __post_init__(self):
        strides = tuple(self.strides)
        if (
            not 1 <= len(strides) <= 4
            or strides[-1] != 1
            or any(type(v) is not int or not 1 <= v <= 16 for v in strides)
            or any(a <= b for a, b in zip(strides, strides[1:]))
        ):
            raise ValueError("Use 1..4 decreasing positive pyramid strides ending at 1")
        object.__setattr__(self, "strides", strides)
        for name, low, high in [
            ("iterations_per_level", 1, 20),
            ("minimum_correspondences", 10, 10000),
        ]:
            value = getattr(self, name)
            if type(value) is not int or not low <= value <= high:
                raise ValueError(f"{name} must be an integer in {low}..{high}")
        for name, low, high in [
            ("maximum_correspondence_m", 1e-5, 0.1),
            ("maximum_translation_m", 1e-5, 0.1),
            ("maximum_rotation_degrees", 0.01, 45),
        ]:
            value = getattr(self, name)
            if isinstance(value, bool) or not np.isfinite(value) or not low <= value <= high:
                raise ValueError(f"{name} must be finite in [{low},{high}]")
            object.__setattr__(self, name, float(value))


def _centered(mesh, pose):
    centered = pose.copy()
    centered[:3, 3] += pose[:3, :3] @ mesh.center
    return centered


def _fit(mesh, frame, pose, settings):
    return visible_fit(mesh, frame, _centered(mesh, pose), settings)


@dataclass(frozen=True)
class _PreparedLevel:
    depth: np.ndarray
    camera: np.ndarray
    rows: np.ndarray
    columns: np.ndarray
    observed: np.ndarray


def _prepare_level(frame, stride):
    """Prepare eligible measured rays once for this instance and pyramid level."""
    depth = frame.depth[::stride, ::stride]
    mask = frame.mask[::stride, ::stride]
    k = frame.camera.copy()
    k[:2] /= stride
    rows, columns = np.where(mask[1:-1, 1:-1] & (depth[1:-1, 1:-1] > 0))
    measured = depth[1:-1, 1:-1][rows, columns]
    observed = np.stack(
        (
            (columns + 1 - k[0, 2]) * measured / k[0, 0],
            (rows + 1 - k[1, 2]) * measured / k[1, 1],
            measured,
        ),
        axis=-1,
    )
    return _PreparedLevel(depth, k, rows, columns, observed)


def _correspondences(mesh, frame, pose, stride, maximum, cancelled=lambda: False, prepared=None):
    # Subsample actual sensor rays. This does not resize/interpolate/fill measured depth.
    level = prepared if prepared is not None else _prepare_level(frame, stride)
    if not len(level.rows):
        return np.empty((0, 3)), np.empty((0, 3)), np.empty((0, 3), np.float32)
    xyz = render_xyz(
        mesh, _centered(mesh, pose), level.camera, shape=level.depth.shape, cancelled=cancelled
    )
    valid = xyz[..., 2] > 0
    interior = (
        valid[1:-1, 1:-1] & valid[:-2, 1:-1] & valid[2:, 1:-1] & valid[1:-1, :-2] & valid[1:-1, 2:]
    )[level.rows, level.columns]
    y, x = level.rows[interior] + 1, level.columns[interior] + 1
    p = xyz[y, x].astype(np.float64)
    q = level.observed[interior]
    dx = xyz[y, x + 1] - xyz[y, x - 1]
    dy = xyz[y + 1, x] - xyz[y - 1, x]
    normal = np.cross(dx, dy)
    length = np.linalg.norm(normal, axis=-1)
    keep = (
        (length > 1e-12)
        & (np.linalg.norm(p - q, axis=-1) <= maximum)
        & (np.linalg.norm(dx, axis=-1) <= maximum)
        & (np.linalg.norm(dy, axis=-1) <= maximum)
    )
    return p[keep], q[keep], normal[keep] / length[keep, None]


def refine_pose(mesh, frame, initial, settings=None, *, fit_settings=None, cancelled=lambda: False):
    """Return an improved local proposal or the unchanged input, with explicit evidence.

    Fixed-gate violations must not worsen and support minus contradiction must
    improve. Translation is bounded at the physical model
    center so an arbitrary CAD origin cannot change the permitted motion.
    """
    if not isinstance(mesh, Mesh) or not isinstance(frame, Frame):
        raise TypeError("Use validated metric mesh and RGB-D inputs")
    settings = settings or RefinementSettings()
    fit_settings = fit_settings or Settings()
    if not isinstance(settings, RefinementSettings) or not isinstance(fit_settings, Settings):
        raise TypeError("Use validated refinement and independent fit settings")
    initial = rigid(initial)
    pose = initial.copy()
    initial_center = initial[:3, :3] @ mesh.center + initial[:3, 3]
    radius = mesh.diameter / 2
    trace = []
    stop = "iteration_budget"
    if cancelled():
        raise RuntimeError("Depth refinement cancelled; no result published")
    before = _fit(mesh, frame, initial, fit_settings)
    for stride in settings.strides:
        stop = "iteration_budget"
        if cancelled():
            raise RuntimeError("Depth refinement cancelled; no result published")
        prepared = _prepare_level(frame, stride)
        for iteration in range(settings.iterations_per_level):
            if cancelled():
                raise RuntimeError("Depth refinement cancelled; no result published")
            p, q, n = _correspondences(
                mesh, frame, pose, stride, settings.maximum_correspondence_m, cancelled, prepared
            )
            if len(p) < settings.minimum_correspondences:
                stop = "insufficient_correspondences"
                break
            center = pose[:3, :3] @ mesh.center + pose[:3, 3]
            residual = np.sum((p - q) * n, axis=1)
            scale = max(
                fit_settings.distance_tolerance / 2,
                1.4826 * np.median(np.abs(residual - np.median(residual))),
            )
            weight = np.minimum(1, 1.345 * scale / np.maximum(np.abs(residual), 1e-20))
            a = np.c_[np.cross(p - center, n) / radius, n]
            delta, _, rank, singular = np.linalg.lstsq(
                a * np.sqrt(weight[:, None]), -residual * np.sqrt(weight), rcond=1e-3
            )
            if rank < 3:
                stop = "insufficient_geometric_rank"
                break
            delta[:3] /= radius
            delta *= min(
                1,
                min(0.005, settings.maximum_translation_m) / max(np.linalg.norm(delta[3:]), 1e-20),
                np.deg2rad(min(3, settings.maximum_rotation_degrees))
                / max(np.linalg.norm(delta[:3]), 1e-20),
            )
            updated = None
            fraction = 1.0
            # Check the exact rigid update on the same correspondences before reprojecting.
            old_loss = float(np.mean(weight * residual**2))
            for fraction in (1.0, 0.5, 0.25):
                rotation = cv2.Rodrigues(delta[:3] * fraction)[0]
                moved = (p - center) @ rotation.T + center + delta[3:] * fraction
                loss = float(np.mean(weight * np.sum((moved - q) * n, axis=1) ** 2))
                if loss <= old_loss + 1e-18:
                    updated = pose.copy()
                    updated[:3, :3] = rotation @ pose[:3, :3]
                    updated[:3, 3] = (
                        rotation @ (pose[:3, 3] - center) + center + delta[3:] * fraction
                    )
                    break
            if updated is None:
                stop = "no_descent_step"
                break
            angle = np.rad2deg(
                np.arccos(np.clip((np.trace(updated[:3, :3] @ initial[:3, :3].T) - 1) / 2, -1, 1))
            )
            displacement = np.linalg.norm(
                updated[:3, :3] @ mesh.center + updated[:3, 3] - initial_center
            )
            if (
                displacement > settings.maximum_translation_m
                or angle > settings.maximum_rotation_degrees
            ):
                stop = "trust_region_bound"
                break
            trace.append(
                dict(
                    stride=stride,
                    iteration=iteration,
                    rank=int(rank),
                    samples=len(p),
                    robust_scale_m=float(scale),
                    point_to_plane_rmse_m=float(np.sqrt(np.mean(residual**2))),
                    rotation_step_degrees=float(np.rad2deg(np.linalg.norm(delta[:3]) * fraction)),
                    translation_step_m=float(np.linalg.norm(delta[3:]) * fraction),
                    singular_values=singular.tolist(),
                    line_search_fraction=fraction,
                )
            )
            pose = updated
            if (
                np.linalg.norm(delta[3:]) * fraction < 1e-5
                and np.linalg.norm(delta[:3]) * fraction < 1e-4
            ):
                stop = "converged"
                break
    if cancelled():
        raise RuntimeError("Depth refinement cancelled; no result published")
    after = _fit(mesh, frame, pose, fit_settings) if trace else before
    if cancelled():
        raise RuntimeError("Depth refinement cancelled; no result published")
    before_quality = before["coverage"] - before["contradiction"]
    after_quality = after["coverage"] - after["contradiction"]
    improvement = after_quality > before_quality + 1e-9
    safe = max(0, fit_settings.minimum_coverage - after["coverage"]) <= max(
        0, fit_settings.minimum_coverage - before["coverage"]
    ) and max(0, after["contradiction"] - fit_settings.maximum_contradiction) <= max(
        0, before["contradiction"] - fit_settings.maximum_contradiction
    )
    applied = bool(trace) and improvement and safe
    report = dict(
        method="projective_icp_v1",
        execution_backend=BACKEND,
        status="applied" if applied else "unavailable",
        reason="improved_fit_without_worsening_gate_violations"
        if applied
        else "no_safe_fit_improvement",
        stop_reason=stop,
        settings=asdict(settings),
        fit_before=before,
        proposed_fit=after,
        iterations=trace,
        minimum_observed_rank=min((v["rank"] for v in trace), default=0),
        all_solved_systems_full_rank=bool(trace) and all(v["rank"] == 6 for v in trace),
        same_depth_used_for_refinement_and_verification=True,
        pose_labels_used=False,
        before_quality=before_quality,
        proposed_quality=after_quality,
    )
    return (pose if applied else initial.copy()), report
