"""Bounded portable capture reader for the API's own numeric RGB-D review format."""

import io
from pathlib import Path
from zipfile import ZipFile

import numpy as np

from .persistence import bounded_array
from .specs import Frame

LIMIT = 64 * 1024 * 1024


def read_capture(path):
    path = Path(path)
    if path.stat().st_size > LIMIT:
        raise ValueError("Capture exceeds 64 MiB")
    with ZipFile(path) as archive:
        expected = {name + ".npy" for name in ("rgb", "depth", "camera", "mask", "frame", "units")}
        if (
            set(archive.namelist()) != expected
            or len(archive.namelist()) != len(expected)
            or sum(info.file_size for info in archive.infolist()) > LIMIT
        ):
            raise ValueError("Use the retained RGB-D/mask/camera capture members")
        arrays = {
            name: bounded_array(
                archive.read(name + ".npy"),
                dtypes=("|u1", "<i4", "<f4", "<f8", "|b1"),
            )
            for name in ("rgb", "depth", "camera", "mask")
        }
        # These two legacy metadata members are scalar Unicode, never object arrays.
        text = {}
        for name in ("frame", "units"):
            raw = archive.read(name + ".npy")
            if len(raw) > 4096:
                raise ValueError("Oversized capture metadata")
            stream = io.BytesIO(raw)
            version = np.lib.format.read_magic(stream)
            if version not in ((1, 0), (2, 0)):
                raise ValueError("Unsupported capture array format")
            reader = (
                np.lib.format.read_array_header_1_0
                if version == (1, 0)
                else np.lib.format.read_array_header_2_0
            )
            shape, _, dtype = reader(stream)
            if (
                shape != ()
                or dtype.kind != "U"
                or dtype.itemsize > 256
                or dtype.itemsize != len(raw) - stream.tell()
            ):
                raise ValueError("Capture metadata must be bounded Unicode scalars")
            text[name] = str(np.frombuffer(raw, dtype=dtype, offset=stream.tell())[0])
    if text["units"] != "m":
        raise ValueError("Retained capture depth must be physical axial meters")
    return Frame(arrays["rgb"], arrays["depth"], arrays["camera"], arrays["mask"], text["frame"])
