"""Exact worker-owned completion; retrieval performs no pose or geometry analysis."""

import hashlib
import json
from dataclasses import asdict

import numpy as np

SCHEMA = "simple_foundation_pose_completed/v1"
BINDING = "foundation_pose_completed_review"


def json_bytes(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def report_digest(report):
    return hashlib.sha256(
        json_bytes({k: v for k, v in report.items() if k != "request_timing"})
    ).hexdigest()


def transport_arrays(arrays):
    result = {}
    for name, value in arrays.items():
        if value.dtype.kind in "iu" and value.dtype.itemsize > 4:
            if value.size and (value.min() < -(2**31) or value.max() >= 2**31):
                raise ValueError("Stored indices exceed the lossless wire representation")
            value = value.astype(np.int32)
        result[name] = value
    return result


class RetainedExecution:
    def __init__(
        self, session, token, recipe, frame, capture_id, initial, report, evidence, scene, graphics
    ):
        if recipe._source_bytes is None or recipe._archive_sha256 is None:
            raise ValueError("Retain the exact loaded applied recipe before completed review")
        self.identity = dict(
            schema=SCHEMA,
            session=session,
            token=token,
            archive_sha256=recipe._archive_sha256,
            report_sha256=report_digest(report),
            candidates=len(report["candidates"]),
        )
        self.recipe, self.frame, self.capture_id = recipe, frame, capture_id
        self.initial, self.report, self.evidence = initial, report, evidence
        self.scene, self.graphics = scene, graphics

    def retrieve(self, operation, data):
        if data.get("identity") != self.identity:
            raise ValueError("Completed execution expired or belongs to another worker session")
        meta = dict(identity=self.identity)
        if operation == "capture_completed":
            raw = self.recipe._source_bytes
            width = min(len(raw), 1_000_000)
            packed = np.zeros(((len(raw) + width - 1) // width, width), np.uint8)
            packed.flat[: len(raw)] = np.frombuffer(raw, np.uint8)
            frame, reference = self.frame, self.recipe.reference
            arrays = dict(
                rgb=frame.rgb,
                depth=frame.depth,
                camera=frame.camera,
                mask=frame.mask,
                reference_rgb=reference.rgb,
                reference_depth=reference.depth,
                reference_camera=reference.camera,
                reference_mask=reference.mask,
                recipe_bytes=packed,
                initial_centered=self.evidence["initial_centered"],
                **self.scene,
            )
            if self.initial is not None:
                arrays["supplied_initial"] = self.initial
            meta.update(
                report=self.report,
                archive_bytes=len(raw),
                capture=dict(
                    capture_id=self.capture_id,
                    camera_frame=frame.frame,
                    model_frame=self.recipe.mesh.frame,
                    supplied_coarse_poses=self.initial is not None,
                ),
                setup=dict(
                    settings=asdict(self.recipe.settings),
                    model_frame=self.recipe.mesh.frame,
                    reference_camera_frame=reference.frame,
                    original_origin_preserved=True,
                    model_center_m=self.recipe.mesh.center.tolist(),
                    diameter_m=self.recipe.mesh.diameter,
                    weights=self.report["execution"]["backend"],
                ),
                scene_available=bool(self.scene),
                graphics=list(self.graphics),
                scope=(
                    "Exact consumed RGB-D/mask and original complete ranking cohort/fit samples. "
                    "Initial centered poses are model-bbox-centered camera transforms; "
                    "supplied initial poses and reported final poses use the original part frame."
                ),
            )
        elif operation == "capture_completed_candidate":
            index = data.get("index")
            if type(index) is not int or not 0 <= index < len(self.report["candidates"]):
                raise ValueError("Unknown completed candidate rank")
            candidate = self.report["candidates"][index]
            arrays = self.evidence["fits"].get(candidate["id"], {})
            meta.update(index=index, candidate_id=candidate["id"], available=bool(arrays))
        elif operation == "capture_completed_graphics":
            arrays = self.graphics
        else:
            raise ValueError("Unknown completed retrieval")
        return meta, transport_arrays(arrays)
