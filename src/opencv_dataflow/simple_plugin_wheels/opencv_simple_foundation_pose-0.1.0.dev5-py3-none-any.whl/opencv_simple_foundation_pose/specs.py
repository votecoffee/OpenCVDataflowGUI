"""Bounded RGB/axial depth in meters, explicit pinhole camera and retained model origin."""

from dataclasses import dataclass, field
from pathlib import Path

import numpy as np


def frozen(value, dtype):
    result = np.array(value, dtype=dtype, copy=True, order="C")
    result.flags.writeable = False
    return result


def rigid(value):
    pose = np.asarray(value, np.float64)
    if (
        pose.shape != (4, 4)
        or not np.isfinite(pose).all()
        or not np.allclose(pose[3], [0, 0, 0, 1], atol=1e-9, rtol=0)
        or not np.allclose(pose[:3, :3].T @ pose[:3, :3], np.eye(3), atol=1e-5, rtol=0)
        or not np.isclose(np.linalg.det(pose[:3, :3]), 1.0, atol=1e-5, rtol=0)
        or np.max(np.abs(pose[:3, 3])) > 100
    ):
        raise ValueError("Pose must be a finite proper rigid 4x4, translation within 100 m")
    result = pose.copy()
    u, _, vt = np.linalg.svd(result[:3, :3])
    result[:3, :3] = u @ vt
    return result


def capture_id(value):
    if (
        not isinstance(value, str)
        or not value.strip()
        or len(value) > 256
        or any(ord(c) < 32 for c in value)
    ):
        raise ValueError("Supply a nonempty capture ID of at most 256 characters")
    return value


def frame_name(value):
    if (
        not isinstance(value, str)
        or value != value.strip()
        or not 1 <= len(value) <= 64
        or any(ord(c) < 32 for c in value)
    ):
        raise ValueError("Use a plain nonempty frame name of at most 64 characters")
    return value


@dataclass(frozen=True)
class Frame:
    rgb: np.ndarray = field(repr=False)
    depth: np.ndarray = field(repr=False)
    camera: np.ndarray = field(repr=False)
    mask: np.ndarray = field(repr=False)
    frame: str = "camera"

    def __post_init__(self):
        rgb, depth, k, mask = map(np.asarray, (self.rgb, self.depth, self.camera, self.mask))
        if (
            depth.ndim != 2
            or min(depth.shape) < 2
            or depth.size > 2_000_000
            or depth.dtype.kind != "f"
            or rgb.shape != (*depth.shape, 3)
            or rgb.dtype != np.uint8
            or mask.shape != depth.shape
            or mask.dtype.kind not in "bui"
            or np.any(mask < 0)
        ):
            raise ValueError(
                "Use uint8 RGB, matching floating axial depth in meters and integer mask"
            )
        if len(np.unique(mask[mask != 0])) > 1:
            raise ValueError("Select one instance mask; do not merge a multi-instance label image")
        if (
            k.shape != (3, 3)
            or not np.isfinite(k).all()
            or np.max(np.abs(k)) > 1e7
            or min(k[0, 0], k[1, 1]) <= 0
            or abs(k[0, 1]) > 1e-12
            or abs(k[1, 0]) > 1e-12
            or not np.allclose(k[2], [0, 0, 1], atol=1e-12)
        ):
            raise ValueError("Connect rectified pinhole intrinsics with positive focal lengths")
        depth = np.where(np.isfinite(depth) & (depth > 0) & (depth <= 100), depth, 0)
        for name, value, dtype in (
            ("rgb", rgb, np.uint8),
            ("depth", depth, np.float32),
            ("camera", k, np.float64),
            ("mask", mask != 0, bool),
        ):
            object.__setattr__(self, name, frozen(value, dtype))
        frame_name(self.frame)


@dataclass(frozen=True)
class Mesh:
    vertices: np.ndarray = field(repr=False)
    faces: np.ndarray = field(repr=False)
    colors: np.ndarray | None = field(default=None, repr=False)
    frame: str = "part"
    center: np.ndarray = field(init=False, repr=False)
    normals: np.ndarray = field(init=False, repr=False)
    diameter: float = field(init=False)

    def __post_init__(self):
        vertices, faces = np.asarray(self.vertices), np.asarray(self.faces)
        if (
            vertices.ndim != 2
            or vertices.shape[1:] != (3,)
            or not 4 <= len(vertices) <= 20_000
            or not np.isfinite(vertices).all()
            or np.max(np.abs(vertices)) > 100
            or faces.ndim != 2
            or faces.shape[1:] != (3,)
            or not 4 <= len(faces) <= 100_000
            or faces.dtype.kind not in "ui"
            or faces.min() < 0
            or faces.max() >= len(vertices)
        ):
            raise ValueError("Use bounded finite metric vertices and integer triangle indices")
        colors = (
            np.full(vertices.shape, 128, np.uint8)
            if self.colors is None
            else np.asarray(self.colors)
        )
        if colors.shape != vertices.shape or colors.dtype != np.uint8:
            raise ValueError("Vertex colors must be uint8 RGB matching the vertices")
        triangles = vertices[faces]
        face_normal = np.cross(triangles[:, 1] - triangles[:, 0], triangles[:, 2] - triangles[:, 0])
        if np.max(np.linalg.norm(face_normal, axis=1)) < 1e-12:
            raise ValueError("Mesh needs nondegenerate physical triangle area")
        normals = np.zeros(vertices.shape, np.float64)
        for i in range(3):
            np.add.at(normals, faces[:, i], face_normal)
        lengths = np.linalg.norm(normals, axis=1)
        normals /= np.maximum(lengths[:, None], 1e-20)
        center = (vertices.min(axis=0) + vertices.max(axis=0)) / 2
        # Deterministic bounded diameter sample, with coordinate extrema retained.
        ids = np.unique(
            np.r_[
                np.linspace(0, len(vertices) - 1, min(len(vertices), 4096), dtype=int),
                np.argmin(vertices, axis=0),
                np.argmax(vertices, axis=0),
            ]
        )
        points = vertices[ids].astype(np.float64)
        diameter = (
            max(
                float(np.max(np.sum((points[i : i + 128, None] - points[None]) ** 2, axis=2)))
                for i in range(0, len(points), 128)
            )
            ** 0.5
        )
        if not 1e-5 <= diameter <= 10:
            raise ValueError("Model diameter must be 0.01 mm..10 m; verify mesh scale")
        for name, value, dtype in (
            ("vertices", vertices, np.float64),
            ("faces", faces, np.int32),
            ("colors", colors, np.uint8),
            ("center", center, np.float64),
            ("normals", normals, np.float64),
        ):
            object.__setattr__(self, name, frozen(value, dtype))
        object.__setattr__(self, "diameter", diameter)
        frame_name(self.frame)

    @classmethod
    def read(cls, path, *, scale, frame="part"):
        path = Path(path)
        if path.suffix.lower() not in (".ply", ".stl") or path.stat().st_size > 50 * 1024 * 1024:
            raise ValueError("Initial CPU pilot accepts local PLY/STL up to 50 MiB")
        if not np.isfinite(scale) or isinstance(scale, bool) or not 1e-9 <= scale <= 1e6:
            raise ValueError("Declare a positive mesh-to-meter scale")
        import trimesh

        loaded = trimesh.load(path, force="mesh", process=False)
        colors = loaded.visual.vertex_colors[:, :3] if loaded.visual.kind is not None else None
        return cls(np.asarray(loaded.vertices) * scale, loaded.faces, colors, frame)


@dataclass(frozen=True)
class Settings:
    iterations: int = 2
    refiner_batch: int = 8
    threads: int = 4
    inplane_steps: int = 6
    distance_tolerance: float = 0.005
    minimum_coverage: float = 0.7
    maximum_contradiction: float = 0.1

    def __post_init__(self):
        for name, maximum in (
            ("iterations", 5),
            ("refiner_batch", 32),
            ("threads", 8),
            ("inplane_steps", 6),
        ):
            if type(getattr(self, name)) is not int or not 1 <= getattr(self, name) <= maximum:
                raise ValueError(f"{name} must be an integer in 1..{maximum}")
        for name, low, high in (
            ("distance_tolerance", 1e-5, 0.1),
            ("minimum_coverage", 0.1, 1.0),
            ("maximum_contradiction", 0.0, 1.0),
        ):
            value = getattr(self, name)
            if isinstance(value, bool) or not np.isfinite(value) or not low <= value <= high:
                raise ValueError(f"{name} must be finite and in [{low}, {high}]")
            object.__setattr__(self, name, float(value))
