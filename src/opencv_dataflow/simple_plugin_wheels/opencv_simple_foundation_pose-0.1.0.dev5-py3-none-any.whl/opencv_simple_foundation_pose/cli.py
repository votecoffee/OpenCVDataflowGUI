"""Explicit offline recipe setup and CPU ONNX registration; no implicit asset downloads."""

import argparse
import json
from pathlib import Path

import cv2
import numpy as np

from .persistence import Recipe, load_recipe, save_recipe, strict_json
from .register import Estimator
from .review import export_review
from .runtime import OnnxModels
from .specs import Frame, Mesh, Settings


def read_frame(rgb, depth, mask, camera, scale, *, frame="camera"):
    if isinstance(scale, bool) or not np.isfinite(scale) or not 1e-12 <= scale <= 1:
        raise ValueError("Depth scale must convert stored axial depth into meters")
    image = cv2.imread(str(rgb), cv2.IMREAD_COLOR)
    raw = cv2.imread(str(depth), cv2.IMREAD_UNCHANGED)
    labels = cv2.imread(str(mask), cv2.IMREAD_GRAYSCALE)
    if image is None or raw is None or labels is None or raw.ndim != 2:
        raise ValueError("Provide readable RGB, one-channel axial depth and mask images")
    if raw.dtype not in (np.uint16, np.float32, np.float64):
        raise ValueError("Raw depth must be uint16/float32/float64; do not convert it to uint8")
    if isinstance(camera, (str, Path)):
        camera = strict_json(Path(camera).read_bytes())
    if isinstance(camera, dict):
        if camera.get("lens", "pinhole") != "pinhole" or np.any(camera.get("distortion", [])):
            raise ValueError("Rectify color and depth before running this tool")
        if "image_size" in camera and tuple(camera["image_size"]) != raw.shape[::-1]:
            raise ValueError("Camera dimensions differ from the current input")
        frame = camera.get("frame", frame)
        camera = camera.get("camera_matrix", camera.get("matrix"))
    return Frame(image[..., ::-1], raw.astype(np.float32) * scale, camera, labels, frame)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    train = commands.add_parser(
        "train", help="Retain mesh and calibrated reference; no network training"
    )
    train.add_argument("mesh", type=Path)
    train.add_argument("rgb", type=Path)
    train.add_argument("depth", type=Path)
    train.add_argument("mask", type=Path)
    train.add_argument("camera", type=Path)
    train.add_argument("recipe", type=Path)
    train.add_argument("--mesh-scale", type=float, required=True, help="Mesh units to meters")
    train.add_argument(
        "--depth-scale", type=float, required=True, help="Stored depth units to meters"
    )
    train.add_argument("--frame", default="part")
    run = commands.add_parser("run", help="Global registration of one explicitly selected instance")
    run.add_argument("recipe", type=Path)
    run.add_argument("rgb", type=Path)
    run.add_argument("depth", type=Path)
    run.add_argument("mask", type=Path)
    run.add_argument("--weights", type=Path, required=True)
    run.add_argument(
        "--camera", type=Path, help="Explicit new calibration; defaults to retained camera"
    )
    run.add_argument("--depth-scale", type=float, required=True)
    run.add_argument("--output", type=Path, required=True, help="New review directory")
    args = parser.parse_args(argv)
    if args.command == "train":
        mesh = Mesh.read(args.mesh, scale=args.mesh_scale, frame=args.frame)
        frame = read_frame(args.rgb, args.depth, args.mask, args.camera, args.depth_scale)
        digest = save_recipe(args.recipe, Recipe(mesh, frame, Settings()))
        print(json.dumps({"recipe_sha256": digest, "network_training": False}))
        return 0
    recipe = load_recipe(args.recipe)
    camera = args.camera if args.camera else recipe.reference.camera
    current = read_frame(
        args.rgb, args.depth, args.mask, camera, args.depth_scale, frame=recipe.reference.frame
    )
    if args.output.exists():
        raise ValueError("Choose a new review directory")
    models = OnnxModels(args.weights, threads=recipe.settings.threads)
    result = Estimator(recipe.mesh, models, recipe.settings).register(current)
    export_review(args.output, result)
    print(
        json.dumps(
            {
                "passed": result.best is not None,
                "accepted_candidates": len(result.accepted),
                "output": str(args.output),
            }
        )
    )
    return 0 if result.best is not None else 1


if __name__ == "__main__":
    raise SystemExit(main())
