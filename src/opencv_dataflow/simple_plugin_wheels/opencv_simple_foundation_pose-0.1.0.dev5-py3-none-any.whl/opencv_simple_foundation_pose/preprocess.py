# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.
# Adapted crop/normalization conventions from TAO's Apache-2.0
# foundationpose_postprocessor.py at 9a30f9692bf29fb728520e9dba1c79be2bf65e74.
# SPDX-License-Identifier: Apache-2.0
"""CPU tensor geometry; original measured depth is kept separate from model preprocessing."""

import cv2
import numpy as np


def xyz_map(depth, k):
    y, x = np.indices(depth.shape, dtype=np.float32)
    return np.stack(
        ((x - k[0, 2]) / k[0, 0] * depth, (y - k[1, 2]) / k[1, 1] * depth, depth), axis=-1
    ).astype(np.float32)


def filter_depth(depth):
    """TAO radius-2 mean/range filter; may fill model-input holes, never raw evidence."""
    valid = (depth >= 0.1) & (depth < 100)
    total = cv2.boxFilter(
        np.where(valid, depth, 0), -1, (5, 5), normalize=False, borderType=cv2.BORDER_CONSTANT
    )
    count = cv2.boxFilter(
        valid.astype(np.float32), -1, (5, 5), normalize=False, borderType=cv2.BORDER_CONSTANT
    )
    mean = total / np.maximum(count, 1)
    padded = np.pad(depth, 2)
    sums = np.zeros_like(depth)
    weights = np.zeros_like(depth)
    h, w = depth.shape
    for dy in range(-2, 3):
        for dx in range(-2, 3):
            current = padded[2 + dy : 2 + dy + h, 2 + dx : 2 + dx + w]
            selected = (current >= 0.1) & (current < 100) & (np.abs(current - mean) < 0.01)
            weight = (
                np.exp(-(dx * dx + dy * dy) / 8 - (depth - current) ** 2 / (2 * 1e10)) * selected
            )
            sums += weight * current
            weights += weight
    return np.where(weights > 0, sums / np.maximum(weights, 1e-20), 0).astype(np.float32)


def crop_transform(pose, diameter, k, ratio):
    center = k @ pose[:3, 3]
    if center[2] <= 0.1:
        raise ValueError("Model center must be beyond the network's 0.1 m near plane")
    u, v = center[:2] / center[2]
    radius = diameter * ratio / 2 * max(k[0, 0], k[1, 1]) / center[2]
    left, right, top, bottom = np.rint([u - radius, u + radius, v - radius, v + radius])
    if min(right - left, bottom - top) < 2:
        raise ValueError("Projected crop is degenerate")
    sx, sy = 160 / (right - left), 160 / (bottom - top)
    return np.array([[sx, 0, -left * sx], [0, sy, -top * sy], [0, 0, 1]], np.float64)


def warp_coordinates(transform, source_shape, output_shape=(160, 160)):
    """Kornia normalized homography + grid_sample align_corners=False convention."""
    h, w = source_shape[:2]
    y, x = np.indices(output_shape, dtype=np.float64)
    mapped = np.stack((x, y, np.ones_like(x)), axis=-1) @ np.linalg.inv(transform).T
    return mapped[..., 0] / mapped[..., 2] * w / (w - 1) - 0.5, mapped[..., 1] / mapped[
        ..., 2
    ] * h / (h - 1) - 0.5


def sample(image, x, y, *, linear=False):
    image = np.asarray(image)
    h, w = image.shape[:2]

    def gather(xs, ys):
        valid = (xs >= 0) & (ys >= 0) & (xs < w) & (ys < h)
        values = image[np.clip(ys, 0, h - 1), np.clip(xs, 0, w - 1)]
        return values * (valid[..., None] if image.ndim == 3 else valid)

    if not linear:
        return gather(np.rint(x).astype(int), np.rint(y).astype(int)).astype(np.float32)
    x0, y0 = np.floor(x).astype(int), np.floor(y).astype(int)
    a, b = x - x0, y - y0
    if image.ndim == 3:
        a, b = a[..., None], b[..., None]
    return (
        (1 - a) * (1 - b) * gather(x0, y0)
        + a * (1 - b) * gather(x0 + 1, y0)
        + (1 - a) * b * gather(x0, y0 + 1)
        + a * b * gather(x0 + 1, y0 + 1)
    ).astype(np.float32)


def scorer_xyz(crop_depth, transform, original_shape, k):
    """Fuse crop→original→XYZ→crop nearest warps without allocating full images per pose."""
    h, w = original_shape
    x, y = warp_coordinates(transform, original_shape)
    xi, yi = np.rint(x).astype(int), np.rint(y).astype(int)
    in_frame = (xi >= 0) & (xi < w) & (yi >= 0) & (yi < h)
    mapped = np.stack((xi, yi, np.ones_like(xi)), axis=-1) @ transform.T
    cx = mapped[..., 0] / mapped[..., 2] * 160 / 159 - 0.5
    cy = mapped[..., 1] / mapped[..., 2] * 160 / 159 - 0.5
    depth = sample(crop_depth, cx, cy) * in_frame
    return np.stack(
        ((xi - k[0, 2]) / k[0, 0] * depth, (yi - k[1, 2]) / k[1, 1] * depth, depth), axis=-1
    ).astype(np.float32)


def normalize_xyz(xyz, translation, radius):
    invalid = xyz[..., 2] < 0.1
    result = (xyz - translation) / radius
    result[invalid] = 0
    result[np.abs(result) >= 2] = 0
    return result.astype(np.float32)


def update_poses(poses, translation, rotation, diameter):
    result = poses.copy()
    for i, (trans, rot) in enumerate(zip(translation, rotation, strict=True)):
        # pytorch3d's row-vector SO(3) map is transposed by TAO before left composition.
        delta, _ = cv2.Rodrigues(-np.tanh(rot.astype(np.float64)) * np.deg2rad(20))
        result[i, :3, :3] = delta @ poses[i, :3, :3]
        result[i, :3, 3] += trans * (diameter / 2)
    return result
