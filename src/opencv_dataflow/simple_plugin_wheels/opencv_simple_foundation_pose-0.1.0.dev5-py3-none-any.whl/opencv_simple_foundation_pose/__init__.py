"""Experimental registration; heavyweight inference is loaded explicitly, never on import."""

from .specs import Frame, Mesh, Settings

__all__ = ["Frame", "Mesh", "Settings"]
