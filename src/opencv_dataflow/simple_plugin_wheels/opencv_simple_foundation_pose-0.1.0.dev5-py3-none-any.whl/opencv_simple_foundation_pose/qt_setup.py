"""Retained object setup, independent cancellable preview and transactional Stage."""

import json
import tempfile
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, replace
from pathlib import Path
from queue import Empty, Full, Queue
from threading import Event

import cv2
import numpy as np
from opencv_dataflow.canvas import pixmap
from opencv_dataflow.cloud_viewer import CloudViewer
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from opencv_dataflow.images import ImageArray
from opencv_dataflow.pointclouds import PointCloud
from PySide6.QtCore import QSize, Qt, QTimer
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListView,
    QListWidget,
    QListWidgetItem,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from .bridge import WorkerClient
from .capture import read_capture
from .dataflow import CAPTURE_PORTS, coarse_poses, connected_frame, project_recipe_path
from .machine import runtime_paths
from .persistence import Recipe, load_recipe, save_recipe, strict_json
from .qt_capture import CaptureFilesDialog, RuntimeDialog
from .qt_mask import InstanceMaskView
from .runtime import ASSETS, REVISION, verified_assets
from .specs import Frame, Mesh, Settings, frame_name
from .teaching import camera_cloud, model_cloud, read_mask, reference_health, target_depth_support


class FoundationPoseSetupDialog(QDialog):
    def __init__(self, parent, parameters, context, *, client=None):
        super().__init__(parent)
        self.setWindowTitle("SimpleFoundationPose — retain object setup")
        self.resize(1380, 940)
        self.parameters, self.context = parameters, context
        self.mesh = self.reference = self.original_mask = None
        self.last_result = self.pending = self.sealed = None
        self.closed, self.restoring, self.revision = False, False, 0
        self.client = client
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="foundation-setup")
        self.scratch = tempfile.TemporaryDirectory(prefix="foundation-setup-")
        self.progress_events = Queue(maxsize=1)
        self.unsubscribe = None
        self.coarse = None
        self.checked_backend = None
        self.reference_cache = None
        self.display_depth = None
        self.displayed_draft = None
        self.displayed_mesh = None
        layout = QVBoxLayout(self)
        self.identity = QLabel(
            "Import a metric mesh and calibrated reference, or reopen retained setup."
        )
        self.identity.setWordWrap(True)
        self.identity.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.identity)
        self.health = QLabel("Choose a calibrated RGB-D reference and mask one visible instance.")
        self.health.setWordWrap(True)
        self.health.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.health)
        self.filmstrip = QListWidget()
        self.filmstrip.setFlow(QListView.Flow.LeftToRight)
        self.filmstrip.setIconSize(QSize(84, 62))
        self.filmstrip.setFixedHeight(102)
        self.filmstrip.currentRowChanged.connect(self.show_source)
        layout.addWidget(self.filmstrip)
        splitter = QSplitter(Qt.Orientation.Horizontal)
        layout.addWidget(splitter, 1)
        side = QWidget()
        controls = QVBoxLayout(side)
        for label, action in (
            ("Runtime on this machine…", self.runtime),
            ("Import retained setup…", self.import_recipe),
            ("Import CAD mesh (PLY/STL)…", self.import_mesh),
            ("Reference from image files…", self.reference_files),
            ("Reference from retained capture…", self.reference_file),
            ("Capture connected reference", self.reference_connected),
            ("Import instance mask…", self.import_mask),
        ):
            self.button(controls, label, action)
        form = QFormLayout()
        self.fields = {}
        for key, label, value in (
            ("mesh_frame", "Original part frame", "part"),
            ("camera_frame", "Reference camera frame", "camera"),
            ("camera", "Rectified 3×3 K (JSON)", ""),
            ("depth_multiplier", "Reference depth multiplier (m)", "1.0"),
        ):
            self.field(form, key, label, value)
        self.settings_keys = tuple(asdict(Settings()))
        labels = dict(
            iterations="Refinement passes (1–5)",
            refiner_batch="Refinement batch (1–32)",
            threads="ONNX threads (1–8)",
            inplane_steps="In-plane steps (1–6)",
            distance_tolerance="Raw-depth tolerance (m)",
            minimum_coverage="Minimum support (0–1)",
            maximum_contradiction="Maximum free-space contradiction (0–1)",
        )
        for key, value in asdict(Settings()).items():
            self.field(form, key, labels[key], repr(value))
        self.execution_mode = QComboBox()
        self.execution_mode.addItems(["Connected RGB-D", "Retained reference"])
        self.execution_mode.setCurrentText(parameters.get("mode", "Connected RGB-D"))
        form.addRow("Execution after Apply", self.execution_mode)
        controls.addLayout(form)
        mask_form = QFormLayout()
        self.tool = QComboBox()
        self.tool.addItems(["pan", "brush", "rectangle", "circle", "polygon", "wand"])
        self.operation = QComboBox()
        self.operation.addItems(["Add target pixels", "Remove target pixels"])
        self.radius, self.tolerance = QSpinBox(), QSpinBox()
        self.radius.setRange(1, 100)
        self.radius.setValue(5)
        self.tolerance.setRange(0, 255)
        self.tolerance.setValue(25)
        for label, widget in (
            ("Mask tool", self.tool),
            ("Operation", self.operation),
            ("Brush radius (pixels)", self.radius),
            ("Wand RGB tolerance", self.tolerance),
        ):
            mask_form.addRow(label, widget)
        controls.addLayout(mask_form)
        row = QHBoxLayout()
        self.button(row, "Apply drawn region", self.apply_region)
        self.button(row, "Discard region", self.discard_region)
        controls.addLayout(row)
        row = QHBoxLayout()
        self.button(row, "Undo mask", lambda: self.editor.undo())
        self.button(row, "Restore imported mask", self.reset_mask)
        controls.addLayout(row)
        self.backend_status = QLabel()
        self.backend_status.setWordWrap(True)
        self.backend_status.setTextFormat(Qt.TextFormat.PlainText)
        controls.addWidget(self.backend_status)
        self.backend_button = self.button(controls, "Check worker and weights", self.check_backend)
        self.preview_reference_button = self.button(
            controls, "Preview reference pose", self.preview_reference
        )
        self.preview_file_button = self.button(
            controls, "Preview independent capture…", self.preview_file
        )
        self.preview_files_button = self.button(
            controls, "Preview independent image files…", self.preview_files
        )
        self.preview_wire_button = self.button(
            controls, "Preview connected capture", self.preview_connected
        )
        self.coarse_choice = QComboBox()
        self.coarse_choice.addItems(["Global rotation search", "Imported coarse proposals"])
        self.coarse_choice.currentIndexChanged.connect(self.preview_changed)
        controls.addWidget(
            QLabel("File/reference initialization; connected preview follows wired poses.")
        )
        controls.addWidget(self.coarse_choice)
        self.button(controls, "Load coarse proposals for preview…", self.import_coarse)
        controls.addStretch()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(side)
        splitter.addWidget(scroll)
        self.tabs = QTabWidget()
        self.editor = InstanceMaskView(self.tabs)
        self.editor.mask_changed.connect(self.invalidate)
        self.editor.region_changed.connect(self.region_changed)
        self.tabs.addTab(self.editor, "Reference / instance mask")
        self.model_view, self.reference_view, self.result_view = [
            self.cloud_view() for _ in range(3)
        ]
        self.tabs.addTab(self.model_view, "CAD / original part origin")
        self.tabs.addTab(self.reference_view, "Measured reference / camera")
        self.overlay = FilmstripImageView(self.tabs)
        self.tabs.addTab(self.overlay, "Preview pose / raw-depth fit")
        self.tabs.addTab(self.result_view, "Preview fit cloud")
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(
            ["Rank / ID", "Status", "Raw cohort logit", "Support", "Contradiction"]
        )
        self.tabs.addTab(self.table, "Preview candidates")
        splitter.addWidget(self.tabs)
        splitter.setSizes([425, 955])
        self.progress = QProgressBar()
        self.progress.setRange(0, 1)
        layout.addWidget(self.progress)
        self.status = QLabel(
            "Object setup retains CAD/RGB-D/mask/calibration, not new network weights."
        )
        self.status.setWordWrap(True)
        self.status.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.status)
        hint = QLabel(
            "Scroll to zoom. Draw then Apply region. Drag polygon points, Shift-click to "
            "insert, or right-click to remove. CPU pose search may take minutes."
        )
        hint.setWordWrap(True)
        layout.addWidget(hint)
        row = QHBoxLayout()
        self.stage_button = self.button(row, "Stage object setup", self.stage)
        self.cancel_button = self.button(row, "Cancel task", self.cancel_preview)
        self.button(row, "Cancel", self.reject)
        layout.addLayout(row)
        self.tool.currentTextChanged.connect(self.tools_changed)
        self.operation.currentIndexChanged.connect(self.tools_changed)
        self.radius.valueChanged.connect(self.tools_changed)
        self.tolerance.valueChanged.connect(self.tools_changed)
        self.timer = QTimer(self)
        self.timer.setInterval(40)
        self.timer.timeout.connect(self.poll)
        self.finished.connect(lambda *_: self.shutdown())
        if hasattr(context, "subscribe_outputs"):
            self.unsubscribe = context.subscribe_outputs(self.outputs_changed)
        if parameters.get("recipe_path"):
            self.safe(
                lambda: self.restore(
                    load_recipe(
                        project_recipe_path(context.project_dir, parameters["recipe_path"]),
                        sha256=parameters["sha256"],
                    )
                )
            )
        self.tools_changed()
        self.refresh()

    def button(self, layout, label, action):
        button = QPushButton(label)
        button.setAutoDefault(False)
        button.clicked.connect(lambda: self.safe(action))
        layout.addWidget(button)
        return button

    def field(self, form, key, label, value):
        widget = self.fields[key] = QLineEdit(value)
        widget.textChanged.connect(self.invalidate)
        form.addRow(label, widget)

    def cloud_view(self):
        view = CloudViewer(None, self)
        view.setWindowFlags(Qt.WindowType.Widget)
        return view

    def safe(self, action):
        try:
            return action()
        except Exception as error:
            self.status.setText(str(error))
            return None

    def choose(self, title, types):
        filename, _ = QFileDialog.getOpenFileName(self, title, "", types)
        return Path(filename) if filename else None

    def runtime(self):
        if self.pending:
            raise ValueError("Cancel and finish the preview before changing its runtime")
        if RuntimeDialog(self).exec() != QDialog.DialogCode.Accepted:
            return
        self.checked_backend = None
        old, self.client = self.client, None
        self.preview_changed()
        if old is not None:
            self.submit(lambda cancelled: old.close(), lambda _: None)
        self.refresh()

    def backend_paths(self):
        python, weights = runtime_paths()
        for name in ASSETS:
            if not (Path(weights) / name).is_file():
                raise ValueError(f"Select the weights revision folder containing {name}")
        return python, weights

    def check_backend(self):
        paths = self.backend_paths()
        self.checked_backend = None
        client = self.worker()
        self.status.setText("Checking the worker and both pinned ONNX files…")

        def work(cancelled):
            info, arrays = client.call("describe", {}, {}, cancelled=cancelled)
            if (
                arrays
                or info.get("protocol") != 1
                or info.get("weights_revision") != REVISION
                or info.get("provider") != "CPUExecutionProvider"
                or "register" not in info.get("operations", ())
            ):
                raise ValueError("Choose the installed SimpleFoundationPose CPU worker")
            verified_assets(paths[1], cancelled=cancelled)
            return paths

        def completed(checked):
            self.checked_backend = checked
            self.status.setText(
                "Worker responded and both ONNX hashes matched. Preview to test pose fit."
            )

        self.submit(work, completed)

    def restore(self, recipe):
        self.mesh = recipe.mesh
        self.restoring = True
        self.fields["mesh_frame"].setText(recipe.mesh.frame)
        for key, value in asdict(recipe.settings).items():
            self.fields[key].setText(repr(value))
        self.restoring = False
        self.set_reference(recipe.reference)

    def set_reference(self, current):
        if not isinstance(current, Frame):
            raise TypeError("Use a calibrated RGB-D reference")
        self.reference = current
        self.original_mask = current.mask.copy()
        self.restoring = True
        self.fields["camera_frame"].setText(current.frame)
        self.fields["camera"].setText(json.dumps(current.camera.tolist()))
        self.fields["depth_multiplier"].setText("1.0")
        self.editor.set_case(current.rgb, current.mask)
        self.display_depth = self.depth_plane(current.depth)
        self.filmstrip.clear()
        self.filmstrip.addItem(
            QListWidgetItem(QIcon(pixmap(ImageArray(current.rgb, "rgb"))), "RGB")
        )
        self.filmstrip.addItem(
            QListWidgetItem(QIcon(pixmap(ImageArray(self.display_depth, "rgb"))), "Measured depth")
        )
        self.filmstrip.addItem("Instance mask")
        support = QListWidgetItem("Mask/depth support")
        support.setToolTip("Turquoise: selected and usable. Orange: missing or below 100 mm.")
        self.filmstrip.addItem(support)
        self.filmstrip.setCurrentRow(0)
        self.restoring = False
        self.invalidate()
        self.show_source()

    def show_reference_cloud(self, current):
        xyz, colors, pixels = camera_cloud(current)
        self.reference_view.set_cloud(
            PointCloud(
                xyz,
                "m",
                current.frame,
                colors=colors,
                pixels=pixels,
                source_size=tuple(current.rgb.shape[1::-1]),
                metadata=dict(
                    observations=True, description="Raw measured reference only; no aligned CAD"
                ),
            )
        )

    @staticmethod
    def depth_plane(raw):
        known = raw > 0
        image = np.zeros(raw.shape, np.uint8)
        if known.any():
            low, high = np.percentile(raw[known], [1, 99])
            image[known] = np.rint(np.clip((raw[known] - low) / max(high - low, 1e-9), 0, 1) * 255)
        depth = cv2.applyColorMap(image, cv2.COLORMAP_TURBO)[..., ::-1]
        depth[~known] = 0
        return depth

    def show_source(self, *_):
        if self.reference is None or self.restoring:
            return
        row = self.filmstrip.currentRow()
        if row == 3:
            try:
                current = self.current_reference()
            except ValueError:
                self.editor.set_plane(self.reference.rgb)
                return
            rgb = current.rgb // 3
            rgb[current.mask] = (255, 165, 40)
            rgb[target_depth_support(current)] = (30, 235, 220)
            self.editor.set_plane(rgb, tint=False)
        elif row == 2:
            binary = (self.editor.mask * 255).astype(np.uint8)
            self.editor.set_plane(cv2.cvtColor(binary, cv2.COLOR_GRAY2RGB))
        elif row == 1:
            self.editor.set_plane(self.display_depth)
        else:
            self.editor.set_plane(self.reference.rgb)

    def show_model(self):
        name = frame_name(self.fields["mesh_frame"].text())
        xyz, rgb = model_cloud(self.mesh)
        self.model_view.set_cloud(
            PointCloud(
                xyz,
                "m",
                name,
                colors=rgb,
                metadata=dict(
                    observations=False, description="Canonical CAD plus original-origin axes"
                ),
            )
        )
        span = " × ".join(f"{size * 1000:.4g}" for size in np.ptp(self.mesh.vertices, axis=0))
        self.displayed_mesh = self.mesh
        self.identity.setText(
            f"CAD {name} · XYZ span {span} mm · diameter {self.mesh.diameter * 1000:.4g} mm\n"
            f"{len(self.mesh.vertices):,} vertices / {len(self.mesh.faces):,} triangles · "
            "original origin retained"
        )

    def tools_changed(self, *_):
        self.editor.tool = self.tool.currentText()
        self.editor.add = self.operation.currentIndex() == 0
        self.editor.radius, self.editor.tolerance = self.radius.value(), self.tolerance.value()
        self.tabs.setCurrentIndex(0)

    def apply_region(self):
        self.editor.apply_region()

    def discard_region(self):
        self.editor.region = None
        self.editor.draw_region()
        self.refresh()

    def region_changed(self):
        # Pending vector edits are not silently folded into the retained binary mask.
        self.stage_button.setEnabled(False)
        self.preview_reference_button.setEnabled(False)
        self.preview_file_button.setEnabled(False)
        self.preview_files_button.setEnabled(False)
        self.preview_wire_button.setEnabled(False)
        self.status.setText("Apply or discard the drawn region before previewing/staging.")

    def reset_mask(self):
        if self.reference is None:
            raise ValueError("Retain a reference first")
        self.editor.replace_mask(self.original_mask)

    def import_mask(self):
        if self.reference is None:
            raise ValueError("Retain a reference first")
        path = self.choose("Single-instance mask", "Masks (*.png *.tif *.tiff *.npy)")
        if path:
            try:
                selected = read_mask(path, self.reference.mask.shape)
            except ValueError as error:
                if "foreground label" not in str(error):
                    raise
                label, ok = QInputDialog.getInt(
                    self, "Choose one instance", "Foreground label", 1, 1, 2**30
                )
                if not ok:
                    return
                selected = read_mask(path, self.reference.mask.shape, label=label)
            self.editor.replace_mask(selected)

    def settings(self):
        defaults = asdict(Settings())
        return Settings(
            **{key: type(defaults[key])(self.fields[key].text()) for key in self.settings_keys}
        )

    def current_reference(self):
        if self.reference is None:
            raise ValueError("Import calibrated RGB-D and select one visible instance")
        controls = tuple(
            self.fields[k].text() for k in ("camera", "camera_frame", "depth_multiplier")
        )
        if self.reference_cache:
            source, mask, cached_controls, current = self.reference_cache
            if (
                source is self.reference
                and mask is self.editor.mask
                and controls == cached_controls
            ):
                return current
        scale = float(controls[2])
        if not np.isfinite(scale) or not 1e-6 <= scale <= 1e6:
            raise ValueError("Use a finite positive reference depth multiplier")
        current = Frame(
            self.reference.rgb,
            self.reference.depth * scale,
            strict_json(controls[0]),
            self.editor.mask,
            controls[1],
        )
        self.reference_cache = (self.reference, self.editor.mask, controls, current)
        return current

    def build_candidate(self):
        if self.mesh is None:
            raise ValueError("Import a metric CAD mesh first")
        name = frame_name(self.fields["mesh_frame"].text())
        mesh = self.mesh if name == self.mesh.frame else replace(self.mesh, frame=name)
        return Recipe(mesh, self.current_reference(), self.settings())

    def refresh(self):
        if self.closed or self.restoring:
            return
        valid = False
        lines = []
        try:
            current = self.current_reference()
        except (ValueError, TypeError) as error:
            lines.append(str(error))
            self.reference_view.set_cloud(None)
        else:
            key = (id(self.reference), self.reference_cache[2])
            if (
                key != getattr(self, "_reference_cloud_key", None)
                or self.reference_view.cloud is None
            ):
                self.show_reference_cloud(current)
                self._reference_cloud_key = key
            if self.displayed_draft is not current:
                self.displayed_draft = current
                support = target_depth_support(current)
                measured = int(np.count_nonzero(support))
                selected = int(np.count_nonzero(current.mask))
                depth_range = ""
                if measured:
                    values = current.depth[support]
                    depth_range = f" · {values.min() * 1000:.1f}–{values.max() * 1000:.1f} mm"
                h, w = current.depth.shape
                self.reference_details = (
                    f"Reference {current.frame} · {w} × {h} px · "
                    f"fx {current.camera[0, 0]:.2f} px, fy {current.camera[1, 1]:.2f} px\n"
                    f"Target mask: {measured:,}/{selected:,} pixels with usable depth"
                    f"{depth_range} · {selected - measured:,} missing/below 100 mm."
                )
                self.target_measured = measured
                self.update_mask_icons(current.mask, support)
            lines.append(self.reference_details)
            if self.target_measured < 12:
                lines.append("Select one visible instance with at least 12 depths ≥100 mm.")
            try:
                if self.mesh is None:
                    raise ValueError("Import metric CAD to complete setup.")
                if (
                    self.displayed_mesh is not self.mesh
                    or self.model_view.cloud is None
                    or self.model_view.cloud.frame != self.fields["mesh_frame"].text()
                ):
                    self.show_model()
                self.settings()
                valid = self.target_measured >= 12
            except (ValueError, TypeError) as error:
                lines.append(str(error))
        self.health.setText("\n".join(lines))
        if self.filmstrip.currentRow() in (2, 3):
            self.show_source()

        busy = self.pending is not None
        configured = False
        try:
            paths = self.backend_paths()
            configured = True
            backend = (
                "Worker answered and both hashes matched. Preview runs the ONNX models."
                if self.checked_backend == paths
                else "Runtime and weights selected. Check worker and weights before preview."
            )
        except (ValueError, OSError, TypeError) as error:
            backend = str(error)
        self.backend_status.setText(backend)
        self.backend_button.setEnabled(configured and not busy)
        self.cancel_button.setEnabled(busy)
        available = valid and not busy and self.editor.region is None
        self.stage_button.setEnabled(available and self.context.project_dir is not None)
        for button in (
            self.preview_reference_button,
            self.preview_file_button,
            self.preview_files_button,
            self.preview_wire_button,
        ):
            button.setEnabled(available and configured)

    def update_mask_icons(self, mask, support):
        shape = (84, 62)
        foreground = cv2.resize(mask.astype(np.uint8), shape, interpolation=cv2.INTER_NEAREST) > 0
        measured = cv2.resize(support.astype(np.uint8), shape, interpolation=cv2.INTER_NEAREST) > 0
        binary = np.zeros((62, 84, 3), dtype=np.uint8)
        binary[foreground] = (255, 255, 255)
        self.filmstrip.item(2).setIcon(QIcon(pixmap(ImageArray(binary, "rgb"))))
        binary[foreground] = (255, 165, 40)
        binary[measured] = (30, 235, 220)
        self.filmstrip.item(3).setIcon(QIcon(pixmap(ImageArray(binary, "rgb"))))

    def clear_preview(self):
        self.last_result = None
        self.overlay.image_item.setPixmap(QPixmap())
        self.result_view.set_cloud(None)
        self.table.setRowCount(0)

    def invalidate(self, *_):
        if self.restoring or self.closed:
            return
        self.revision += 1
        self.sealed = None
        self.cancel_preview()
        self.clear_preview()
        self.status.setText("Draft changed. Preview again to assess the current setup.")
        self.refresh()

    def preview_changed(self, *_):
        if hasattr(self, "status"):
            self.cancel_preview()
            self.clear_preview()
            self.status.setText("Preview initialization changed; run a new preview.")

    def cancel_preview(self):
        if self.pending:
            self.pending[1].set()
            self.pending[0].cancel()
            self.status.setText("Cancelling the current setup task…")

    def worker(self):
        if self.client is None:
            python, _ = runtime_paths()
            self.client = WorkerClient(
                python=python, timeout=self.parameters.get("timeout_seconds", 1800)
            )
        return self.client

    def submit(self, work, completed, *, publication=None):
        if self.closed:
            raise ValueError("Setup has closed")
        if self.pending:
            raise ValueError("Wait for the current work/cancellation to finish")
        cancellation = Event()
        revision = self.revision
        self.pending = (
            self.pool.submit(work, cancellation.is_set),
            cancellation,
            revision,
            completed,
            publication,
        )
        self.timer.start()
        self.progress.setRange(0, 0)
        self.refresh()

    def poll(self):
        if self.closed or self.pending is None:
            return
        try:
            revision, event = self.progress_events.get_nowait()
            if revision == self.revision and not self.pending[1].is_set():
                self.progress.setRange(0, max(event["total"], 1))
                self.progress.setValue(event["current"])
                self.status.setText(
                    f"{event['stage']}: {event['current']}/{event['total']} · "
                    "private preview, no pose committed"
                )
        except Empty:
            pass
        future, cancellation, revision, completed, publication = self.pending
        if not future.done():
            return
        self.pending = None
        self.timer.stop()
        self.progress.setRange(0, 1)
        self.progress.setValue(0)
        try:
            value = future.result()
            if (
                not cancellation.is_set()
                and revision == self.revision
                and (publication is None or publication == self.context.output_revision)
            ):
                completed(value)
            else:
                self.status.setText("Discarded stale or cancelled setup results.")
        except Exception as error:
            self.status.setText(str(error))
        self.refresh()

    def import_recipe(self):
        path = self.choose("Retained object setup", "FoundationPose (*.sfp)")
        if path:
            self.restore(load_recipe(path))

    def import_mesh(self):
        path = self.choose("Original CAD mesh", "Triangle mesh (*.ply *.stl)")
        if not path:
            return
        text, ok = QInputDialog.getText(
            self, "Declare mesh units", "Stored mesh units to meters", text="0.001"
        )
        if ok:
            self.import_mesh_path(path, float(text))

    def import_mesh_path(self, path, scale):
        client = self.worker()
        name = frame_name(self.fields["mesh_frame"].text())

        def work(cancelled):
            metadata, arrays = client.call(
                "import_mesh",
                dict(path=str(Path(path).resolve()), scale=scale, frame=name),
                cancelled=cancelled,
            )
            return Mesh(arrays["vertices"], arrays["faces"], arrays["colors"], metadata["frame"])

        def completed(mesh):
            self.mesh = mesh
            self.invalidate()
            if self.displayed_mesh is not mesh:
                self.show_model()
            self.status.setText(
                "Metric CAD retained with original origin; camera alignment not assumed."
            )

        self.submit(work, completed)

    def reference_files(self):
        dialog = CaptureFilesDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.set_reference(dialog.capture)

    def reference_file(self):
        path = self.choose("Retained RGB-D reference", "Calibrated capture (*.npz)")
        if path:
            self.set_reference(read_capture(path))

    def connected(self):
        self.context.refresh_images()
        bundle = self.context.snapshot_connected_inputs([*CAPTURE_PORTS, "coarse_poses"])
        values = {name: packet.value for name, packet in bundle.inputs.items()}
        payloads = {name: packet.payload for name, packet in bundle.inputs.items()}
        current, identity = connected_frame(
            values, payloads, depth_scale_to_m=self.parameters.get("depth_scale_to_m", 1)
        )
        return current, identity, values.get("coarse_poses"), self.context.output_revision

    def reference_connected(self):
        current, _, _, _ = self.connected()
        self.set_reference(current)

    def import_coarse(self):
        path = self.choose("Original part-to-camera proposals", "Pose hypotheses (*.json)")
        if path:
            if path.stat().st_size > 1024 * 1024:
                raise ValueError("Oversized coarse-pose file")
            self.coarse = strict_json(path.read_bytes())
            self.coarse_choice.setCurrentIndex(1)
            self.preview_changed()

    def preview_reference(self):
        self.preview_capture(self.current_reference(), title="Retained reference")

    def preview_file(self):
        path = self.choose("Independent RGB-D capture", "Calibrated capture (*.npz)")
        if path:
            self.preview_capture(read_capture(path), title=f"Independent: {path.name}")

    def preview_files(self):
        dialog = CaptureFilesDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.preview_capture(dialog.capture, title="Independent image files")

    def preview_connected(self):
        current, identity, coarse, publication = self.connected()
        self.preview_capture(
            current, title=f"Connected: {identity}", coarse=coarse, publication=publication
        )

    def preview_capture(
        self, current, *, title="Independent capture", coarse=None, publication=None
    ):
        if self.editor.region is not None:
            raise ValueError("Apply or discard the pending mask region")
        candidate = self.build_candidate()
        if not reference_health(candidate)["valid"]:
            raise ValueError("Retain a valid reference with measured target depth first")
        if self.sealed is None:
            path = Path(self.scratch.name) / (uuid.uuid4().hex + ".sfp")
            digest = save_recipe(path, candidate)
            self.sealed = path, digest
        path, digest = self.sealed
        client = self.worker()
        _, weights = runtime_paths()
        if coarse is None and self.coarse_choice.currentIndex() == 1:
            if self.coarse is None:
                raise ValueError("Import explicit coarse proposals, or choose global search")
            coarse = self.coarse
        arrays = dict(
            rgb=current.rgb, depth=current.depth, camera=current.camera, mask=current.mask
        )
        if coarse is not None:
            arrays["initial"] = coarse_poses(coarse, candidate, current)
        metadata = dict(
            recipe_path=str(path),
            recipe_sha256=digest,
            weights_dir=weights,
            capture_id="editor-preview:" + uuid.uuid4().hex,
            frame=current.frame,
            graphics=True,
        )
        revision, events = self.revision, self.progress_events

        def progress(event):
            try:
                events.put_nowait((revision, event))
            except Full:
                try:
                    events.get_nowait()
                except Empty:
                    pass
                events.put_nowait((revision, event))

        self.clear_preview()
        self.submit(
            lambda cancelled: client.call(
                "register", metadata, arrays, cancelled=cancelled, progress=progress
            ),
            lambda value: self.show_result(value, title),
            publication=publication,
        )

    def show_result(self, value, title):
        metadata, arrays = value
        report = metadata["report"]
        self.last_result = value
        self.overlay.set_image(pixmap(ImageArray(arrays["overlay_rgb"], "rgb")))
        self.result_view.set_cloud(
            PointCloud(
                arrays["review_xyz"],
                "m",
                report["target_frame"],
                colors=arrays["review_rgb"],
                metadata=dict(derived_review=True, review=report["review"]),
            )
        )
        self.result_view.flyaround.setChecked(True)
        self.table.setRowCount(len(report["candidates"]))
        for row, candidate in enumerate(report["candidates"]):
            fit = candidate["fit"]
            for col, text in enumerate(
                (
                    f"{row + 1} / {candidate['id']}",
                    fit["status"],
                    f"{candidate['raw_logit']:.6g}",
                    f"{fit['coverage']:.2%}",
                    f"{fit['contradiction']:.2%}",
                )
            ):
                self.table.setItem(row, col, QTableWidgetItem(text))
        best = report["candidates"][0] if report["candidates"] else None
        self.status.setText(
            f"{title}: {report['accepted_candidates']} accepted hypotheses. "
            + (
                f"Top proposal support {best['fit']['coverage']:.2%}; "
                if best
                else "No observed target; "
            )
            + report["execution"]["initialization"]
            + ". Rejected proposals remain diagnostic; no pose is committed by this editor."
        )
        self.tabs.setCurrentIndex(3)

    def outputs_changed(self, *_):
        if self.pending and self.pending[4] is not None:
            self.cancel_preview()
        if not self.closed:
            self.status.setText(
                "Graph publication changed. Capture/preview connected inputs again."
            )

    def stage(self):
        if self.pending or self.editor.region is not None or self.editor.gesture is not None:
            raise ValueError("Finish current work and apply/discard the drawn region before Stage")
        candidate = self.build_candidate()
        if not reference_health(candidate)["valid"]:
            raise ValueError("Retain a valid reference with at least 12 measured target depths")
        relative = f"assets/foundationpose/{uuid.uuid4().hex}.sfp"
        path = project_recipe_path(self.context.project_dir, relative)
        path.parent.mkdir(parents=True, exist_ok=True)
        digest = save_recipe(path, candidate)
        self.parameters.update(
            recipe_path=relative, sha256=digest, mode=self.execution_mode.currentText()
        )
        self.accept()

    def shutdown(self):
        if self.closed:
            return
        self.closed = True
        self.timer.stop()
        self.cancel_preview()
        if self.unsubscribe:
            self.unsubscribe()
        client, scratch = self.client, self.scratch

        def cleanup():
            try:
                if client is not None:
                    client.close()
            finally:
                scratch.cleanup()

        self.pool.submit(cleanup)
        self.pool.shutdown(wait=False, cancel_futures=False)

    def done(self, result):
        self.shutdown()
        super().done(result)
