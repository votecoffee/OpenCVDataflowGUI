"""Private binary-mask editing over the host's native zoom/pan source image view."""

import cv2
import numpy as np
from opencv_dataflow.canvas import pixmap
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from opencv_dataflow.images import ImageArray
from PySide6.QtCore import QRectF, Qt, Signal
from PySide6.QtGui import QColor, QPen
from PySide6.QtWidgets import QGraphicsItem


class InstanceMaskView(FilmstripImageView):
    mask_changed = Signal()
    region_changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.rgb = self.plane = self.mask = None
        self.tool, self.add, self.radius, self.tolerance = "pan", True, 5, 25
        self.region = self.gesture = None
        self.history, self.items = [], []
        self.tint = True

    def set_case(self, rgb, mask):
        self.tint = True
        self.rgb, self.plane = np.array(rgb, copy=True), np.array(rgb, copy=True)
        self.mask = np.array(mask, dtype=bool, copy=True)
        self.history, self.region, self.gesture = [], None, None
        self.refresh()
        self.fit_image()

    def set_plane(self, rgb, *, tint=True):
        self.tint = tint
        self.plane = np.array(rgb, copy=True)
        self.refresh()

    def refresh(self):
        if self.mask is None:
            return
        rgb = self.plane.copy()
        if self.tint:
            rgb[self.mask] = (rgb[self.mask].astype(float) * 0.6 + [20, 90, 60]).clip(0, 255)
            contours, _ = cv2.findContours(
                self.mask.astype(np.uint8), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE
            )
            cv2.drawContours(rgb, contours, -1, (40, 240, 140), 1)
        self.image_item.setPixmap(pixmap(ImageArray(rgb, "rgb")))
        self.setSceneRect(self.image_item.boundingRect())
        self.draw_region()

    def draw_region(self):
        for item in self.items:
            self.scene().removeItem(item)
        self.items = []
        if self.region is None:
            return
        shape, points = self.region
        pen = QPen(QColor(255, 210, 40), 1)
        pen.setCosmetic(True)
        if shape == "circle":
            a, b = np.asarray(points[0]), np.asarray(points[1])
            radius = max(1, float(np.linalg.norm(b - a)))
            box = QRectF(a[0] - radius, a[1] - radius, 2 * radius, 2 * radius)
            self.items.append(self.scene().addEllipse(box, pen))
        elif shape == "rectangle":
            a, b = points
            box = QRectF(a[0], a[1], b[0] - a[0], b[1] - a[1]).normalized()
            method = self.scene().addRect if shape == "rectangle" else self.scene().addEllipse
            self.items.append(method(box, pen))
        else:
            for a, b in zip(points, points[1:] + points[:1]):
                self.items.append(self.scene().addLine(*a, *b, pen))
        for x, y in points:
            handle = self.scene().addRect(-4, -4, 8, 8, pen, QColor(255, 210, 40))
            handle.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations)
            handle.setPos(x, y)
            self.items.append(handle)

    def checkpoint(self):
        self.history.append(self.mask.copy())
        del self.history[:-12]

    def replace_mask(self, mask):
        mask = np.asarray(mask, bool)
        if mask.shape != self.mask.shape:
            raise ValueError("Mask must match the retained source grid")
        self.checkpoint()
        self.mask = mask.copy()
        self.region = None
        self.refresh()
        self.mask_changed.emit()

    def undo(self):
        if self.history:
            self.mask = self.history.pop()
            self.region = None
            self.refresh()
            self.mask_changed.emit()

    def set_region(self, shape, points):
        if shape not in ("rectangle", "circle", "polygon"):
            raise ValueError("Choose rectangle, circle or polygon")
        h, w = self.mask.shape
        points = np.asarray(points, dtype=np.int32)
        if points.ndim != 2 or points.shape[1] != 2 or len(points) < 1:
            raise ValueError("Region requires pixel points")
        points = np.clip(points, [0, 0], [w - 1, h - 1]).tolist()
        if shape != "polygon" and len(points) != 2:
            raise ValueError("Use two opposite bounds for rectangle/circle")
        self.region = (shape, points)
        self.draw_region()
        self.region_changed.emit()

    def apply_region(self):
        if self.region is None:
            raise ValueError("Draw a region first")
        shape, points = self.region
        selected = np.zeros(self.mask.shape, np.uint8)
        if shape == "polygon":
            if len(points) < 3:
                raise ValueError("A polygon needs at least three vertices")
            cv2.fillPoly(selected, [np.asarray(points, np.int32)], 1)
        elif shape == "circle":
            center = np.asarray(points[0])
            radius = max(1, int(np.linalg.norm(np.asarray(points[1]) - center)))
            cv2.circle(selected, tuple(center), radius, 1, -1)
        else:
            a, b = np.min(points, axis=0), np.max(points, axis=0)
            if shape == "rectangle":
                cv2.rectangle(selected, tuple(a), tuple(b), 1, -1)
        value = self.mask.copy()
        value[selected != 0] = self.add
        self.replace_mask(value)

    def edit_vertex(self, index, point):
        shape, points = self.region
        points = [p.copy() for p in points]
        points[index] = list(point)
        self.set_region(shape, points)

    def insert_vertex(self, point):
        if self.region is None or self.region[0] != "polygon":
            return
        points = self.region[1]
        p = np.asarray(point)
        distances = []
        for a, b in zip(points, points[1:] + points[:1]):
            a, b = np.asarray(a), np.asarray(b)
            v = b - a
            t = np.clip(np.dot(p - a, v) / max(float(v @ v), 1), 0, 1)
            distances.append(np.linalg.norm(p - (a + t * v)))
        where = int(np.argmin(distances)) + 1
        self.set_region("polygon", points[:where] + [list(point)] + points[where:])

    def remove_vertex(self, index):
        if self.region and self.region[0] == "polygon":
            points = self.region[1]
            if len(points) > 3:
                self.set_region("polygon", points[:index] + points[index + 1 :])

    def wand(self, point):
        scratch = self.rgb.copy()
        selected = np.zeros((scratch.shape[0] + 2, scratch.shape[1] + 2), np.uint8)
        tolerance = (self.tolerance,) * 3
        cv2.floodFill(
            scratch,
            selected,
            tuple(point),
            0,
            tolerance,
            tolerance,
            flags=4 | cv2.FLOODFILL_FIXED_RANGE | cv2.FLOODFILL_MASK_ONLY,
        )
        value = self.mask.copy()
        value[selected[1:-1, 1:-1] != 0] = self.add
        self.replace_mask(value)

    def pixel(self, event):
        point = self.mapToScene(event.position().toPoint())
        if self.mask is None:
            return None
        h, w = self.mask.shape
        x, y = int(np.floor(point.x())), int(np.floor(point.y()))
        return (x, y) if 0 <= x < w and 0 <= y < h else None

    def nearest_handle(self, event):
        if self.region:
            for i, p in enumerate(self.region[1]):
                if (self.mapFromScene(*p) - event.position().toPoint()).manhattanLength() <= 12:
                    return i
        return None

    def mousePressEvent(self, event):
        point = self.pixel(event)
        if self.tool == "pan" or point is None:
            return super().mousePressEvent(event)
        index = self.nearest_handle(event)
        if event.button() == Qt.MouseButton.RightButton:
            if index is not None:
                self.remove_vertex(index)
            return
        if event.button() != Qt.MouseButton.LeftButton:
            return
        if event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
            self.insert_vertex(point)
        elif index is not None:
            self.gesture = ("handle", index)
        elif self.tool == "brush":
            self.checkpoint()
            self.gesture = ("brush", point)
            self.paint(point, point)
        elif self.tool == "wand":
            self.wand(point)
        elif self.tool == "polygon":
            points = self.region[1] if self.region and self.region[0] == "polygon" else []
            self.set_region("polygon", points + [point])
        else:
            self.set_region(self.tool, [point, point])
            self.gesture = ("handle", 1)
        event.accept()

    def paint(self, start, end):
        value = self.mask.astype(np.uint8)
        cv2.line(value, start, end, int(self.add), self.radius * 2 + 1)
        self.mask = value.astype(bool)
        self.refresh()

    def mouseMoveEvent(self, event):
        point = self.pixel(event)
        if self.gesture is None or point is None:
            return super().mouseMoveEvent(event)
        kind, value = self.gesture
        if kind == "brush":
            self.paint(value, point)
            self.gesture = (kind, point)
        else:
            self.edit_vertex(value, point)
        event.accept()

    def mouseReleaseEvent(self, event):
        if self.gesture:
            kind, _ = self.gesture
            self.gesture = None
            if kind == "brush":
                self.mask_changed.emit()
            event.accept()
        else:
            super().mouseReleaseEvent(event)
