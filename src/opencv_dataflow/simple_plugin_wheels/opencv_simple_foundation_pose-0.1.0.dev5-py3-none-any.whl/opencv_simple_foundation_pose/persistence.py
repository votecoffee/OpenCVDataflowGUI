"""Atomic retained metric mesh/reference archives; bounded arrays, strict JSON and no pickle."""

import hashlib
import io
import json
import math
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from tempfile import NamedTemporaryFile
from zipfile import ZIP_DEFLATED, BadZipFile, ZipFile, ZipInfo

import numpy as np

from .runtime import REVISION
from .specs import Frame, Mesh, Settings

LIMIT = 64 * 1024 * 1024


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError(f"Duplicate JSON key: {key}")
            result[key] = value
        return result

    def invalid(value):
        raise ValueError("Nonfinite JSON number")

    def floating(value):
        result = float(value)
        return result if np.isfinite(result) else invalid(value)

    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid, parse_float=floating)


@dataclass(frozen=True)
class Recipe:
    mesh: Mesh
    reference: Frame
    settings: Settings
    _source_bytes: bytes | None = field(default=None, repr=False, compare=False, kw_only=True)
    _archive_sha256: str | None = field(default=None, repr=False, compare=False, kw_only=True)

    def __post_init__(self):
        if (
            not isinstance(self.mesh, Mesh)
            or not isinstance(self.reference, Frame)
            or not isinstance(self.settings, Settings)
        ):
            raise TypeError("Retain a validated mesh, calibrated reference and settings")


def save_recipe(path, recipe):
    if not isinstance(recipe, Recipe):
        raise TypeError("Save a validated Recipe")
    arrays = {
        "vertices": recipe.mesh.vertices,
        "faces": recipe.mesh.faces,
        "colors": recipe.mesh.colors,
        "rgb": recipe.reference.rgb,
        "depth": recipe.reference.depth,
        "mask": recipe.reference.mask.astype(np.uint8),
    }
    entries = {}
    for name, value in arrays.items():
        stream = io.BytesIO()
        np.save(stream, value, allow_pickle=False)
        entries[name + ".npy"] = stream.getvalue()
    manifest = {
        "version": 1,
        "units": "m",
        "mesh_frame": recipe.mesh.frame,
        "camera_frame": recipe.reference.frame,
        "camera": recipe.reference.camera.tolist(),
        "settings": asdict(recipe.settings),
        "weights_revision": REVISION,
        "arrays": {n: hashlib.sha256(v).hexdigest() for n, v in entries.items()},
    }
    entries["recipe.json"] = json.dumps(manifest, indent=2, allow_nan=False).encode("utf-8")
    if sum(map(len, entries.values())) > LIMIT:
        raise ValueError("Retained recipe exceeds 64 MiB")
    path = Path(path)
    if path.exists():
        raise FileExistsError("Preserve existing training; choose a new recipe filename")
    with NamedTemporaryFile(dir=path.parent, prefix=".foundation-pose-", delete=False) as temporary:
        pending = Path(temporary.name)
    try:
        with ZipFile(pending, "w") as archive:
            for name, value in entries.items():
                info = ZipInfo(name, (1980, 1, 1, 0, 0, 0))
                info.compress_type, info.create_system = ZIP_DEFLATED, 0
                archive.writestr(info, value)
        if pending.stat().st_size > LIMIT:
            raise ValueError("Recipe archive exceeds 64 MiB")
        os.link(pending, path)
    finally:
        pending.unlink(missing_ok=True)
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bounded_array(raw, *, dtypes=("|u1", "<i4", "<f4", "<f8")):
    stream = io.BytesIO(raw)
    version = np.lib.format.read_magic(stream)
    if version not in ((1, 0), (2, 0)):
        raise ValueError("Only NPY version 1/2 is supported")
    reader = (
        np.lib.format.read_array_header_1_0
        if version == (1, 0)
        else np.lib.format.read_array_header_2_0
    )
    shape, _, dtype = reader(stream)
    size = math.prod(shape) * dtype.itemsize
    if (
        not 1 <= len(shape) <= 3
        or any(type(v) is not int or not 1 <= v <= 100_000 for v in shape)
        or dtype.str not in dtypes
        or size > LIMIT
        or size != len(raw) - stream.tell()
    ):
        raise ValueError("Invalid/oversized retained array")
    return np.load(io.BytesIO(raw), allow_pickle=False)


def load_recipe(path, *, sha256=None):
    path = Path(path)
    if path.stat().st_size > LIMIT:
        raise ValueError("Recipe archive exceeds 64 MiB")
    raw = path.read_bytes()
    archive_sha256 = hashlib.sha256(raw).hexdigest()
    if sha256 is not None and archive_sha256 != sha256:
        raise ValueError("Recipe SHA-256 differs")
    expected = {name + ".npy" for name in ("vertices", "faces", "colors", "rgb", "depth", "mask")}
    try:
        with ZipFile(io.BytesIO(raw)) as archive:
            names = archive.namelist()
            if (
                set(names) != expected | {"recipe.json"}
                or len(names) != len(set(names))
                or sum(i.file_size for i in archive.infolist()) > LIMIT
                or archive.getinfo("recipe.json").file_size > 1024 * 1024
            ):
                raise ValueError("Unexpected/duplicate/oversized recipe entries")
            manifest = strict_json(archive.read("recipe.json"))
            if (
                type(manifest["version"]) is not int
                or manifest["version"] != 1
                or manifest["units"] != "m"
                or manifest["weights_revision"] != REVISION
                or not isinstance(manifest["arrays"], dict)
                or set(manifest["arrays"]) != expected
            ):
                raise ValueError("Unsupported recipe manifest")
            arrays = {}
            for name, digest in manifest["arrays"].items():
                value = archive.read(name)
                if hashlib.sha256(value).hexdigest() != digest:
                    raise ValueError("Retained array checksum differs")
                arrays[name[:-4]] = bounded_array(value)
        return Recipe(
            Mesh(arrays["vertices"], arrays["faces"], arrays["colors"], manifest["mesh_frame"]),
            Frame(
                arrays["rgb"],
                arrays["depth"],
                manifest["camera"],
                arrays["mask"],
                manifest["camera_frame"],
            ),
            Settings(**manifest["settings"]),
            _source_bytes=raw,
            _archive_sha256=archive_sha256,
        )
    except (BadZipFile, KeyError, TypeError, OSError) as error:
        raise ValueError(f"Invalid retained FoundationPose recipe: {error}") from error
