"""Explicit RGB/registered-depth/mask/camera file teaching and machine runtime setup."""

from pathlib import Path

from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
)

from .machine import configure_runtime, runtime_paths
from .teaching import read_images


class CaptureFilesDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Calibrated reference from image files")
        self.resize(660, 320)
        self.capture = None
        layout = QVBoxLayout(self)
        hint = QLabel(
            "Depth must already be registered to RGB. Declare its stored units explicitly. "
            "Camera JSON: matrix, image_size [width,height], frame, zero distortion. "
            "An omitted mask starts blank for drawing a single visible instance."
        )
        hint.setWordWrap(True)
        layout.addWidget(hint)
        form = QFormLayout()
        self.fields = {}
        for key, label, value in (
            ("rgb", "RGB image", ""),
            ("depth", "Registered axial depth", ""),
            ("camera", "Camera JSON", ""),
            ("mask", "Instance mask (optional)", ""),
            ("depth_scale", "Stored depth to meters", "0.001"),
        ):
            field = QLineEdit(value)
            self.fields[key] = field
            if key == "depth_scale":
                form.addRow(label, field)
            else:
                row = QHBoxLayout()
                row.addWidget(field)
                button = QPushButton("Browse…")
                button.clicked.connect(lambda _=False, k=key: self.choose(k))
                row.addWidget(button)
                form.addRow(label, row)
        layout.addLayout(form)
        self.status = QLabel("")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Import calibrated capture")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def choose(self, key):
        filename, _ = QFileDialog.getOpenFileName(
            self,
            key,
            "",
            "Camera (*.json)" if key == "camera" else "Images (*.png *.tif *.tiff *.bmp)",
        )
        if filename:
            self.fields[key].setText(filename)

    def accept(self):
        try:
            values = {key: field.text().strip() for key, field in self.fields.items()}
            self.capture = read_images(
                values["rgb"],
                values["depth"],
                values["camera"],
                depth_scale=float(values["depth_scale"]),
                mask=values["mask"] or None,
            )
        except (ValueError, OSError, TypeError) as error:
            self.status.setText(str(error))
            return
        super().accept()


class RuntimeDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("FoundationPose runtime on this machine")
        layout = QVBoxLayout(self)
        hint = QLabel(
            "Choose an existing trusted isolated Python and external pinned NVIDIA weights. "
            "Saving changes this machine's runtime profile immediately, independently of "
            "inspector Apply/Cancel. Nothing is installed or downloaded."
        )
        hint.setWordWrap(True)
        layout.addWidget(hint)
        try:
            python, weights = runtime_paths()
        except (ValueError, OSError, KeyError):
            python = weights = ""
        self.fields = {}
        form = QFormLayout()
        for key, label, value in (
            ("python", "Isolated Python", python),
            ("weights", "Pinned weights folder", weights),
        ):
            field = self.fields[key] = QLineEdit(value)
            row = QHBoxLayout()
            row.addWidget(field)
            button = QPushButton("Browse…")
            button.clicked.connect(lambda _=False, k=key: self.choose(k))
            row.addWidget(button)
            form.addRow(label, row)
        layout.addLayout(form)
        self.status = QLabel("")
        layout.addWidget(self.status)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def choose(self, key):
        value = (
            QFileDialog.getExistingDirectory(self, "Pinned weights")
            if key == "weights"
            else QFileDialog.getOpenFileName(
                self, "Trusted isolated Python", "", "Python (python.exe python)"
            )[0]
        )
        if value:
            self.fields[key].setText(str(Path(value)))

    def accept(self):
        try:
            configure_runtime(*(self.fields[k].text() for k in ("python", "weights")))
        except (ValueError, OSError) as error:
            self.status.setText(str(error))
            return
        super().accept()
