"""Optional host adapter; ONNX Runtime and mesh import stay in the private worker."""

import copy
import re
from pathlib import Path

import numpy as np
from opencv_dataflow.core import Block, Port, Result
from opencv_dataflow.images import ImageArray, opencv_image
from opencv_dataflow.parameter_validation import NumericRange, ValidationError
from opencv_dataflow.payloads import NO_VALUE, ValuePacket, frame, require_same_frame
from opencv_dataflow.pointclouds import PointCloud

from .bridge import WorkerClient
from .completed_review import prepare_capture, retain_completed
from .machine import runtime_paths
from .persistence import load_recipe
from .specs import Frame, capture_id, rigid
from .worker_lease import WorkerLease

CAPTURE_PORTS = ("image", "depth", "mask", "camera", "capture_id")


def project_recipe_path(project_dir, relative):
    if project_dir is None:
        raise ValueError("Save the project before selecting retained training")
    if (
        not isinstance(relative, str)
        or not relative
        or "\\" in relative
        or ":" in relative
        or relative.startswith("/")
        or ".." in Path(relative).parts
        or Path(relative).suffix != ".sfp"
    ):
        raise ValueError("Use a project-relative .sfp recipe")
    root = Path(project_dir).resolve()
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise ValueError("Recipe resolves outside this project")
    return path


def connected_frame(inputs, payloads, *, depth_scale_to_m):
    if any(name not in inputs for name in CAPTURE_PORTS):
        raise ValueError(
            "Connect image, registered depth, one instance mask, camera and capture ID"
        )
    image = opencv_image(inputs["image"])
    raw, mask, camera = inputs["depth"], inputs["mask"], inputs["camera"]
    raw, mask = np.asarray(raw), np.asarray(mask)
    if raw.ndim != 2 or raw.dtype not in (np.uint16, np.float32, np.float64):
        raise ValueError("Connect registered uint16/float physical axial depth")
    require_same_frame(
        [ValuePacket(inputs[name], payloads.get(name, {})) for name in ("image", "depth", "mask")],
        message="Color, depth and mask declare different coordinate grids; register them first",
    )
    if (
        not isinstance(camera, dict)
        or camera.get("lens", "pinhole") != "pinhole"
        or np.any(camera.get("distortion", []))
        or tuple(camera.get("image_size", ())) != image.shape[1::-1]
    ):
        raise ValueError(
            "Declare rectified pinhole intrinsics with the matching image_size and frame"
        )
    units = getattr(inputs["depth"], "units", "unknown")
    if units not in ("unknown", "m", "mm"):
        raise ValueError("Declare metric m/mm depth or an explicit stored-depth conversion")
    scale = {"m": 1.0, "mm": 0.001}.get(units, depth_scale_to_m)
    if isinstance(scale, bool) or not np.isfinite(scale) or not 1e-12 <= scale <= 1:
        raise ValueError("Declare a positive stored-depth to meter scale")
    current = Frame(
        image[..., ::-1],
        raw.astype(np.float32) * scale,
        camera.get("camera_matrix", camera.get("matrix")),
        mask,
        camera.get("frame"),
    )
    return current, capture_id(inputs["capture_id"])


def coarse_poses(values, recipe, current):
    if not isinstance(values, list) or not 1 <= len(values) <= 252:
        raise ValueError("Supply 1..252 explicit pose_3d_v1 coarse hypotheses")
    poses = []
    for value in values:
        if (
            not isinstance(value, dict)
            or value.get("model") != "pose_3d_v1"
            or value.get("units") != "m"
            or value.get("source_frame") != recipe.mesh.frame
            or value.get("target_frame") != current.frame
        ):
            raise ValueError(
                "Coarse poses must map the retained original part frame to this camera in m"
            )
        poses.append(rigid(value["source_to_target"]))
    return np.asarray(poses, dtype=np.float64)


class SimpleFoundationPose(Block):
    type_id = "3d.simple_foundation_pose"
    title = "SimpleFoundationPose"
    category = block_type = "3D vision"
    subtype = "Learned object pose"
    composes_result_image = True
    process_inputs_readonly = True
    parallel_safe = False
    preview_safe = False
    plugin_dialog_label = "Set up object…"
    plugin_dialog_modeless = True
    plugin_review_dialog_label = "Review completed poses and score cohort…"
    inputs = tuple(
        Port(name, kind, required=False, required_when_connected=True)
        for name, kind in (
            ("image", "image"),
            ("depth", "depth"),
            ("mask", "image"),
            ("camera", "data"),
            ("capture_id", "text"),
            ("coarse_poses", "data"),
        )
    )
    outputs = (
        Port("report", "data"),
        Port("pose", "data", required=False),
        Port("poses", "data"),
        Port("accepted_count", "integer"),
        Port("overlay", "image", required=False),
        Port("cloud", "cloud", required=False),
        Port("candidate_table", "data"),
    )
    defaults = dict(
        recipe_path="",
        sha256="",
        mode="Connected RGB-D",
        depth_scale_to_m=1.0,
        render_graphics=True,
        timeout_seconds=1800.0,
    )
    parameter_choices = {"mode": ("Connected RGB-D", "Retained reference")}
    parameter_ranges = {
        "depth_scale_to_m": NumericRange(1e-12, 1),
        "timeout_seconds": NumericRange(1, 7200),
    }
    parameter_help = {
        "recipe_path": "Project-relative .sfp mesh and retained RGB-D/mask/camera.",
        "sha256": "Complete retained recipe hash. Changed training requires a new file and hash.",
        "mode": "Run a connected current capture, or explicitly rerun the retained reference.",
        "depth_scale_to_m": "Stored depth only; m/mm tagged depth already declares units.",
        "render_graphics": "Pose/fit overlay and native colored diagnostic cloud.",
        "timeout_seconds": "Deadline; cancellation/timeout retires the worker tree.",
    }
    input_help = {
        "mask": "One visible instance, same image grid; nonzero selects target.",
        "camera": "Rectified pinhole: matrix, image_size [width,height], frame.",
        "depth": "Physical axial depth already registered to RGB.",
        "capture_id": "Explicit acquisition identity; never reuse a previous pose on failure.",
        "coarse_poses": "Optional part-to-camera poses in m; coarse assistance is reported.",
    }
    output_help = {
        "pose": "Best raw-depth-accepted hypothesis, absent on rejection. This is not a grasp.",
        "poses": "Accepted alternatives for ONE instance; these are not multiple detected parts.",
        "cloud": "Diagnostic scene and derived CAD/axes, including rejected proposals.",
        "candidate_table": "Every hypothesis, rank, raw logit, support, contradiction and status.",
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._client = None
        self._lease = None
        self._completed_record = None
        self._recipe_key = self._recipe = None
        self.preview_output = "cloud"

    @property
    def filmstrip_output(self):
        return "overlay"

    def validate_parameters(self, parameters=None):
        super().validate_parameters(parameters)
        p = self.parameters if parameters is None else parameters
        if p["recipe_path"]:
            try:
                project_recipe_path(self.project_dir, p["recipe_path"])
            except ValueError as error:
                raise ValidationError(str(error), "recipe_path") from error
            if (
                not isinstance(p["sha256"], str)
                or re.fullmatch("[a-f0-9]{64}", p["sha256"]) is None
            ):
                raise ValidationError("Pin the complete .sfp SHA-256", "sha256")
        if type(p["render_graphics"]) is not bool:
            raise ValidationError("Rendering option must be boolean", "render_graphics")

    def _training(self):
        p = self.parameters
        path = project_recipe_path(self.project_dir, p["recipe_path"])
        stat = path.stat()
        key = (str(path), p["sha256"], stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)
        if key != self._recipe_key:
            self._recipe = self._recipe_key = None
            self._recipe = load_recipe(path, sha256=p["sha256"])
            self._recipe_key = key
        return path, self._recipe

    def process(self, inputs):
        self._completed_record = None
        p = self.parameters
        try:
            path, recipe = self._training()
            if p["mode"] == "Connected RGB-D":
                current, capture_id = connected_frame(
                    inputs,
                    self.input_payloads,
                    depth_scale_to_m=p["depth_scale_to_m"],
                )
                payload = copy.deepcopy(self.input_payloads.get("image", {}))
            else:
                if any(name in inputs for name in CAPTURE_PORTS):
                    raise ValueError(
                        "Retained-reference mode must not ignore connected current inputs"
                    )
                current, capture_id = recipe.reference, f"reference:{p['sha256']}"
                payload = {"spatial": frame(current.rgb.shape[1::-1], capture_id)}
            arrays = dict(
                rgb=current.rgb, depth=current.depth, camera=current.camera, mask=current.mask
            )
            if "coarse_poses" in inputs:
                arrays["initial"] = coarse_poses(inputs["coarse_poses"], recipe, current)
            python, weights = runtime_paths()
            if self._client is None or self._client.python != python:
                self.close()
                self._client = WorkerClient(python=python, timeout=p["timeout_seconds"])
            if self._lease is None:
                self._lease = WorkerLease(self._client)
            self._client.timeout = float(p["timeout_seconds"])
            result, graphics = self._client.call(
                "register",
                dict(
                    recipe_path=str(path),
                    recipe_sha256=p["sha256"],
                    weights_dir=weights,
                    frame=current.frame,
                    capture_id=capture_id,
                    graphics=self.generate_graphics and p["render_graphics"],
                    retain_completed=bool(
                        self.run_profile.input_previews and self.run_profile.output_previews
                    ),
                ),
                arrays,
                cancelled=getattr(self, "_cancelled", lambda: False),
            )
        except (ValueError, KeyError, OSError) as error:
            raise ValidationError(str(error)) from error
        report = result["report"]
        if report["capture_id"] != capture_id or report["recipe_sha256"] != p["sha256"]:
            raise ValidationError("Worker response belongs to a different capture or recipe")
        accepted = [c for c in report["candidates"] if c["fit"]["status"] == "accepted"]
        poses = [
            dict(
                model="pose_3d_v1",
                units="m",
                source_frame=recipe.mesh.frame,
                target_frame=current.frame,
                source_to_target=rigid(c["source_to_target"]).tolist(),
                capture_id=capture_id,
                candidate_id=c["id"],
            )
            for c in accepted
        ]
        overlay_image = cloud = NO_VALUE
        contexts = {}
        views = {}
        if self.generate_graphics and p["render_graphics"]:
            overlay_image = ImageArray(graphics["overlay_rgb"], "rgb")
            views["pose_depth_fit"] = overlay_image
            contexts["overlay"] = payload
            cloud = PointCloud(
                graphics["review_xyz"],
                "m",
                current.frame,
                colors=graphics["review_rgb"],
                metadata=dict(
                    derived_review=True,
                    capture_id=capture_id,
                    review=copy.deepcopy(report["review"]),
                ),
            )
        table = [
            dict(
                rank=i + 1,
                candidate_id=c["id"],
                status=c["fit"]["status"],
                raw_cohort_logit=c["raw_logit"],
                coverage=c["fit"]["coverage"],
                contradiction=c["fit"]["contradiction"],
            )
            for i, c in enumerate(report["candidates"])
        ]
        outputs = dict(
            report=report,
            pose=poses[0] if poses else NO_VALUE,
            poses=poses,
            accepted_count=len(poses),
            overlay=overlay_image,
            cloud=cloud,
            candidate_table=table,
        )
        for key, context in retain_completed(self, result, outputs, inputs).items():
            contexts.setdefault(key, {}).update(context)
        return Result(
            outputs,
            payloads=contexts,
            graphics=views,
            passed=bool(poses),
            score=max((c["fit"]["coverage"] for c in report["candidates"]), default=0.0),
            message=(
                f"{len(poses)} accepted hypotheses for one instance; "
                "score is maximum raw-depth support; experimental CPU"
            ),
            fail_reasons=[] if poses else ["no_raw_depth_accepted_pose"],
        )

    def create_plugin_dialog(self, parent, parameters, context):
        from .qt_setup import FoundationPoseSetupDialog

        return FoundationPoseSetupDialog(parent, parameters, context)

    def prepare_completed_review(self, context):
        return prepare_capture(self, context)

    def create_plugin_review_dialog(self, parent, context):
        from .qt_completed_review import CompletedReviewDialog

        return CompletedReviewDialog(
            parent, context, lambda: self.prepare_completed_review(context)
        )

    def copy_runtime_from(self, other):
        super().copy_runtime_from(other)
        if self._lease is not other._lease:
            self.close()
            if other._lease is not None:
                self._lease = other._lease.acquire()
                self._client = self._lease.client
        self._recipe_key, self._recipe = other._recipe_key, other._recipe
        self._completed_record = other._completed_record

    def close(self):
        self._completed_record = None
        lease, self._lease = self._lease, None
        if lease is not None:
            self._client = None
            lease.release()
        elif self._client is not None:
            self._client.close()
            self._client = None

    def reset_runtime(self):
        self.close()
        self._recipe_key = self._recipe = None


def register(registry):
    registry.register(SimpleFoundationPose)
