"""Read-only selection of the original ranked cohort; no scoring or pose analysis."""


def candidate_status(candidate):
    return candidate["fit"]["status"]


def describe_review(report):
    candidates = report["candidates"]
    accepted = [i for i, c in enumerate(candidates) if candidate_status(c) == "accepted"]
    selected = accepted[0] if accepted else (0 if candidates else None)
    return dict(
        candidate_index=selected,
        candidate_number=selected + 1 if selected is not None else None,
        candidate_id=candidates[selected]["id"] if selected is not None else None,
        candidate_count=len(candidates),
        status=candidate_status(candidates[selected]) if selected is not None else "no_candidates",
    )


def candidate_table(report):
    return [
        dict(
            rank=i + 1,
            candidate_id=c["id"],
            status=c["fit"]["status"],
            raw_cohort_logit=c["raw_logit"],
            coverage=c["fit"]["coverage"],
            contradiction=c["fit"]["contradiction"],
        )
        for i, c in enumerate(report["candidates"])
    ]


def accepted_poses(report):
    from .specs import rigid

    return [
        dict(
            model="pose_3d_v1",
            units="m",
            source_frame=report["source_frame"],
            target_frame=report["target_frame"],
            source_to_target=rigid(c["source_to_target"]).tolist(),
            capture_id=report["capture_id"],
            candidate_id=c["id"],
        )
        for c in report["candidates"]
        if candidate_status(c) == "accepted"
    ]
