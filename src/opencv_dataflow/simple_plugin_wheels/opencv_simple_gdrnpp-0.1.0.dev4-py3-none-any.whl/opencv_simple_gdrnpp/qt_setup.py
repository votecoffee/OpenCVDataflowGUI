"""Native setup draft: retained reference, editable boxes, isolated preview and Stage."""

import re
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Event

import numpy as np
from PySide6.QtCore import QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QPen
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from opencv_dataflow.canvas import pixmap
from opencv_dataflow.cloud_viewer import CloudViewer
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from opencv_dataflow.images import ImageArray
from opencv_dataflow.pointclouds import PointCloud

from .bridge import (
    WorkerClient,
    configure_models,
    configure_runtime,
    project_recipe_path,
    runtime_models,
    runtime_python,
)
from .estimate import Detection
from .preprocess import validate_box
from .selection import candidate_status, describe_review


class BoxView(FilmstripImageView):
    box_drawn = Signal(tuple)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.draw_mode = False
        self.start = None
        self.rubber = None

    def mousePressEvent(self, event):
        if self.draw_mode and event.button() == Qt.MouseButton.LeftButton:
            self.start = self.mapToScene(event.position().toPoint())
            self.rubber = self.scene().addRect(
                QRectF(self.start, self.start), QPen(QColor(255, 220, 40), 2)
            )
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self.start is not None:
            self.rubber.setRect(
                QRectF(self.start, self.mapToScene(event.position().toPoint())).normalized()
            )
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if self.start is not None:
            rect = self.rubber.rect()
            self.scene().removeItem(self.rubber)
            self.start = self.rubber = None
            width, height = self.image_item.pixmap().width(), self.image_item.pixmap().height()
            box = (
                max(0, int(np.floor(rect.left()))),
                max(0, int(np.floor(rect.top()))),
                min(width, int(np.ceil(rect.right()))),
                min(height, int(np.ceil(rect.bottom()))),
            )
            if box[2] > box[0] and box[3] > box[1]:
                self.box_drawn.emit(box)
            return
        super().mouseReleaseEvent(event)


class GDRNPPSetupDialog(QDialog):
    def __init__(self, parent, parameters, context, *, client=None):
        super().__init__(parent)
        self.setWindowTitle("SimpleGDRNPP — object setup")
        self.resize(1180, 800)
        self.parameters = parameters
        self.context = context
        self.client = client or WorkerClient()
        self.pool = ThreadPoolExecutor(max_workers=1)
        self.base = None
        self.reference_override = None
        self.reference_arrays = {}
        self.reference = None
        self.summary = None
        self.revision = 0
        self.pending = None
        self.closed = False
        self.restoring = False
        self.token = None
        self.preview_arrays = None
        self.preview_report = None
        self.preview_review = None
        self.preview_source = ""
        self.checkpoint_prepared = False
        self.depth_pixels = None
        self.depth_count = 0
        self.box_items = []
        layout = QVBoxLayout(self)
        actions = QHBoxLayout()
        for text, callback in [
            ("Open recipe…", self._open_recipe),
            ("Import setup…", self._import),
            ("Replace reference…", self._reference_request),
        ]:
            actions.addWidget(self._button(text, callback))
        self.runtime_label = QLabel("Runtime not selected")
        self.runtime_label.setWordWrap(True)
        self.runtime_label.setTextFormat(Qt.TextFormat.PlainText)
        actions.addWidget(self.runtime_label, 1)
        actions.addWidget(self._button("Choose runtime…", self._runtime))
        layout.addLayout(actions)
        model_row = QHBoxLayout()
        model_row.addWidget(QLabel("Model folder override"))
        self.models = QLineEdit(parameters.get("models_dir", ""))
        self.models.setPlaceholderText("Blank uses this machine's model default")
        self.models.setToolTip(
            "An explicit project path takes precedence. Browse also saves the machine default "
            "immediately, independently of inspector Apply/Cancel. Worker verifies checkpoint pins."
        )
        model_row.addWidget(self.models, 1)
        model_row.addWidget(self._button("Browse…", self._models))
        layout.addLayout(model_row)
        self.model_default = QLabel()
        self.model_default.setWordWrap(True)
        self.model_default.setTextFormat(Qt.TextFormat.PlainText)
        self._model_default_status()
        layout.addWidget(self.model_default)
        readiness_row = QHBoxLayout()
        self.checkpoint_status = QLabel()
        self.checkpoint_status.setWordWrap(True)
        self.checkpoint_status.setTextFormat(Qt.TextFormat.PlainText)
        readiness_row.addWidget(self.checkpoint_status, 1)
        self.checkpoint_button = self._button("Check checkpoint", self._check_checkpoint)
        readiness_row.addWidget(self.checkpoint_button)
        layout.addLayout(readiness_row)
        self.models.textChanged.connect(self._invalidate)
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)
        reference_tab = QWidget()
        ref_layout = QVBoxLayout(reference_tab)
        toolbar = QHBoxLayout()
        self.viewer = BoxView(self)
        for text, callback in [
            ("Fit", self.viewer.fit_image),
            ("100%", self.viewer.actual_size),
            ("Zoom +", lambda: self.viewer.zoom(1.25)),
            ("Zoom −", lambda: self.viewer.zoom(0.8)),
        ]:
            toolbar.addWidget(self._button(text, callback))
        self.draw = QCheckBox("Draw instance rectangle")
        self.draw.toggled.connect(self._draw_mode)
        toolbar.addWidget(self.draw)
        toolbar.addStretch()
        ref_layout.addLayout(toolbar)
        split = QSplitter()
        split.addWidget(self.viewer)
        side = QWidget()
        side_layout = QVBoxLayout(side)
        self.name = QLineEdit()
        self.name.textChanged.connect(self._invalidate)
        side_layout.addWidget(QLabel("Setup name"))
        side_layout.addWidget(self.name)
        self.boxes = QTableWidget(0, 5)
        self.boxes.setHorizontalHeaderLabels(["Instance", "Left", "Top", "Right", "Bottom"])
        self.boxes.cellChanged.connect(self._box_changed)
        self.boxes.itemSelectionChanged.connect(self._paint_boxes)
        side_layout.addWidget(self.boxes, 1)
        side_layout.addWidget(self._button("Remove selected instance", self._remove))
        self.reference_info = QLabel("Open a recipe or import its setup definition.")
        self.reference_info.setWordWrap(True)
        self.reference_info.setTextFormat(Qt.TextFormat.PlainText)
        self.box_info = QLabel("Draw a rectangle around each instance in the reference.")
        self.box_info.setWordWrap(True)
        side_layout.addWidget(self.box_info)
        side_layout.addWidget(self.reference_info)
        self.reference_cloud = self._button("Reference cloud…", self._reference_cloud)
        side_layout.addWidget(self.reference_cloud)
        split.addWidget(side)
        split.setSizes([780, 400])
        ref_layout.addWidget(split, 1)
        self.tabs.addTab(reference_tab, "Reference / instances")
        settings_tab = QWidget()
        form = QFormLayout(settings_tab)
        self.fields = {}
        self.dirty_fields = set()
        for key, text, low, high, decimals in [
            ("threads", "CPU threads", 1, 32, 0),
            ("batch_size", "Instance batch size", 1, 8, 0),
            ("distance_tolerance_m", "Depth tolerance", 0.01, 100, 2),
            ("minimum_coverage", "Minimum measured support", 10, 100, 1),
            ("maximum_contradiction", "Maximum contradiction", 0, 100, 1),
            ("maximum_overlap", "Maximum overlap (100% disables)", 0, 100, 1),
            ("maximum_correction_m", "Maximum translation correction", 0.01, 100, 2),
        ]:
            widget = QSpinBox() if decimals == 0 else QDoubleSpinBox()
            if decimals:
                widget.setDecimals(decimals)
            widget.setRange(low, high)
            if key.endswith("_m"):
                widget.setSuffix(" mm")
            elif decimals:
                widget.setSuffix(" %")
            widget.valueChanged.connect(lambda value, key=key: self._setting_changed(key))
            form.addRow(text, widget)
            self.fields[key] = widget
        self.depth_refine = QCheckBox("Optional depth refinement")
        self.depth_refine.toggled.connect(self._invalidate)
        form.addRow(self.depth_refine)
        self.refine_method = QComboBox()
        self.refine_method.addItem("Axial median translation", "median_translation")
        self.refine_method.addItem("Robust projective ICP (local 6D)", "projective_icp_v1")
        self.refine_method.currentIndexChanged.connect(self._invalidate)
        form.addRow("Depth alignment method", self.refine_method)
        hint = QLabel(
            "Setup imports a trained object model. It does not train a new object.\n"
            "Depth acceptance and pose/fit colors remain independent of detector confidence."
        )
        hint.setWordWrap(True)
        form.addRow(hint)
        self.tabs.addTab(settings_tab, "Execution / fit gates")
        preview_tab = QWidget()
        preview_layout = QVBoxLayout(preview_tab)
        preview_actions = QHBoxLayout()
        self.candidates = QComboBox()
        self.candidates.activated.connect(self._candidate)
        preview_actions.addWidget(self.candidates, 1)
        self.result_cloud_button = self._button("Flyaround result…", self._result_cloud)
        preview_actions.addWidget(self.result_cloud_button)
        preview_layout.addLayout(preview_actions)
        self.result_view = FilmstripImageView(self)
        preview_layout.addWidget(self.result_view, 1)
        self.result_info = QLabel("Preview the reference or a separate calibrated capture.")
        self.result_info.setWordWrap(True)
        self.result_info.setTextFormat(Qt.TextFormat.PlainText)
        preview_layout.addWidget(self.result_info)
        self.tabs.addTab(preview_tab, "Pose / depth review")
        self.status = QLabel()
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        bottom = QHBoxLayout()
        self.preview_button = self._button("Preview reference", self._preview_reference)
        self.test_button = self._button("Preview another capture…", self._preview_capture)
        self.stage_button = self._button("Stage setup", self._stage)
        self.cancel_button = self._button("Cancel task", self._cancel_job)
        for button in [
            self.preview_button,
            self.test_button,
            self.stage_button,
            self.cancel_button,
        ]:
            bottom.addWidget(button)
        bottom.addStretch()
        self.connected_reference_button = self.connected_preview_button = None
        if hasattr(context, "snapshot_connected_inputs"):
            self.connected_reference_button = self._button(
                "Use connected reference", self._use_connected
            )
            self.connected_preview_button = self._button(
                "Preview connected", self._preview_connected
            )
            bottom.addWidget(self.connected_reference_button)
            bottom.addWidget(self.connected_preview_button)
        bottom.addWidget(self._button("Close / discard", self.reject))
        layout.addLayout(bottom)
        self.viewer.box_drawn.connect(self._add_box)
        self.timer = QTimer(self)
        self.timer.setInterval(40)
        self.timer.timeout.connect(self._poll)
        self.timer.start()
        self.finished.connect(self._finish)
        self._runtime_status()
        self._buttons()
        if parameters.get("recipe_path"):
            try:
                path = project_recipe_path(context.project_dir, parameters["recipe_path"])
                self.load_base(
                    dict(kind="recipe", path=str(path), sha256=parameters.get("sha256", ""))
                )
            except Exception as error:
                self.status.setText(str(error))

    def _button(self, text, callback):
        button = QPushButton(text)
        button.setAutoDefault(False)
        button.clicked.connect(lambda: self._perform(callback))
        return button

    def _perform(self, callback):
        try:
            callback()
        except Exception as error:
            self.status.setText(str(error))

    def _runtime_status(self):
        try:
            self.runtime_label.setText("Runtime: " + runtime_python())
        except (ValueError, OSError):
            self.runtime_label.setText("Choose the isolated GDRNPP runtime")

    def _runtime(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Choose installed GDRNPP Python",
            filter="Python (python.exe python);;All files (*)",
        )
        if path:
            if self.pending:
                raise ValueError("Cancel the current preview before changing runtime")
            configure_runtime(path)
            self.client.close()
            self.client = WorkerClient()
            self._invalidate()
            self._runtime_status()
            if self.base and self.reference is None:
                data = dict(base=self.base)
                if self.reference_override:
                    data["reference"] = self.reference_override
                self._submit("inspect", data, self._loaded, self.reference_arrays)

    def _models(self):
        path = QFileDialog.getExistingDirectory(self, "Choose verified checkpoint folder")
        if path:
            self.models.setText(configure_models(path))
            self._model_default_status()

    def _model_default_status(self):
        try:
            self.model_default.setText("Machine model default: " + runtime_models())
        except (ValueError, OSError):
            self.model_default.setText("Machine model default not configured / unavailable.")
        self.model_default.setText(
            self.model_default.text()
            + "\nBrowse saves a local default immediately; worker checks checkpoint hashes on load."
        )

    def _open_recipe(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Open retained object setup", filter="GDRNPP setup (*.gdrnpp)"
        )
        if path:
            self.load_base(dict(kind="recipe", path=path))

    def _import(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Import object setup definition", filter="Setup definition (*.json)"
        )
        if path:
            self.load_base(dict(kind="definition", path=path))

    def load_base(self, base):
        if self.pending:
            raise ValueError("Cancel the current task before opening another setup")
        self._invalidate()
        self.base = base
        self.reference_override = None
        self.reference_arrays = {}
        self.reference = None
        self.summary = None
        self._waiting_reference()
        self._submit("inspect", dict(base=base), self._loaded)

    def _reference_request(self):
        if not self.base:
            raise ValueError("Open a setup first")
        if self.pending:
            raise ValueError("Cancel the current task before replacing the reference")
        path, _ = QFileDialog.getOpenFileName(
            self, "Choose calibrated RGB-D reference capture", filter="Capture request (*.json)"
        )
        if path:
            self._invalidate()
            self.reference_override = dict(kind="request", path=path)
            self.reference_arrays = {}
            self.reference = None
            self._waiting_reference()
            self._submit(
                "inspect", dict(base=self.base, reference=self.reference_override), self._loaded
            )

    def _submit(self, operation, data, callback, arrays=None):
        if self.pending:
            raise ValueError("Wait for the current task, or cancel it")
        cancellation = Event()
        revision = self.revision
        client = self.client

        def work():
            metadata, result = client.call(operation, data, arrays, cancelled=cancellation.is_set)
            if operation == "inspect" and not cancellation.is_set():
                depth = result["depth"]
                depth_pixels = np.isfinite(depth) & (depth > 0) & result["mask"]
                metadata = dict(
                    metadata,
                    depth_pixels=depth_pixels,
                    depth_count=int(np.count_nonzero(depth_pixels)),
                )
            return metadata, result

        future = self.pool.submit(work)
        self.pending = (future, cancellation, revision, callback)
        self.status.setText("Working…")
        self._buttons()

    def _poll(self):
        if self.pending is None or not self.pending[0].done():
            return
        future, cancellation, revision, callback = self.pending
        self.pending = None
        try:
            result = future.result()
            if not self.closed and not cancellation.is_set() and revision == self.revision:
                callback(*result)
            elif not self.closed:
                self.status.setText("Discarded an older task result. Use the current draft.")
        except Exception as error:
            if not self.closed:
                self.status.setText(str(error))
        self._buttons()

    def _loaded(self, metadata, arrays):
        self.summary = metadata["setup"]
        self.reference = arrays
        self.depth_pixels = metadata["depth_pixels"]
        self.depth_count = metadata["depth_count"]
        self.restoring = True
        self.dirty_fields.clear()
        try:
            self.name.setText(self.summary["name"])
            self.boxes.setRowCount(0)
            for detection in self.summary["reference_detections"]:
                self._append_box(detection)
            for name, widget in self.fields.items():
                widget.setValue(self._retained_setting(name) * self._display_factor(name))
            self.depth_refine.setChecked(self.summary["settings"]["depth_refine"])
            self.refine_method.setCurrentIndex(
                self.refine_method.findData(
                    self.summary["settings"].get("depth_refinement", "median_translation")
                )
            )
            self.viewer.set_image(pixmap(ImageArray(arrays["rgb"], "rgb")))
            k = arrays["camera"]
            width, height = self.summary["image_size"]
            binding = self.summary["binding"]
            self.reference_info.setText(
                f"Reference {self.summary['reference_capture_id']} · {width} × {height} px\n"
                f"Registered depth: {self.depth_count:,} / {width * height:,} pixels "
                f"({self.depth_count / (width * height):.1%}) · "
                f"fx {k[0, 0]:.1f} px, fy {k[1, 1]:.1f} px\n"
                f"CAD: {binding['dataset']} object {binding['object_id']} · "
                f"{self.summary['symmetry_count']} discrete symmetries\n"
                f"{self.summary['model_frame']} → {self.summary['camera_frame']} "
                f"({self.summary['units']})\n"
                f"Source: {self.summary['credit']['dataset']} · {self.summary['credit']['license']}"
            )
        finally:
            self.restoring = False
        if self.boxes.rowCount():
            self.boxes.setCurrentCell(0, 0)
        self._paint_boxes()
        self.status.setText("Reference ready. Review the instances, then preview or stage.")

    def _append_box(self, detection):
        row = self.boxes.rowCount()
        self.boxes.insertRow(row)
        for column, value in enumerate([detection["identifier"], *detection["box"]]):
            item = QTableWidgetItem(str(value))
            item.setData(Qt.ItemDataRole.UserRole, detection if column == 0 else None)
            self.boxes.setItem(row, column, item)

    def _detections(self):
        if self.reference is None:
            raise ValueError("Open a reference first")
        if not 1 <= self.boxes.rowCount() <= 64:
            raise ValueError("Use 1 to 64 instance rectangles")
        height, width = self.reference["rgb"].shape[:2]
        detections = []
        identifiers = set()
        for row in range(self.boxes.rowCount()):
            try:
                label = self.boxes.item(row, 0)
                original = label.data(Qt.ItemDataRole.UserRole) or {}
                identifier = label.text()
                box = [float(self.boxes.item(row, c).text()) for c in range(1, 5)]
                validate_box(box, width=width, height=height)
                detection = Detection(
                    identifier=identifier,
                    box=box,
                    source=original.get("source", "user_reference_rectangle"),
                    score=original.get("score"),
                )
                if identifier in identifiers:
                    raise ValueError("Each instance needs a unique name")
            except (ValueError, AttributeError) as error:
                raise ValueError(f"Instance row {row + 1}. {error}") from error
            identifiers.add(identifier)
            detections.append(
                dict(
                    identifier=identifier,
                    box=box,
                    object_id=detection.object_id,
                    source=detection.source,
                    score=detection.score,
                )
            )
        return detections

    def _draft(self):
        return dict(
            name=self.name.text(),
            settings={
                **{
                    k: (
                        self._retained_setting(k)
                        if self.summary and k not in self.dirty_fields
                        else w.value() / self._display_factor(k)
                        if self._display_factor(k) != 1
                        else w.value()
                    )
                    for k, w in self.fields.items()
                },
                "depth_refine": self.depth_refine.isChecked(),
                "depth_refinement": self.refine_method.currentData(),
            },
            detections=self._detections(),
        )

    def _data(self):
        if not self.base:
            raise ValueError("Open a setup first")
        result = dict(base=self.base, draft=self._draft())
        if self.reference_override:
            result["reference"] = self.reference_override
        return result

    @staticmethod
    def _display_factor(name):
        return (
            1000
            if name.endswith("_m")
            else 100
            if name in ("minimum_coverage", "maximum_contradiction", "maximum_overlap")
            else 1
        )

    def _retained_setting(self, name):
        if name == "maximum_overlap":
            return self.summary["settings"].get(name, 1.0)
        return self.summary["settings"][name]

    def _model_folder(self):
        return runtime_models(self.models.text(), project_dir=self.context.project_dir)

    def _checkpoint_problem(self):
        try:
            runtime_python()
        except (ValueError, OSError) as error:
            return str(error)
        try:
            directory = Path(self._model_folder())
            if not (directory / "checkpoint.json").is_file():
                return "Choose a checkpoint folder containing checkpoint.json."
        except (ValueError, OSError) as error:
            return str(error)
        return ""

    def _pinned_base(self):
        return (
            self.base is not None
            and self.base["kind"] == "recipe"
            and re.fullmatch(r"[0-9a-f]{64}", self.base.get("sha256", "")) is not None
        )

    def _check_checkpoint(self):
        if not self._pinned_base() or self.reference is None:
            raise ValueError("Stage and apply the setup, then reopen it to check the pinned recipe")
        problem = self._checkpoint_problem()
        if problem:
            raise ValueError(problem)
        self._invalidate()
        self.result_info.setText("Preview a capture after the checkpoint check.")
        self._submit(
            "prepare",
            dict(base=self.base, models_dir=self._model_folder()),
            self._checkpoint_checked,
        )

    def _checkpoint_checked(self, metadata, arrays):
        prepared = metadata["prepared"]
        if (
            prepared.get("schema") != "simple_gdrnpp_preparation/v1"
            or prepared.get("ready") is not True
            or prepared.get("recipe_archive_sha256") != self.base["sha256"]
            or prepared.get("inspection_performed") is not False
            or arrays
        ):
            raise ValueError("The worker did not check the current pinned recipe")
        self.checkpoint_prepared = True
        self.status.setText("Checkpoint check complete. Preview a capture to review pose fit.")

    def _invalidate(self, *_):
        if self.restoring:
            return
        self.checkpoint_prepared = False
        self.preview_review = None
        self.preview_source = ""
        self.revision += 1
        self.token = None
        self.preview_arrays = None
        self.preview_report = None
        if hasattr(self, "result_view"):
            self.result_view.set_image(pixmap(np.zeros((2, 2, 3), np.uint8)))
        if self.pending:
            self.pending[1].set()
        if hasattr(self, "result_cloud_button"):
            self.result_cloud_button.setEnabled(False)
            self.result_info.setText("Draft changed — preview again to assess the current setup.")
            self.candidates.clear()
        self._buttons()

    def _setting_changed(self, name):
        if not self.restoring:
            self.dirty_fields.add(name)
        self._invalidate()

    def _waiting_reference(self):
        self.depth_pixels = None
        self.depth_count = 0
        self.box_info.setText("Waiting for the reference.")
        self.restoring = True
        try:
            self.boxes.setRowCount(0)
            self.viewer.set_image(pixmap(np.zeros((2, 2, 3), np.uint8)))
            self.reference_info.setText("Opening the selected reference…")
        finally:
            self.restoring = False

    def _box_changed(self, *_):
        self._invalidate()
        self._paint_boxes()

    def _paint_boxes(self):
        for item in self.box_items:
            self.viewer.scene().removeItem(item)
        self.box_items = []
        if self.reference is None or self.restoring:
            return
        try:
            for row, detection in enumerate(self._detections()):
                x0, y0, x1, y1 = detection["box"]
                color = (
                    QColor(255, 220, 40) if row == self.boxes.currentRow() else QColor(40, 240, 80)
                )
                pen = QPen(color, 2)
                pen.setCosmetic(True)
                self.box_items.append(
                    self.viewer.scene().addRect(QRectF(x0, y0, x1 - x0, y1 - y0), pen)
                )
        except ValueError as error:
            self.box_info.setText(str(error))
            return
        row = self.boxes.currentRow()
        if not 0 <= row < len(self.box_items):
            self.box_info.setText("Select an instance to check depth inside its rectangle.")
            return
        box = self.box_items[row].rect()
        x0, y0, x1, y1 = np.ceil([box.left(), box.top(), box.right(), box.bottom()]).astype(int)
        selected = self.depth_pixels[y0:y1, x0:x1]
        measured = np.count_nonzero(selected)
        self.box_info.setText(
            f"{len(self.box_items)} valid rectangles. Selected box depth: "
            f"{measured:,} / {selected.size:,} pixels ({measured / selected.size:.1%}).\n"
            "Box depth describes the input. Preview measures pose fit against the CAD surface."
        )

    def _add_box(self, box):
        if self.reference is None:
            return
        if self.boxes.rowCount() >= 64:
            self.status.setText("Use at most 64 instance rectangles.")
            return
        self.restoring = True
        try:
            self._append_box(dict(identifier="instance_" + uuid.uuid4().hex[:8], box=box))
        finally:
            self.restoring = False
        self.boxes.setCurrentCell(self.boxes.rowCount() - 1, 0)
        self._box_changed()

    def _remove(self):
        if self.boxes.currentRow() >= 0:
            self.boxes.removeRow(self.boxes.currentRow())
            self._box_changed()

    def _draw_mode(self, value):
        self.viewer.draw_mode = value
        self.viewer.setDragMode(
            self.viewer.DragMode.NoDrag if value else self.viewer.DragMode.ScrollHandDrag
        )

    def _preview_reference(self):
        data = self._data()
        data.update(models_dir=self._model_folder(), graphics=True)
        self._start_preview("Reference", data, self.reference_arrays)

    def _preview_capture(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Preview independent RGB-D capture", filter="Capture request (*.json)"
        )
        if path:
            data = self._data()
            data.update(
                models_dir=self._model_folder(),
                graphics=True,
                current=dict(kind="request", path=path),
            )
            self._start_preview("Capture file", data, self.reference_arrays)

    def _connected(self, prefix):
        from .dataflow import CAPTURE_PORTS, connected_capture

        bundle = self.context.snapshot_connected_inputs(CAPTURE_PORTS)
        current, arrays = connected_capture(
            {k: v.value for k, v in bundle.inputs.items()},
            {k: v.payload for k, v in bundle.inputs.items()},
            depth_scale_to_m=self.parameters.get("depth_scale_to_m", 1.0),
        )
        current["array_prefix"] = prefix
        return current, {prefix + k: v for k, v in arrays.items()}

    def _use_connected(self):
        if self.base is None:
            raise ValueError("Import the matching trained object setup first")
        if self.pending:
            raise ValueError("Cancel the current task before replacing the reference")
        current, arrays = self._connected("reference_")
        self._invalidate()
        self.reference_override = current
        self.reference_arrays = arrays
        self.reference = None
        self._waiting_reference()
        self._submit("inspect", dict(base=self.base, reference=current), self._loaded, arrays)

    def _preview_connected(self):
        current, arrays = self._connected("current_")
        data = self._data()
        data.update(current=current, models_dir=self._model_folder(), graphics=True)
        self._start_preview("Connected capture", data, {**self.reference_arrays, **arrays})

    def _start_preview(self, source, data, arrays):
        self._submit("preview", data, self._previewed, arrays)
        self.preview_source = source

    def _previewed(self, metadata, arrays):
        self.token = metadata["token"]
        self.preview_report = metadata["report"]
        self.preview_arrays = arrays
        index = metadata.get("candidate_index")
        self.preview_review = (
            metadata.get("review")
            or describe_review(
                self.preview_report,
                index + 1 if index is not None and self.preview_report["candidates"] else 0,
            )[0]
        )
        self.result_view.set_image(pixmap(ImageArray(arrays["overlay"], "rgb")))
        self.candidates.blockSignals(True)
        self.candidates.clear()
        for number, candidate in enumerate(self.preview_report["candidates"], 1):
            fit = candidate["fit"]
            self.candidates.addItem(
                f"{number}: {candidate['id']} · {candidate_status(candidate)} · "
                f"support {fit['coverage']:.1%}"
            )
        self.candidates.setCurrentIndex(index if index is not None else -1)
        self.candidates.blockSignals(False)
        accepted = self.preview_report["accepted_candidates"]
        self.result_info.setText(
            (f"{self.preview_source}. " if self.preview_source else "")
            + f"{accepted} accepted / {len(self.preview_report['candidates'])} candidates. "
            f"Viewing {self.preview_review['candidate_id'] or 'no candidate'} "
            f"({self.preview_review['status']}). "
            "Green: supported; red: contradicted; purple: behind depth; orange: unknown/outside. "
            "Axes and predicted CAD surface are explanatory graphics, not camera measurements."
        )
        self.tabs.setCurrentIndex(2)
        self.status.setText(
            "Preview completed. Acceptance uses measured-depth gates. "
            "Refinement reuses these measurements when enabled."
            + (
                " Overlap selection keeps stronger unique poses; suppressed fits remain reviewable."
                if "overlap_selection" in self.preview_report
                else ""
            )
        )
        self.result_cloud_button.setEnabled(True)

    def _candidate(self, index):
        if self.token and index >= 0:
            self._submit("render", dict(token=self.token, index=index), self._previewed)

    def _reference_cloud(self):
        if self.reference is None:
            raise ValueError("Open a reference first")
        f = self.reference
        if not self.depth_count:
            raise ValueError("The reference has no usable registered depth")
        y, x = np.where(self.depth_pixels)
        ids = np.linspace(0, len(x) - 1, min(30_000, len(x)), dtype=int)
        y, x = y[ids], x[ids]
        z = f["depth"][y, x]
        k = f["camera"]
        points = np.c_[(x - k[0, 2]) * z / k[0, 0], (y - k[1, 2]) * z / k[1, 1], z]
        self._cloud(PointCloud(points, "m", self.summary["camera_frame"], colors=f["rgb"][y, x]))

    def _result_cloud(self):
        if self.preview_arrays is None:
            raise ValueError("Preview the current draft first")
        self._cloud(
            PointCloud(
                self.preview_arrays["points"],
                "m",
                self.preview_report["target_frame"],
                colors=self.preview_arrays["colors"],
                metadata={"derived_review": True, "review": self.preview_review},
            )
        )

    def _cloud(self, cloud):
        dialog = CloudViewer(None, self)
        dialog.set_cloud(cloud)
        dialog.flyaround.setChecked(True)
        dialog.show()

    def _stage(self):
        data = self._data()
        relative = "assets/gdrnpp/" + uuid.uuid4().hex + ".gdrnpp"
        project_recipe_path(self.context.project_dir, relative)
        data.update(project_dir=str(self.context.project_dir), relative_asset=relative)
        self._submit("stage", data, self._staged, self.reference_arrays)

    def _staged(self, metadata, arrays):
        self.parameters.update(
            recipe_path=metadata["recipe_path"],
            sha256=metadata["sha256"],
            models_dir=self.models.text(),
        )
        self.accept()

    def _cancel_job(self):
        if self.pending:
            self.pending[1].set()
        self._invalidate()
        self.status.setText("Cancelling the task. Applied setup is unchanged.")

    def _buttons(self):
        busy = self.pending is not None
        try:
            self._detections()
            valid = True
        except ValueError:
            valid = False
        problem = self._checkpoint_problem()
        can_preview = not busy and valid and not problem
        self.preview_button.setEnabled(can_preview)
        self.test_button.setEnabled(can_preview)
        self.stage_button.setEnabled(not busy and valid)
        if self.connected_preview_button:
            self.connected_preview_button.setEnabled(can_preview)
            self.connected_reference_button.setEnabled(not busy and self.base is not None)
        self.checkpoint_button.setEnabled(
            not busy and not problem and self.reference is not None and self._pinned_base()
        )
        if problem:
            message = problem
        elif self.checkpoint_prepared:
            message = "Pinned checkpoint verified and loaded. No inference was run for this check."
        elif self.reference is None:
            message = "Runtime and checkpoint folder selected. Open a reference to continue."
        elif not self._pinned_base():
            message = "Stage, apply, and reopen to check the pinned recipe. Preview is available."
        else:
            message = "Runtime and model folder selected. Check the pinned checkpoint."
        self.checkpoint_status.setText(message)
        self.cancel_button.setEnabled(busy)
        self.reference_cloud.setEnabled(self.reference is not None and self.depth_count > 0)
        self.result_cloud_button.setEnabled(self.preview_arrays is not None and not busy)

    def _finish(self, *_):
        if self.closed:
            return
        self.closed = True
        self.timer.stop()
        if self.pending:
            self.pending[1].set()
        client = self.client
        self.pool.submit(client.close)
        self.pool.shutdown(wait=False, cancel_futures=False)
