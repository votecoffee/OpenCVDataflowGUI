"""Owned normalized source stacks and bounded sealed reference/calibration recipes."""

import hashlib
import io
import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from tempfile import NamedTemporaryFile
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np

from .cli import read_manifest, strict_json
from .model import CompiledScan
from .patterns import frozen

LIMIT = 160 * 1024 * 1024


def json_copy(value, limit=2 * 1024 * 1024):
    body = json.dumps(value, allow_nan=False).encode()
    if len(body) > limit:
        raise ValueError("Recipe/capture metadata exceeds its bounded JSON budget")
    return strict_json(body)


def source_mask(mask, shape, *, nonempty=False):
    if mask is None:
        return None
    raw = np.asarray(mask)
    if raw.shape != tuple(shape) or raw.dtype.kind not in "bui" or np.any(raw < 0):
        raise ValueError("Inspection mask must match the original source-pixel grid")
    selected = raw != 0
    if nonempty and not selected.any():
        raise ValueError("Retain a nonempty inspection region")
    return frozen(selected, bool)


def validate_definition(data, images):
    raw = np.asarray(images)
    if (
        raw.dtype.str not in ("<f4", "<f8")
        or raw.ndim != 3
        or not 3 <= raw.shape[0] <= 128
        or (min(raw.shape[1:]) < 2 or max(raw.shape[1:]) > 16384 or raw.size > 16_000_000)
    ):
        raise ValueError("Use bounded normalized float32/float64 N×H×W source codes")
    if np.any(np.isfinite(raw) & ((raw < 0) | (raw > 1))):
        raise ValueError(
            "Source codes must be normalized 0..1; unavailable samples remain nonfinite"
        )
    if (
        data.get("source_encoding") != "linear"
        or type(data.get("input_scale")) not in (int, float)
        or (data["input_scale"] != 1)
    ):
        raise ValueError("Retained and connected arrays must already be normalized linear codes")
    for key in ("capture_id", "pixel_grid"):
        if (
            not isinstance(data.get(key), str)
            or not 0 < len(data[key].strip()) <= 128
            or (not data[key].isprintable())
        ):
            raise ValueError("Name the capture and original camera pixel grid")
    exposure = data.get("exposure_s")
    if type(exposure) not in (int, float) or not np.isfinite(exposure) or not 0 < exposure <= 3600:
        raise ValueError("Declare one common positive exposure in seconds")
    frames = data.get("frames")
    if not isinstance(frames, list) or len(frames) != len(raw):
        raise ValueError("Observed frame count differs from the source stack")
    ids = [row.get("id") if isinstance(row, dict) else None for row in frames]
    if any(not isinstance(v, str) or not 0 < len(v.strip()) <= 128 for v in ids) or (
        len(set(ids)) != len(ids)
    ):
        raise ValueError("Retain unique named observed frame IDs")
    model = CompiledScan(data, raw.shape)
    expected = (
        model.plan.pattern_ids if model.plan else tuple(f"phase:{i}" for i in range(len(raw)))
    )
    if tuple(ids) != expected:
        raise ValueError("Observed frame IDs/order must match the complete declared sequence")
    if model.plan is None and data.get("calibration"):
        raise ValueError(
            "Phase-only setup cannot imply absolute correspondence or metric calibration"
        )
    return model


@dataclass(frozen=True, init=False)
class FringeRecipe:
    _definition_raw: bytes = field(repr=False)
    reference: np.ndarray = field(repr=False)
    mask: np.ndarray | None = field(repr=False)
    _source_bytes: bytes | None = field(default=None, repr=False, compare=False)
    _capture_manifest_bytes: bytes | None = field(default=None, repr=False, compare=False)

    def __init__(
        self, definition, reference, mask=None, *, _source_bytes=None, _capture_manifest_bytes=None
    ):
        data = json_copy(definition)
        validate_definition(data, reference)
        selected = source_mask(mask, np.asarray(reference).shape[1:], nonempty=True)
        object.__setattr__(self, "_definition_raw", json.dumps(data, allow_nan=False).encode())
        object.__setattr__(self, "reference", frozen(reference))
        object.__setattr__(self, "mask", selected)
        object.__setattr__(self, "_source_bytes", _source_bytes)
        object.__setattr__(self, "_capture_manifest_bytes", _capture_manifest_bytes)

    @property
    def definition(self):
        return strict_json(self._definition_raw)


def import_capture(path):
    path = Path(path)
    if path.stat().st_size > 2 * 1024 * 1024:
        raise ValueError("Capture manifest exceeds 2 MiB")
    raw = path.read_bytes()
    definition, images, mask = read_manifest(path, manifest_bytes=raw)
    data = dict(definition)
    data["reference_import"] = dict(
        manifest_name=Path(path).name,
        source_encoding=data["source_encoding"],
        input_scale=data["input_scale"],
        channel=data.get("channel", "gray"),
        source_names=[Path(row["image"]).name for row in data["frames"]],
    )
    data["source_encoding"], data["input_scale"] = "linear", 1
    data["frames"] = [dict(id=row["id"]) for row in data["frames"]]
    data.pop("mask", None)
    return FringeRecipe(data, images, mask, _capture_manifest_bytes=raw)


def array_bytes(value):
    stream = io.BytesIO()
    np.save(stream, value, allow_pickle=False)
    return stream.getvalue()


def read_array(raw, *, stack):
    stream = io.BytesIO(raw)
    version = np.lib.format.read_magic(stream)
    if version not in ((1, 0), (2, 0)):
        raise ValueError("Use numeric NPY v1/v2 retained arrays")
    reader = (
        np.lib.format.read_array_header_1_0
        if version == (1, 0)
        else (np.lib.format.read_array_header_2_0)
    )
    shape, _, dtype = reader(stream)
    if (
        len(shape) != (3 if stack else 2)
        or min(shape) < 2
        or max(shape[-2:]) > 16384
        or (
            (stack and not 3 <= shape[0] <= 128)
            or np.prod(shape) > 16_000_000
            or dtype.str not in (("<f4", "<f8") if stack else ("|b1",))
            or int(np.prod(shape)) * dtype.itemsize != len(raw) - stream.tell()
        )
    ):
        raise ValueError("Invalid bounded retained stack/mask header")
    return np.load(io.BytesIO(raw), allow_pickle=False)


def save_recipe(path, recipe):
    if not isinstance(recipe, FringeRecipe):
        raise ValueError("Save a validated fringe reference recipe")
    path = Path(path)
    if path.suffix != ".sfs":
        raise ValueError("Use a .sfs retained fringe recipe")
    if path.exists():
        raise FileExistsError("Preserve the existing recipe; choose a new filename")
    members = {"reference.npy": array_bytes(recipe.reference)}
    if recipe.mask is not None:
        members["mask.npy"] = array_bytes(recipe.mask)
    document = dict(
        schema="simple_fringe_recipe/v1",
        definition=recipe.definition,
        sha256={name: hashlib.sha256(body).hexdigest() for name, body in members.items()},
    )
    members["recipe.json"] = (json.dumps(document, indent=2, allow_nan=False) + "\n").encode()
    if sum(map(len, members.values())) > LIMIT:
        raise ValueError("Retained recipe expansion exceeds 160 MiB")
    with NamedTemporaryFile(dir=path.parent, prefix="." + path.name, delete=False) as stream:
        temporary = Path(stream.name)
    try:
        with ZipFile(temporary, "w", compression=ZIP_DEFLATED) as archive:
            for name, body in members.items():
                archive.writestr(name, body)
        if temporary.stat().st_size > LIMIT:
            raise ValueError("Retained recipe exceeds 160 MiB")
        os.link(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_recipe(path, *, sha256=None):
    path = Path(path)
    if path.stat().st_size > LIMIT:
        raise ValueError("Retained recipe exceeds 160 MiB")
    raw = path.read_bytes()
    if len(raw) > LIMIT or (sha256 is not None and hashlib.sha256(raw).hexdigest() != sha256):
        raise ValueError("Recipe archive checksum/size differs")
    with ZipFile(io.BytesIO(raw)) as archive:
        infos = archive.infolist()
        names = [row.filename for row in infos]
        if set(names) - {"recipe.json", "reference.npy", "mask.npy"} or (
            not {"recipe.json", "reference.npy"} <= set(names)
            or len(names) != len(set(names))
            or any(row.flag_bits & 1 for row in infos)
            or sum(row.file_size for row in infos) > LIMIT
            or archive.getinfo("recipe.json").file_size > 2 * 1024 * 1024
        ):
            raise ValueError("Invalid bounded fringe recipe members")
        data = strict_json(archive.read("recipe.json"))
        if data.get("schema") != "simple_fringe_recipe/v1":
            raise ValueError("Unsupported fringe recipe schema")
        if set(data["sha256"]) != set(names) - {"recipe.json"}:
            raise ValueError("Retained array manifest differs")
        arrays = {}
        for name in names:
            if name == "recipe.json":
                continue
            body = archive.read(name)
            if hashlib.sha256(body).hexdigest() != data["sha256"][name]:
                raise ValueError("Retained array checksum differs")
            arrays[name[:-4]] = read_array(body, stack=name == "reference.npy")
    return FringeRecipe(data["definition"], **arrays, _source_bytes=raw)
