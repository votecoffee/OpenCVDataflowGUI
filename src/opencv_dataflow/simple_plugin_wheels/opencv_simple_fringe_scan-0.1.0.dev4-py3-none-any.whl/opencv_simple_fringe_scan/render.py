"""Source-aligned phase/availability maps and a separate diagnostic dashboard."""

import cv2
import numpy as np

COLORS = np.array(
    [
        (40, 205, 95),
        (65, 65, 70),
        (205, 80, 220),
        (255, 165, 30),
        (55, 120, 230),
        (230, 70, 55),
        (180, 90, 20),
        (55, 170, 235),
        (235, 65, 55),
        (200, 45, 150),
    ],
    np.uint8,
)


def scalar(value, maximum, *, cyclic=False):
    valid = np.isfinite(value)
    normalized = np.clip(np.nan_to_num(value, nan=0) / maximum, 0, 1)
    codes = np.rint(normalized * 255).astype(np.uint8)
    if cyclic:
        hsv = np.stack(
            (
                np.rint(normalized * 179).astype(np.uint8),
                np.full(codes.shape, 230, np.uint8),
                np.full(codes.shape, 235, np.uint8),
            ),
            -1,
        )
        rgb = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
    else:
        rgb = cv2.applyColorMap(codes, cv2.COLORMAP_TURBO)[:, :, ::-1]
    rgb[~valid] = (75, 35, 85)
    return rgb


def panel(image, title, note):
    canvas = np.full((330, 460, 3), 24, np.uint8)
    scale = min(450 / image.shape[1], 270 / image.shape[0])
    resized = cv2.resize(
        image, (max(1, round(image.shape[1] * scale)), max(1, round(image.shape[0] * scale)))
    )
    y, x = 53 + (270 - resized.shape[0]) // 2, (460 - resized.shape[1]) // 2
    canvas[y : y + resized.shape[0], x : x + resized.shape[1]] = resized
    cv2.putText(canvas, title, (9, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (235, 235, 235), 1)
    cv2.putText(canvas, note, (9, 42), cv2.FONT_HERSHEY_SIMPLEX, 0.34, (205, 210, 215), 1)
    return canvas


def views(
    source, phase, amplitude, residual, valid, reason, reason_labels, *, depth=None, title=""
):
    raw = np.rint(np.clip(np.nan_to_num(source), 0, 1) * 255).astype(np.uint8)
    source_rgb = np.repeat(raw[:, :, None], 3, axis=2)
    palette = COLORS
    quality = palette[reason]
    output = dict(
        source=source_rgb,
        phase=scalar(phase, 2 * np.pi, cyclic=True),
        amplitude=scalar(amplitude, 0.5),
        residual=scalar(residual, 0.3),
        quality=quality,
    )
    last = panel(
        quality, "Available / rejected", f"Available {valid.mean():.1%}; see reason legend"
    )
    if depth is not None:
        finite = depth[np.isfinite(depth)]
        maximum = float(np.max(finite)) if len(finite) else 1.0
        output["depth"] = scalar(depth, maximum)
        last = panel(output["depth"], "Calibrated axial depth", f"Meters; display 0..{maximum:.5g}")
    dashboard = np.vstack(
        (
            np.hstack(
                (
                    panel(source_rgb, "Source / first observation", title[:70]),
                    panel(
                        output["phase"],
                        "Wrapped phase",
                        "Cyclic 0..2pi radians; purple unavailable",
                    ),
                    panel(
                        output["amplitude"],
                        "Sinusoidal amplitude",
                        "Fixed display 0..0.5 normalized linear units",
                    ),
                )
            ),
            np.hstack(
                (
                    panel(
                        output["residual"],
                        "Relative sinusoidal RMS",
                        "Fixed display 0..0.3; not physical accuracy",
                    ),
                    panel(
                        quality,
                        "Available / rejected",
                        f"Available {valid.mean():.1%}; see reason legend",
                    ),
                    last
                    if depth is not None
                    else panel(
                        np.full_like(source_rgb, 35),
                        "NO METRIC XYZ",
                        "Phase alone has no calibrated absolute depth",
                    ),
                )
            ),
        )
    )
    legend = np.full((50, dashboard.shape[1], 3), 28, np.uint8)
    for index, label in enumerate(reason_labels):
        x, y = 10 + (index % 5) * 275, 5 + (index // 5) * 22
        cv2.rectangle(legend, (x, y), (x + 10, y + 11), palette[index].tolist(), -1)
        cv2.putText(
            legend,
            label.replace("_", " "),
            (x + 15, y + 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.34,
            (220, 220, 220),
            1,
        )
    output["overview"] = np.vstack((dashboard, legend))
    return output
