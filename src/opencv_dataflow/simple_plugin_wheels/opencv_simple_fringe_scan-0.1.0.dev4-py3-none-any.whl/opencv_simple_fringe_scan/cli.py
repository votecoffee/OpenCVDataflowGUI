"""Bounded offline capture/phase replay and explicit metric reconstruction export."""

import argparse
import io
import json
from dataclasses import fields
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from .decode import REASONS, decode
from .geometry import GEOMETRY_REASONS, triangulate
from .model import CompiledScan
from .patterns import Capture
from .phase import PHASE_REASONS, demodulate
from .render import COLORS, views


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("Duplicate JSON key: " + key)
            result[key] = value
        return result

    def invalid(value):
        raise ValueError("Use finite JSON numbers")

    def floating(value):
        number = float(value)
        return number if np.isfinite(number) else invalid(value)

    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid, parse_float=floating)


def load_plane(path, channel):
    if path.stat().st_size > 128 * 1024 * 1024:
        raise ValueError("Source image exceeds 128 MiB")
    if path.suffix == ".npy":
        raw = path.read_bytes()
        stream = io.BytesIO(raw)
        version = np.lib.format.read_magic(stream)
        if version not in ((1, 0), (2, 0)):
            raise ValueError("Use numeric NPY v1/v2 source planes")
        reader = (
            np.lib.format.read_array_header_1_0
            if version == (1, 0)
            else (np.lib.format.read_array_header_2_0)
        )
        shape, _, dtype = reader(stream)
        if (
            len(shape) != 2
            or min(shape) < 2
            or max(shape) > 16384
            or (
                np.prod(shape) > 16_000_000
                or dtype.kind not in "buif"
                or dtype.itemsize > 8
                or int(np.prod(shape)) * dtype.itemsize != len(raw) - stream.tell()
            )
        ):
            raise ValueError("Use a bounded numeric monochrome plane without objects")
        return np.load(io.BytesIO(raw), allow_pickle=False)
    with Image.open(path) as image:
        if (
            min(image.size) < 2
            or max(image.size) > 16384
            or image.width * image.height > 16_000_000
        ):
            raise ValueError("Expanded image exceeds source bounds")
    array = cv2.imdecode(np.frombuffer(path.read_bytes(), np.uint8), cv2.IMREAD_UNCHANGED)
    if array is not None and array.ndim == 2:
        return array
    if (
        array is not None
        and array.ndim == 3
        and array.shape[2] == 3
        and channel in ("red", "green", "blue")
    ):
        return array[:, :, {"red": 2, "green": 1, "blue": 0}[channel]]
    raise ValueError("Use monochrome files or explicitly declare a red/green/blue camera channel")


def read_manifest(path, *, manifest_bytes=None):
    path = Path(path)
    if path.stat().st_size > 2 * 1024 * 1024:
        raise ValueError("Capture manifest exceeds 2 MiB")
    data = strict_json(path.read_bytes() if manifest_bytes is None else manifest_bytes)
    if data.get("schema") not in ("simple_fringe_phase/v1", "simple_fringe_capture/v1"):
        raise ValueError("Use a simple_fringe_phase/v1 or simple_fringe_capture/v1 manifest")
    scale, encoding = data.get("input_scale"), data.get("source_encoding")
    if type(scale) not in (int, float) or not np.isfinite(scale) or scale <= 0:
        raise ValueError("Declare a positive source-code input scale")
    if encoding not in ("linear", "srgb"):
        raise ValueError("Explicitly declare linear or srgb source encoding")
    entries = data.get("frames")
    if not isinstance(entries, list) or not 3 <= len(entries) <= 128:
        raise ValueError("Declare a bounded complete ordered frame list")
    ids = [row.get("id") for row in entries]
    if any(not isinstance(v, str) or not 0 < len(v.strip()) <= 128 for v in ids) or (
        len(set(ids)) != len(ids)
    ):
        raise ValueError("Declare unique named frame IDs in observed order")
    if data["schema"] == "simple_fringe_phase/v1" and ids != [
        f"phase:{i}" for i in range(len(ids))
    ]:
        raise ValueError("Phase IDs/order must be phase:0 through phase:N-1")
    for key in ("capture_id", "pixel_grid"):
        if not isinstance(data.get(key), str) or not 0 < len(data[key].strip()) <= 128:
            raise ValueError("Name the capture and original camera pixel grid")
    exposure = data.get("exposure_s")
    if type(exposure) not in (int, float) or not np.isfinite(exposure) or not 0 < exposure <= 3600:
        raise ValueError("Declare one common positive exposure in seconds")
    planes, shape = [], None
    for entry in entries:
        image = load_plane(path.parent / entry["image"], data.get("channel", "gray"))
        if shape is None:
            shape = image.shape
            if image.size * len(entries) > 16_000_000:
                raise ValueError("Capture stack exceeds 16 million samples")
        elif image.shape != shape:
            raise ValueError("All observations must share the same registered pixel dimensions")
        raw = image.astype(np.float32) / scale
        if np.any(np.isfinite(raw) & ((raw < 0) | (raw > 1))):
            raise ValueError("Source code scale must produce 0..1 values")
        if encoding == "srgb":
            raw = np.where(raw <= 0.04045, raw / 12.92, ((raw + 0.055) / 1.055) ** 2.4)
        planes.append(raw)
    mask = load_plane(path.parent / data["mask"], "gray") if data.get("mask") else None
    return data, np.stack(planes), mask


def run(data, images, mask=None, *, graphics=True, model=None, cancelled=lambda: False):
    if cancelled():
        raise RuntimeError("Fringe processing cancelled; no result published")
    model = CompiledScan(data, images.shape) if model is None else model
    if not isinstance(model, CompiledScan) or not model.matches(data, images):
        raise ValueError(
            "Compiled scan differs from settings, calibration or original image dimensions"
        )
    if data["schema"] == "simple_fringe_phase/v1":
        fit = demodulate(
            images,
            data["phase_angles"],
            settings=model.phase,
            mask=mask,
            basis=model.basis,
        )
        maps = {
            field.name: getattr(fit, field.name) for field in fields(fit) if field.name != "steps"
        }
        report = dict(
            schema="simple_fringe_phase_result/v1",
            capture_id=data["capture_id"],
            pixel_grid=data["pixel_grid"],
            valid_pixels=int(fit.valid.sum()),
            active_pixels=int(np.sum(fit.reason != 1)),
            phase_angles=list(fit.steps),
            no_phase_redundancy=len(fit.steps) == 3,
            metric=False,
            reason_counts={
                name: int((fit.reason == i).sum())
                for i, name in enumerate(PHASE_REASONS)
                if np.any(fit.reason == i)
            },
            scope="Wrapped phase evidence only; no absolute correspondence or metric XYZ",
        )
        raster = (
            views(
                images[0],
                fit.wrapped,
                fit.amplitude,
                fit.relative_rms,
                fit.valid,
                fit.reason,
                PHASE_REASONS,
                title=data["capture_id"],
            )
            if graphics
            else {}
        )
    else:
        plan = model.plan
        capture = Capture(
            plan,
            images,
            tuple(row["id"] for row in data["frames"]),
            data["capture_id"],
            data["pixel_grid"],
            "linear",
            data["exposure_s"],
            mask,
        )
        decoded = decode(capture, model.decode, cancelled=cancelled, basis=model.basis)
        maps = {
            field.name: getattr(decoded, field.name)
            for field in fields(decoded)
            if field.name != "report"
        }
        report = dict(decoded.report, metric=False)
        depth = None
        final_valid, final_reason, labels = decoded.valid, decoded.reason, REASONS
        if model.calibration is not None:
            if cancelled():
                raise RuntimeError("Fringe processing cancelled; no result published")
            geometry = triangulate(
                model.calibration,
                model.camera.pixels,
                decoded.projector_pixels.reshape(-1, 2),
                model.geometry,
                prepared_camera=model.camera,
            )
            for key, value in geometry.items():
                if key != "report":
                    maps["geometry_" + key] = value.reshape(images.shape[1:] + value.shape[1:])
            report["geometry"], report["metric"] = geometry["report"], True
            report["decoded_valid_pixels"] = report["valid_pixels"]
            report["decoded_coverage"] = report["coverage"]
            report["valid_pixels"] = geometry["report"]["valid_samples"]
            depth = maps["geometry_xyz_m"][:, :, 2]
            final_valid, final_reason, labels = (
                maps["geometry_valid"],
                maps["geometry_reason"],
                GEOMETRY_REASONS,
            )
        raster = (
            views(
                images[1],
                decoded.wrapped_phase[:, :, 0],
                decoded.amplitude[:, :, 0],
                decoded.relative_rms[:, :, 0],
                final_valid,
                final_reason,
                labels,
                depth=depth,
                title=data["capture_id"],
            )
            if graphics
            else {}
        )
        if graphics:
            raster["decode_quality"] = COLORS[decoded.reason]
    report["source_encoding"] = data["source_encoding"]
    report["input_scale"] = data["input_scale"]
    report["coverage"] = float(report["valid_pixels"] / max(1, report["active_pixels"]))
    report["input_provenance"] = data.get("provenance", {})
    if cancelled():
        raise RuntimeError("Fringe processing cancelled; no result published")
    return dict(maps=maps, report=report, views=raster)


def export(output, result):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    with (output / "maps.npz").open("xb") as stream:
        np.savez_compressed(stream, **result["maps"])
    (output / "report.json").write_bytes(
        (json.dumps(result["report"], indent=2, allow_nan=False) + "\n").encode()
    )
    for name, rgb in result["views"].items():
        okay, encoded = cv2.imencode(".png", rgb[:, :, ::-1])
        if not okay:
            raise ValueError("Cannot encode diagnostic result")
        with (output / (name + ".png")).open("xb") as stream:
            stream.write(encoded.tobytes())
    if result["report"]["metric"]:
        maps = result["maps"]
        points = maps["geometry_xyz_m"][maps["geometry_valid"]]
        with (output / "accepted.ply").open("x", encoding="ascii", newline="\n") as stream:
            stream.write(
                "ply\nformat ascii 1.0\ncomment units m\ncomment frame "
                + result["report"]["geometry"]["frame"]
                + "\nelement vertex "
                + str(len(points))
                + "\nproperty float x\nproperty float y\nproperty float z\n"
                "property uchar red\nproperty uchar green\nproperty uchar blue\nend_header\n"
            )
            for point in points:
                stream.write(" ".join(f"{value:.10g}" for value in point) + " 40 210 95\n")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capture", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--no-graphics", action="store_true")
    args = parser.parse_args(argv)
    data, images, mask = read_manifest(args.capture)
    result = run(data, images, mask, graphics=not args.no_graphics)
    export(args.output, result)
    print(
        json.dumps({key: result["report"][key] for key in ("capture_id", "valid_pixels", "metric")})
    )


if __name__ == "__main__":
    main()
