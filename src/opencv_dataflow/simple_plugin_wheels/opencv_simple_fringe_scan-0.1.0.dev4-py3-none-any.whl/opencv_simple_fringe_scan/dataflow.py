"""One cached execution block and native accepted-point cloud output."""

import re
from pathlib import Path, PurePosixPath
from threading import RLock

import numpy as np
from opencv_dataflow.core import Port, Result
from opencv_dataflow.geometry3d_common import Tool3D
from opencv_dataflow.images import ImageArray
from opencv_dataflow.parameter_validation import NumericRange, ValidationError
from opencv_dataflow.payloads import NO_VALUE, frame
from opencv_dataflow.pointclouds import PointCloud

from .completed_review import CompletedFringeReview, retain_completed
from .execution import capture_from_recipe, execute
from .model import CompiledScan
from .recipe import import_capture, load_recipe


def recipe_path(project_dir, relative):
    if project_dir is None:
        raise ValueError("Save the project before staging a fringe recipe")
    path = PurePosixPath(relative)
    if (
        not relative
        or path.is_absolute()
        or ".." in path.parts
        or ":" in relative
        or ("\\" in relative or path.suffix != ".sfs")
    ):
        raise ValueError("Choose a project-contained .sfs recipe using forward slashes")
    root = Path(project_dir).resolve()
    target = (root / relative).resolve()
    if not target.is_relative_to(root):
        raise ValueError("Recipe resolves outside the project directory")
    return target


def signature(path):
    stat = path.stat()
    return stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns, stat.st_ino


class RecipeCache:
    def __init__(self):
        self.lock = RLock()
        self.key = self.recipe = self.model = None

    def get(self, path, digest):
        with self.lock:
            key = str(path), digest, signature(path)
            if key != self.key:
                recipe = load_recipe(path, sha256=digest)
                model = CompiledScan(recipe.definition, recipe.reference.shape)
                if signature(path) != key[2]:
                    raise ValueError("Recipe changed during loading; retry with the current recipe")
                self.key, self.recipe, self.model = key, recipe, model
            return self.recipe, self.model


def result_cloud(output, *, colors=True, gap_limit=0.0005):
    if not output["report"]["metric"]:
        return NO_VALUE
    maps = output["maps"]
    selected = maps["geometry_valid"]
    if not selected.any():
        return NO_VALUE
    rgb = None
    if colors:
        ratio = np.clip(maps["geometry_ray_gap_m"][selected] / gap_limit, 0, 1)
        rgb = np.c_[40 + 200 * ratio, 210 - 130 * ratio, 95 - 60 * ratio].astype(np.uint8)
    return PointCloud(
        maps["geometry_xyz_m"][selected],
        "m",
        output["report"]["geometry"]["frame"],
        colors=rgb,
        pixels=maps["geometry_camera_pixels"][selected].astype(np.int32),
        source_size=tuple(selected.shape[::-1]),
        metadata={
            "fringe_scan": {
                "gap_filling": False,
                "color_scope": "Accepted ray gap: green toward orange at the retained limit",
            }
        },
    )


class SimpleFringeScan(CompletedFringeReview, Tool3D):
    type_id, title = "3d.simple_fringe_scan", "SimpleFringeScan"
    subtype = "Fringe scanning"
    parallel_safe = process_inputs_readonly = preview_safe = True
    plugin_dialog_label = "Set up sequence and calibration…"
    plugin_dialog_modeless = True
    inputs = (
        Port(
            "capture",
            "any",
            required=False,
            required_when_connected=True,
            visual_type="fringe_capture_stack",
        ),
    )
    outputs = (
        Port("image", "image"),
        Port("cloud", "cloud", required=False),
        Port("maps", "any", visual_type="fringe_scan_maps"),
        Port("report", "data"),
        Port("coverage", "number"),
        Port("count", "integer"),
        Port("metric", "boolean"),
        Port("overview", "image", required=False),
    )
    defaults = dict(
        recipe_path="",
        sha256="",
        source="connected capture",
        capture_manifest="",
        minimum_coverage=0.0,
        render_graphics=True,
    )
    parameter_choices = {"source": ("connected capture", "capture manifest")}
    parameter_ranges = {"minimum_coverage": NumericRange(0, 1)}
    project_path_parameters = ("capture_manifest",)
    parameter_help = {
        "recipe_path": "Retained .sfs source/sequence/calibration recipe; use setup to teach.",
        "sha256": "Pinned recipe checksum; cached with the compiled phase basis and camera rays.",
        "source": "Explicitly consume a connected stack or replay an offline capture manifest.",
        "capture_manifest": "Offline capture file; image paths inside it resolve relative to it. "
        "Connected mode never silently falls back to training images.",
        "minimum_coverage": "Minimum accepted/active source pixels, 0..1. Zero still needs a valid "
        "sample. Availability is not accuracy, confidence or defect acceptance.",
        "render_graphics": "Create diagnostic image layers and ray-gap cloud colors. "
        "Disabling graphics preserves numerical maps and accepted XYZ/pixel rows.",
    }
    input_help = {
        "capture": "simple_fringe_stack/v1 with normalized linear N×H×W arrays, "
        "observed IDs/order, sequence, source grid, common exposure and known calibration."
    }
    output_help = {
        "image": "Raw wrapped phase in radians, original camera grid; unavailable NaN. "
        "Use Overview/phase graphic for cyclic display. This is not depth.",
        "cloud": "Native fly-around: accepted finite XYZ in camera meters, source pixel indices "
        "and optional ray-gap colors. Absent in phase-only or zero-metric-coverage results.",
        "maps": "Raw phase, modulation, fit, correspondence, reasons and calibrated ray/XYZ maps.",
        "report": "Actual/reference identity, decoded/metric availability and rejection reasons. "
        "Known calibration is imported; physical accuracy remains unqualified.",
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.preview_output = "cloud"
        self.cache = RecipeCache()
        self._completed_review = None

    def validate_parameters(self, parameters=None):
        super().validate_parameters(parameters)
        p = self.parameters if parameters is None else parameters
        if not all(
            isinstance(p[key], str) for key in ("recipe_path", "sha256", "capture_manifest")
        ):
            raise ValidationError("Choose recipe/capture paths and the recipe checksum")
        if p["recipe_path"] or p["sha256"]:
            try:
                recipe_path(self.project_dir, p["recipe_path"])
            except ValueError as error:
                raise ValidationError(str(error), "recipe_path") from error
            if re.fullmatch("[0-9a-f]{64}", p["sha256"]) is None:
                raise ValidationError("Stage/import the recipe and its SHA-256", "sha256")
        if type(p["render_graphics"]) is not bool:
            raise ValidationError("Render graphics must be boolean", "render_graphics")
        if type(p["minimum_coverage"]) not in (int, float) or not (
            np.isfinite(p["minimum_coverage"]) and 0 <= p["minimum_coverage"] <= 1
        ):
            raise ValidationError("Minimum coverage must be in 0..1", "minimum_coverage")

    def process(self, inputs):
        self._completed_review = None
        p = self.parameters
        if not p["recipe_path"]:
            raise ValidationError("Set up a fringe sequence/reference first", "recipe_path")
        recipe, model = self.cache.get(recipe_path(self.project_dir, p["recipe_path"]), p["sha256"])
        manifest_bytes = None
        if p["source"] == "connected capture":
            if "capture" not in inputs:
                raise ValidationError(
                    "Connect a capture stack or explicitly select capture manifest"
                )
            capture = inputs["capture"]
        else:
            if "capture" in inputs:
                raise ValidationError("Select connected capture to use the wired source stack")
            if not p["capture_manifest"]:
                raise ValidationError("Choose an offline capture manifest", "capture_manifest")
            path = Path(p["capture_manifest"])
            if not path.is_absolute():
                if self.project_dir is None:
                    raise ValidationError("Save the project or use an absolute capture manifest")
                path = self.project_dir / path
            imported = import_capture(path)
            capture = capture_from_recipe(imported)
            manifest_bytes = imported._capture_manifest_bytes
        graphics = self.generate_graphics and p["render_graphics"]
        output = execute(recipe, capture, model=model, graphics=graphics, cancelled=self._cancelled)
        report, maps = output["report"], output["maps"]
        passed = report["valid_pixels"] > 0 and report["coverage"] >= p["minimum_coverage"]
        report["decision"] = dict(
            passed=passed,
            minimum_coverage=p["minimum_coverage"],
            scope="Accepted coverage only; not gauge or defect acceptance",
        )
        image = maps["wrapped"] if "wrapped" in maps else maps["wrapped_phase"][:, :, 0]
        payloads = {
            name: {
                "spatial": frame(
                    list(image.shape[::-1]), "fringe-source:" + recipe.definition["pixel_grid"]
                )
            }
            for name in ("image", "maps")
        }
        if graphics:
            payloads["overview"] = {
                "spatial": frame(
                    list(output["views"]["overview"].shape[1::-1]), "fringe-overview:" + self.id
                )
            }
        outputs = dict(
            image=ImageArray(image, "gray"),
            maps=maps,
            report=report,
            cloud=result_cloud(output, colors=graphics, gap_limit=model.geometry.maximum_ray_gap_m),
            coverage=report["coverage"],
            count=report["valid_pixels"],
            metric=report["metric"],
            overview=ImageArray(output["views"]["overview"], "rgb") if graphics else NO_VALUE,
        )
        binding = retain_completed(self, recipe, model, capture, output, outputs, manifest_bytes)
        for name, token in binding.items():
            payloads.setdefault(name, {}).update(token)
        return Result(
            outputs=outputs,
            payloads=payloads,
            graphics={key: ImageArray(value, "rgb") for key, value in output["views"].items()},
            passed=passed,
            fail_reasons=[] if passed else ["fringe_unavailable_coverage"],
            message=f"{report['valid_pixels']}/{report['active_pixels']} accepted pixels "
            f"({report['coverage']:.1%}); "
            + (
                "calibrated meters"
                if report["metric"]
                else "PHASE/CORRESPONDENCE ONLY, no metric XYZ"
            ),
        )

    def create_plugin_dialog(self, parent, parameters, context):
        from .qt_training import FringeTrainingDialog

        return FringeTrainingDialog(parent, parameters, context)

    def close(self):
        self.cache = RecipeCache()
        super().close()


def register(registry):
    registry.register(SimpleFringeScan)
