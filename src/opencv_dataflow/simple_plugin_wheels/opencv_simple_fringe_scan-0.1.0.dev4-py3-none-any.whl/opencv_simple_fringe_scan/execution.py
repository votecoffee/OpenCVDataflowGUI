"""Explicit array-preserving runtime capture contract and compiled recipe execution."""

import numpy as np

from .cli import run
from .geometry import Calibration, Pinhole
from .model import CompiledScan
from .recipe import FringeRecipe, json_copy, source_mask


def sequence(data):
    return {key: data.get(key) for key in ("schema", "plan", "phase_angles")}


def calibrated_record(value):
    if value is None:
        return None
    if value.get("units", "m") != "m":
        raise ValueError("Known calibration translation must be declared in meters")
    rig = Calibration(
        Pinhole(**value["camera"]),
        Pinhole(**value["projector"]),
        value["rotation_cp"],
        value["translation_cp_m"],
    )

    def device(model):
        return dict(
            matrix=model.matrix.tolist(),
            image_size=list(model.image_size),
            distortion=list(model.distortion),
            frame=model.frame,
        )

    return dict(
        camera=device(rig.camera),
        projector=device(rig.projector),
        rotation_cp=rig.rotation_cp.tolist(),
        translation_cp_m=rig.translation_cp_m.tolist(),
    )


def capture_from_recipe(recipe):
    data = recipe.definition
    return dict(
        schema="simple_fringe_stack/v1",
        images=recipe.reference,
        mask=recipe.mask,
        frame_ids=[row["id"] for row in data["frames"]],
        capture_id=data["capture_id"],
        pixel_grid=data["pixel_grid"],
        response="linear",
        exposure_s=data["exposure_s"],
        sequence=sequence(data),
        calibration=data.get("calibration"),
        metadata=data.get("provenance", {}),
    )


def retain_capture(capture):
    if (
        not isinstance(capture, dict)
        or capture.get("schema") != "simple_fringe_stack/v1"
        or (capture.get("response") != "linear")
    ):
        raise ValueError("Retain a declared simple_fringe_stack/v1 linear capture")
    data = dict(capture["sequence"])
    data.update(
        frames=[dict(id=value) for value in capture["frame_ids"]],
        capture_id=capture["capture_id"],
        pixel_grid=capture["pixel_grid"],
        exposure_s=capture["exposure_s"],
        source_encoding="linear",
        input_scale=1,
    )
    if capture.get("calibration"):
        data["calibration"] = capture["calibration"]
    data["provenance"] = json_copy(capture.get("metadata", {}), limit=512 * 1024)
    return FringeRecipe(data, capture["images"], capture.get("mask"))


def execute(recipe, capture=None, *, model=None, graphics=True, cancelled=lambda: False):
    if not isinstance(recipe, FringeRecipe):
        raise ValueError("Use a retained fringe reference recipe")
    capture = capture_from_recipe(recipe) if capture is None else capture
    data = recipe.definition
    if not isinstance(capture, dict) or capture.get("schema") != "simple_fringe_stack/v1":
        raise ValueError("Provide a simple_fringe_stack/v1 capture")
    if (
        capture.get("response") != "linear"
        or type(capture.get("exposure_s")) not in (int, float)
        or (capture.get("exposure_s") != data["exposure_s"])
    ):
        raise ValueError("Capture must match the reference's linear response and declared exposure")
    if capture.get("pixel_grid") != data["pixel_grid"] or (
        np.asarray(capture.get("images")).shape != recipe.reference.shape
    ):
        raise ValueError("Capture dimensions and original pixel grid must match the reference")
    if list(capture.get("frame_ids", ())) != [row["id"] for row in data["frames"]] or (
        json_copy(capture.get("sequence")) != sequence(data)
    ):
        raise ValueError("Observed sequence, phase angles and frame IDs/order must match training")
    if calibrated_record(capture.get("calibration")) != calibrated_record(data.get("calibration")):
        raise ValueError("Capture camera/projector calibration must match the retained setup")
    identity = capture.get("capture_id")
    if not isinstance(identity, str) or not 0 < len(identity.strip()) <= 128:
        raise ValueError(
            "Name the actual capture; editor IDs do not prove physical synchronization"
        )
    raw = np.asarray(capture["images"])
    if raw.dtype.str not in ("<f4", "<f8"):
        raise ValueError("Connected capture must contain normalized floating linear source codes")
    mask = source_mask(capture.get("mask"), raw.shape[1:])
    if recipe.mask is not None:
        mask = recipe.mask if mask is None else mask & recipe.mask
    model = CompiledScan(data, raw.shape) if model is None else model
    data["capture_id"] = identity
    output = run(data, raw, mask, model=model, graphics=graphics, cancelled=cancelled)
    output["report"]["reference_capture_id"] = recipe.definition["capture_id"]
    output["report"]["capture_metadata"] = json_copy(capture.get("metadata", {}), 512 * 1024)
    return output
