"""Reusable phase/calibration/grid compilation, independent of inspection image values."""

import json

import numpy as np

from .decode import DecodeSettings
from .geometry import Calibration, GeometrySettings, Pinhole, PreparedCameraRays
from .patterns import PatternPlan
from .phase import PhaseBasis, PhaseSettings


def processing_key(data):
    return json.dumps(
        {
            key: data.get(key)
            for key in (
                "schema",
                "plan",
                "phase_angles",
                "decode_settings",
                "phase_settings",
                "calibration",
                "geometry",
            )
        },
        sort_keys=True,
        allow_nan=False,
    )


class ScanDefinition:
    """Validate settings and calibration without building a full camera-ray grid."""

    def __init__(self, definition, image_shape):
        if len(image_shape) != 3 or min(image_shape) < 2 or np.prod(image_shape) > 16_000_000:
            raise ValueError("Compile a bounded N×H×W source stack")
        self.image_shape, self.key = tuple(image_shape), processing_key(definition)
        self.plan = self.calibration = None
        self.geometry = GeometrySettings(**definition.get("geometry", {}))
        if definition["schema"] == "simple_fringe_phase/v1":
            self.phase = PhaseSettings(**definition.get("phase_settings", {}))
            self.basis = PhaseBasis(definition["phase_angles"])
            if len(self.basis.angles) != image_shape[0]:
                raise ValueError("Phase count differs from the observed stack")
        elif definition["schema"] == "simple_fringe_capture/v1":
            self.plan = PatternPlan(**definition["plan"])
            options = dict(definition.get("decode_settings", {}))
            options["phase"] = PhaseSettings(**options.get("phase", {}))
            self.decode = DecodeSettings(**options)
            self.basis = PhaseBasis(self.plan.phase_angles)
            if len(self.plan.pattern_ids) != image_shape[0]:
                raise ValueError("Pattern count differs from the observed stack")
            if definition.get("calibration"):
                record = definition["calibration"]
                if record.get("units", "m") != "m":
                    raise ValueError("Known calibration translation must be declared in meters")
                self.calibration = Calibration(
                    Pinhole(**record["camera"]),
                    Pinhole(**record["projector"]),
                    record["rotation_cp"],
                    record["translation_cp_m"],
                )
                if self.calibration.camera.image_size != (image_shape[2], image_shape[1]) or (
                    self.calibration.projector.image_size != self.plan.projector_size
                ):
                    raise ValueError(
                        "Calibration must match original camera and projector dimensions"
                    )
        else:
            raise ValueError("Compile a declared full-scan or phase-only definition")


class CompiledScan(ScanDefinition):
    def __init__(self, definition, image_shape):
        super().__init__(definition, image_shape)
        self.camera = None
        if self.calibration is not None:
            yy, xx = np.indices(image_shape[1:])
            self.camera = PreparedCameraRays(
                self.calibration.camera, np.stack((xx, yy), -1).reshape(-1, 2)
            )

    def matches(self, data, images):
        return tuple(images.shape) == self.image_shape and processing_key(data) == self.key
