"""Retained sequence/calibration teaching with stale-safe worker previews and draft staging."""

import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Event

import cv2
import numpy as np
from opencv_dataflow.canvas import pixmap
from opencv_dataflow.cloud_viewer import CloudViewer
from opencv_dataflow.filmstrip_viewer import FilmstripImageView
from opencv_dataflow.images import ImageArray
from opencv_dataflow.payloads import NO_VALUE
from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from .cli import strict_json
from .dataflow import recipe_path, result_cloud
from .execution import capture_from_recipe, execute, retain_capture
from .qt_region import FringeRegionView
from .recipe import FringeRecipe, import_capture, json_copy, load_recipe, save_recipe, source_mask
from .training_setup import frame_rows, input_ceiling, setup_summary, source_audit, validate_setup


def rectangle(mask, shape):
    if mask is None:
        return (0, 0, shape[1], shape[0])
    yy, xx = np.nonzero(mask)
    if not len(xx):
        return None
    x, y, right, bottom = int(xx.min()), int(yy.min()), int(xx.max()) + 1, int(yy.max()) + 1
    return (x, y, right - x, bottom - y) if mask.sum() == (right - x) * (bottom - y) else None


class CalibrationEditor(QWidget):
    changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.current = None
        self.devices = {}
        box = QVBoxLayout(self)
        for name in ("camera", "projector"):
            box.addWidget(QLabel(name.title() + " original pixel calibration"))
            table = QTableWidget(3, 3)
            table.setMaximumHeight(120)
            table.setHorizontalHeaderLabels(["X", "Y", "1"])
            table.cellChanged.connect(lambda *_: self.changed.emit())
            box.addWidget(table)
            form = QFormLayout()
            frame, distortion = QLineEdit(), QLineEdit()
            for label, field in (
                ("Physical frame", frame),
                ("Distortion coefficients", distortion),
            ):
                field.textChanged.connect(lambda *_: self.changed.emit())
                form.addRow(label, field)
            box.addLayout(form)
            size = QLabel()
            box.addWidget(size)
            self.devices[name] = dict(matrix=table, frame=frame, distortion=distortion, size=size)
        box.addWidget(QLabel("Camera → projector rotation (proper rigid 3×3)"))
        self.rotation = QTableWidget(3, 3)
        self.rotation.setMaximumHeight(120)
        self.rotation.cellChanged.connect(lambda *_: self.changed.emit())
        box.addWidget(self.rotation)
        form = QFormLayout()
        self.translation = [QLineEdit() for _ in range(3)]
        for axis, field in zip(("X", "Y", "Z"), self.translation):
            field.textChanged.connect(lambda *_: self.changed.emit())
            form.addRow("Translation " + axis + " (meters)", field)
        box.addLayout(form)
        self.setEnabled(False)

    @staticmethod
    def fill(table, matrix):
        for r in range(3):
            for c in range(3):
                table.setItem(r, c, QTableWidgetItem(repr(float(matrix[r][c]))))

    @staticmethod
    def matrix(table):
        return [[float(table.item(r, c).text()) for c in range(3)] for r in range(3)]

    def restore(self, record):
        self.current = json_copy(record) if record else None
        self.setEnabled(bool(record))
        if not record:
            for fields in self.devices.values():
                fields["matrix"].clearContents()
                fields["frame"].clear()
                fields["distortion"].clear()
                fields["size"].setText("No known metric calibration retained")
            self.rotation.clearContents()
            for field in self.translation:
                field.clear()
            return
        for name, fields in self.devices.items():
            data = record[name]
            self.fill(fields["matrix"], data["matrix"])
            fields["frame"].setText(data["frame"])
            fields["distortion"].setText(
                ", ".join(repr(float(v)) for v in data.get("distortion", []))
            )
            fields["size"].setText(f"Original width × height: {data['image_size']}")
        self.fill(self.rotation, record["rotation_cp"])
        for field, value in zip(self.translation, record["translation_cp_m"]):
            field.setText(repr(float(value)))

    def record(self):
        if self.current is None:
            return None
        record = json_copy(self.current)
        for name, fields in self.devices.items():
            record[name].update(
                matrix=self.matrix(fields["matrix"]),
                frame=fields["frame"].text(),
                distortion=[
                    float(v.strip()) for v in fields["distortion"].text().split(",") if v.strip()
                ],
            )
        record["rotation_cp"] = self.matrix(self.rotation)
        record["translation_cp_m"] = [float(field.text()) for field in self.translation]
        return record


class FringeTrainingDialog(QDialog):
    def __init__(self, parent, parameters, context):
        super().__init__(parent)
        self.setWindowTitle("SimpleFringeScan · sequence, region and known calibration")
        screen = self.screen().availableGeometry()
        self.resize(min(1320, screen.width() - 40), min(900, screen.height() - 40))
        self.parameters, self.context = parameters, context
        self.reference = self.candidate = self.reference_result = self.last_result = None
        self.mask = None
        self.audit_result = None
        self.sequence_display = None
        self.revision = 0
        self.restoring = self.closed = False
        self.pending = None
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="fringe-setup")
        self.unsubscribe = None
        self.cloud_windows = []
        layout = QVBoxLayout(self)
        self.status = QLabel(
            "1. Import/capture an ordered reference. 2. Review region/calibration. "
            "3. Preview, then Stage / Apply."
        )
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.guidance = QLabel()
        self.guidance.setWordWrap(True)
        layout.addWidget(self.guidance)
        row = QGridLayout()
        footer = QGridLayout()
        for title, action in (
            ("Import reference capture…", self.import_reference),
            ("Capture connected reference", self.capture_reference),
            ("Import recipe…", self.import_recipe),
        ):
            self.button(row, title, action)
        layout.addLayout(row)
        split = QSplitter(Qt.Orientation.Horizontal)
        layout.addWidget(split, 1)
        side = QWidget()
        controls = QVBoxLayout(side)
        self.identity = QLabel("No retained reference")
        self.identity.setWordWrap(True)
        controls.addWidget(self.identity)
        self.setup_status = QLabel()
        self.setup_status.setWordWrap(True)
        controls.addWidget(self.setup_status)
        self.reference_health = QLabel()
        self.reference_health.setWordWrap(True)
        controls.addWidget(self.reference_health)
        self.source_frame = QComboBox()
        self.source_frame.currentIndexChanged.connect(self.show_source)
        controls.addWidget(QLabel("Retained observation / observed ID"))
        controls.addWidget(self.source_frame)
        self.sequence_table = QTableWidget(0, 6)
        self.sequence_table.setHorizontalHeaderLabels(
            ["Observed ID", "Role", "Shift (rad)", "Available", "Nonfinite", "Ceiling"]
        )
        self.sequence_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.sequence_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.sequence_table.setMinimumHeight(150)
        self.sequence_table.setMaximumHeight(200)
        self.sequence_table.currentCellChanged.connect(self.select_frame)
        controls.addWidget(self.sequence_table)
        self.source_flags = QCheckBox("Show unavailable observations on source")
        self.source_flags.setToolTip("Magenta: nonfinite. Red: at or above input ceiling.")
        self.source_flags.toggled.connect(self.show_source)
        controls.addWidget(self.source_flags)
        self.audit_health = QLabel()
        self.audit_health.setWordWrap(True)
        controls.addWidget(self.audit_health)
        self.fields = {}
        form = QFormLayout()
        for key, label, default in (
            ("exposure", "Common exposure (seconds)", ".01"),
            ("angles", "Phase-only shifts (radians)", ""),
            ("amplitude", "Minimum phase amplitude (0..1)", ".03"),
            ("rms", "Maximum relative phase RMS", ".15"),
            ("illumination", "Minimum white-black signal", ".08"),
            ("gray", "Minimum relative Gray contrast", ".15"),
            ("disagreement", "Maximum Gray/phase error (pixels)", ".75"),
            ("angle", "Minimum ray angle (degrees)", ".25"),
            ("gap", "Maximum ray gap (meters)", ".0005"),
            ("reprojection", "Maximum reprojection error (pixels)", ".75"),
            ("near", "Minimum axial depth (meters)", ".001"),
            ("far", "Maximum axial depth (meters)", "100"),
        ):
            field = QLineEdit(default)
            field.setProperty("field_label", label)
            field.textChanged.connect(lambda *_: self.invalidate())
            self.fields[key] = field
            form.addRow(label, field)
        controls.addLayout(form)
        for title, action in (
            ("Import camera / projector calibration…", self.import_calibration),
            ("Clear metric calibration", lambda: self.set_calibration(None)),
            ("Import source inspection mask…", self.import_mask),
            ("Use full source region", lambda: self.set_mask(None)),
            ("Draw inspection rectangle", lambda: self.region_mode("draw")),
            ("Move / resize rectangle", lambda: self.region_mode("edit")),
            ("Pan image", lambda: self.region_mode("pan")),
        ):
            self.button(controls, title, action)
        self.audit_button = self.button(footer, "Audit source sequence", self.start_audit)
        self.preview_button = self.button(footer, "Preview reference", self.preview_reference)
        self.test_button = self.button(footer, "Preview another capture…", self.preview_file)
        self.wire_button = self.button(footer, "Preview connected capture", self.preview_connected)
        self.cloud_button = self.button(controls, "Open native result cloud…", self.open_cloud)
        self.health = QLabel("Fit, decoded/metric coverage and rejection counts appear here.")
        self.health.setWordWrap(True)
        controls.addWidget(self.health)
        controls.addStretch()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(side)
        scroll.setMinimumWidth(270)
        split.addWidget(scroll)
        self.tabs = QTabWidget()
        self.editor = FringeRegionView(self.tabs)
        self.views = {}
        self.add_view(self.editor, "Retained source / region")
        for name, title in (
            ("overview", "Fit overview"),
            ("phase", "Wrapped phase"),
            ("amplitude", "Modulation"),
            ("residual", "Sinusoidal fit"),
            ("decode_quality", "Decode availability"),
            ("quality", "Result availability"),
            ("depth", "Metric depth"),
        ):
            view = FilmstripImageView(self.tabs)
            self.views[name] = view
            self.add_view(view, title)
        self.calibration = CalibrationEditor(self.tabs)
        cal_scroll = QScrollArea()
        cal_scroll.setWidgetResizable(True)
        cal_scroll.setWidget(self.calibration)
        self.tabs.addTab(cal_scroll, "Known calibration")
        self.calibration.changed.connect(self.invalidate)
        self.editor.region_changed.connect(lambda roi: self.safe(lambda: self.set_region(roi)))
        split.addWidget(self.tabs)
        split.setSizes([440, 880])
        hint = QLabel(
            "Scroll to zoom; Pan moves the view. Masks stay exact until replaced. "
            "Import known calibration; estimating it from images is future work. "
            "Keep original pixel coordinates and one pose/exposure through the ordered sequence. "
            "Phase-only results have no metric cloud. Preview captures never replace training. "
            "Stage edits the inspector draft; Apply configuration commits it."
        )
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.stage_button = self.button(footer, "Stage recipe", self.stage)
        self.button(footer, "Cancel", self.reject)
        layout.addLayout(footer)
        self.timer = QTimer(self)
        self.timer.setInterval(40)
        self.timer.timeout.connect(self.poll)
        if hasattr(context, "subscribe_outputs"):
            self.unsubscribe = context.subscribe_outputs(self.outputs_changed)
        if parameters.get("recipe_path"):
            self.safe(
                lambda: self.restore(
                    load_recipe(
                        recipe_path(context.project_dir, parameters["recipe_path"]),
                        sha256=parameters["sha256"],
                    ),
                    preview=True,
                )
            )
        self.refresh()
        self.finished.connect(lambda *_: self.shutdown())

    def button(self, layout, title, action):
        button = QPushButton(title)
        button.setAutoDefault(False)
        button.clicked.connect(lambda checked=False: self.safe(action))
        if isinstance(layout, QGridLayout):
            index = layout.count()
            layout.addWidget(button, index // 2, index % 2)
        else:
            layout.addWidget(button)
        return button

    def add_view(self, view, title):
        page, row = QWidget(), QHBoxLayout()
        box = QVBoxLayout(page)
        box.addWidget(view, 1)
        for label, action in (
            ("−", lambda: view.zoom(0.8)),
            ("+", lambda: view.zoom(1.25)),
            ("Fit", view.fit_image),
            ("100%", view.actual_size),
        ):
            self.button(row, label, action)
        box.addLayout(row)
        self.tabs.addTab(page, title)

    def safe(self, action):
        try:
            action()
        except Exception as error:
            self.status.setText(str(error))

    def choose(self, title, pattern):
        path, _ = QFileDialog.getOpenFileName(self, title, "", pattern)
        return Path(path) if path else None

    def restore(self, recipe, *, preview=False):
        from .decode import DecodeSettings
        from .geometry import GeometrySettings
        from .phase import PhaseSettings

        data = recipe.definition
        phase_only = data["schema"] == "simple_fringe_phase/v1"
        phase = (
            PhaseSettings(**data.get("phase_settings", {}))
            if phase_only
            else (PhaseSettings(**data.get("decode_settings", {}).get("phase", {})))
        )
        decode = DecodeSettings()
        gray = data.get("decode_settings", {})
        geometry = GeometrySettings(**data.get("geometry", {}))
        self.restoring = True
        try:
            self.reference, self.mask = recipe, recipe.mask
            self.source_frame.clear()
            names = data.get("reference_import", {}).get("source_names", [])
            self.source_frame.addItems(
                [
                    row["id"] + (" / " + names[i] if i < len(names) else "")
                    for i, row in enumerate(data["frames"])
                ]
            )
            self.source_frame.setCurrentIndex(0 if phase_only else 1)
            values = dict(
                exposure=data["exposure_s"],
                amplitude=phase.minimum_amplitude,
                rms=phase.maximum_relative_rms,
                illumination=gray.get("minimum_illumination", decode.minimum_illumination),
                gray=gray.get("minimum_gray_contrast", decode.minimum_gray_contrast),
                disagreement=gray.get("maximum_gray_phase_error_px", 0.75),
                angle=geometry.minimum_ray_angle_deg,
                gap=geometry.maximum_ray_gap_m,
                reprojection=geometry.maximum_reprojection_px,
                near=geometry.minimum_depth_m,
                far=geometry.maximum_depth_m,
            )
            for key, value in values.items():
                self.fields[key].setText(repr(float(value)))
            self.fields["angles"].setText(
                ", ".join(repr(float(v)) for v in (data.get("phase_angles") or []))
            )
            self.fields["angles"].setEnabled(phase_only)
            for key in ("gray", "illumination", "disagreement"):
                self.fields[key].setEnabled(not phase_only)
            for key in ("angle", "gap", "reprojection", "near", "far"):
                self.fields[key].setEnabled(bool(data.get("calibration")))
            self.calibration.restore(data.get("calibration"))
            scope = (
                "PHASE ONLY · no XYZ"
                if phase_only
                else (
                    "Known calibrated camera/projector · meters"
                    if data.get("calibration")
                    else "Decoded correspondence only · no metric calibration"
                )
            )
            self.identity.setText(
                f"Retained {recipe.reference.shape[0]} observations · "
                f"{recipe.reference.shape[2]} × {recipe.reference.shape[1]}\n"
                f"{data['capture_id']} / {data['pixel_grid']}\n{scope}"
            )
        finally:
            self.restoring = False
        self.invalidate()
        self.show_source()
        self.status.setText("Saved source images, sequence and known calibration restored.")
        if preview:
            self.preview_reference()

    def invalidate(self, *_):
        if self.restoring or self.closed:
            return
        self.revision += 1
        self.candidate = self.reference_result = self.last_result = None
        self.audit_result = None
        for viewer in self.cloud_windows:
            viewer.close()
        self.cloud_windows.clear()
        if self.pending:
            self.pending[1].set()
            self.pending[0].cancel()
        for view in self.views.values():
            view.image_item.setPixmap(QPixmap())
        self.health.setText("Draft changed. Preview the reference again before Stage.")
        self.refresh()

    def show_source(self, *_):
        if self.reference is None or self.restoring:
            return
        index = max(0, self.source_frame.currentIndex())
        source = self.reference.reference[index]
        if self.sequence_table.currentRow() != index and index < self.sequence_table.rowCount():
            self.sequence_table.setCurrentCell(index, 0)
        gray = np.rint(np.clip(np.nan_to_num(source), 0, 1) * 255).astype(np.uint8)
        rgb = np.repeat(gray[:, :, None], 3, axis=2)
        if self.source_flags.isChecked():
            finite = np.isfinite(source)
            ceiling = input_ceiling(self.reference.definition)
            missing, clipped = ~finite, finite & (source >= ceiling)
            if self.mask is not None:
                missing &= self.mask
                clipped &= self.mask
            rgb[missing] = (235, 45, 215)
            rgb[clipped] = (245, 55, 55)
        if self.mask is not None:
            contours, _ = cv2.findContours(
                self.mask.astype(np.uint8), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE
            )
            cv2.drawContours(rgb, contours, -1, (30, 210, 230), 1)
        self.editor.set_image(pixmap(ImageArray(rgb, "rgb")))
        self.editor.set_roi(rectangle(self.mask, rgb.shape))

    def select_frame(self, row, *_):
        if 0 <= row < self.source_frame.count():
            self.source_frame.setCurrentIndex(row)

    def update_sequence(self, rows):
        if rows == self.sequence_display:
            return
        self.sequence_display = rows
        self.sequence_table.blockSignals(True)
        self.sequence_table.setRowCount(len(rows))
        for index, row in enumerate(rows):
            shift = row["phase_shift_rad"]
            values = (
                row["id"],
                row["role"],
                "—" if shift is None else f"{shift:.6g}",
                *(str(row.get(key, "—")) for key in ("available", "nonfinite", "ceiling")),
            )
            for column, value in enumerate(values):
                item = QTableWidgetItem(value)
                if row["source_name"]:
                    item.setToolTip(row["source_name"])
                self.sequence_table.setItem(index, column, item)
        if rows:
            self.sequence_table.setCurrentCell(max(0, self.source_frame.currentIndex()), 0)
            self.sequence_table.resizeColumnsToContents()
        self.sequence_table.blockSignals(False)

    def import_reference(self):
        path = self.choose("Ordered fringe reference", "Fringe captures (*.json)")
        if path:
            self.restore(import_capture(path))

    def import_recipe(self):
        path = self.choose("Retained fringe setup", "Fringe recipes (*.sfs)")
        if path:
            self.restore(load_recipe(path), preview=True)

    def connected(self):
        self.context.refresh_images()
        bundle = self.context.snapshot_connected_inputs(["capture"])
        if "capture" not in bundle.inputs:
            raise ValueError("Connect an ordered fringe capture stack first")
        return bundle.inputs["capture"].value, self.context.output_revision, bundle.snapshot_id

    def capture_reference(self):
        capture, _, identity = self.connected()
        recipe = retain_capture(capture)
        data = recipe.definition
        data["editor_snapshot"] = dict(
            id=identity, scope="Copy provenance, not physical synchronization"
        )
        self.restore(FringeRecipe(data, recipe.reference, recipe.mask))

    def region_mode(self, mode):
        self.editor.mode = mode
        self.tabs.setCurrentIndex(0)

    def set_region(self, roi):
        if self.reference is None:
            raise ValueError("Import or capture a reference first")
        x, y, width, height = roi
        h, w = self.reference.reference.shape[1:]
        if (
            any(type(v) is not int for v in roi)
            or min(x, y) < 0
            or min(width, height) < 1
            or (x + width > w or y + height > h)
        ):
            raise ValueError("Keep a positive inspection rectangle inside original source pixels")
        mask = np.zeros((h, w), bool)
        mask[y : y + height, x : x + width] = True
        self.set_mask(mask)

    def set_mask(self, mask):
        if self.reference is None:
            raise ValueError("Import or capture a reference first")
        self.mask = source_mask(mask, self.reference.reference.shape[1:], nonempty=True)
        self.invalidate()
        self.show_source()

    def import_mask(self):
        from .cli import load_plane

        path = self.choose("Source inspection mask", "Masks (*.png *.tif *.tiff *.npy)")
        if path:
            self.set_mask(load_plane(path, "gray"))

    def set_calibration(self, record):
        if self.reference is None:
            raise ValueError("Import or capture a reference first")
        data = self.reference.definition
        data["calibration"] = record
        validate_setup(data, self.reference.reference.shape)
        self.restoring = True
        try:
            self.calibration.restore(record)
        finally:
            self.restoring = False
        self.invalidate()
        for key in ("angle", "gap", "reprojection", "near", "far"):
            self.fields[key].setEnabled(bool(record))
        self.tabs.setCurrentIndex(self.tabs.count() - 1)

    def import_calibration(self):
        path = self.choose("Known camera/projector calibration", "Calibration (*.json)")
        if path:
            if path.stat().st_size > 1024 * 1024:
                raise ValueError("Calibration exceeds 1 MiB")
            record = strict_json(path.read_bytes())
            if record.get("schema") != "simple_fringe_calibration/v1":
                raise ValueError("Import a simple_fringe_calibration/v1 known calibration")
            if record.get("units", "m") != "m":
                raise ValueError("Import known calibration with translation in meters")
            self.set_calibration(
                {
                    key: record[key]
                    for key in ("camera", "projector", "rotation_cp", "translation_cp_m")
                }
            )

    def draft_definition(self):
        if self.reference is None:
            raise ValueError("Import or capture a reference first")
        data = self.reference.definition

        def number(key):
            try:
                return float(self.fields[key].text())
            except ValueError as error:
                label = self.fields[key].property("field_label")
                raise ValueError(f"Enter a number for {label}") from error

        data["exposure_s"] = number("exposure")
        phase_only = data["schema"] == "simple_fringe_phase/v1"
        if phase_only:
            data["phase_angles"] = [
                float(v.strip()) for v in self.fields["angles"].text().split(",")
            ]
            phase = data.setdefault("phase_settings", {})
        else:
            decode = data.setdefault("decode_settings", {})
            decode.update(
                minimum_illumination=number("illumination"),
                minimum_gray_contrast=number("gray"),
                maximum_gray_phase_error_px=number("disagreement"),
            )
            phase = decode.setdefault("phase", {})
        phase.update(minimum_amplitude=number("amplitude"), maximum_relative_rms=number("rms"))
        data["calibration"] = self.calibration.record()
        if data["calibration"] is not None:
            data.setdefault("geometry", {}).update(
                minimum_ray_angle_deg=number("angle"),
                maximum_ray_gap_m=number("gap"),
                maximum_reprojection_px=number("reprojection"),
                minimum_depth_m=number("near"),
                maximum_depth_m=number("far"),
            )
        return data, validate_setup(data, self.reference.reference.shape)

    def build_candidate(self):
        data, _ = self.draft_definition()
        return FringeRecipe(data, self.reference.reference, self.mask)

    def start_audit(self):
        data, _ = self.draft_definition()
        images, mask = self.reference.reference, self.mask
        self.submit(
            lambda cancelled: source_audit(data, images, mask, cancelled=cancelled),
            self.show_audit,
        )

    def show_audit(self, report):
        self.audit_result = report
        self.status.setText("Source audit complete. Select a pattern to inspect its pixels.")

    def submit(self, function, callback, *, publication=None):
        if self.closed:
            raise ValueError("This setup editor has closed")
        if self.pending:
            self.pending[1].set()
            self.pending[0].cancel()
        cancellation = Event()
        self.pending = (
            self.pool.submit(function, cancellation.is_set),
            cancellation,
            self.revision,
            callback,
            publication,
        )
        self.timer.start()
        self.status.setText("Computing a frozen reference/preview…")
        self.refresh()

    def preview_reference(self):
        data, _ = self.draft_definition()
        images, mask = self.reference.reference, self.mask

        def run(cancelled):
            if cancelled():
                raise RuntimeError("Reference preview cancelled")
            recipe = FringeRecipe(data, images, mask)
            return recipe, execute(recipe, cancelled=cancelled)

        def completed(value):
            self.candidate, self.reference_result = value
            self.show_result(self.reference_result, "Reference preview")

        self.submit(run, completed)

    def preview_capture(self, capture, *, title="Independent capture", publication=None):
        if self.candidate is None:
            raise ValueError("Preview the current reference before testing another capture")
        recipe = self.candidate
        self.submit(
            lambda cancelled: execute(recipe, capture, cancelled=cancelled),
            lambda output: self.show_result(output, title),
            publication=publication,
        )

    def preview_file(self):
        path = self.choose("Independent fringe test capture", "Fringe captures (*.json)")
        if path:
            self.preview_capture(capture_from_recipe(import_capture(path)), title=path.name)

    def preview_connected(self):
        capture, revision, _ = self.connected()
        self.preview_capture(capture, title="Connected preview", publication=revision)

    def poll(self):
        if self.pending is None or not self.pending[0].done() or self.closed:
            return
        future, cancellation, revision, callback, publication = self.pending
        self.pending = None
        self.timer.stop()
        try:
            output = future.result()
            if (
                not cancellation.is_set()
                and revision == self.revision
                and (publication is None or publication == self.context.output_revision)
            ):
                callback(output)
            else:
                self.status.setText("Discarded stale work; preview the current draft or capture.")
        except Exception as error:
            self.status.setText(str(error))
        self.refresh()

    def show_result(self, output, title):
        for viewer in self.cloud_windows:
            viewer.close()
        self.cloud_windows.clear()
        self.last_result = output
        for name, view in self.views.items():
            if name in output["views"]:
                view.set_image(pixmap(ImageArray(output["views"][name], "rgb")))
            else:
                view.image_item.setPixmap(QPixmap())
        report = output["report"]
        self.health.setText(
            f"{title}: {report['valid_pixels']}/{report['active_pixels']} accepted pixels\n"
            f"Coverage {report['coverage']:.1%} (availability, not accuracy)\n"
            + ("Calibrated XYZ in camera meters\n" if report["metric"] else "NO METRIC XYZ\n")
            + "Decode/phase: "
            + str(report["reason_counts"])
            + (
                "\nGeometry: " + str(report["geometry"]["reason_counts"])
                if report["metric"]
                else ""
            )
        )
        self.status.setText(
            title + ": review source, phase, modulation, rejected areas and ray fit."
        )
        self.tabs.setCurrentIndex(1)

    def open_cloud(self):
        if self.last_result is None:
            raise ValueError("Preview a calibrated capture first")
        cloud = result_cloud(self.last_result, gap_limit=float(self.fields["gap"].text()))
        if cloud is NO_VALUE:
            raise ValueError(
                "No accepted metric XYZ; phase-only or unavailable results have no cloud"
            )
        viewer = CloudViewer(None, self)
        viewer.set_cloud(cloud)
        viewer.flyaround.setChecked(True)
        self.cloud_windows.append(viewer)
        viewer.show()

    def stage(self):
        if (
            self.pending
            or self.candidate is None
            or self.reference_result is None
            or not (self.reference_result["report"]["valid_pixels"])
        ):
            raise ValueError("Preview the current reference with accepted samples before Stage")
        relative = f"assets/fringe_scan/{uuid.uuid4().hex}.sfs"
        path = recipe_path(self.context.project_dir, relative)
        path.parent.mkdir(parents=True, exist_ok=True)
        data = self.candidate.definition
        data["reference_fit"] = self.reference_result["report"]
        digest = save_recipe(
            path, FringeRecipe(data, self.candidate.reference, self.candidate.mask)
        )
        self.parameters.update(recipe_path=relative, sha256=digest)
        self.accept()

    def refresh(self):
        busy = self.pending is not None
        valid = self.guide()
        self.audit_button.setEnabled(valid and not busy)
        self.preview_button.setEnabled(valid and not busy)
        ready = valid and self.candidate is not None and not busy
        self.test_button.setEnabled(ready)
        self.wire_button.setEnabled(ready)
        self.stage_button.setEnabled(
            ready
            and self.context.project_dir is not None
            and self.reference_result is not None
            and self.reference_result["report"]["valid_pixels"] > 0
        )
        self.cloud_button.setEnabled(
            self.last_result is not None
            and self.last_result["report"]["metric"]
            and self.last_result["report"]["valid_pixels"] > 0
        )

    def guide(self):
        if self.reference is None:
            self.guidance.setText("Import or capture an ordered reference sequence.")
            return False
        report = self.reference_result["report"] if self.reference_result else None
        self.reference_health.setText(
            "Reference fit pending. Preview the current draft."
            if report is None
            else (
                f"Reference fit: {report['valid_pixels']:,}/{report['active_pixels']:,} "
                f"{'metric' if report['metric'] else 'decoded'} pixels accepted."
            )
        )
        try:
            data, setup = self.draft_definition()
        except (ValueError, TypeError) as error:
            self.setup_status.setText(f"Invalid setup: {error}")
            self.guidance.setText("Correct the setup before auditing or previewing.")
            self.audit_health.setText("Source audit pending.")
            self.update_sequence(frame_rows(self.reference.definition))
            return False
        self.setup_status.setText(
            setup_summary(setup)
            + f"\nLinear source · {data['exposure_s']:g} s declared common exposure."
        )
        audit = self.audit_result
        self.update_sequence(audit["frames"] if audit else frame_rows(data, setup))
        self.audit_health.setText(
            (
                f"{audit['complete_pixels']:,}/{audit['active_pixels']:,} selected pixels have "
                "every observation available. Preview to assess decoding and geometry."
            )
            if audit
            else "Audit the sequence to count unavailable observations by frame."
        )
        if self.pending:
            guidance = "Checking a frozen draft. Edits discard pending results."
        elif report is None:
            guidance = "Review pattern order and calibration, then preview the reference."
        elif report["valid_pixels"] == 0:
            guidance = (
                "The reference has no accepted pixels. Inspect availability and rejection reasons."
            )
        elif self.context.project_dir is None:
            guidance = "Save the project before staging this reference."
        else:
            guidance = "Preview another capture, then Stage and Apply configuration."
        self.guidance.setText(guidance)
        return True

    def outputs_changed(self, *_):
        if not self.pending:
            self.status.setText(
                "New outputs available. Capture explicitly; the reference stays frozen."
            )

    def shutdown(self):
        if not self.closed:
            self.closed = True
            self.timer.stop()
            if self.pending:
                self.pending[1].set()
                self.pending[0].cancel()
            self.pool.shutdown(wait=False, cancel_futures=True)
            if self.unsubscribe:
                self.unsubscribe()
                self.unsubscribe = None
            for viewer in self.cloud_windows:
                viewer.close()

    def done(self, result):
        self.shutdown()
        super().done(result)
