"""Source-sequence teaching diagnostics that do not decode or triangulate."""

import numpy as np

from .model import ScanDefinition
from .phase import PhaseSettings


def validate_setup(data, shape):
    seconds = data["exposure_s"]
    if not np.isfinite(seconds) or not 0 < seconds <= 3600:
        raise ValueError("Declare one common positive exposure in seconds (up to 3600)")
    setup = ScanDefinition(data, shape)
    ids = tuple(row["id"] for row in data["frames"])
    expected = (
        setup.plan.pattern_ids if setup.plan else tuple(f"phase:{i}" for i in range(shape[0]))
    )
    if ids != expected:
        raise ValueError("Observed frame IDs/order must match the complete declared sequence")
    if setup.plan is None and data.get("calibration") is not None:
        raise ValueError("Phase-only setup has no camera/projector calibration")
    return setup


def frame_rows(data, setup=None):
    names = data.get("reference_import", {}).get("source_names", ())
    angles = data.get("phase_angles") or []
    if setup is not None:
        angles = setup.basis.angles
    rows = []
    for index, row in enumerate(data["frames"]):
        name = row["id"]
        parts = name.split(":")
        shift = None
        if name == "black":
            role = "Dark reference"
        elif name == "white":
            role = "Illuminated reference"
        elif parts[0] == "gray":
            _, axis, bit, polarity = parts
            role = f"Gray {axis.upper()} bit {bit} ({polarity})"
        elif len(parts) == 3:
            _, axis, step = parts
            role = f"Phase {axis.upper()} step {int(step) + 1}"
            if len(angles):
                shift = float(angles[int(step)])
        else:
            role = f"Phase step {index + 1}"
            if index < len(angles):
                shift = float(angles[index])
        rows.append(
            {
                "id": name,
                "role": role,
                "phase_shift_rad": shift,
                "source_name": names[index] if index < len(names) else "",
            }
        )
    return rows


def input_ceiling(data):
    options = (
        data.get("phase_settings", {})
        if data["schema"] == "simple_fringe_phase/v1"
        else data.get("decode_settings", {}).get("phase", {})
    )
    return PhaseSettings(**options).input_ceiling


def source_audit(data, reference, mask, *, cancelled):
    """Apply the decoder's input-availability rules, one observation at a time."""
    setup = validate_setup(data, reference.shape)
    rows = frame_rows(data, setup)
    all_available = np.ones(reference.shape[1:], bool) if mask is None else mask.copy()
    active = int(np.count_nonzero(all_available))
    ceiling = input_ceiling(data)
    for row, image in zip(rows, reference):
        if cancelled():
            raise RuntimeError("Source audit cancelled")
        finite = np.isfinite(image)
        clipped = finite & (image >= ceiling)
        missing = ~finite
        if mask is not None:
            clipped &= mask
            missing &= mask
        nonfinite, clipped_count = int(missing.sum()), int(clipped.sum())
        all_available &= ~(clipped | missing)
        row.update(
            available=active - nonfinite - clipped_count, nonfinite=nonfinite, ceiling=clipped_count
        )
    return {
        "capture_id": data["capture_id"],
        "input_ceiling": ceiling,
        "active_pixels": active,
        "complete_pixels": int(all_available.sum()),
        "frames": rows,
    }


def setup_summary(setup):
    if setup.plan is None:
        return (
            f"Phase only · {len(setup.basis.angles)} observed shifts in radians. "
            "Result is wrapped phase. Metric XYZ is unavailable."
        )
    width, height = setup.plan.projector_size
    x_period, y_period = setup.plan.period_px
    code = (
        f"Gray + phase · {width} × {height} projector pixels · "
        f"X/Y periods {x_period:g}/{y_period:g} px\n"
        f"Dark, illuminated, {len(setup.plan.gray_ids) // 2} Gray pairs, "
        f"then {setup.plan.phase_steps} phase steps per axis."
    )
    rig = setup.calibration
    if rig is None:
        return code + "\nProjector correspondence only. Import known calibration for metric XYZ."
    gap = setup.geometry
    return (
        code + f"\n{rig.camera.frame} → {rig.projector.frame} · "
        f"baseline {np.linalg.norm(rig.translation_cp_m):.6g} m\n"
        "Projector XYZ = R × camera XYZ + t. XYZ output is in camera meters.\n"
        f"Axial Z range {gap.minimum_depth_m:g}–{gap.maximum_depth_m:g} m · "
        f"ray gap ≤ {gap.maximum_ray_gap_m:g} m"
    )
