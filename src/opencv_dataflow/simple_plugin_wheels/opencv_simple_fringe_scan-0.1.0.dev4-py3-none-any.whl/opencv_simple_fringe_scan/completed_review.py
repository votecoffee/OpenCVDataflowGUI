"""Frozen completed pattern/correspondence/XYZ evidence; never a second reconstruction."""

import copy
import hashlib
import json
from dataclasses import asdict, dataclass, field, is_dataclass
from functools import cached_property
from pathlib import Path
from uuid import uuid4

import cv2
import numpy as np
from opencv_dataflow.payloads import NO_VALUE
from opencv_dataflow.pointclouds import PointCloud

from .decode import REASONS
from .geometry import GEOMETRY_REASONS
from .phase import PHASE_REASONS
from .render import COLORS, panel, scalar

BINDING = "fringe_completed_review"
CAPTURE_FIELDS = (
    "schema",
    "images",
    "mask",
    "frame_ids",
    "capture_id",
    "pixel_grid",
    "response",
    "exposure_s",
    "sequence",
    "calibration",
    "metadata",
)


def json_bytes(value):
    return json.dumps(value, sort_keys=True, allow_nan=False).encode("utf-8")


def freeze(value, memo=None):
    """Copy only on explicit review capture; immutable array backing survives graph close."""
    memo = {} if memo is None else memo
    if id(value) in memo:
        return memo[id(value)]
    if isinstance(value, np.ndarray):
        result = np.frombuffer(value.tobytes(), dtype=value.dtype).reshape(value.shape)
    elif is_dataclass(value):
        result = object.__new__(type(value))
        memo[id(value)] = result
        for name, item in vars(value).items():
            object.__setattr__(result, name, freeze(item, memo))
    elif isinstance(value, dict):
        result = {key: freeze(item, memo) for key, item in value.items()}
    elif isinstance(value, (list, tuple)):
        result = type(value)(freeze(item, memo) for item in value)
    else:
        result = copy.deepcopy(value)
    memo[id(value)] = result
    return result


def same(left, right):
    if isinstance(left, np.ndarray):
        return (
            isinstance(right, np.ndarray)
            and left.shape == right.shape
            and left.dtype == right.dtype
            and left.tobytes() == right.tobytes()
        )
    if is_dataclass(left):
        return type(left) is type(right) and same(vars(left), vars(right))
    if isinstance(left, dict):
        return (
            isinstance(right, dict)
            and left.keys() == right.keys()
            and all(same(value, right[key]) for key, value in left.items())
        )
    if isinstance(left, (list, tuple)):
        return (
            type(left) is type(right)
            and len(left) == len(right)
            and all(same(a, b) for a, b in zip(left, right))
        )
    return left == right


def describe(value):
    if isinstance(value, np.ndarray):
        return dict(
            shape=list(value.shape),
            dtype=value.dtype.str,
            sha256=hashlib.sha256(value.tobytes()).hexdigest(),
        )
    if isinstance(value, dict):
        return {key: describe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [describe(item) for item in value]
    return value.item() if isinstance(value, np.generic) else value


def finite(value):
    if isinstance(value, np.ndarray):
        return finite(value.tolist())
    if isinstance(value, (list, tuple)):
        return [finite(item) for item in value]
    if isinstance(value, np.generic):
        return finite(value.item())
    return None if isinstance(value, float) and not np.isfinite(value) else value


def consumed_fields(capture):
    return {name: capture.get(name) for name in CAPTURE_FIELDS}


@dataclass(frozen=True)
class CompletedFringeRecord:
    identifier: str
    report_json: bytes
    parameters_json: bytes
    scalar_json: bytes
    settings_json: bytes
    ports: tuple
    ignored_fields: tuple
    _recipe: object = field(repr=False, compare=False)
    _capture: dict = field(repr=False, compare=False)
    _output: dict = field(repr=False, compare=False)
    _outputs: dict = field(repr=False, compare=False)
    _manifest: bytes | None = field(repr=False, compare=False)

    @property
    def report(self):
        return json.loads(self.report_json)

    @property
    def parameters(self):
        return json.loads(self.parameters_json)

    def __deepcopy__(self, memo):
        return self


def retain_completed(block, recipe, model, capture, output, outputs, manifest):
    if not (block.run_profile.input_previews and block.run_profile.output_previews):
        return {}
    emitted = {name: value for name, value in outputs.items() if value is not NO_VALUE}
    record = CompletedFringeRecord(
        uuid4().hex,
        json_bytes(outputs["report"]),
        json_bytes(block.parameters),
        json_bytes(
            {
                name: value
                for name, value in emitted.items()
                if name in ("coverage", "count", "metric")
            }
        ),
        json_bytes(
            dict(
                geometry=asdict(model.geometry),
                **(
                    {"phase": asdict(model.phase)}
                    if model.plan is None
                    else {"decode": asdict(model.decode)}
                ),
            )
        ),
        tuple(emitted),
        tuple(str(name) for name in capture if name not in CAPTURE_FIELDS),
        recipe,
        consumed_fields(capture),
        output,
        emitted,
        manifest,
    )
    block._completed_review = record
    return {name: {BINDING: {"id": record.identifier}} for name in record.ports}


class CompletedFringeReview:
    plugin_review_dialog_label = "Review completed coding, phase and cloud…"

    def copy_runtime_from(self, other):
        super().copy_runtime_from(other)
        self._completed_review = other._completed_review

    def reset_runtime(self):
        super().reset_runtime()
        self._completed_review = None

    def close(self):
        self._completed_review = None
        super().close()

    def capture_completed_review(self, context):
        snapshot = getattr(context, "snapshot_processed_execution", None)
        if snapshot is None:
            raise ValueError("Completed review needs the host's paired execution-snapshot API")
        record = self._completed_review
        inputs = (
            ()
            if record is None or record.parameters["source"] == "capture manifest"
            else ("capture",)
        )
        try:
            bundle = snapshot(
                input_ports=inputs, output_ports=("report",) if record is None else record.ports
            )
        except ValueError as error:
            if (
                record is not None
                and not inputs
                and "Processed inputs are unavailable" in str(error)
            ):
                raise ValueError(
                    "Update the host for empty paired-input selections; this "
                    "completed manifest run consumed no wired inputs"
                ) from error
            raise
        return capture_completed(record, bundle)

    def create_plugin_review_dialog(self, parent, context):
        from .qt_completed_review import CompletedFringeReviewDialog

        return CompletedFringeReviewDialog(
            parent, context, lambda: self.capture_completed_review(context)
        )


@dataclass(frozen=True)
class CompletedFringeCapture:
    record: CompletedFringeRecord
    _provenance: dict = field(repr=False, compare=False)

    @property
    def provenance(self):
        return copy.deepcopy(self._provenance)

    @property
    def recipe_bytes(self):
        return self.record._recipe._source_bytes

    @property
    def shape(self):
        return self.record._capture["images"].shape[1:]

    @property
    def frame_count(self):
        return self.record._capture["images"].shape[0]

    @property
    def cloud(self):
        return self.record._outputs.get("cloud")

    @cached_property
    def _description(self):
        return describe(self.record._capture)

    @cached_property
    def _map_description(self):
        return describe(self.record._output["maps"])

    @property
    def view_names(self):
        return ("source", "reference", *self.record._output["maps"], "overview")

    def frame(self, index):
        if type(index) is not int or not 0 <= index < self.frame_count:
            raise ValueError("Choose a recorded pattern frame index")
        return index

    def pixel(self, selected):
        if (
            not isinstance(selected, tuple)
            or len(selected) != 2
            or any(type(v) is not int for v in selected)
        ):
            raise ValueError("Choose one original (x, y) camera pixel")
        x, y = selected
        if not 0 <= y < self.shape[0] or not 0 <= x < self.shape[1]:
            raise ValueError("Choose a pixel inside the recorded camera grid")
        maps = self.record._output["maps"]
        result = {name: finite(value[y, x]) for name, value in maps.items()}
        labels = PHASE_REASONS if "wrapped" in maps else REASONS
        result["reason_name"] = labels[int(maps["reason"][y, x])]
        if "geometry_reason" in maps:
            result["geometry_reason_name"] = GEOMETRY_REASONS[int(maps["geometry_reason"][y, x])]
        result.update(x=x, y=y, cloud_row=self.cloud_row(selected))
        return result

    def cloud_row(self, selected):
        if self.cloud is None:
            return None
        rows = np.flatnonzero(np.all(self.cloud.pixels == selected, axis=1))
        return int(rows[0]) if len(rows) else None

    def observations(self, selected):
        self.pixel(selected)
        x, y = selected
        capture, definition = self.record._capture, self.record._recipe.definition
        settings = json.loads(self.record.settings_json)
        phase = settings.get("phase", settings.get("decode", {}).get("phase", {}))
        ceiling = phase["input_ceiling"]
        angles = definition.get("phase_angles")
        if angles is None:
            angles = (
                2
                * np.pi
                * np.arange(definition["plan"]["phase_steps"])
                / definition["plan"]["phase_steps"]
            ).tolist()
        rows = []
        for index, identifier in enumerate(capture["frame_ids"]):
            value = float(capture["images"][index, y, x])
            phase_index = int(identifier.rsplit(":", 1)[1]) if "phase" in identifier else None
            rows.append(
                dict(
                    index=index,
                    frame_id=identifier,
                    raw_code=finite(value),
                    phase_angle_rad=None if phase_index is None else angles[phase_index],
                    nonfinite=not np.isfinite(value),
                    at_ceiling=bool(value >= ceiling),
                    scope="Recorded normalized linear code; no fit/prediction reconstructed",
                )
            )
        return rows

    def view(self, name, frame=0, component=0, selected=None):
        self.frame(frame)
        if name not in self.view_names:
            raise ValueError("Choose a recorded source or map view")
        if selected is not None:
            self.pixel(selected)
        if name == "overview":
            if "overview" in self.record._output["views"]:
                return np.array(
                    self.record._output["views"]["overview"], copy=True
                ), "Exact emitted overview"
            keys = [
                "source",
                "wrapped" if "wrapped" in self.view_names else "wrapped_phase",
                "reason",
            ]
            return np.hstack(
                [
                    panel(self.view(key, frame, 0)[0], key, "Frozen maps; display coordinates only")
                    for key in keys
                ]
            ), "Review-only panels"
        if name in ("source", "reference"):
            value = (
                self.record._capture["images"]
                if name == "source"
                else self.record._recipe.reference
            )[frame]
            gray = np.rint(np.clip(np.nan_to_num(value, nan=0), 0, 1) * 255).astype(np.uint8)
            image = np.repeat(gray[:, :, None], 3, axis=2)
            image[~np.isfinite(value)] = (75, 35, 85)
            note = "Consumed inspection" if name == "source" else "Executed training reference"
            note += " normalized linear code, display 0..1; purple nonfinite"
            if name == "source":
                active = (self.record._output["maps"]["reason"] != 1).astype(np.uint8)
                contours, _ = cv2.findContours(active, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
                cv2.drawContours(image, contours, -1, (30, 210, 230), 1)
                note += "; cyan effective ROI"
        else:
            value = self.record._output["maps"][name]
            if value.ndim == 3:
                if type(component) is not int or not 0 <= component < value.shape[2]:
                    raise ValueError("Choose a stored map component")
                value = value[:, :, component]
            if name in ("reason", "geometry_reason"):
                image = COLORS[value]
                note = (
                    "Stored "
                    + ("triangulation" if name.startswith("geometry") else "decode/phase")
                    + " reason; categorical"
                )
            elif name in ("valid", "geometry_valid"):
                image = np.full((*self.shape, 3), (75, 35, 85), np.uint8)
                image[value] = (40, 205, 95)
                note = "Stored availability: green valid / purple unavailable; not accuracy"
            else:
                fixed = (
                    2 * np.pi
                    if name in ("wrapped", "wrapped_phase")
                    else 0.5
                    if name == "amplitude"
                    else 0.3
                    if name == "relative_rms"
                    else 1
                    if name == "minimum_gray_contrast"
                    else None
                )
                finite_values = value[np.isfinite(value)]
                maximum = fixed or (float(np.max(finite_values)) if len(finite_values) else 1)
                maximum = max(maximum, 1e-12)
                minimum = min(0.0, float(np.min(finite_values))) if len(finite_values) else 0.0
                if minimum < 0:
                    image = scalar(value - minimum, maximum - minimum)
                else:
                    image = scalar(value, maximum, cyclic=name in ("wrapped", "wrapped_phase"))
                units = (
                    "m"
                    if name in ("geometry_xyz_m", "geometry_ray_gap_m")
                    else "rad"
                    if name in ("wrapped", "wrapped_phase")
                    else "degrees"
                    if name == "geometry_ray_angle_deg"
                    else "pixels"
                    if any(key in name for key in ("pixels", "error", "coarse"))
                    else "normalized / relative"
                )
                note = (
                    f"Stored {name}[{component}], {units}; "
                    f"display {minimum:.6g}..{maximum:.6g}; purple nonfinite"
                )
                if name == "coarse_pixels":
                    note += "; raw diagnostic code may exist at rejected pixels"
        image = np.array(image, copy=True)
        if selected is not None:
            cv2.drawMarker(image, selected, (250, 220, 40), cv2.MARKER_CROSS, 13, 1)
        return image, note

    def chart(self, selected):
        rows = self.observations(selected)
        image = np.full((360, 1100, 3), 245, np.uint8)
        for row in rows:
            x = round(45 + (row["index"] + 0.5) * 1010 / len(rows))
            value = row["raw_code"]
            color = (
                (150, 50, 180)
                if row["nonfinite"]
                else (240, 140, 25)
                if row["at_ceiling"]
                else (40, 140, 200)
            )
            if value is None:
                cv2.drawMarker(image, (x, 285), color, cv2.MARKER_TILTED_CROSS, 8, 1)
            else:
                cv2.line(image, (x, 285), (x, round(285 - 220 * value)), color, 3)
            cv2.putText(
                image,
                str(row["index"]),
                (x - 5, 306),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.3,
                (25, 25, 25),
                1,
            )
        cv2.putText(
            image,
            "Recorded pattern codes at selected camera pixel; fixed display 0..1",
            (12, 28),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (25, 25, 25),
            1,
            cv2.LINE_AA,
        )
        cv2.putText(
            image,
            "Blue source / orange ceiling / purple nonfinite. No decoding, fit or prediction.",
            (12, 342),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.46,
            (25, 25, 25),
            1,
            cv2.LINE_AA,
        )
        return image

    def display_cloud(self, selected=None):
        if self.cloud is None:
            return None
        original = self.cloud
        colors = (
            np.array(original.colors, copy=True)
            if original.colors is not None
            else np.full(original.points.shape, (40, 205, 95), np.uint8)
        )
        if selected is not None:
            row = self.cloud_row(selected)
            if row is not None:
                colors[row] = (255, 220, 20)
        return PointCloud(
            original.points.copy(),
            original.units,
            original.frame,
            colors=colors,
            pixels=original.pixels.copy(),
            source_size=original.source_size,
            metadata={
                "review_display": {
                    "selected_pixel": list(selected) if selected else None,
                    "source": "Exact emitted accepted rows; colors are display only",
                }
            },
        )

    def rig_segments(self, selected):
        """View-only declarations and stored accepted XYZ, never new rays/intersections."""
        rig = self.record._recipe.definition.get("calibration")
        if rig is None:
            return []
        origin = np.zeros(3)
        projector = -np.asarray(rig["rotation_cp"]).T @ np.asarray(rig["translation_cp_m"])
        result = [(origin, projector, (80, 180, 255), "Declared camera-projector baseline")]
        if selected is not None:
            pixel = self.pixel(selected)
            if pixel.get("geometry_valid"):
                point = pixel["geometry_xyz_m"]
                result.extend(
                    (
                        (origin, point, (80, 180, 255), "Derived camera sightline"),
                        (projector, point, (255, 160, 60), "Derived projector sightline"),
                    )
                )
        return result

    def selection_segments(self, selected):
        if selected is None or self.cloud is None:
            return []
        row = self.cloud_row(selected)
        if row is None:
            return []
        center = self.cloud.points[row].astype(float)
        size = max(float(np.max(np.ptp(self.cloud.points, axis=0))) * 0.015, 1e-6)
        return [
            (center - axis * size, center + axis * size, (255, 220, 20), "Selected accepted row")
            for axis in np.eye(3)
        ]

    def report(self, selected=None, frame=0, view="reason", component=0):
        self.frame(frame)
        return dict(
            schema="simple_fringe_completed_review/v1",
            execution_binding=self.record.identifier,
            completed_result=self.record.report,
            executed_parameters=self.record.parameters,
            executed_definition=self.record._recipe.definition,
            effective_settings=json.loads(self.record.settings_json),
            consumed_capture=copy.deepcopy(self._description),
            ignored_capture_fields=list(self.record.ignored_fields),
            selected_pixel=None if selected is None else self.pixel(selected),
            selected_observations=[] if selected is None else self.observations(selected),
            selected_frame=frame,
            selected_view=view,
            selected_component=component,
            provenance=self.provenance,
            emitted_cloud=self.cloud is not None,
            emitted_views=list(self.record._output["views"]),
            map_arrays=copy.deepcopy(self._map_description),
            manifest_sha256=None
            if self.record._manifest is None
            else hashlib.sha256(self.record._manifest).hexdigest(),
            geometry_scope=(
                "Accepted known-calibration reconstruction, not measured XYZ; "
                "native cloud is float32; raw maps retain precision. No gap filling."
            ),
            display_geometry_scope=(
                "Camera/projector origins and sightlines derive from the "
                "declared rig and stored accepted XYZ; never source cloud rows."
            ),
            source_scope=(
                "Actual normalized consumed native arrays; original encoded "
                "camera image bytes unavailable"
            ),
            identity_scope=(
                "Caller capture/grid/radiometry/calibration/tickets do not establish "
                "synchrony, registration, absolute coding truth or physical accuracy"
            ),
            diagnostic_scope=(
                "Stored diagnostics only; no per-frame fitted prediction or residual"
            ),
            decoding_reexecuted=False,
            unwrapping_reexecuted=False,
            triangulation_reexecuted=False,
            calibration_changed=False,
            capture_reloaded=False,
            recipe_reloaded=False,
            training_changed=False,
        )

    def export(self, directory, selected=None, frame=0, view="reason", component=0):
        document = self.report(selected, frame, view, component)
        chosen, note = self.view(view, frame, component, selected)
        if self.recipe_bytes is None:
            raise ValueError("Original executed recipe bytes are unavailable")
        target = Path(directory)
        target.mkdir(parents=True, exist_ok=False)
        (target / "executed_recipe.sfs").write_bytes(self.recipe_bytes)
        document["exported_recipe_sha256"] = hashlib.sha256(self.recipe_bytes).hexdigest()
        if self.record._manifest is not None:
            (target / "consumed_manifest.json").write_bytes(self.record._manifest)
        declarations = []

        def native(value):
            if isinstance(value, np.ndarray):
                name = f"capture_array_{len(declarations):03d}.npy"
                np.save(target / name, value, allow_pickle=False)
                declarations.append(name)
                return dict(array_file=name, **describe(value))
            if isinstance(value, dict):
                return {key: native(item) for key, item in value.items()}
            if isinstance(value, (list, tuple)):
                return [native(item) for item in value]
            return describe(value)

        capture_document = native(self.record._capture)
        (target / "capture_data.json").write_bytes(
            json.dumps(capture_document, indent=2, allow_nan=False).encode() + b"\n"
        )
        for name, value in self.record._output["maps"].items():
            np.save(target / f"map_{name}.npy", value, allow_pickle=False)
        for name, value in self.record._output["views"].items():
            np.save(target / f"emitted_{name}.npy", value, allow_pickle=False)
        images = dict(
            source=self.view("source", frame, selected=selected)[0],
            reference=self.view("reference", frame, selected=selected)[0],
            selected_view=chosen,
            overview=self.view("overview", frame)[0],
        )
        if selected is not None:
            images["observations"] = self.chart(selected)
        if self.cloud is not None:
            from opencv_dataflow.cloud_io import write_cloud
            from opencv_dataflow.pointclouds import render_cloud

            write_cloud(target / "emitted_cloud.ply", self.cloud, binary=True)
            for name in ("points", "colors", "pixels"):
                value = getattr(self.cloud, name)
                if value is not None:
                    np.save(target / f"emitted_cloud_{name}.npy", value, allow_pickle=False)
            images["cloud_projection"] = render_cloud(
                self.display_cloud(selected), width=920, height=640, yaw=25, pitch=-20
            )
        reason_name = "geometry_reason" if self.record.report["metric"] else "reason"
        assessment = np.hstack(
            (
                panel(images["source"], "Consumed pattern", "Source grid / cyan effective ROI"),
                panel(chosen, view, note),
                panel(
                    self.view(reason_name)[0],
                    "Recorded rejection",
                    "No new coding or reconstruction",
                ),
            )
        )
        banner = np.full((54, assessment.shape[1], 3), 28, np.uint8)
        report = self.record.report
        title = (
            f"Completed fringe scan | {report['capture_id']} | "
            f"{report['coverage']:.1%} available | frame {frame} | pixel {selected}"
        )
        for y, text in (
            (23, title),
            (
                45,
                "Known-calibration reconstruction"
                if report["metric"]
                else "PHASE/CORRESPONDENCE ONLY - no metric cloud",
            ),
        ):
            cv2.putText(
                banner,
                text.encode("ascii", errors="replace").decode()[:170],
                (10, y),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.46,
                (235, 235, 235),
                1,
                cv2.LINE_AA,
            )
        labels = (
            GEOMETRY_REASONS
            if report["metric"]
            else PHASE_REASONS
            if "wrapped" in self.view_names
            else REASONS
        )
        legend = np.full((48, assessment.shape[1], 3), 28, np.uint8)
        for i, label in enumerate(labels):
            x, y = 10 + (i % 5) * 275, 5 + (i // 5) * 22
            cv2.rectangle(legend, (x, y), (x + 10, y + 11), COLORS[i].tolist(), -1)
            cv2.putText(
                legend,
                label.replace("_", " "),
                (x + 15, y + 10),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.34,
                (220, 220, 220),
                1,
            )
        images["assessment"] = np.vstack((banner, assessment, legend))
        for name, image in images.items():
            okay, png = cv2.imencode(".png", image[:, :, ::-1])
            if not okay:
                raise ValueError("Cannot encode frozen fringe review")
            (target / f"{name}.png").write_bytes(png.tobytes())
        (target / "review.json").write_bytes(
            json.dumps(document, indent=2, allow_nan=False).encode() + b"\n"
        )
        return target


def capture_completed(record, bundle):
    if record is None:
        raise ValueError("No retained completed fringe scan; execute in Debug before reviewing")
    if set(bundle.outputs) != set(record.ports) or any(
        bundle.outputs[name].payload.get(BINDING, {}).get("id") != record.identifier
        for name in record.ports
    ):
        raise ValueError("Completed capture/model/result changed; capture latest explicitly")
    if json_bytes(bundle.outputs["report"].value) != record.report_json:
        raise ValueError("Completed report changed")
    scalars = {name: bundle.outputs[name].value for name in ("coverage", "count", "metric")}
    if json_bytes(scalars) != record.scalar_json:
        raise ValueError("Completed coverage/count/metric changed")
    for name in ("image", "maps", "overview", "cloud"):
        if name in record.ports and not same(record._outputs[name], bundle.outputs[name].value):
            raise ValueError("Completed raw map/image/cloud evidence changed")
    if record.parameters["source"] == "connected capture":
        if not same(record._capture, consumed_fields(bundle.inputs["capture"].value)):
            raise ValueError("Completed connected capture changed")
    provenance = dict(
        snapshot_id=bundle.snapshot_id,
        block_id=bundle.block_id,
        execution_count=bundle.execution_count,
        output_revision=bundle.output_revision,
        passed=bool(bundle.passed),
        score=bundle.score,
        message=bundle.message,
        inputs={name: copy.deepcopy(packet.payload) for name, packet in bundle.inputs.items()},
        outputs={name: copy.deepcopy(packet.payload) for name, packet in bundle.outputs.items()},
    )
    return CompletedFringeCapture(freeze(record), provenance)
